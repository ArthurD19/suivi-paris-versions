/* Suivi Paris : la fiche de chaque site (où sont les paris, comment arrivent les dépôts et retraits), partagée par la
   fenêtre de l'extension et le guide affiché sur le site. Mêmes textes que la fiche « Où aller sur chaque site » de
   l'appli. `ac` : par AsianConnect ; `main` : pas encore lus. [libellé, lettres du logo, couleur, paris, dépôts]. */
(() => {
  const AC = { mode: "ac", ou: "Sur <b>ac0188.com</b> : transactions, chacune dépliée" };
  const PAS_LU = { mode: "main", ou: "Pas encore lus : à ajouter dans la page Soldes de l'appli" };
  const SITES_GUIDE = {
    betclic: ["Betclic", "B", "#E4002B", "<i>Mes paris</i> → <b>En cours</b> et <b>Terminés</b>", { ou: "<i>Mon compte</i> → historique des <b>dépôts</b>, puis des <b>retraits</b>" }],
    winamax: ["Winamax", "W", "#16141F", "<i>Mes paris</i>, ou <b>Historique de compte</b>", { ou: "<i>Historique de compte</i> → <b>Dépôts</b>, puis <b>Retraits</b>" }],
    unibet: ["Unibet", "U", "#147B45", "<i>Mes paris</i> → <b>Terminés</b>", { ou: "<b>Transactions</b>, onglets <i>Compte</i> et <i>Archivé</i>" }],
    pmu: ["PMU", "P", "#00843D", "<i>Mes paris</i> → <b>Tous</b>", { ou: "<b>Mon historique de mouvements</b> → <i>Appro / Retrait</i>" }],
    bet365: ["bet365", "365", "#126E51", "<b>Historique</b> → <i>Paris terminés</i>", { ou: "<i>Historique</i> → <b>Dépôts</b>, puis <b>Retraits</b>" }],
    ps3838: ["ps3838", "PS", "#0B2D5B", "<b>Mes paris</b>, statut <i>Réglé</i>", AC],
    piwi247: ["PIWI247", "PW", "#14305E", "<b>Mes paris</b>, statut <i>Réglé</i>", AC],
    orbitx: ["OrbitX", "OX", "#7BB51E", "<i>My Bets</i> → <b>Settled</b>", AC],
    olybet: ["Olybet", "O", "#D98E04", "<b>Historique des paris</b>, puis ouvre chaque pari", PAS_LU],
    bwin: ["bwin", "bw", "#1E1E1E", "<i>Mes paris</i> → <b>Ouvert</b>, <b>Évalué</b>", PAS_LU],
    sportaza: ["Sportaza", "SZ", "#5B2BE0", "<i>Mes paris</i> → <b>Calculé</b>, <b>Ouvrir</b>", { ou: "<b>Historique des transactions</b>, filtres <i>Dépôt</i> et <i>Retraits</i>" }],
    netbet: ["NetBet", "NB", "#C8102E", "<i>Mes paris</i> → <b>Paris terminés</b>", PAS_LU],
    asianconnect: ["AsianConnect", "AC", "#1F3A8A", "—", { ou: "<b>Historique des transactions</b> : déplie chaque transaction" }],
  };
  globalThis.SUIVI_GUIDE = SITES_GUIDE;
})();
