/* Suivi Paris : la « boîte » chiffrée de la synchronisation (suivi_paris/synchro.py, mobile/mobile.js).

   Sur l'iPhone (Orion), ou quand l'appli de l'ordinateur est fermée, l'extension n'a personne à qui envoyer ce
   qu'elle lit. Avec le code de liaison (collé une fois dans sa fenêtre), elle dépose chaque page dans le gist de
   synchronisation, compressée et chiffrée (AES-256-GCM), dans le fichier « boîte ». L'appli iPhone ou l'ordinateur,
   à leur prochaine synchronisation, lisent la boîte, enregistrent les pages et la vident. GitHub ne voit rien. */
const BOITE = "suivi-paris-boite.bin";
const COMPTES_BOITE = "suivi-paris-comptes.bin";  // [{id, bookmaker, nom}], écrit par l'ordinateur et l'iPhone
// Ce que l'appli a fait de chaque page de la boîte : [{id, statut, compte, nouveaux, mis_a_jour, deja_connus, solde,
// details, le}], écrit par l'ordinateur et l'iPhone quand ils la vident ; la fenêtre de l'extension l'affiche.
const ACCUSES_BOITE = "suivi-paris-accuses.bin";
const API_GITHUB = "https://api.github.com";
// L'appli téléphone publiée (outils/mobile.py) : on y trouve aussi la dernière extension pour Orion.
const PAGES_APPLI = "https://arthurd19.github.io/suivi-paris-versions/";

const boiteBase64 = (o) => { let b = ""; for (let i = 0; i < o.length; i += 0x8000) b += String.fromCharCode(...o.subarray(i, i + 0x8000)); return btoa(b); };
const boiteOctets = (t) => Uint8Array.from(atob(t), (c) => c.charCodeAt(0));
const boiteFlux = async (o, t) => new Uint8Array(await new Response(new Blob([o]).stream().pipeThrough(t)).arrayBuffer());

/* « SP1-… » : le gist, le jeton, la clé (le code affiché par l'ordinateur, Mes données → Avec l'iPhone). */
function lireCodeLiaison(code) {
  try {
    const l = JSON.parse(atob(String(code).trim().replace(/^SP1-/, "").replace(/-/g, "+").replace(/_/g, "/")));
    return l && l.g && l.t && l.k ? { g: l.g, t: l.t, k: l.k } : null;
  } catch { return null; }
}

async function boiteCle(l) { return crypto.subtle.importKey("raw", boiteOctets(l.k), "AES-GCM", false, ["encrypt", "decrypt"]); }
async function boiteChiffrer(l, objet) {
  const nonce = crypto.getRandomValues(new Uint8Array(12));
  const clair = await boiteFlux(new TextEncoder().encode(JSON.stringify(objet)), new CompressionStream("gzip"));
  const c = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce }, await boiteCle(l), clair));
  const tout = new Uint8Array(12 + c.length); tout.set(nonce); tout.set(c, 12);
  return boiteBase64(tout);
}
async function boiteDechiffrer(l, texte) {
  const b = boiteOctets(texte.trim());
  const clair = await crypto.subtle.decrypt({ name: "AES-GCM", iv: b.subarray(0, 12) }, await boiteCle(l), b.subarray(12));
  return JSON.parse(new TextDecoder().decode(await boiteFlux(new Uint8Array(clair), new DecompressionStream("gzip"))));
}
/* GitHub limite le nombre d'écritures : après un refus (403, 429), plus aucun appel pendant 15 min, au lieu de
   réessayer chaque minute (ce qui prolonge le blocage). Ce qui attend est gardé et repart ensuite. */
const PAUSE_GITHUB = 15 * 60 * 1000;
async function finPauseGithub() {
  try { const { pause_github: p = 0 } = await chrome.storage.local.get("pause_github"); return p > Date.now() ? p : 0; } catch { return 0; }
}
const heureCourte = (t) => new Date(t).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
async function boiteGithub(l, methode, corps) {
  const pause = await finPauseGithub();
  if (pause) throw new Error(`GitHub limite les envois : pause jusqu'à ${heureCourte(pause)}`);
  const r = await fetch(`${API_GITHUB}/gists/${l.g}`, { method: methode, headers: { Authorization: `Bearer ${l.t}`,
    Accept: "application/vnd.github+json", ...(corps ? { "Content-Type": "application/json" } : {}) }, body: corps ? JSON.stringify(corps) : undefined });
  if (!r.ok) {
    // 403 : jeton sans droit, ou GitHub qui limite le nombre d'appels (passager) ; le message de GitHub le dit.
    const message = r.status === 403 ? String((await r.json().catch(() => ({}))).message || "") : "";
    if (r.status === 429 || /rate limit/i.test(message) || r.headers.get("x-ratelimit-remaining") === "0") {
      const fin = Date.now() + PAUSE_GITHUB;
      await chrome.storage.local.set({ pause_github: fin }).catch(() => {});
      throw new Error(`GitHub limite les envois : pause jusqu'à ${heureCourte(fin)}`);
    }
    throw new Error(r.status === 401 || r.status === 403 ? `GitHub ${r.status} : jeton refusé, relie à nouveau` : `GitHub ${r.status}`);
  }
  return r.json();
}
/* Les pages en attente dans la boîte : [{id, type, bookmaker, texte, url, capture_le, compte_id}]. */
async function lireBoite(l) {
  const g = await boiteGithub(l, "GET");
  const f = (g.files || {})[BOITE];
  if (!f || f.content === "vide") return [];
  const texte = f.truncated ? await (await fetch(f.raw_url)).text() : f.content;
  return boiteDechiffrer(l, texte);
}
async function ecrireBoite(l, pages) {
  await boiteGithub(l, "PATCH", { files: { [BOITE]: { content: pages.length ? await boiteChiffrer(l, pages) : "vide" } } });
}
/* Ajoute des pages (un seul solde gardé par site, le plus récent ; une page identique n'est pas doublée). */
let fileBoite = Promise.resolve();
function deposerDansBoite(l, nouvelles) {
  // Un dépôt à la fois : deux écritures du gist en même temps se perdraient (ou GitHub refuse la seconde).
  const essai = () => deposerMaintenant(l, nouvelles);
  const p = fileBoite.then(() => essai().catch(() => new Promise((ok) => setTimeout(ok, 2000)).then(essai)));
  fileBoite = p.catch(() => {});
  return p;
}
async function deposerMaintenant(l, nouvelles) {
  const meme = (a, b) => a.bookmaker === b.bookmaker && (a.type || "page") === (b.type || "page")
    && (a.type === "solde" || a.texte === b.texte);
  const pages = (await lireBoite(l)).filter((p) => !nouvelles.some((n) => meme(p, n)));
  for (const n of nouvelles) pages.push({ id: crypto.randomUUID(), ...n });
  await ecrireBoite(l, pages.slice(-60));
}
/* La liste des comptes ; null si aucun appareil ne l'a encore écrite (appli pas à jour). */
async function lireComptesBoite(l) {
  // Gardée 10 min : un appel GitHub de moins à chaque page envoyée.
  try {
    const { comptes_boite: c } = await chrome.storage.local.get("comptes_boite");
    if (c && c.g === l.g && Date.now() - c.le < 10 * 60 * 1000) return c.liste;
  } catch { /* stockage indisponible */ }
  const f = ((await boiteGithub(l, "GET")).files || {})[COMPTES_BOITE];
  const liste = !f || f.content === "vide" ? null : await boiteDechiffrer(l, f.truncated ? await (await fetch(f.raw_url)).text() : f.content);
  await chrome.storage.local.set({ comptes_boite: { g: l.g, le: Date.now(), liste } }).catch(() => {});
  return liste;
}
/* Le compte d'une page : celui choisi sur le site, sinon le seul du bookmaker. Sinon {ok: false} et pourquoi. */
function compteBoite(comptes, bookmaker, choisi) {
  if (!comptes) return { ok: true, compte: null };  // pas de liste : l'appli tranchera à la réception
  const ici = comptes.filter((c) => c.bookmaker === bookmaker);
  const c = ici.find((x) => x.id === choisi) || (ici.length === 1 ? ici[0] : null);
  return c ? { ok: true, compte: c }
    : { ok: false, statut: ici.length ? "choisir_compte" : "aucun_compte", comptes: ici.map(({ id, nom }) => ({ id, nom })) };
}
/* Ce qui part dans la boîte pour une page : le compte y est désigné par son nom (même nom sur tous les appareils). */
const pageBoite = (p, compte) => ({ id: crypto.randomUUID(), type: p.type || "page", bookmaker: p.bookmaker, texte: p.texte, url: p.url,
  capture_le: p.capture_le, lus: p.lus || 0, compte_id: compte ? compte.id : p.compte_id || null,
  compte_nom: compte ? compte.nom : p.compte_nom || null });
/* Les accusés de l'appli (voir ACCUSES_BOITE) ; [] si aucun appareil n'en a encore écrit. */
async function lireAccuses(l) {
  const f = ((await boiteGithub(l, "GET")).files || {})[ACCUSES_BOITE];
  if (!f || f.content === "vide") return [];
  return boiteDechiffrer(l, f.truncated ? await (await fetch(f.raw_url)).text() : f.content);
}
if (typeof self !== "undefined") Object.assign(self, { lireCodeLiaison, lireBoite, ecrireBoite, deposerDansBoite, lireComptesBoite, compteBoite, pageBoite, lireAccuses, BOITE });
