/* Suivi Paris : récupère toutes les pages de l'historique des paris Winamax et les télécharge dans un
   seul fichier texte, à déposer dans l'onglet Importer de l'application.

   À utiliser comme favori (bookmarklet), depuis la page Winamax « Mon compte > Historique de compte >
   Paris Sportifs », une fois connecté. Le script lit les pages une à une avec ta propre session, en
   laissant 1,5 à 3 secondes entre deux pages, exactement comme si tu cliquais sur « Suivant ».
   Il ne lit rien d'autre, ne modifie rien et n'envoie rien ailleurs : le fichier reste sur ton ordinateur.
   Attention : il n'y a pas de commentaires « // » dans ce fichier, car un favori tient sur une seule ligne. */
(async () => {
  const PAUSE_MIN = 1500, PAUSE_MAX = 3000;
  const ENTETE_PARI = /^[0-9A-Z]{6,}(?:-\d+)?\t\d{2}\/\d{2}\/\d{4}/m;

  if (!/(^|\.)winamax\.fr$/.test(location.hostname) || !location.pathname.includes("/account/history")) {
    alert("Suivi Paris : ouvre d'abord ton historique Winamax (Mon compte > Historique de compte > Paris Sportifs), puis reclique sur ce favori.");
    return;
  }
  const adresse = new URL(location.href);
  if (adresse.searchParams.get("to_display") !== "betting") {
    alert("Suivi Paris : choisis l'onglet « Paris Sportifs » de l'historique (et la période voulue), puis reclique sur ce favori.");
    return;
  }

  const numeros = [...document.querySelectorAll('a[href*="page="]')]
    .map((a) => Number(new URL(a.href, location.href).searchParams.get("page")))
    .filter((n) => Number.isFinite(n) && n > 0);
  const derniere = Math.max(1, Number(adresse.searchParams.get("page") || 1), ...numeros);
  const reponse = prompt(
    `Suivi Paris : ton historique compte ${derniere} page(s) sur la période choisie.\n` +
      `Quelles pages récupérer ? (ex. 1-${derniere}, ou 1-59)`,
    `1-${derniere}`
  );
  if (!reponse) return;
  const plage = reponse.match(/^\s*(\d+)\s*(?:-\s*(\d+))?\s*$/);
  if (!plage) {
    alert("Suivi Paris : écris les pages sous la forme 1-59.");
    return;
  }
  let de = Number(plage[1]), a = Number(plage[2] || plage[1]);
  if (de > a) [de, a] = [a, de];
  de = Math.max(1, de);
  a = Math.min(a, derniere);

  const boite = document.createElement("div");
  boite.style.cssText =
    "position:fixed;z-index:2147483647;right:20px;bottom:20px;max-width:360px;background:#1B1340;color:#fff;" +
    "padding:14px 18px;border-radius:14px;font:600 14px/1.4 system-ui,sans-serif;box-shadow:0 12px 32px rgba(0,0,0,.35);cursor:pointer";
  document.body.append(boite);
  const zone = document.createElement("div");
  zone.setAttribute("aria-hidden", "true");
  zone.style.cssText = "position:absolute;left:-30000px;top:0;width:1200px";
  document.body.append(zone);

  let arret = false;
  boite.onclick = () => { arret = true; };
  const morceaux = [];
  let parisLus = 0;
  try {
    for (let p = de; p <= a && !arret; p++) {
      boite.textContent = `Suivi Paris : page ${p} sur ${a}… (${parisLus} paris lus). Clique ici pour arrêter.`;
      adresse.searchParams.set("page", String(p));
      const reponseHttp = await fetch(adresse.href, { credentials: "same-origin" });
      if (!reponseHttp.ok) throw new Error(`la page ${p} a répondu ${reponseHttp.status}`);
      const doc = new DOMParser().parseFromString(await reponseHttp.text(), "text/html");
      doc.querySelectorAll("script,style,link,iframe,img,video,audio,object,embed,noscript").forEach((e) => e.remove());
      zone.innerHTML = doc.body ? doc.body.innerHTML : "";
      const texte = zone.innerText;
      if (!ENTETE_PARI.test(texte)) {
        if (p === de) throw new Error("aucun pari trouvé sur la première page (es-tu bien connecté, et le format de la page a-t-il changé ?)");
        break;
      }
      parisLus += (texte.match(new RegExp(ENTETE_PARI.source, "gm")) || []).length;
      morceaux.push(`=== Suivi Paris : page ${p} ===\n${texte}`);
      if (p < a) await new Promise((r) => setTimeout(r, PAUSE_MIN + Math.random() * (PAUSE_MAX - PAUSE_MIN)));
    }
  } catch (erreur) {
    boite.textContent = `Suivi Paris : arrêt, ${erreur.message}.` + (morceaux.length ? " Les pages déjà lues sont téléchargées." : "");
  } finally {
    zone.remove();
  }
  if (!morceaux.length) {
    setTimeout(() => boite.remove(), 10000);
    return;
  }
  /* Lancé par l'extension (« Récupérer tout mon historique ») : le texte part vers l'appli, sans fichier. */
  if (window.__suiviParisExtension) {
    window.postMessage({ suiviParisHistorique: morceaux.join("\n\n") }, location.origin);
    boite.textContent = "Suivi Paris : historique envoyé à l'appli.";
    setTimeout(() => boite.remove(), 10000);
    return;
  }
  const lien = document.createElement("a");
  lien.href = URL.createObjectURL(new Blob([morceaux.join("\n\n")], { type: "text/plain;charset=utf-8" }));
  lien.download = `winamax-historique-pages-${de}-${de + morceaux.length - 1}.txt`;
  document.body.append(lien);
  lien.click();
  lien.remove();
  boite.textContent = `Suivi Paris : ${morceaux.length} page(s), ${parisLus} paris. Fichier téléchargé : dépose-le dans l'onglet Importer de l'application.`;
  setTimeout(() => boite.remove(), 15000);
})();
