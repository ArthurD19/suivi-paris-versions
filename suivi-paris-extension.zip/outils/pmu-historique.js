/* Suivi Paris : récupère l'historique des paris sportifs PMU en cliquant sur « Voir plus » à ta place, puis le
   télécharge dans un fichier texte à déposer dans l'onglet Importer de l'application.

   À utiliser comme favori (bookmarklet), depuis pmu.fr, page Sport > « Mes paris » (onglet « Tous »), une fois
   connecté. Le site affiche certains textes en majuscules par la mise en page (« Référence Du Pari ») : le
   script la neutralise le temps de relever le texte, pour le lire tel qu'il est écrit. Le script clique sur « Voir plus » comme tu le ferais (une fois toutes les 1,2 à 2 secondes),
   relève les paris au fur et à mesure, et s'arrête à la date demandée ou quand plus rien ne se charge. Il ne
   clique sur aucun pari, ne modifie rien et n'envoie rien ailleurs : le fichier reste sur ton ordinateur.
   Pas de commentaires « // » dans ce fichier : un favori tient sur une seule ligne. */
(async () => {
  const REF = /^Référence du pari\s*:\s*(\d+)/i;
  const TYPE = /^(Simple|Combiné(\s*\(\d+\))?|Système)/i;
  const DATE = /^(\d{1,2})\s+([^\s.]+)\.?\s+(\d{4})\s*•\s*\d{1,2}:\d{2}$/;
  const FIN = /^(Voir plus|Jeu responsable)$/i;
  const MOIS = ["janv", "fevr", "mars", "avr", "mai", "juin", "juil", "aout", "sept", "oct", "nov", "dec"];
  const PAUSE_MIN = 1200, PAUSE_MAX = 2000, ESSAIS_SANS_NOUVEAUTE = 6;
  const pause = (ms) => new Promise((r) => setTimeout(r, ms));
  const lignesPage = () => {
    const casse = document.createElement("style");
    casse.textContent = "*,*::before,*::after{text-transform:none!important}";
    document.head.append(casse);
    const texte = document.body.innerText;
    casse.remove();
    return texte.replace(/[\u00a0\u202f\u200e\u200f]/g, " ").split("\n").map((l) => l.trim()).filter((l) => l);
  };
  const lireDate = (l) => {
    const m = l.match(DATE);
    if (!m) return null;
    const cle = m[2].normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const mois = MOIS.findIndex((x) => cle.startsWith(x));
    return mois < 0 ? null : new Date(Number(m[3]), mois, Number(m[1]));
  };

  if (!/(^|\.)pmu\.fr$/.test(location.hostname)) {
    alert("Suivi Paris : ouvre d'abord pmu.fr, Sport > Mes paris, puis reclique sur ce favori.");
    return;
  }
  if (!lignesPage().some((l) => REF.test(l))) {
    alert("Suivi Paris : aucun pari affiché. Ouvre Sport > Mes paris (onglet « Tous »), puis reclique sur ce favori.");
    return;
  }
  const reponse = prompt(
    "Suivi Paris : jusqu'à quelle date remonter ?\nEx. 01/01/2026. Laisse vide pour tout l'historique (cela peut prendre plusieurs minutes).",
    ""
  );
  if (reponse === null) return;
  let limite = null;
  if (reponse.trim()) {
    const m = reponse.trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (!m) {
      alert("Suivi Paris : écris la date sous la forme 01/01/2026.");
      return;
    }
    limite = new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
  }

  const paris = new Map();
  let plusAncienne = null;
  const recolter = () => {
    const L = lignesPage();
    let nouveaux = 0;
    const debuts = L.map((l, i) => (TYPE.test(l) ? i : -1)).filter((i) => i >= 0);
    debuts.forEach((d, k) => {
      let lignes = L.slice(d, k + 1 < debuts.length ? debuts[k + 1] : L.length);
      const ref = lignes.map((l) => l.match(REF)).find((m) => m);
      if (!ref) return;
      const fin = lignes.findIndex((l, i) => i > 0 && FIN.test(l));
      if (fin > 0) lignes = lignes.slice(0, fin);
      const bloc = lignes.join("\n");
      const ancien = paris.get(ref[1]);
      if (!ancien) nouveaux++;
      if (!ancien || bloc.length > ancien.length) paris.set(ref[1], bloc);
      const date = lignes.map(lireDate).find((x) => x);
      if (date && (!plusAncienne || date < plusAncienne)) plusAncienne = date;
    });
    return nouveaux;
  };
  const boutonPlus = () => {
    const visibles = [...document.querySelectorAll("button, a, [role='button'], span, div")].filter(
      (el) => /^(voir|afficher|charger) plus( de paris)?$/i.test((el.textContent || "").trim()) && el.getClientRects().length
    );
    return visibles.find((el) => !visibles.some((autre) => autre !== el && el.contains(autre))) || null;
  };

  const boite = document.createElement("div");
  boite.style.cssText =
    "position:fixed;z-index:2147483647;right:20px;bottom:20px;max-width:360px;background:#1B1340;color:#fff;" +
    "padding:14px 18px;border-radius:14px;font:600 14px/1.4 system-ui,sans-serif;box-shadow:0 12px 32px rgba(0,0,0,.35);cursor:pointer";
  document.body.append(boite);
  let arret = false;
  boite.onclick = () => { arret = true; boite.textContent = "Suivi Paris : arrêt demandé…"; };
  const dateFr = (d) => (d ? d.toLocaleDateString("fr-FR") : "…");

  recolter();
  let calmes = 0;
  while (!arret) {
    boite.textContent = `Suivi Paris : ${paris.size} paris lus, jusqu'au ${dateFr(plusAncienne)}. Clique ici pour arrêter.`;
    if (limite && plusAncienne && plusAncienne < limite) break;
    const plus = boutonPlus();
    if (plus) {
      plus.scrollIntoView({ block: "center" });
      plus.click();
    }
    await pause(PAUSE_MIN + Math.random() * (PAUSE_MAX - PAUSE_MIN));
    calmes = recolter() ? 0 : calmes + 1;
    if (calmes >= ESSAIS_SANS_NOUVEAUTE) break;
  }
  recolter();

  if (!paris.size) {
    boite.textContent = "Suivi Paris : aucun pari relevé.";
    setTimeout(() => boite.remove(), 10000);
    return;
  }
  const contenu = "=== Suivi Paris : historique PMU ===\n\n" + [...paris.values()].join("\n\n") + "\n";
  /* Lancé par l'extension (« Récupérer tout mon historique ») : le texte part vers l'appli, sans fichier. */
  if (window.__suiviParisExtension) {
    window.postMessage({ suiviParisHistorique: contenu }, location.origin);
    boite.textContent = "Suivi Paris : historique envoyé à l'appli.";
    setTimeout(() => boite.remove(), 10000);
    return;
  }
  const lien = document.createElement("a");
  lien.href = URL.createObjectURL(new Blob([contenu], { type: "text/plain;charset=utf-8" }));
  const aujourdhui = new Date().toISOString().slice(0, 10);
  lien.download = `pmu-historique-${aujourdhui}.txt`;
  document.body.append(lien);
  lien.click();
  lien.remove();
  boite.textContent = `Suivi Paris : ${paris.size} paris, jusqu'au ${dateFr(plusAncienne)}. Fichier téléchargé : dépose-le dans l'onglet Importer de l'application.`;
  setTimeout(() => boite.remove(), 15000);
})();
