/* Suivi Paris : récupère l'historique des paris Unibet en faisant défiler l'onglet « Terminés » à ta place,
   puis le télécharge dans un fichier texte à déposer dans l'onglet Importer de l'application.

   À utiliser comme favori (bookmarklet), depuis unibet.fr, page « Mes paris » > « Terminés », une fois connecté
   (ou, pour les paris d'avant la fusion avec PSEL, « Mes paris (ancienne version Unibet) » > « Mes paris
   précédents » > « Terminés »). Le script fait défiler la liste comme tu le ferais (une étape toutes les
   1,2 à 2 secondes), relève les paris au fur et à mesure, et s'arrête à la date demandée ou quand plus rien
   ne se charge. Il ne clique sur aucun pari, ne modifie rien et n'envoie rien ailleurs : le fichier reste
   sur ton ordinateur. Pas de commentaires « // » dans ce fichier : un favori tient sur une seule ligne. */
(async () => {
  const REF = /^Pari n°\s*([A-Z]?\d+(?:\/\d+)?)$/;
  const DATE = /^Le (\d{2})-(\d{2})-(\d{2}) à \d{2}h\d{2}$/;
  const TYPE = /^(Simple|Combin[ée].*|Syst[èe]me.*)$/i;
  const PAUSE_MIN = 1200, PAUSE_MAX = 2000, ESSAIS_SANS_NOUVEAUTE = 8;
  const pause = (ms) => new Promise((r) => setTimeout(r, ms));
  const lignesPage = () => document.body.innerText.replace(/[\u00a0\u202f]/g, " ").split("\n").map((l) => l.trim()).filter((l) => l);

  if (!/(^|\.)unibet\.fr$/.test(location.hostname)) {
    alert("Suivi Paris : ouvre d'abord unibet.fr, Mes paris > onglet « Terminés », puis reclique sur ce favori.");
    return;
  }
  if (!lignesPage().some((l) => REF.test(l))) {
    alert("Suivi Paris : aucun pari affiché. Ouvre Mes paris > onglet « Terminés » (ou, pour les paris d'avant la fusion, Mes paris (ancienne version Unibet) > Mes paris précédents > Terminés), puis reclique sur ce favori.");
    return;
  }
  const reponse = prompt(
    "Suivi Paris : jusqu'à quelle date remonter ?\nEx. 01/01/2026. Laisse vide pour tout l'historique (cela peut prendre plusieurs minutes).",
    ""
  );
  if (reponse === null) return;
  let limite = null;
  if (reponse.trim()) {
    const m = reponse.trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (!m) {
      alert("Suivi Paris : écris la date sous la forme 01/01/2026.");
      return;
    }
    limite = new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
  }

  const paris = new Map();
  let plusAncienne = null;
  const recolter = () => {
    const L = lignesPage();
    let debut = 0, nouveaux = 0;
    for (let i = 0; i < L.length - 1; i++) {
      const r = L[i].match(REF);
      const d = r && L[i + 1].match(DATE);
      if (!d) continue;
      let lignes = L.slice(debut, i + 2);
      debut = i + 2;
      const fin = lignes.findIndex((l) => /^cote totale$/i.test(l));
      let t = -1;
      for (let k = (fin === -1 ? lignes.length : fin) - 1; k >= 0; k--) {
        if (TYPE.test(lignes[k])) { t = k; break; }
      }
      if (t > 0) lignes = lignes.slice(t);
      const bloc = lignes.filter((l) => l).join("\n");
      const ancien = paris.get(r[1]);
      if (!ancien) nouveaux++;
      if (!ancien || bloc.length > ancien.length) paris.set(r[1], bloc);
      const date = new Date(2000 + Number(d[3]), Number(d[2]) - 1, Number(d[1]));
      if (!plusAncienne || date < plusAncienne) plusAncienne = date;
    }
    return nouveaux;
  };
  const trouverDefilant = () => {
    const marques = [...document.querySelectorAll("body *")].filter(
      (el) => el.children.length === 0 && REF.test((el.textContent || "").trim())
    );
    let el = marques.length ? marques[marques.length - 1].parentElement : null;
    while (el && el !== document.body) {
      const style = getComputedStyle(el);
      if (/(auto|scroll)/.test(style.overflowY) && el.scrollHeight > el.clientHeight + 20) return el;
      el = el.parentElement;
    }
    return null;
  };

  const boite = document.createElement("div");
  boite.style.cssText =
    "position:fixed;z-index:2147483647;right:20px;bottom:20px;max-width:360px;background:#1B1340;color:#fff;" +
    "padding:14px 18px;border-radius:14px;font:600 14px/1.4 system-ui,sans-serif;box-shadow:0 12px 32px rgba(0,0,0,.35);cursor:pointer";
  document.body.append(boite);
  let arret = false;
  boite.onclick = () => { arret = true; boite.textContent = "Suivi Paris : arrêt demandé…"; };
  const dateFr = (d) => (d ? d.toLocaleDateString("fr-FR") : "…");

  recolter();
  let calmes = 0, conteneur = trouverDefilant();
  while (!arret) {
    boite.textContent = `Suivi Paris : ${paris.size} paris lus, jusqu'au ${dateFr(plusAncienne)}. Clique ici pour arrêter.`;
    if (!conteneur || !conteneur.isConnected) conteneur = trouverDefilant();
    if (conteneur) {
      conteneur.scrollTop = Math.max(0, conteneur.scrollHeight - conteneur.clientHeight - 400);
      await pause(150);
      conteneur.scrollTop = conteneur.scrollHeight;
    }
    window.scrollTo(0, Math.max(0, document.documentElement.scrollHeight - window.innerHeight - 400));
    await pause(150);
    window.scrollTo(0, document.documentElement.scrollHeight);
    const plus = [...document.querySelectorAll("button, a")].find((b) =>
      /^(voir|afficher|charger) (plus|d'autres|davantage)/i.test((b.textContent || "").trim())
    );
    if (plus) plus.click();
    await pause(PAUSE_MIN + Math.random() * (PAUSE_MAX - PAUSE_MIN));
    calmes = recolter() ? 0 : calmes + 1;
    if (limite && plusAncienne && plusAncienne < limite) break;
    if (calmes >= ESSAIS_SANS_NOUVEAUTE) break;
  }
  recolter();

  if (!paris.size) {
    boite.textContent = "Suivi Paris : aucun pari relevé.";
    setTimeout(() => boite.remove(), 10000);
    return;
  }
  const contenu = "=== Suivi Paris : historique Unibet ===\n\n" + [...paris.values()].join("\n\n") + "\n";
  /* Lancé par l'extension (« Récupérer tout mon historique ») : le texte part vers l'appli, sans fichier. */
  if (window.__suiviParisExtension) {
    window.postMessage({ suiviParisHistorique: contenu }, location.origin);
    boite.textContent = "Suivi Paris : historique envoyé à l'appli.";
    setTimeout(() => boite.remove(), 10000);
    return;
  }
  const lien = document.createElement("a");
  lien.href = URL.createObjectURL(new Blob([contenu], { type: "text/plain;charset=utf-8" }));
  const aujourdhui = new Date().toISOString().slice(0, 10);
  lien.download = `unibet-historique-${aujourdhui}.txt`;
  document.body.append(lien);
  lien.click();
  lien.remove();
  boite.textContent = `Suivi Paris : ${paris.size} paris, jusqu'au ${dateFr(plusAncienne)}. Fichier téléchargé : dépose-le dans l'onglet Importer de l'application.`;
  setTimeout(() => boite.remove(), 15000);
})();
