/* Suivi Paris : récupère tout l'historique des paris ps3838, que le site ne laisse chercher que par mois,
   puis le télécharge dans un fichier texte à déposer dans l'onglet Importer de l'application.

   À utiliser comme favori (bookmarklet), depuis ps3838.com, page « Mes paris », une fois connecté, avec le
   statut voulu (« Réglé »). Le principe : le favori clique lui-même sur « Recherche », fenêtre de 30 jours
   après fenêtre de 30 jours, en remplaçant seulement les dates de la demande que la page envoie (et rien
   d'autre : ta session, tes filtres et les en-têtes du site restent ceux de la page). Après chaque réponse,
   il relève le tableau affiché. Les fenêtres se chevauchent d'un jour pour ne rien rater ; l'application
   fusionne les doublons. Une pause de 1,5 à 2,5 secondes sépare deux recherches. Rien n'est envoyé ailleurs :
   le fichier reste sur ton ordinateur. Pas de commentaires « // » ici : un favori tient sur une seule ligne. */
(async () => {
  const PAUSE_MIN = 1500, PAUSE_MAX = 2500, DUREE_FENETRE = 30, DELAI_REPONSE = 25000;
  const pause = (ms) => new Promise((r) => setTimeout(r, ms));
  const jour = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

  if (!/(^|\.)ps3838\.com$/.test(location.hostname) || !/my-bets/.test(location.pathname)) {
    alert("Suivi Paris : ouvre d'abord ps3838.com, Mon compte > Mes paris, puis reclique sur ce favori.");
    return;
  }
  const bouton = [...document.querySelectorAll("button, a, input[type=button], input[type=submit]")].find((b) =>
    /^(recherche|rechercher|search)$/i.test((b.textContent || b.value || "").trim())
  );
  if (!bouton) {
    alert("Suivi Paris : bouton « Recherche » introuvable sur cette page.");
    return;
  }
  const reponse = prompt(
    "Suivi Paris : depuis quelle date récupérer tes paris ?\nEx. 01/01/2025. Garde le statut « Réglé » et les dates par défaut du site.",
    "01/01/2025"
  );
  if (reponse === null) return;
  const m = reponse.trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!m) {
    alert("Suivi Paris : écris la date sous la forme 01/01/2025.");
    return;
  }
  const depart = new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
  const demain = new Date();
  demain.setDate(demain.getDate() + 1);
  const fenetres = [];
  for (let d = new Date(depart); d < demain; ) {
    const fin = new Date(d);
    fin.setDate(fin.getDate() + DUREE_FENETRE);
    fenetres.push({ f: `${jour(d)} 00:00:00`, t: `${jour(fin < demain ? fin : demain)} 00:00:00` });
    d = fin;
  }
  if (!fenetres.length) {
    alert("Suivi Paris : cette date est dans le futur.");
    return;
  }

  let fenetre = null, signaler = null;
  const reecrire = (url, corps) => {
    if (!fenetre || typeof corps !== "string" || !/member-service/.test(url)) return corps;
    const p = new URLSearchParams(corps);
    if (!p.has("f") || !p.has("t")) return corps;
    p.set("f", fenetre.f);
    p.set("t", fenetre.t);
    return p.toString();
  };
  const estListe = (url) => /wager/i.test(url);
  const ouvrirOrigine = XMLHttpRequest.prototype.open, envoyerOrigine = XMLHttpRequest.prototype.send;
  const fetchOrigine = window.fetch;
  XMLHttpRequest.prototype.open = function (methode, url, ...reste) {
    this.__suiviParisUrl = String(url);
    return ouvrirOrigine.call(this, methode, url, ...reste);
  };
  XMLHttpRequest.prototype.send = function (corps) {
    const url = this.__suiviParisUrl || "";
    if (fenetre && estListe(url)) this.addEventListener("loadend", () => signaler && signaler(this.status));
    return envoyerOrigine.call(this, reecrire(url, corps));
  };
  window.fetch = async function (entree, options) {
    const url = typeof entree === "string" ? entree : (entree && entree.url) || "";
    if (options && typeof options.body === "string") options = { ...options, body: reecrire(url, options.body) };
    const r = await fetchOrigine.call(this, entree, options);
    if (fenetre && estListe(url)) r.clone().text().then(() => signaler && signaler(r.status), () => signaler && signaler(r.status));
    return r;
  };
  const retablir = () => {
    XMLHttpRequest.prototype.open = ouvrirOrigine;
    XMLHttpRequest.prototype.send = envoyerOrigine;
    window.fetch = fetchOrigine;
  };

  const releverTableau = () => {
    const tableau = [...document.querySelectorAll("table")].find((t) => /Produit/.test(t.innerText) && /Sélection/.test(t.innerText));
    if (tableau) {
      return [...tableau.rows].map((tr) => [...tr.cells].map((c) => c.innerText.trim()).join("\t")).join("\n");
    }
    const lignes = document.body.innerText.split("\n");
    const debut = lignes.findIndex((l) => /^#\t/.test(l));
    if (debut === -1) return "";
    const fin = lignes.findIndex((l, k) => k > debut && /^Total\t/.test(l));
    return lignes.slice(debut, fin === -1 ? undefined : fin + 1).join("\n");
  };

  const boite = document.createElement("div");
  boite.style.cssText =
    "position:fixed;z-index:2147483647;right:20px;bottom:20px;max-width:360px;background:#1B1340;color:#fff;" +
    "padding:14px 18px;border-radius:14px;font:600 14px/1.4 system-ui,sans-serif;box-shadow:0 12px 32px rgba(0,0,0,.35);cursor:pointer";
  document.body.append(boite);
  let arret = false;
  boite.onclick = () => { arret = true; boite.textContent = "Suivi Paris : arrêt demandé…"; };

  const morceaux = [];
  const references = new Set();
  let erreur = null;
  try {
    for (let i = 0; i < fenetres.length && !arret; i++) {
      fenetre = fenetres[i];
      boite.textContent = `Suivi Paris : du ${fenetre.f.slice(0, 10)} au ${fenetre.t.slice(0, 10)} (${i + 1}/${fenetres.length}), ${references.size} paris lus. Clique ici pour arrêter.`;
      const reponseRecue = new Promise((r) => { signaler = r; });
      bouton.click();
      const statut = await Promise.race([reponseRecue, pause(DELAI_REPONSE).then(() => "délai")]);
      signaler = null;
      if (statut === "délai") throw new Error("le site n'a pas répondu à la recherche");
      if (statut >= 400) throw new Error(`le site a refusé la recherche (erreur ${statut})`);
      await pause(1200);
      const texte = releverTableau();
      if (texte) {
        (texte.match(/(^|\s)\d{7,}(?=\s|$)/g) || []).forEach((r) => references.add(r.trim()));
        morceaux.push(`=== Suivi Paris : ps3838 du ${fenetre.f.slice(0, 10)} au ${fenetre.t.slice(0, 10)} ===\n${texte}`);
      }
      if (i < fenetres.length - 1) await pause(PAUSE_MIN + Math.random() * (PAUSE_MAX - PAUSE_MIN));
    }
  } catch (e) {
    erreur = e.message;
  } finally {
    fenetre = null;
    retablir();
  }

  if (!morceaux.length) {
    boite.textContent = `Suivi Paris : aucun pari relevé${erreur ? ` (${erreur})` : ""}.`;
    setTimeout(() => boite.remove(), 12000);
    return;
  }
  /* Lancé par l'extension (« Récupérer tout mon historique ») : le texte part vers l'appli, sans fichier. */
  if (window.__suiviParisExtension) {
    window.postMessage({ suiviParisHistorique: morceaux.join("\n\n") + "\n" }, location.origin);
    boite.textContent = "Suivi Paris : historique envoyé à l'appli.";
    setTimeout(() => boite.remove(), 10000);
    return;
  }
  const lien = document.createElement("a");
  lien.href = URL.createObjectURL(new Blob([morceaux.join("\n\n") + "\n"], { type: "text/plain;charset=utf-8" }));
  lien.download = `ps3838-historique-${jour(new Date())}.txt`;
  document.body.append(lien);
  lien.click();
  lien.remove();
  boite.textContent =
    `Suivi Paris : ${references.size} paris relevés${erreur ? `, arrêt : ${erreur}` : ""}. ` +
    "Fichier téléchargé : dépose-le dans l'onglet Importer de l'application. Recharge la page ps3838 pour retrouver tes dates.";
  setTimeout(() => boite.remove(), 20000);
})();
