/* Suivi Paris : script de page, sur les sites des bookmakers.

   Il ne change rien à la page et ne clique sur rien, sauf « Afficher plus » dans l'historique bet365 et Sportaza, et
   les paris Sportaza quand tu le demandes (bouton « Ouvrir tous les paris » de l'icône, voir plus bas). Il relève le texte de la page comme le ferait un Ctrl+A /
   Ctrl+C et le passe au service worker, qui l'envoie à l'appli Suivi Paris de l'ordinateur :
   - le haut de chaque page, où le site affiche le solde du compte (relevé quand il change) ;
   - les paris affichés (« Mes paris », historique…) ;
   - les dépôts et retraits affichés (historique des mouvements). Il relit la page quand elle change (« Voir plus », défilement,
   pari réglé), sans renvoyer ce qui n'a pas changé.

   Le bouton « Copier le texte de la page » de l'icône met ce même texte dans le presse-papiers, pour un collage à
   la main dans l'appli (bet365 empêche de sélectionner le texte : Ctrl+A n'y prend rien).

   Winamax : « Mes paris » est lu comme les autres sites. Son historique de compte, plus détaillé (sport,
   sélections des combinés), s'affiche en pages HTML classiques : une fois que tu l'as ouvert, son adresse est retenue, et chaque visite sur winamax.fr relit sa première page (au plus une fois
   toutes les 20 minutes), sans que tu aies à l'ouvrir. */
(() => {
  // Déjà en place et relié à l'extension (script remis par l'extension après une mise à jour) : rien à faire.
  try { if (window.__suiviParisVivant && window.__suiviParisVivant()) return; } catch { /* ancien script coupé */ }
  window.__suiviParisVivant = () => { try { return Boolean(chrome.runtime && chrome.runtime.id); } catch { return false; } };
  const SITES = {
    // `marques` : une icône sans texte (le « F » d'un freebet) est lue comme le mot donné.
    betclic: { hote: /(^|\.)betclic\.fr$/, repere: /^Réf\s+[0-9a-f]{16,}/gm, marques: [[".icon_freebet", "Freebet"]] },
    // Historique de compte (tableau) ou « Mes paris » (« Réf : 6K5VBD7A »).
    // `soldeEnBas` : sur le site mobile, le solde est dans la barre du bas (les dernières lignes de la page).
    winamax: { hote: /(^|\.)winamax\.fr$/, soldeEnBas: 20, repere: /^(?:[0-9A-Z]{6,}(?:-\d+)?\t\d{2}\/\d{2}\/\d{4}|Réf\s*:\s*[0-9A-Z]{6,}(?:-\d+)?$)/gm },
    unibet: { hote: /(^|\.)unibet\.fr$/, repere: /^Pari n°\s*[A-Z]?\d+(?:\/\d+)?$/gm },
    pmu: { hote: /(^|\.)pmu\.fr$/, repere: /^Référence du pari\s*:\s*\d+/gim },
    ps3838: { hote: /(^|\.)ps3838\.com$/, repere: /^\d{7,}$/gm, aussi: /Risque\s*:\s*[\d.,]+/ },
    piwi247: { hote: /(^|\.)piwi247\.com$/, repere: /^\d{7,}$/gm, aussi: /Risque\s*:\s*[\d.,]+/ },
    // Le détail d'un pari, une fois cliqué dans l'historique (« ID:33874999389297 ») : relu à chaque pari ouvert.
    olybet: { hote: /(^|\.)olybet\.fr$/, repere: /^ID\s*:\s*\d{8,}/gm },
    // Pas encore lus : l'extension ne fait que copier leur texte (bouton « Copier le texte de la page »), que ces
    // sites empêchent de sélectionner, pour écrire leur lecture.
    // Mes paris, « Ouvert » et « Évalué » : pas de numéro de pari, la date du pari (à la minute) sous chaque pari.
    // Solde et dépôts / retraits (Historique des transactions) ; les paris, pas encore.
    // Sportaza change d'adresse (« sportaza-5178.com ») : ces adresses-là sont autorisées une à une depuis l'icône.
    // Mes paris : dans des composants de page (« shadow DOM » imbriqués), « Afficher plus de paris » sous la liste.
    // En français ou en anglais selon le compte (« Cotes totales » / « Total odds », « ID: 5005715455 »).
    sportaza: { hote: /(^|\.)sportaza(-\d+)?\.com$/, repere: /(?:^|\s)(?:Numéro d'identification|ID):\s*\d{6,}$/gm,
                aussi: /^(?:Cotes totales|Total odds)$/m, ombres: "profond",
                plus: /^(Afficher plus de paris|Afficher plus|Show more(?: bets)?|Load more(?: bets)?|More bets)$/i,
                termines: /^(?:Cotes totales|Total odds)$/m,
                // Un pari ouvert d'un clic (un à la fois) : son détail (choix, date de l'événement) part aussitôt.
                ouvrir: true,  // le bouton « Ouvrir tous les paris » de l'icône les ouvre un par un
                detail: /^(?:GAGNÉ|PERDU|NUL|REMBOURSÉ|ANNULÉ|CASH ?OUT|RETIRÉ|EN COURS|OUVERT|EN ATTENTE|WON|LOST|VOID|PUSH|REFUNDED|CANCELL?ED|CASHED ?OUT|PENDING|HALF ?WON|HALF ?LOST)\n(?!(?:Cotes totales|Total odds)\n)[^]*?^(?:Cotes totales|Total odds)$/gim },
    bwin: { hote: /(^|\.)bwin\.fr$/, repere: /^(?:Détail|Épingler \(en haut\))\n\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/gm,
            aussi: /^Mise\nCotes\nGains/m,
            periodes: 90 },  // « Évalué » : 90 jours au plus par filtre ; l'icône les enchaîne depuis une date choisie
    // Mes paris → Paris terminés : un combiné ne donne ses sélections (et sa date) qu'ouvert (« Voir les détails ») ;
    // le bouton « Ouvrir tous les paris » de l'icône les ouvre. Le solde est dans un cadre (pam.netbet.fr).
    netbet: { hote: /(^|\.)netbet\.fr$/, repere: /^Réf\s*:\s*[0-9A-Z]{8,}\s*-\s*ID/gm, ouvrir: "details" },
    // Exchange : My Bets → Settled (un tableau, une ligne par pari : Ref ID, dates, sélection…).
    orbitx: { hote: /(^|\.)orbitxch\.com$/, repere: /^\d{6,}\n\d{1,2} [A-Z][a-z]{2} \d{4} \d{2}:\d{2}$/gm,
              aussi: /^Ref ID$/m },
    // Le courtier de ps3838 et PIWI247 : son historique des transactions (dépliées d'un clic) donne leurs dépôts,
    // retraits et transferts. Ni paris ni solde de bookmaker.
    asianconnect: { hote: /(^|\.)(ac0188|asianconnect88)\.com$/, sansSolde: true },
    // Historique du compte : un pari par date à la seconde, avec sa mise. Le site empêche de sélectionner le texte,
    // mais innerText le lit quand même. L'historique s'affiche souvent dans un cadre : le script y tourne aussi.
    bet365: { hote: /(^|\.)bet365\.(fr|com)$/, repere: /^[ \t\u00a0]*\d{2}\/\d{2}\/\d{4}\s+\d{2}:\d{2}:\d{2}[ \t\u00a0]*$/gm,
              aussi: /Mise\s*:?\s*[\d\s.]*,\d{2}/, plus: "Afficher plus", ombres: true, termines: /^Paris terminés/m,
              // La page des paris est ouverte, mais vide tant que la période n'est pas choisie : le guide le dit.
              plage: 6,  // « Plage de dates » : 6 mois au plus par recherche
              pageParis: [/^(Paris terminés|Paris en cours)$/m, "Page ouverte : choisis la période, puis <b>Afficher l'historique</b>"] },
  };
  // Un cadre vide (about:blank) a l'adresse de la page qui le contient.
  let hote = location.hostname;
  try { if (!hote && window !== window.top) hote = window.parent.location.hostname; } catch { /* cadre d'un autre site */ }
  const bookmaker = Object.keys(SITES).find((b) => SITES[b].hote.test(hote));
  if (!bookmaker) return;
  const site = SITES[bookmaker];
  /* Le stockage et les messages de l'extension, sous la forme que tous les navigateurs acceptent (Orion sur l'iPhone
     ne rend pas toujours de promesse) : rappel ou promesse, et une réponse par défaut au bout de 5 s. */
  const appel = (f, arg, defaut, delai = 5000) => new Promise((ok) => {
    const fin = setTimeout(() => ok(defaut), delai);
    const rendre = (v) => { clearTimeout(fin); ok(v === undefined ? defaut : v); };
    try {
      const r = f(arg, (v) => { void (chrome.runtime && chrome.runtime.lastError); rendre(v); });
      if (r && typeof r.then === "function") r.then(rendre, () => rendre(defaut));
    } catch { rendre(defaut); }
  });
  const stock = {
    get: (cles) => appel((a, rap) => chrome.storage.local.get(a, rap), cles, {}).then((v) => v || {}),
    set: (o) => appel((a, rap) => chrome.storage.local.set(a, rap), o, null),
    remove: (c) => appel((a, rap) => chrome.storage.local.remove(a, rap), c, null),
  };
  // L'envoi peut passer par la boîte de la synchronisation (GitHub) : jusqu'à 30 s.
  const versExtension = (message) => appel((m, rap) => chrome.runtime.sendMessage(m, rap), message, null, 30000);
  /* Le compte choisi dans cet onglet (plusieurs comptes chez ce bookmaker) : retenu par la page elle-même, le temps de
     l'onglet (3 h au plus), et renvoyé avec chaque envoi. Orion (iPhone) perd parfois la mémoire de l'extension : sans
     cela, la question revenait à chaque page alors que tu y avais déjà répondu. */
  const CLE_COMPTE = `suiviParis.compte.${bookmaker}`;
  function compteOnglet() {
    try {
      const c = JSON.parse(sessionStorage.getItem(CLE_COMPTE) || "null");
      return c && Number(c.id) && Date.now() - c.le < 3 * 3600e3 ? Number(c.id) : null;
    } catch { return null; }
  }
  function retenirCompte(id) {
    try { sessionStorage.setItem(CLE_COMPTE, JSON.stringify({ id: Number(id), le: Date.now() })); } catch { /* stockage bloqué */ }
  }
  const ATTENTE = 2000;      // relire 2 s après le dernier changement de la page…
  const ATTENTE_MAX = 6000;  // … ou 6 s après le premier, sur une page qui ne s'arrête jamais (cotes, scores en direct)
  const RENVOI_MIN = 60 * 1000;
  const RELECTURE_WINAMAX = 20 * 60 * 1000;

  /* Les « shadow roots » sous un élément ; `profond` : aussi ceux qu'ils contiennent. */
  function racinesOmbre(element, profond) {
    const racines = [];
    const fouiller = (r) => {
      for (const e of r.querySelectorAll("*")) {
        if (!e.shadowRoot) continue;
        racines.push(e.shadowRoot);
        if (profond) fouiller(e.shadowRoot);
      }
    };
    fouiller(element);
    return racines;
  }

  /* Le texte tel qu'écrit : certains sites mettent des mots en majuscules par la mise en page
     (« Référence Du Pari » chez PMU), ce que innerText reprendrait. */
  function texteDe(element) {
    const casse = document.createElement("style");
    casse.textContent = "*,*::before,*::after{text-transform:none!important}";
    (document.head || document.documentElement).append(casse);
    // Une icône qui veut dire quelque chose (freebet) : un mot posé à côté le temps de la lecture, puis retiré.
    const poses = [];
    for (const [selecteur, mot] of site.marques || []) {
      for (const icone of element.querySelectorAll(selecteur)) {
        const m = document.createElement("span");
        m.textContent = ` ${mot} `;
        icone.after(m);
        poses.push(m);
      }
    }
    let texte = element.innerText;
    for (const m of poses) m.remove();
    // Le contenu d'un « shadow DOM » (composants web) n'est pas dans innerText : on l'ajoute à la suite (« profond » :
    // aussi celui des composants dans les composants).
    if (site.ombres) {
      const parts = [];
      for (const racine of racinesOmbre(element, site.ombres === "profond")) {
        for (const enfant of racine.children) if (enfant.innerText) parts.push(enfant.innerText);
      }
      if (parts.length) texte += "\n" + parts.join("\n");
    }
    casse.remove();
    if (observateur) observateur.takeRecords();  // ce style posé puis retiré n'est pas un changement de la page
    return texte;
  }
  /* Une page de dépôts ou de retraits : des lignes « Validé » / « Refusé » (Betclic…) ou « APPROVISIONNEMENT » /
     « RETRAIT » (PMU), au moins deux. */
  const MOUVEMENT = /^(Validée?|Refusée?|APPROVISIONNEMENT|RETRAIT)$/gm;
  const MOUVEMENT_BET365 = /^Montant du (dépôt|retrait)/gm;  // une ligne par mouvement
  const TABLEAU_WINAMAX = /^\s*Historique des (dépôts|retraits) du /im;  // Mon compte → Historique de compte
  const LIGNE_WINAMAX = /^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}:\d{2}\t/gm;
  // Unibet (Mon compte → Transactions) : « Mercredi 8 avril 2026 », puis libellé et montant signé (« + 40,00 € »).
  const DATE_LONGUE = /^(lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche)\s+\d{1,2}(er)?\s+\S+\s+\d{4}\s*$/im;
  const MONTANT_SIGNE = /^[+\-−]\s*\d[\d\s]*,\d{2}\s*€\s*$/gm;
  const NUMERO_AC = /^\d{8}-\d{6}-\d+-\d$/gm;  // AsianConnect : « 20260630-050235-472683-3 »
  const LIGNE_SPORTAZA = /^\d{2}\.\d{2}\.\d{4}, \d{2}:\d{2}$/gm;  // « 26.08.2026, 08:33 »
  const estSportaza = (texte) => bookmaker === "sportaza" && /^(Type d'opération|Operation type|Transaction type|Type)$/m.test(texte)
    && LIGNE_SPORTAZA.test(texte);
  const estAsianConnect = (texte) => bookmaker === "asianconnect" && /^Numéro de transaction$/m.test(texte);
  const estUnibet = (texte) => bookmaker === "unibet" && /^Transactions\s*$/m.test(texte) && DATE_LONGUE.test(texte);
  function lignesMouvements(texte) {
    if (estAsianConnect(texte)) return texte.match(NUMERO_AC) || [];
    if (estSportaza(texte)) return texte.match(LIGNE_SPORTAZA) || [];
    return [...(texte.match(MOUVEMENT_BET365) || []), ...(texte.match(MOUVEMENT) || []),
      ...(TABLEAU_WINAMAX.test(texte) ? texte.match(LIGNE_WINAMAX) || [] : []),
      ...(estUnibet(texte) ? texte.match(MONTANT_SIGNE) || [] : [])];
  }
  function estPageMouvements(texte) {
    if (estAsianConnect(texte)) return (texte.match(NUMERO_AC) || []).length >= 1;
    if (estSportaza(texte)) return (texte.match(LIGNE_SPORTAZA) || []).length >= 1;
    if (estUnibet(texte)) return (texte.match(MONTANT_SIGNE) || []).length >= 1;
    return ((texte.match(MOUVEMENT_BET365) || []).length >= 1 || (texte.match(MOUVEMENT) || []).length >= 2
      || (TABLEAU_WINAMAX.test(texte) && (texte.match(LIGNE_WINAMAX) || []).length >= 1))
      && /\d{2}\/\d{2}\/\d{4}/.test(texte);
  }

  /* Le texte d'une autre page du même site, lue avec ta session, sans l'afficher ni exécuter son code. */
  async function texteDistant(adresse) {
    const r = await fetch(adresse, { credentials: "same-origin" });
    if (!r.ok) return "";
    const doc = new DOMParser().parseFromString(await r.text(), "text/html");
    doc.querySelectorAll("script,style,link,iframe,img,video,audio,object,embed,noscript,svg").forEach((e) => e.remove());
    doc.querySelectorAll("*").forEach((e) => [...e.attributes].forEach((a) => { if (/^on/i.test(a.name)) e.removeAttribute(a.name); }));
    const zone = document.createElement("div");
    zone.setAttribute("aria-hidden", "true");
    zone.style.cssText = "position:absolute;left:-30000px;top:0;width:1200px";
    zone.innerHTML = doc.body ? doc.body.innerHTML : "";
    document.body.append(zone);
    const texte = texteDe(zone);
    zone.remove();
    return texte;
  }

  /* Winamax : un tableau de dépôts paginé (« 1 2 3 Suivant »). Les autres pages sont lues aussi et ajoutées au
     texte envoyé (le tableau d'une page à la suite de l'autre). */
  async function avecPagesSuivantes(texte) {
    if (bookmaker !== "winamax" || !TABLEAU_WINAMAX.test(texte)) return texte;
    const ici = location.href.split("#")[0];
    const adresses = [...new Set([...document.querySelectorAll("a[href]")]
      .filter((a) => /^\d+$/.test(a.textContent.trim()))
      .map((a) => a.href.split("#")[0])
      .filter((h) => h.startsWith(location.origin) && h !== ici))].slice(0, 50);
    const parts = [texte];
    for (const adresse of adresses) {
      try {
        bulle(`Suivi Paris : lecture de la page ${parts.length + 1} sur ${adresses.length + 1}…`);
        const autre = await texteDistant(adresse);
        if (TABLEAU_WINAMAX.test(autre)) parts.push(autre);
      } catch { /* page illisible : on garde les autres */ }
      await pause(600);
    }
    return parts.join("\n");
  }
  /* Le haut de la page, où se trouve le solde. */
  function enTete(texte) {
    const lignes = texte.split("\n").map((l) => l.trim()).filter((l) => l);
    const bas = site.soldeEnBas && lignes.length > 60 ? lignes.slice(Math.max(60, lignes.length - site.soldeEnBas)) : [];
    return [...lignes.slice(0, 60), ...bas].join("\n");
  }

  /* Un aperçu de ce qui est lu, pour la liste « Prêt à envoyer » (iPhone) : chaque pari en une ligne, et le solde.
     Indicatif seulement : c'est l'appli qui lit vraiment la page (suivi_paris/adaptateurs, soldes.py). */
  const MONTANT = /^\d{1,3}(?:[ \u00a0\u202f]?\d{3})*(?:,\d{1,2})?\s*€$/;
  const COTE = /^\d{1,4}(?:[,.]\d{1,3})?$/;
  const ETATS = /^(en cours|gagnée?|perdue?|remboursée?|annulée?|cash ?out)$/i;
  function apercuParis(texte) {
    const lignes = texte.split("\n").map((l) => l.trim()).filter((l) => l);
    const refs = [];
    lignes.forEach((l, i) => { site.repere.lastIndex = 0; if (site.repere.test(l)) refs.push(i); });
    site.repere.lastIndex = 0;
    return refs.slice(0, 200).map((i, k) => {
      const bloc = lignes.slice(k ? refs[k - 1] + 2 : Math.max(0, i - 30), i);
      const apres = (mot) => { const j = bloc.findIndex((l) => l.toLowerCase() === mot); return j >= 0 ? bloc[j + 1] : null; };
      const iMise = bloc.findIndex((l) => l.toLowerCase() === "mise");
      const avantMise = iMise > 0 ? bloc.slice(0, iMise) : bloc;
      const cote = apres("cote totale") || [...avantMise].reverse().find((l) => COTE.test(l)) || null;
      // Le pari commence à son type (« Simple », « Combiné ») : ce qui est au-dessus (onglets du site) n'en est pas.
      const iDebut = avantMise.map((l) => /^(simple|combiné|multiple|système)(\s|\(|$)/i.test(l)).lastIndexOf(true);
      const corps = avantMise.slice(iDebut + 1);
      const etat = corps.find((l) => ETATS.test(l)) || null;
      const type = iDebut >= 0 ? avantMise[iDebut] : "";
      const titre = /^combiné/i.test(type) ? `Combiné${/^\(\d+\)$/.test(corps[0] || "") ? ` ${corps[0]}` : ""}`
        : corps.filter((l) => l.length > 2 && !ETATS.test(l) && !COTE.test(l) && !MONTANT.test(l) && !/^(cote totale|compétition de )/i.test(l)
            && !/^(\d{1,3}(:\d{2}|')|mi-temps$|pause$|prol)/i.test(l))  // le chrono d'un match en direct
          .slice(0, 3).map((l) => l.replace(/\s+/g, " ").slice(0, 50)).join(" · ");
      return { ref: lignes[i].replace(/^(Réf\s*:|Pari n°|Référence du pari\s*:)\s*/i, "").split(/\s/)[0],
        titre: titre.slice(0, 90), mise: iMise >= 0 ? bloc[iMise + 1] || null : null, cote,
        gains: apres("gains potentiels") || apres("gains") || null, etat };
    });
  }
  function apercuSolde(tete) {
    const l = tete.split("\n");
    const i = (mot) => l.findIndex((x) => x.toLowerCase() === mot);
    const premier = (de, a) => l.slice(Math.max(0, de), a).find((x) => MONTANT.test(x)) || null;
    if (bookmaker === "winamax") {
      const fin = i("mon espace perso");
      if (fin >= 0) return premier(fin - 15, fin);
      const j = l.findIndex((x, k) => x.toLowerCase() === "sport" && (l[k + 1] || "").toLowerCase() === "poker");
      return j >= 0 ? premier(j + 2, j + 4) : null;
    }
    if (bookmaker === "unibet") { const d = i("mes paris"); return d >= 0 ? premier(d + 1, d + 9) : null; }
    if (bookmaker === "bet365") { const d = i("récompenses"); return d >= 0 ? premier(d + 1, d + 9) : null; }
    return null;
  }

  function references(texte) {
    if (!site.repere) return [];
    if (site.aussi && !site.aussi.test(texte)) return [];
    return [...texte.matchAll(site.repere)].map((m) => m[0].replace(/\s+/g, " ").trim());
  }
  function empreinte(texte) {
    let h = 2166136261;
    for (let i = 0; i < texte.length; i++) h = Math.imul(h ^ texte.charCodeAt(i), 16777619);
    return (h >>> 0).toString(16);
  }
  function maintenantLocal() {
    const d = new Date();
    const deux = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${deux(d.getMonth() + 1)}-${deux(d.getDate())}T${deux(d.getHours())}:${deux(d.getMinutes())}:${deux(d.getSeconds())}`;
  }

  /* Petite bulle en bas à droite, quelques secondes, pour voir ce qui a été fait. */
  function bulle(message, duree = 5000) {  // duree 0 : reste affichée (une consigne)
    let el = document.getElementById("suivi-paris-bulle");
    if (!el) {
      el = document.createElement("div");
      el.id = "suivi-paris-bulle";
      el.style.cssText = "position:fixed;z-index:2147483647;right:18px;bottom:18px;max-width:340px;background:#1B1340;color:#fff;" +
        "padding:11px 15px;border-radius:13px;font:600 13.5px/1.4 system-ui,sans-serif;box-shadow:0 10px 28px rgba(0,0,0,.3);" +
        "transition:opacity .3s;pointer-events:none";
      document.documentElement.append(el);
    }
    el.textContent = message;
    el.style.opacity = "1";
    if (observateur) observateur.takeRecords();
    clearTimeout(bulle.minuteur);
    if (duree) bulle.minuteur = setTimeout(() => { el.style.opacity = "0"; }, duree);
  }

  /* Le guide sur le site (page principale) : une pastille en bas à gauche ; ouverte, la fiche du site — paris, solde,
     dépôts et retraits — avec ce qui a été lu et envoyé, ou où aller sinon. Ouverte d'elle-même à la première visite
     du site, puis comme on l'a laissée. Dans un « shadow DOM » fermé : son texte n'est jamais lu avec la page. */
  const etatGuide = { paris: null, mvts: null, pageVide: false };
  let guideRacine = null, guideOuvert = false, guideQuestion = null, derniersComptes = null;
  let guideBoite = null, guideDernier = "", guideDebut = "", guideTire = false;
  function placerGuide(x, y) {
    if (!guideBoite) return;
    const r = guideBoite.getBoundingClientRect();
    guideBoite.style.left = `${Math.max(4, Math.min(window.innerWidth - Math.max(r.width, 60) - 4, x))}px`;
    guideBoite.style.top = `${Math.max(4, Math.min(window.innerHeight - Math.max(r.height, 40) - 4, y))}px`;
    guideBoite.style.bottom = "auto";
  }
  const HISTORIQUES = ["betclic", "winamax", "ps3838", "pmu", "unibet"];  // les lectures de outils/
  let derniereDate = null;  // le dernier pari enregistré de ce site, dit par l'appli
  // Sans appli (iPhone) : ce qui est prêt à envoyer, tous sites confondus, pour le bouton « Envoyer vers l'appli ».
  let prets = [], envoiEnCours = false;
  function majPrets() {
    stock.get("attente").then(({ attente = [] }) => { prets = attente.filter((p) => p.statut === "a_envoyer"); guide(); }, () => {});
  }
  let soldeMemorise = null;  // le dernier solde relevé sur ce site (moins de 12 h), pour les pages qui ne l'affichent pas
  const echapper = (x) => String(x ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const eurosGuide = (x) => new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(x);
  /* Ce que voit un cadre (bet365 : l'historique est dans members.bet365.fr) est remis au guide de la page principale. */
  function versGuide(cle, valeur) {
    etatGuide[cle] = valeur;
    if (window === window.top) { guide(); return; }
    try { window.top.postMessage({ suiviParisGuide: { cle, valeur } }, "*"); } catch { /* page fermée */ }
  }
  if (window === window.top) {
    window.addEventListener("message", (e) => {
      const m = e.data && e.data.suiviParisGuide;
      if (!m || !["paris", "mvts", "pageVide"].includes(m.cle)) return;
      let hoteCadre = "";
      try { hoteCadre = new URL(e.origin).hostname; } catch { return; }
      if (!site.hote.test(hoteCadre)) return;  // un cadre du même bookmaker seulement
      etatGuide[m.cle] = m.valeur;
      guide();
    });
  }
  // Un message aux cadres de la page, et à leurs propres cadres (chacun le fait suivre).
  function versCadres(message) {
    for (let i = 0; i < window.frames.length; i++) {
      try { window.frames[i].postMessage(message, "*"); } catch { /* cadre fermé */ }
    }
  }
  function majDerniereDate() {
    versExtension({ type: "dernier", bookmaker }).then((d) => { derniereDate = d || null; guide(); }, () => {});
  }
  async function guide() {
    const fiche = (globalThis.SUIVI_GUIDE || {})[bookmaker];
    if (!fiche || window !== window.top || !document.body) return;
    if (!guideRacine) {
      let ouverts = {};
      try { ({ guides_ouverts: ouverts = {} } = await stock.get("guides_ouverts")); } catch { return; }
      guideOuvert = Boolean(guideQuestion) || ouverts[bookmaker] !== false;
      document.querySelectorAll("#suivi-paris-guide").forEach((x) => x.remove());  // celui d'un ancien script
      const hote = document.createElement("div");
      hote.id = "suivi-paris-guide";
      guideRacine = hote.attachShadow({ mode: "closed" });
      guideRacine.innerHTML = `<style>
      :host { all: initial; }
      .g { position: fixed; left: 16px; bottom: 16px; z-index: 2147483646; font: 13px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif; color: #EEF1FA; }
      .pastille { touch-action: none; display: flex; align-items: center; gap: 8px; padding: 6px 12px 6px 6px; border: 0; border-radius: 999px; cursor: pointer;
        background: #0B1020; color: #fff; font: inherit; font-weight: 700; box-shadow: 0 8px 24px rgba(0,0,0,.35), inset 0 -2px 0 #FFC928; }
      .logo { width: 26px; height: 26px; border-radius: 50%; display: grid; place-items: center; font-size: 10.5px; font-weight: 800; background: var(--bk); color: #fff; }
      .point { width: 8px; height: 8px; border-radius: 50%; background: var(--point); }
      .carte { width: 300px; background: #0B1020; border-radius: 18px; padding: 14px; box-shadow: 0 16px 40px rgba(0,0,0,.4); border-top: 3px solid #FFC928; }
      .tete { cursor: grab; user-select: none; display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
      .tete .logo { width: 34px; height: 34px; border-radius: 11px; font-size: 12px; }
      .tete div { flex: 1; } .tete b { display: block; font-size: 14px; } .tete span { font-size: 11.5px; color: #9AA3BF; }
      .fermer { border: 0; background: rgba(255,255,255,.08); color: #fff; width: 28px; height: 28px; border-radius: 50%; cursor: pointer; font: inherit; }
      ul { list-style: none; margin: 0; padding: 0; display: grid; gap: 6px; }
      li { display: flex; align-items: center; gap: 8px; padding: 8px 10px; border-radius: 12px; background: #141B31; }
      li div { flex: 1; display: grid; } li b { font-size: 12.5px; } small { font-size: 11.5px; color: #9AA3BF; } small b, small i { color: #EEF1FA; }
      em { font-style: normal; font-size: 10.5px; font-weight: 700; padding: 2px 8px; border-radius: 999px; white-space: nowrap; }
      .historique { display: grid; gap: 6px; margin-top: 10px; }
      .historique label { display: flex; align-items: center; justify-content: space-between; gap: 8px; font-size: 12px; color: #9AA3BF; }
      .historique input { font: inherit; padding: 5px 8px; border-radius: 8px; border: 1px solid #263052; background: #141B31; color: #EEF1FA; color-scheme: dark; }
      .action { border: 0; border-radius: 12px; padding: 10px; font: 700 13px system-ui, sans-serif; cursor: pointer; background: #2450F5; color: #fff; }
      .action:hover { filter: brightness(1.1); }
      .historique small { text-align: center; }
      .ok { background: rgba(47,211,138,.16); color: #2FD38A; } .info { background: rgba(36,80,245,.25); color: #9DB4FF; }
      .attente { background: rgba(255,201,40,.16); color: #FFC928; } .non { background: rgba(255,92,115,.16); color: #FF5C73; }
      p { margin: 10px 2px 0; font-size: 11.5px; color: #9AA3BF; }
      .question { display: grid; gap: 4px; padding: 10px; margin-bottom: 8px; border-radius: 12px; background: rgba(255,201,40,.12); border: 1.5px solid #FFC928; }
      .choix { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; }
      .choix button { border: 0; border-radius: 9px; padding: 7px 12px; font: 700 13px system-ui, sans-serif; cursor: pointer; background: #2450F5; color: #fff; }
      .choix .tard { background: transparent; color: #9AA3BF; }
      .lien { border: 0; padding: 0; background: none; color: #FFC928; font: inherit; text-decoration: underline; cursor: pointer; }
    </style><div class="g"></div>`;
      guideBoite = guideRacine.querySelector(".g");
      // Déplaçable : on tire l'en-tête (ou la pastille) ; la place est retenue pour tous les sites.
      try {
        const { guide_place: place } = await stock.get("guide_place");
        if (place) placerGuide(place.x, place.y);
      } catch { /* stockage indisponible */ }
      guideRacine.addEventListener("pointerdown", (e) => {
        const poignee = e.target.closest(".tete, .pastille");
        if (!poignee || e.target.closest("button:not(.pastille), input")) return;
        const r = guideBoite.getBoundingClientRect();
        const dx = e.clientX - r.left, dy = e.clientY - r.top, x0 = e.clientX, y0 = e.clientY;
        let tire = false;
        try { poignee.setPointerCapture(e.pointerId); } catch { /* ancien navigateur */ }  // au-dessus d'un cadre aussi
        const bouger = (m) => {
          if (!tire && Math.hypot(m.clientX - x0, m.clientY - y0) < 5) return;
          tire = true;
          placerGuide(m.clientX - dx, m.clientY - dy);
        };
        const lacher = () => {
          window.removeEventListener("pointermove", bouger, true);
          window.removeEventListener("pointerup", lacher, true);
          if (!tire) return;
          guideTire = true;  // ce n'était pas un clic
          setTimeout(() => { guideTire = false; }, 50);
          const b = guideBoite.getBoundingClientRect();
          stock.set({ guide_place: { x: Math.round(b.left), y: Math.round(b.top) } }).catch(() => {});
        };
        window.addEventListener("pointermove", bouger, true);
        window.addEventListener("pointerup", lacher, true);
      });
      guideRacine.addEventListener("input", (e) => { if (e.target.matches("[data-debut]")) guideDebut = e.target.value; });
      document.documentElement.append(hote);
      if (observateur) observateur.takeRecords();
      majDerniereDate();
      majPrets();
      try { chrome.storage.onChanged.addListener((ch, zone) => { if (zone === "local" && ch.attente) majPrets(); }); } catch { /* Orion */ }
      versCadres({ suiviParisEtat: true });  // les cadres disent ce qu'ils voient (bet365 : page des paris vide)
      stock.get("soldes_lus").then(({ soldes_lus: o = {} }) => {
        const m = o[bookmaker];
        if (m && Date.now() - m.le < 12 * 3600e3 && !soldeMemorise) { soldeMemorise = m; guide(); }
      }).catch(() => {});
      guideRacine.addEventListener("click", async (e) => {
        if (guideTire) return;
        const choix = e.target.closest("[data-compte]");
        if (choix) {
          const q = guideQuestion, nom = choix.textContent;
          guideQuestion = null;
          guide();
          if (choix.dataset.compte === "plus-tard") return;
          retenirCompte(choix.dataset.compte);
          dernierEnTete = null;  // le solde, lu avant de connaître le compte, repart
          setTimeout(verifier, 800);
          const resultats = await versExtension({ type: "confirmer_compte", bookmaker: q.bookmaker, compte_id: Number(choix.dataset.compte) })
            .catch(() => null);
          // Les pages qui attendaient ce choix sont parties : le guide le montre.
          const lusAvant = etatGuide.paris && etatGuide.paris.lus;
          for (const r of resultats || []) {
            if ((r.type || "page") === "page") versGuide("paris", lusAvant ? { ...r, lus: lusAvant } : r);
            else if (r.type === "mouvements") versGuide("mvts", r);
          }
          const messages = (resultats || []).map(messageResultat).filter(Boolean);
          bulle(messages.length ? messages.join(" · ") : `Suivi Paris : compte ${q.libelle} – ${nom} retenu pour cet onglet.`);
          return;
        }
        if (e.target.closest("[data-envoyer]")) {
          if (envoiEnCours) return;
          envoiEnCours = true;
          guide();
          const avant = prets.length;
          const r = await versExtension({ type: "vider" }).catch(() => null);
          envoiEnCours = false;
          bulle(r && r.erreur ? `Suivi Paris : envoi impossible (${r.erreur}). Rien n'est perdu, réessaie plus tard.`
            : r && r.restantes < avant ? "Suivi Paris : envoyé. L'appli l'enregistre à sa prochaine ouverture."
            : "Suivi Paris : rien n'est parti, réessaie dans un instant.");
          majPrets();
          return;
        }
        if (e.target.closest("[data-redemander]")) { if (derniersComptes) choisirCompte(derniersComptes); return; }
        if (e.target.closest("[data-historique]")) {
          if (site.plage) {  // bet365 : l'historique est dans un cadre ; recliquer arrête
            const { plages_en_cours: job } = await stock.get("plages_en_cours").catch(() => ({}));
            if (job && job.bookmaker === bookmaker && Date.now() - job.le < 30 * 60 * 1000) { await arreterPlages(); versCadres({ suiviParisPlages: "arret" }); }
            else await demarrerPlages(guideRacine.querySelector("[data-debut]").value);
            return;
          }
          if (ouverture) { ouverture.arret = true; return; }
          if (site.periodes) { remonterPeriodes(guideRacine.querySelector("[data-debut]").value); return; }
          if (site.ouvrir === true) { ouvrirTous(); return; }
          const r = await versExtension({ type: "historique", site: bookmaker }).catch(() => null);
          if (!r || r.statut !== "lance") bulle(`Suivi Paris : impossible de lancer la récupération (${(r && r.message) || "recharge la page"}).`);
          return;
        }
        if (!e.target.closest("[data-bascule]")) return;
        guideOuvert = !guideOuvert;
        stock.get("guides_ouverts").then(({ guides_ouverts: o = {} }) =>
          stock.set({ guides_ouverts: { ...o, [bookmaker]: guideOuvert } })).catch(() => {});
        guide();
      });
    }
    const [libelle, lettres, couleur, ouParis, mvts] = fiche;
    const s = dernierSolde, p = etatGuide.paris, m = etatGuide.mvts;
    const ligne = (titre, texte, pastille, classe) =>
      `<li><div><b>${titre}</b><small>${texte}</small></div>${pastille ? `<em class="${classe}">${pastille}</em>` : ""}</li>`;
    const lus = p && p.lus ? `${p.lus} pari${p.lus > 1 ? "s" : ""} lu${p.lus > 1 ? "s" : ""} sur cette page · ` : "";
    // Compte à choisir, question fermée (« Plus tard », ou page rechargée) : un bouton la rouvre.
    const choixCompte = guideQuestion ? "dis ci-dessus sur quel compte tu es connecté"
      : derniersComptes ? `<button type="button" class="lien" data-redemander>choisis le compte connecté</button>` : "dis sur quel compte tu es connecté";
    const paris = p && p.statut === "ok"
      ? ligne("Paris", p.nouveaux || p.mis_a_jour ? `${p.nouveaux || 0} nouveau${p.nouveaux > 1 ? "x" : ""}, ${p.mis_a_jour || 0} mis à jour` : `${lus}déjà dans l'appli`, "Envoyé", "ok")
      : p && p.statut === "boite" ? ligne("Paris", `${lus}envoyé, chiffré : enregistré à la prochaine ouverture de l'appli`, "Envoyé", "ok")
      : p && p.statut === "envoi" ? ligne("Paris", `${lus}lecture…`, "Lu", "info")
      : p && p.statut === "a_envoyer" ? ligne("Paris", `${lus}prêts. Envoie-les quand tu veux : fenêtre de l'extension → <b>Envoyer vers l'appli</b>`, "Prêt", "ok")
      : p && p.statut === "sans_reponse" ? ligne("Paris", `${lus}l'extension n'a pas répondu : recharge la page`, "Lu", "attente")
      : p && p.statut === "en_attente" ? ligne("Paris", `${lus}gardés : ${p.erreur ? `envoi impossible (${echapper(p.erreur)}), nouvel essai toutes les minutes` : "appli fermée, envoyés à son ouverture"}`, "En attente", "attente")
      : p && p.statut === "choisir_compte" ? ligne("Paris", `${lus}${choixCompte}`, "Compte ?", "attente")
      : p && p.statut === "aucun_compte" ? ligne("Paris", "Crée d'abord ce compte dans l'appli (page Comptes)", "Compte ?", "attente")
      : etatGuide.pageVide ? ligne("Paris", site.pageParis[1], "À afficher", "attente")
      : ligne("Paris", `Ouvre ${ouParis}`, "À ouvrir", "info");
    // Une page sans le solde (ps3838 « Mes paris », dans un nouvel onglet) : celui relevé avant sur ce site.
    const avant = soldeMemorise && (!s || s.statut === "aucun_solde") ? soldeMemorise : null;
    const solde = avant ? ligne("Solde", `${echapper(eurosGuide(avant.solde))} sur ${echapper(avant.compte)}, relevé à ${echapper(avant.heure)}`, "Relevé", "ok")
      : !s ? ligne("Solde", site.sansSolde ? "Pas affiché par ce site" : "Lu en haut de page", "…", "info")
      : s.statut === "ok" ? ligne("Solde", `${echapper(eurosGuide(s.solde))} sur ${echapper(s.compte)}`, "Relevé", "ok")
      : s.statut === "boite" ? ligne("Solde", `${Number.isFinite(s.solde) ? `${echapper(eurosGuide(s.solde))} · ` : ""}envoyé, chiffré : enregistré à la prochaine ouverture de l'appli`, "Envoyé", "ok")
      : s.statut === "aucun_solde" ? ligne("Solde", "Pas affiché sur cette page : il sera relevé sur l'accueil du site", "Plus tard", "info")
      : s.statut === "aucun_compte" ? ligne("Solde", "Crée d'abord le compte dans l'appli (page Comptes)", "Compte ?", "attente")
      : s.statut === "a_envoyer" ? ligne("Solde", "Prêt, part avec le reste : fenêtre de l'extension → <b>Envoyer vers l'appli</b>", "Prêt", "ok")
      : s.statut === "en_attente" ? ligne("Solde", s.erreur ? `Envoi impossible (${echapper(s.erreur)}) : nouvel essai toutes les minutes` : "Appli fermée : envoyé à son ouverture", "En attente", "attente")
      : ligne("Solde", `${Number.isFinite(s.solde) ? `${echapper(eurosGuide(s.solde))} · ` : ""}${choixCompte}`, "Compte ?", "attente");
    const depots = m && m.statut === "ok" ? ligne("Dépôts et retraits", `${m.nouveaux || 0} nouveau${m.nouveaux > 1 ? "x" : ""} enregistré${m.nouveaux > 1 ? "s" : ""}`, "Envoyé", "ok")
      : ligne("Dépôts et retraits", mvts.ou, { ac: "AsianConnect", main: "À la main" }[mvts.mode] || "À ouvrir", mvts.mode === "main" ? "attente" : "info");
    const pret = [p && p.statut === "ok", s && s.statut === "ok"].filter(Boolean).length;
    // Tout l'historique, d'ici : la lecture du site (Betclic, Winamax…), bwin par périodes, Sportaza pari par pari.
    const historique = HISTORIQUES.includes(bookmaker) || site.periodes || site.plage || site.ouvrir === true;
    const ilYaUnAn = new Date(Date.now() - 365 * 864e5).toISOString().slice(0, 10);
    const blocHistorique = !historique ? "" : `<div class="historique">${site.periodes || site.plage
      ? `<label>Depuis le <input type="date" data-debut value="${guideDebut || ilYaUnAn}"></label>` : ""}
      <button type="button" class="action" data-historique>${ouverture ? "Arrêter la récupération" : "Récupérer tout mon historique"}</button>
      ${site.plage ? `<small>L'extension choisit les dates ; toi, à chaque plage, tu cliques « Afficher l'historique », puis « Retour » quand la bulle le dit. Recliquer ici arrête.</small>` : ""}
      ${derniereDate ? `<small>Dernier pari enregistré : <b>${echapper(derniereDate)}</b></small>` : ""}</div>`;
    // Rendu seulement si quelque chose a changé : la fenêtre ne clignote pas, et la date tapée reste.
    const html = `${guideOuvert ? `<div class="carte">
      <div class="tete"><span class="logo">${echapper(lettres)}</span><div><b>Suivi Paris · ${echapper(libelle)}</b><span>Ce qui est lu sur ce site</span></div>
        <button class="fermer" type="button" data-bascule title="Réduire">–</button></div>
      ${guideQuestion ? `<div class="question"><b>Sur quel compte ${echapper(guideQuestion.libelle || libelle)} es-tu connecté ?</b>
        <small>Rien n'est enregistré avant ta réponse. Elle vaut pour cet onglet.</small>
        <div class="choix">${guideQuestion.comptes.map((c) => `<button type="button" data-compte="${Number(c.id)}">${echapper(c.nom)}</button>`).join("")}
          <button type="button" class="tard" data-compte="plus-tard">Plus tard</button></div></div>` : ""}
      <ul>${paris}${solde}${depots}</ul>
      ${prets.length ? `<div class="historique"><button type="button" class="action" data-envoyer ${envoiEnCours ? "disabled" : ""}>${envoiEnCours
        ? "Envoi…" : `Envoyer vers l'appli (${prets.length} élément${prets.length > 1 ? "s" : ""} prêt${prets.length > 1 ? "s" : ""})`}</button>
        <small>${echapper(prets.map((p) => (globalThis.SUIVI_GUIDE && SUIVI_GUIDE[p.bookmaker] || [p.bookmaker])[0]).filter((v, i, t) => t.indexOf(v) === i).join(", "))} :
          détail dans la fenêtre de l'extension (••• → Suivi Paris)</small></div>` : ""}
      ${blocHistorique}
      <p>Rien à faire de plus : ouvre la page, elle est lue en quelques secondes et envoyée à l'appli.</p></div>`
      : `<button class="pastille" type="button" data-bascule title="Suivi Paris : ce qui est lu sur ce site"><span class="logo">${echapper(lettres)}</span>Suivi Paris<span class="point"></span></button>`}`;
    guideBoite.style.setProperty("--bk", couleur);
    guideBoite.style.setProperty("--point", pret ? "#2FD38A" : "#FFC928");
    if (html === guideDernier) return;
    guideDernier = html;
    guideBoite.innerHTML = html;
  }

  /* Plusieurs comptes chez ce bookmaker : avant d'enregistrer quoi que ce soit, l'extension demande sur quel compte
     tu es connecté (une fois par onglet). Affiché dans la page principale seulement. */
  function choisirCompte(m) {
    if (window !== window.top || !Array.isArray(m.comptes) || !m.comptes.length) return;
    // La question s'affiche dans le guide du site (une seule fenêtre), ouvert pour l'occasion.
    guideQuestion = m;
    derniersComptes = m;
    guideOuvert = true;
    guide();
  }

  function messageResultat(r) {
    if (!r) return null;
    if ((r.statut === "ok" || r.statut === "autre_devise") && r.message) return r.message;
    if (r.statut === "ok" && r.type === "mouvements") {
      const n = r.nouveaux || 0;
      if (!n) return null;
      const quoi = r.sens === "depot" ? "dépôt" : r.sens === "retrait" ? "retrait" : "mouvement";
      return `Suivi Paris : ${n} ${quoi}${n > 1 ? "s" : ""} enregistré${n > 1 ? "s" : ""} (${r.libelle} – ${r.compte})`;
    }
    if (r.statut === "ok") {
      const n = r.nouveaux, m = r.mis_a_jour;
      if (!n && !m) return null;
      const parts = [];
      if (n) parts.push(`${n} nouveau${n > 1 ? "x" : ""} pari${n > 1 ? "s" : ""}`);
      if (m) parts.push(`${m} mis à jour`);
      return `Suivi Paris : ${parts.join(", ")} (${r.libelle} – ${r.compte})`;
    }
    if (r.statut === "en_attente" && r.erreur) return `Suivi Paris : envoi impossible (${r.erreur}). Gardé, nouvel essai toutes les minutes.`;
    if (r.statut === "en_attente") return "Suivi Paris : appli fermée, tes paris seront envoyés à son ouverture.";
    if (r.statut === "boite") return "Suivi Paris : envoyé, chiffré ; enregistré à la prochaine ouverture de l'appli (iPhone ou ordinateur).";
    if (r.statut === "choisir_compte") return null;  // la question du compte s'affiche à la place
    if (r.statut === "a_envoyer") return null;  // le guide le dit : prêt, envoyé depuis la fenêtre de l'extension
    if (r.statut === "aucun_compte") return `Suivi Paris : crée d'abord un compte ${r.libelle} dans l'appli.`;
    return null;
  }

  /* Recharger l'extension (après un git pull) laisse l'ancien script dans les onglets déjà ouverts, coupé de
     l'extension : il doit s'arrêter sans bruit (sinon « Extension context invalidated »). Le nouveau script
     prend la relève au prochain chargement de la page. */
  const vivant = () => {
    try { return Boolean(chrome.runtime && chrome.runtime.id); } catch { return false; }
  };
  let observateur = null;
  let minuteur = null;
  const arreter = () => { if (observateur) observateur.disconnect(); clearTimeout(minuteur); };

  const envoyes = new Set();
  let derniereEmpreinte = null;
  let derniersDetails = "";
  let dernierEnvoi = 0;

  async function envoyer(texte, source, type = "page") {
    const n = type === "page" ? references(texte).length : 0;
    if (n) versGuide("paris", { statut: "envoi", lus: n });  // lus sur la page : le guide le dit tout de suite
    const reponse = await versExtension({ type, bookmaker, texte, url: source, capture_le: maintenantLocal(), compte_id: compteOnglet(), lus: n,
      refs: n ? references(texte).slice(0, 2000) : undefined, apercu: n ? apercuParis(texte) : undefined });
    if (n && !reponse) versGuide("paris", { statut: "sans_reponse", lus: n });
    const message = messageResultat(reponse && { ...reponse, type });
    if (message) bulle(message);
    // Plusieurs comptes et aucun choisi : la question, dans le guide (aussi pour une page de paris).
    if (reponse && reponse.statut === "choisir_compte" && Array.isArray(reponse.comptes) && reponse.comptes.length && !guideQuestion) {
      choisirCompte({ bookmaker, libelle: reponse.libelle, comptes: reponse.comptes });
    }
    // Le compte de l'onglet est maintenant connu (paris enregistrés) : un solde lu avant, sans compte, repart.
    if (reponse && (reponse.statut === "ok" || reponse.statut === "a_envoyer") && dernierSolde && dernierSolde.statut === "choisir_compte") {
      dernierEnTete = null;
      setTimeout(verifier, 500);
    }
    if (reponse && reponse.statut !== "aucun_pari" && reponse.statut !== "aucun_mouvement") {
      if (window === window.top && reponse.statut === "ok" && reponse.nouveaux) majDerniereDate();
      versGuide(type === "mouvements" ? "mvts" : "paris", n ? { ...reponse, lus: n } : reponse);    } else if (n && reponse) versGuide("paris", null);  // rien de lisible pour l'appli : plus d'« envoi en cours »
    return reponse;
  }
  let dernierEnTete = null;
  let dernierSolde = null;  // la réponse de l'appli au dernier solde envoyé, pour l'icône de l'extension
  let derniersMouvements = null;

  /* bet365 : l'historique n'affiche que les derniers paris (ou dépôts, retraits), « Afficher plus » charge les
     suivants. Le script le clique à ta place, une fois chargée la page précédente, jusqu'à retomber sur un pari déjà
     envoyé (au premier passage : tout l'historique ; dépôts et retraits : toujours toute la liste, elle est courte).
     Tout part ensuite en un seul envoi. */
  const MAX_CLICS = 1000;
  const pause = (ms) => new Promise((r) => setTimeout(r, ms));
  let chargement = false;
  let listeChargee = null;
  function boutonPlus() {
    if (!site.plus) return null;
    const racines = [document, ...racinesOmbre(document, site.ombres === "profond")];
    for (const racine of racines) {
      const egal = (t) => (site.plus instanceof RegExp ? site.plus.test(t) : t === site.plus);
      const b = auPlusProfond(racine, egal);
      if (b) return b;
    }
    return null;
  }
  const CLE_VUS = `${bookmaker}Vus`;
  async function dejaVus() {
    const { [CLE_VUS]: vus = [] } = await stock.get(CLE_VUS);
    return new Set(vus);
  }
  async function noterVus(refs) {
    const vus = [...new Set([...refs, ...(await dejaVus())])].slice(0, 20000);
    await stock.set({ [CLE_VUS]: vus });
  }
  /* La plage de dates choisie sur le site (« Du 14/04/2026 Au 13/10/2026 »), en « 2026-04-14 » ; null si absente. */
  function debutPlage(texte) {
    const m = texte.match(/Du\s+(\d{2})\/(\d{2})\/(\d{4})\s+Au\s+\d{2}\/\d{2}\/\d{4}/i);
    return m ? `${m[3]}-${m[2]}-${m[1]}` : null;
  }
  /* Le plancher : le début de la plus ancienne plage chargée jusqu'au bout. Tout ce qui est plus récent a déjà été
     vu ; une plage qui remonte plus loin doit être chargée en entier, même si ses premiers paris sont connus. */
  const CLE_PLANCHER = `${bookmaker}Plancher`;

  /* Renvoie true si la liste a été chargée jusqu'au bout (plus de bouton). */
  async function toutAfficher(compter, vus = new Set(), quoi = "paris") {
    chargement = true;
    try {
      for (let n = 0; n < MAX_CLICS; n++) {
        const bouton = boutonPlus();
        const refs = compter(texteDe(document.body));
        if (!bouton) return true;
        if (!vivant() || (refs.length && vus.has(refs[refs.length - 1]))) break;
        bulle(`Suivi Paris : chargement de l'historique… ${refs.length} ${quoi}`);
        bouton.scrollIntoView({ block: "center" });
        bouton.click();
        let charges = refs.length;
        for (let t = 0; t < 12 && charges <= refs.length; t++) {  // 6 s au plus
          await pause(500);
          charges = compter(texteDe(document.body)).length;
        }
        if (charges <= refs.length) return !boutonPlus();  // rien de plus : fin de la liste (ou clic ignoré)
        await pause(800);
      }
      return false;
    } finally {
      chargement = false;
    }
  }

  /* bet365 « Plage de dates » (6 mois au plus) : depuis la date choisie jusqu'à aujourd'hui, une plage après l'autre.
     Pour chaque plage, « Du » puis « Au » sont choisis dans le calendrier du site (flèches du mois, puis le jour),
     « Afficher l'historique », tout « Afficher plus », et la liste part vers l'appli. */
  // La page et ses cadres du même site (bet365 peut afficher les résultats dans un cadre à l'intérieur du cadre).
  function documents() {
    const liste = [document];
    for (let k = 0; k < liste.length; k++) {
      for (const f of liste[k].querySelectorAll("iframe")) {
        try { if (f.contentDocument && f.contentDocument.body) liste.push(f.contentDocument); } catch { /* autre site */ }
      }
    }
    return liste;
  }
  function trouverPartout(texte) {
    const egal = (t) => (texte instanceof RegExp ? texte.test(t) : t === texte);
    for (const d of documents()) { const e = auPlusProfond(d, egal); if (e) return e; }
    return null;
  }
  /* Un vrai clic, comme à la souris : certains sites (bet365 « Retour », un <div role="link">) n'écoutent que
     l'appui ou le relâchement, pas le seul « click » ; et la touche Entrée pour un lien au clavier. */
  function cliquer(e, clavier = false) {
    const r = e.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, composed: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
    const vue = e.ownerDocument.defaultView;
    for (const [type, C] of [["pointerdown", vue.PointerEvent || vue.MouseEvent], ["mousedown", vue.MouseEvent],
      ["pointerup", vue.PointerEvent || vue.MouseEvent], ["mouseup", vue.MouseEvent], ["click", vue.MouseEvent]]) {
      e.dispatchEvent(new C(type, { ...o, pointerId: 1, isPrimary: true }));
    }
    if (clavier) {
      e.focus();
      for (const type of ["keydown", "keypress", "keyup"]) {
        e.dispatchEvent(new vue.KeyboardEvent(type, { bubbles: true, cancelable: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 }));
      }
    }
  }
  const libellesDates = () => documents().flatMap((d) => [...d.querySelectorAll("[class*='DatePicker_DateLabel']")]);
  const texteToutes = () => documents().map((d) => (d === document ? texteDe(document.body) : d.body.innerText)).join("\n");
  const MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
  async function choisirJour(rang, date) {
    const libelles = libellesDates();
    const libelle = libelles[rang];
    if (!libelle) {
      // Ce que voit l'extension à ce moment, pour comprendre (dit dans la bulle).
      const docs = documents();
      throw new Error(`champ de date introuvable : ${libelles.length} champ(s), « Retour » ${trouverPartout(/^‹?\s*Retour$/) ? "présent" : "absent"}, `
        + `« Plage de dates » ${trouverPartout("Plage de dates") ? "présent" : "absent"}, « Du: » ${trouverPartout(/^Du\s*:?$/) ? "présent" : "absent"}, `
        + `${docs.length} document(s), ${location.hostname}${location.pathname}`);
    }
    const cible = `${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`;
    if (libelle.textContent.trim() === cible) return;
    libelle.click();
    const entete = async () => {
      for (let t = 0; t < 30; t++) {
        if (t === 15 && libelle.nextElementSibling) libelle.nextElementSibling.click();  // l'icône du calendrier
        const e = trouverPartout(new RegExp(`^(${MOIS.join("|")}) \\d{4}$`, "i"));
        if (e) return e;
        await pause(100);
      }
      throw new Error("calendrier fermé");
    };
    for (let n = 0; n < 240; n++) {  // 20 ans de mois au plus
      const e = await entete();
      const [mot, an] = e.textContent.trim().toLowerCase().split(" ");
      const ecart = (date.getFullYear() - Number(an)) * 12 + date.getMonth() - MOIS.indexOf(mot);
      if (!ecart) break;
      // L'en-tête du mois et ses flèches, de part et d'autre (en remontant jusqu'à la ligne qui les contient).
      let h = e;
      while (h.parentElement && [...h.parentElement.children].filter(visible).length < 3) h = h.parentElement;
      const freres = [...h.parentElement.children].filter((x) => x !== h && visible(x));
      const fleche = ecart < 0 ? freres[0] : freres[freres.length - 1];
      if (!fleche) throw new Error("flèches du calendrier introuvables");
      fleche.click();
      await pause(150);
    }
    // Les cases du mois affiché : du premier « 1 » au suivant (avant et après, les jours des mois voisins).
    const e = await entete();
    const chiffres = (z) => [...z.querySelectorAll("*")].filter((x) => !x.childElementCount && /^\d{1,2}$/.test(x.textContent.trim()) && visible(x));
    let zone = e.parentElement;
    while (zone.parentElement && chiffres(zone).length < 28) zone = zone.parentElement;  // le calendrier entier
    const cases = chiffres(zone);
    const premier = cases.findIndex((x) => x.textContent.trim() === "1");
    const jour = cases[premier + date.getDate() - 1];
    if (premier < 0 || !jour || jour.textContent.trim() !== String(date.getDate())) throw new Error("jour introuvable");
    jour.click();
    for (let t = 0; t < 10 && libelle.textContent.trim() !== cible; t++) await pause(100);
    if (libelle.textContent.trim() !== cible) throw new Error(`date ${cible} refusée par le site`);
  }
  /* bet365, à moitié automatique (le site n'accepte pas les clics de l'extension sur « Retour » et « Afficher
     l'historique ») : l'extension choisit Du / Au, tu cliques « Afficher l'historique » ; elle charge et envoie toute
     la plage, tu cliques « Retour » ; elle choisit la plage suivante, et ainsi de suite jusqu'à aujourd'hui. L'étape
     en cours est retenue (plages_en_cours) : le cadre qui montre le formulaire ou les résultats la reprend. */
  let etapeEnCours = false;
  const isoJour = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  async function demarrerPlages(debut) {
    await stock.set({ plages_en_cours: { bookmaker, debut, attente: "dates", lues: 0, nouveaux: 0, le: Date.now() } });
    versCadres({ suiviParisPlages: debut });
    etapePlages();
  }
  async function arreterPlages() {
    await stock.remove("plages_en_cours").catch(() => {});
    bulle("Suivi Paris : récupération arrêtée.");
  }
  async function etapePlages() {
    if (!site.plage || etapeEnCours) return;
    let job = null;
    try { ({ plages_en_cours: job } = await stock.get("plages_en_cours")); } catch { return; }
    if (!job || job.bookmaker !== bookmaker || Date.now() - job.le > 30 * 60 * 1000) return;
    etapeEnCours = true;
    const fr = (d) => d.toLocaleDateString("fr-FR");
    const sauver = (m) => stock.set({ plages_en_cours: { ...job, ...m, le: Date.now() } });
    try {
      const fin = new Date(); fin.setHours(0, 0, 0, 0);
      const a = new Date(`${job.debut}T00:00:00`);
      const b = new Date(a); b.setMonth(b.getMonth() + site.plage); b.setDate(b.getDate() - 1);
      if (b > fin) b.setTime(fin.getTime());
      const texte = texteToutes();
      const resultats = !libellesDates().length && (references(texte).length || /aucune information|aucun pari/i.test(texte));
      if (job.attente === "dates" && (libellesDates().length || trouverPartout("Plage de dates"))) {
        for (let t = 0; t < 15 && !libellesDates().length; t++) {
          const plage = trouverPartout("Plage de dates");
          if (plage && t % 5 === 0) cliquer(plage, t > 0);
          await pause(200);
        }
        if (!libellesDates().length) { bulle("Suivi Paris : clique sur l'onglet « Plage de dates ».", 0); return; }
        await choisirJour(0, a);
        await choisirJour(1, b);
        await sauver({ attente: "afficher" });
        bulle(`Suivi Paris : du ${fr(a)} au ${fr(b)}. Clique sur « Afficher l'historique ».`, 0);
      } else if (job.attente === "afficher" && resultats) {
        bulle(`Suivi Paris : du ${fr(a)} au ${fr(b)}, chargement…`, 0);
        await pause(800);
        chargement = false;
        await toutAfficher(references);
        chargement = true;
        // Une liste qui se charge en descendant : en bas, jusqu'à ce que rien de neuf n'arrive.
        let n = references(texteToutes()).length;
        for (let calme = 0; calme < 3;) {
          for (const d of documents()) d.defaultView.scrollTo(0, d.documentElement.scrollHeight);
          await pause(700);
          const m = references(texteToutes()).length;
          calme = m > n ? 0 : calme + 1;
          n = m;
          bulle(`Suivi Paris : du ${fr(a)} au ${fr(b)}, ${m} paris chargés…`, 0);
        }
        chargement = false;
        let nouveaux = 0;
        if (n) {
          const r = await envoyer(texteToutes(), location.href).catch(() => null);
          if (r && r.statut !== "ok") { bulle("Suivi Paris : envoi refusé (compte à choisir ?). Réponds à la question, puis recommence.", 0); return; }
          nouveaux = (r && r.nouveaux) || 0;
        }
        const suivant = new Date(b); suivant.setDate(suivant.getDate() + 1);
        const lues = (job.lues || 0) + 1, total = (job.nouveaux || 0) + nouveaux;
        if (suivant > fin) {
          await stock.remove("plages_en_cours").catch(() => {});
          bulle(`Suivi Paris : c'est fini ! ${lues} plage${lues > 1 ? "s" : ""} lue${lues > 1 ? "s" : ""}, ${total} nouveau${total > 1 ? "x" : ""} pari${total > 1 ? "s" : ""}.`, 15000);
        } else {
          await sauver({ debut: isoJour(suivant), attente: "dates", lues, nouveaux: total });
          bulle(`Suivi Paris : plage lue (${n} paris). Clique sur « Retour » : la plage suivante (du ${fr(suivant)}) sera choisie toute seule.`, 0);
        }
      }
    } catch (e) {
      bulle(`Suivi Paris : ${e.message || e}. Choisis les dates toi-même, ou recommence.`, 0);
    } finally {
      chargement = false;
      etapeEnCours = false;
    }
  }

  /* « Ouvrir tous les paris » (bouton de l'icône, Sportaza) : la liste ne montre le choix et la date de l'événement
     que d'un pari ouvert, un à la fois. Le script clique sur le titre de chaque pari (jamais sur un bouton : ni
     « Retirer », ni cash-out), attend son détail et l'envoie, puis passe au suivant. Les paris déjà ouverts une fois
     sont sautés. Rien d'autre n'est touché ; recliquer sur le bouton de l'icône arrête. */
  const CLE_OUVERTS = `${bookmaker}Ouverts4`;  // « 4 » : tout est rouvert une fois (années, matchs)
  const INTERDITS = /retirer|cash ?-?out|encaisser|supprimer|annuler|miser|parier|épingler|imprimer|withdraw|cancel|delete|place bet|bet now|print|share|partager/i;
  let ouverture = null;  // { arret: bool } pendant l'ouverture des paris
  function carteDe(ref) {
    for (const racine of [document, ...racinesOmbre(document, true)]) {
      const fin = new RegExp(`(?:Numéro d'identification|ID):\\s*${ref}$`);
      const id = [...racine.querySelectorAll("*")].find((e) => !e.childElementCount
        && fin.test(e.textContent.trim().replace(/\s+/g, " ")));
      if (!id) continue;
      // La carte du pari : le plus grand ancêtre qui ne contient que ce pari (un seul « Cotes totales »).
      let carte = id;
      for (let e = id.parentElement; e && e !== racine; e = e.parentElement) {
        if ((e.textContent.match(/Cotes totales|Total odds/g) || []).length > 1) break;
        carte = e;
      }
      return carte;
    }
    return null;
  }
  const detailOuvert = (carte) => /\d{2}\/\d{2}\s*•\s*\d{1,2}:\d{2}[\s\S]*(Cotes totales|Total odds)/.test(carte.innerText || carte.textContent);
  const nbLignes = (carte) => (carte.innerText || "").split("\n").filter((l) => l.trim()).length;
  const ETAT_PARI = /^(GAGNÉ|PERDU|NUL|REMBOURSÉ|ANNULÉ|CASH ?OUT|RETIRÉ|EN COURS|OUVERT|EN ATTENTE|WON|LOST|VOID|PUSH|REFUNDED|PENDING|OPEN)$/i;
  async function ouvrirTous() {
    if (!site.ouvrir || ouverture) return;
    ouverture = { arret: false };
    chargement = true;
    let ouverts = 0, echecs = 0;
    try {
      const { [CLE_OUVERTS]: deja = [] } = await stock.get(CLE_OUVERTS);
      const faits = new Set(deja);
      const lireRefs = () => references(texteDe(document.body)).map((r) => (r.match(/\d{6,}/) || [""])[0]).filter(Boolean);
      const traites = new Set();
      let stop = false;
      // Les paris affichés, puis « Afficher plus de paris » et les suivants, jusqu'au bout de la liste.
      while (!stop && !ouverture.arret && vivant()) {
        const refs = lireRefs();
        const aFaire = refs.filter((r) => !faits.has(r) && !traites.has(r));
        for (const ref of aFaire) {
          if (ouverture.arret || !vivant()) { stop = true; break; }
          traites.add(ref);
          bulle(`Suivi Paris : ouverture des paris… ${ouverts + echecs + 1} (${refs.length} affichés ; reclique sur le bouton de l'icône pour arrêter)`);
          const carte = carteDe(ref);
          if (!carte) { echecs++; continue; }
          // Ouvert : la carte compte plus de lignes qu'avant le clic (le choix, la cote… ; la date de l'événement
          // n'est pas toujours donnée).
          let ouvert = detailOuvert(carte);
          if (!ouvert) {
            const avant = nbLignes(carte);
            // Le titre du pari (sa première ligne : « Tour d'Italie 2026 - Étape 19 - Top 3 », « Combiné », « A vs. B »),
            // sinon l'état, sinon la carte elle-même ; jamais un bouton ni un lien.
            const feuilles = [...carte.querySelectorAll("*")].filter((e) => !e.childElementCount && e.textContent.trim()
              && !INTERDITS.test(e.textContent) && !e.closest("button,a,input,select"));
            const titre = feuilles[0];
            const etatPari = feuilles.find((e) => ETAT_PARI.test(e.textContent.trim()));
            for (const cible of [titre, etatPari, carte].filter(Boolean)) {
              cible.scrollIntoView({ block: "center" });
              cible.click();
              for (let t = 0; t < 10; t++) {
                await pause(300);
                const c = carteDe(ref) || carte;
                if (detailOuvert(c) || nbLignes(c) >= avant + 2) { ouvert = true; break; }
              }
              if (ouvert) break;
            }
          }
          if (!ouvert) { echecs++; continue; }
          const r = await envoyer(texteDe(document.body), location.href).catch(() => null);
          if (r && r.statut === "ok") {
            faits.add(ref);
            ouverts++;
            await stock.set({ [CLE_OUVERTS]: [...faits].slice(-20000) });
          } else if (r && r.statut !== "ok") {
            stop = true;  // compte à choisir, appli fermée… : le message de l'envoi le dit
            break;
          }
          await pause(400);
        }
        if (stop || ouverture.arret) break;
        const bouton = boutonPlus();
        if (!bouton) break;  // fin de la liste
        bulle(`Suivi Paris : chargement des paris suivants… (${refs.length} affichés)`);
        bouton.scrollIntoView({ block: "center" });
        bouton.scrollIntoView({ block: "center" });
        bouton.click();
        let charges = refs.length;
        for (let t = 0; t < 20 && charges <= refs.length; t++) {  // 10 s au plus
          await pause(500);
          charges = lireRefs().length;
        }
        if (charges <= refs.length) break;  // plus rien ne vient
        await pause(600);
      }
    } finally {
      chargement = false;
      ouverture = null;
    }
    bulle(`Suivi Paris : ${ouverts} pari${ouverts > 1 ? "s" : ""} ouvert${ouverts > 1 ? "s" : ""} et envoyé${ouverts > 1 ? "s" : ""}`
      + (echecs ? ` (${echecs} pas ouvert${echecs > 1 ? "s" : ""})` : "") + ".");
  }

  /* bwin, « Évalué » : le filtre ne montre que 90 jours à la fois. Depuis la date choisie dans l'icône, le script
     remplit lui-même le filtre (date de début, date de fin), clique sur « Afficher résultats », charge la liste et
     l'envoie, puis passe aux 90 jours suivants, jusqu'à aujourd'hui. Il ne touche qu'au filtre ; recliquer sur le
     bouton de l'icône arrête. */
  const visible = (e) => e && e.getClientRects().length > 0;
  /* L'élément visible dont le texte est celui cherché, le plus profond : « Retour » dans <a><i></i>Retour</a> est le
     lien entier (son texte n'est pas dans un élément à lui seul). */
  function auPlusProfond(racine, egal) {
    return [...racine.querySelectorAll("*")].find((x) => visible(x) && egal(x.textContent.trim())
      && ![...x.children].some((c) => egal(c.textContent.trim()))) || null;
  }
  function feuille(texte) {
    const re = texte instanceof RegExp ? texte : null;
    const egal = (t) => (re ? re.test(t) : t === texte);
    for (const racine of [document, ...racinesOmbre(document, true)]) {
      const e = auPlusProfond(racine, egal);
      if (e) return e;
    }
    return null;
  }
  function champDate(libelle, rang) {
    const etiquette = feuille(libelle);
    for (let e = etiquette; e && e !== document.body; e = e.parentElement) {
      const champ = e.querySelector("input");
      if (champ && visible(champ)) return champ;
    }
    const champs = [...document.querySelectorAll("input")].filter((c) => visible(c)
      && /date|text/.test(c.type) && !/recherche|search/i.test(c.placeholder || c.name || ""));
    return champs[rang] || null;
  }
  function remplir(champ, jour) {
    const deux = (n) => String(n).padStart(2, "0");
    const valeur = champ.type === "date"
      ? `${jour.getFullYear()}-${deux(jour.getMonth() + 1)}-${deux(jour.getDate())}`
      : `${deux(jour.getDate())}/${deux(jour.getMonth() + 1)}/${jour.getFullYear()}`;
    champ.focus();
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(champ, valeur);
    for (const type of ["input", "change", "blur"]) champ.dispatchEvent(new Event(type, { bubbles: true }));
  }
  /* La date tapée touche par touche, pour un site qui ne lit que la frappe (calendrier masqué). */
  async function taper(champ, jour) {
    const deux = (n) => String(n).padStart(2, "0");
    const valeur = champ.type === "date"
      ? `${jour.getFullYear()}-${deux(jour.getMonth() + 1)}-${deux(jour.getDate())}`
      : `${deux(jour.getDate())}/${deux(jour.getMonth() + 1)}/${jour.getFullYear()}`;
    const poser = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    champ.focus();
    poser.call(champ, "");
    champ.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContentBackward" }));
    for (const c of valeur) {
      champ.dispatchEvent(new KeyboardEvent("keydown", { key: c, bubbles: true }));
      poser.call(champ, champ.value + c);
      champ.dispatchEvent(new InputEvent("input", { bubbles: true, data: c, inputType: "insertText" }));
      champ.dispatchEvent(new KeyboardEvent("keyup", { key: c, bubbles: true }));
      await pause(20);
    }
    champ.dispatchEvent(new Event("change", { bubbles: true }));
    champ.dispatchEvent(new Event("blur", { bubbles: true }));
  }
  /* La plage affichée par bwin au-dessus de la liste (« 25/07/2026 - 22/10/2026 »), s'il y a des paris. */
  const plageAffichee = (texte) => (texte.match(/(\d{2}\/\d{2}\/\d{4})\s*-\s*(\d{2}\/\d{2}\/\d{4})/) || [""])[0]
    .replace(/\s+/g, " ");
  const decrireChamps = () => [...document.querySelectorAll("input")].filter(visible)
    .map((c) => `${c.type}${c.placeholder ? ` « ${c.placeholder} »` : ""}`).slice(0, 6).join(", ") || "aucun";
  function ancetresDefilants(e) {
    const liste = [];
    for (let x = e && e.parentElement; x && x !== document.documentElement; x = x.parentElement) {
      const style = getComputedStyle(x);
      if (x.scrollHeight > x.clientHeight + 10 && /auto|scroll/.test(style.overflowY)) liste.push(x);
    }
    return liste;
  }
  async function defilerEtEnvoyer(periode, total) {
    const vus = new Set();
    let nouveaux = 0, calme = 0;
    const envoyerSiNouveau = async () => {
      const texte = texteDe(document.body);
      const refs = references(texte);
      const neufs = refs.filter((r) => !vus.has(r));
      if (!neufs.length) return { neufs: 0 };
      refs.forEach((r) => vus.add(r));
      const r = await envoyer(texte, location.href).catch(() => null);
      if (r && r.statut === "ok") nouveaux += r.nouveaux || 0;
      return { neufs: neufs.length, stop: Boolean(r && r.statut !== "ok") };
    };
    let r = await envoyerSiNouveau();
    if (r.stop) return { nouveaux, stop: true };
    // Descendre la liste écran par écran, en relisant à chaque pas : un pari affiché puis retiré plus bas (liste qui
    // ne garde que ce qui est à l'écran) est lu au passage. En bas : la suite se charge, on continue ; deux fois
    // rien de neuf en bas, c'est fini.
    window.scrollTo(0, 0);
    await pause(300);
    for (let k = 0; k < 3000 && calme < 2; k++) {
      if (ouverture.arret || !vivant()) break;
      const reperes = [...document.querySelectorAll("*")].filter((e) => !e.childElementCount
        && /^(Détail|Épingler \(en haut\))$/.test(e.textContent.trim()) && visible(e));
      const defilants = ancetresDefilants(reperes[reperes.length - 1]);
      const fenetreEnBas = window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 8;
      const enBas = fenetreEnBas && defilants.every((e) => e.scrollTop + e.clientHeight >= e.scrollHeight - 8);
      if (!enBas) {
        window.scrollBy(0, Math.round(window.innerHeight * 0.7));
        for (const e of defilants) e.scrollTop += Math.round(e.clientHeight * 0.7);
        await pause(350);
        r = await envoyerSiNouveau();
        if (r.stop) return { nouveaux, stop: true };
        if (r.neufs) calme = 0;
        bulle(`Suivi Paris : période ${periode} sur ${total}, ${vus.size} paris lus…`);
        continue;
      }
      // En bas : « Afficher plus » s'il y en a un ; sinon remonter un peu et revenir, ce qui charge la suite.
      const hauteur = document.documentElement.scrollHeight + defilants.reduce((t, e) => t + e.scrollHeight, 0);
      const plus = feuille(/^(Afficher plus|Charger plus|Voir plus|Plus de paris)$/i);
      if (plus) plus.click();
      else {
        window.scrollBy(0, -window.innerHeight);
        for (const e of defilants) e.scrollTop = Math.max(0, e.scrollTop - e.clientHeight);
        await pause(150);
        window.scrollTo(0, document.documentElement.scrollHeight);
        for (const e of defilants) e.scrollTop = e.scrollHeight;
      }
      let neufs = 0, grandi = false;
      for (let t = 0; t < 10 && !neufs && !grandi; t++) {  // 2 s au plus pour que la suite arrive
        await pause(200);
        r = await envoyerSiNouveau();
        if (r.stop) return { nouveaux, stop: true };
        neufs = r.neufs;
        grandi = document.documentElement.scrollHeight + defilants.reduce((x, e) => x + e.scrollHeight, 0) > hauteur + 20;
      }
      calme = neufs || grandi ? 0 : calme + 1;
      bulle(`Suivi Paris : période ${periode} sur ${total}, ${vus.size} paris lus…`);
    }
    window.scrollTo(0, 0);
    return { nouveaux, stop: false };
  }

  async function remonterPeriodes(debut) {
    if (!site.periodes || ouverture) return;
    ouverture = { arret: false };
    chargement = true;
    const fr = (d) => d.toLocaleDateString("fr-FR");
    let lues = 0, nouveaux = 0, message = "";
    try {
      const aujourdHui = new Date();
      const fenetres = [];
      for (let d = new Date(`${debut}T12:00:00`); d <= aujourdHui;) {
        const f = new Date(d);
        f.setDate(f.getDate() + site.periodes - 1);
        fenetres.push([new Date(d), f > aujourdHui ? new Date(aujourdHui) : f]);
        d = new Date(f);
        d.setDate(d.getDate() + 1);
      }
      for (const [n, [a, b]] of fenetres.entries()) {
        if (ouverture.arret || !vivant()) break;
        bulle(`Suivi Paris : période ${n + 1} sur ${fenetres.length} (${fr(a)} → ${fr(b)})…`);
        if (!feuille("Date de début")) {
          const filtre = feuille("Filtre");
          if (filtre) {
            filtre.click();
            for (let t = 0; t < 20 && !feuille("Date de début"); t++) await pause(100);
          }
        }
        const champDebut = champDate("Date de début", 0), champFin = champDate("Date de fin", 1);
        const bouton = feuille(/^Afficher (les )?résultats$/i);
        if (!champDebut || !champFin || champDebut === champFin || !bouton) {
          message = `Suivi Paris : filtre de dates introuvable (champs vus : ${decrireChamps()}). Envoie une capture du filtre ouvert.`;
          break;
        }
        remplir(champDebut, a);
        await pause(80);
        remplir(champFin, b);
        await pause(80);
        // Le champ a-t-il gardé la date ? Sinon (le site ne lit que la frappe au clavier), on la tape.
        for (const [champ, jour] of [[champDebut, a], [champFin, b]]) {
          if (!champ.value || !champ.value.replace(/\D/g, "").includes(String(jour.getFullYear()))) {
            await taper(champ, jour);
          }
        }
        const avant = texteDe(document.body);
        bouton.click();
        // La liste de la période : des paris (dès qu'elle a changé), ou « Vous n'avez pas de paris évalués ».
        // Une période vide après une autre période vide ne change rien à la page : 1,5 s suffit alors, pas
        // besoin d'attendre un changement qui ne viendra pas.
        let vide = false, plage = "";
        const attendue = `${fr(a)} - ${fr(b)}`;
        for (let t = 1; t <= 40; t++) {
          await pause(250);
          const t2 = texteDe(document.body);
          plage = plageAffichee(t2);
          if (references(t2).length && (plage === attendue || (!plage && t2 !== avant))) break;
          if (/pas de paris/i.test(t2) && (t2 !== avant || t >= 4)) { vide = true; break; }
        }
        // bwin affiche encore une autre période : il n'a pas pris nos dates. Mieux vaut s'arrêter et le dire que
        // relire dix fois la même liste.
        if (!vide && plage && plage !== attendue) {
          message = `Suivi Paris : bwin n'a pas pris les dates ${attendue} (il affiche ${plage}). Choisis cette période à la main une fois, puis relance ; sinon envoie une capture du filtre ouvert.`;
          break;
        }
        lues++;
        if (!vide) {
          await pause(200);
          // La liste se charge au fil du défilement : on descend jusqu'en bas, en envoyant à chaque fois les
          // paris apparus (si la page retire ceux du haut en descendant, ils sont déjà partis).
          const r = await defilerEtEnvoyer(n + 1, fenetres.length);
          nouveaux += r.nouveaux;
          if (r.stop) break;
        }
        await pause(200);
      }
    } finally {
      chargement = false;
      ouverture = null;
    }
    bulle(message || `Suivi Paris : ${lues} période${lues > 1 ? "s" : ""} lue${lues > 1 ? "s" : ""}, ${nouveaux} nouveau${nouveaux > 1 ? "x" : ""} pari${nouveaux > 1 ? "s" : ""}.`);
  }

  /* NetBet : « Voir les détails » de chaque combiné de la page, un par un, puis la page entière envoyée. */
  async function ouvrirDetails() {
    if (ouverture) return;
    ouverture = { arret: false };
    chargement = true;
    let ouverts = 0;
    try {
      for (let k = 0; k < 200 && !ouverture.arret && vivant(); k++) {
        const lien = feuille("Voir les détails");
        if (!lien) break;
        lien.scrollIntoView({ block: "center" });
        lien.click();
        for (let t = 0; t < 15 && lien.isConnected && lien.textContent.trim() === "Voir les détails"; t++) await pause(100);
        ouverts++;
        bulle(`Suivi Paris : ${ouverts} combiné${ouverts > 1 ? "s" : ""} ouvert${ouverts > 1 ? "s" : ""}…`);
        await pause(150);
      }
      await envoyer(texteDe(document.body), location.href).catch(() => null);
    } finally {
      chargement = false;
      ouverture = null;
    }
    bulle(`Suivi Paris : ${ouverts} combiné${ouverts > 1 ? "s" : ""} ouvert${ouverts > 1 ? "s" : ""}, page envoyée. Passe à la page suivante et recommence.`);
  }

  async function verifier() {
    if (!vivant()) { arreter(); return; }
    if (chargement) return;
    let actif = true;
    ({ actif = true } = await stock.get("actif"));
    if (!actif || !document.body || site.copie) return;
    const texte = texteDe(document.body);
    const vide = Boolean(site.pageParis && site.pageParis[0].test(texte) && !references(texte).length);
    if (vide !== etatGuide.pageVide) versGuide("pageVide", vide);
    if (site.plage) etapePlages();
    // Le solde : à chaque changement du haut de page (sans bulle, c'est discret).
    const tete = enTete(texte);
    if (!site.sansSolde && tete !== dernierEnTete) {
      dernierEnTete = tete;
      versExtension({ type: "solde", bookmaker, texte: tete, url: location.href, capture_le: maintenantLocal(), compte_id: compteOnglet(),
        apercu: apercuSolde(tete) })
        .then((r) => {
          dernierSolde = r || null;
          if (r && r.statut === "ok") {
            soldeMemorise = { solde: r.solde, compte: r.compte, heure: new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }) };
            stock.get("soldes_lus").then(({ soldes_lus: o = {} }) =>
              stock.set({ soldes_lus: { ...o, [bookmaker]: { ...soldeMemorise, le: Date.now() } } })).catch(() => {});
          }
          // Plusieurs comptes et aucun choisi pour cet onglet : la question, dans le guide.
          if (r && r.statut === "choisir_compte" && Array.isArray(r.comptes) && r.comptes.length && !guideQuestion) {
            choisirCompte({ bookmaker, libelle: r.libelle, comptes: r.comptes });
          } else guide();
        }, () => {});
    }
    // Les dépôts et retraits (bet365 : toute la liste d'abord).
    if (estPageMouvements(texte)) {
      const liste = `mouvements|${location.href}|${lignesMouvements(texte).length ? texte.split("\n").find((l) => /\d{2}\/\d{2}\/\d{4}/.test(l)) : ""}`;
      if (site.plus && liste !== listeChargee && boutonPlus()) {
        listeChargee = liste;
        await toutAfficher(lignesMouvements, new Set(), "mouvements");
        return verifier();
      }
      const e = empreinte(texte);
      if (e !== derniersMouvements) {
        derniersMouvements = e;
        try { await envoyer(await avecPagesSuivantes(texte), location.href, "mouvements"); } catch { /* extension rechargée */ }
      }
    }
    const refs = references(texte);
    if (!refs.length) return;
    // Une fois par liste (onglet, plage de dates, premier pari affiché) : la relecture qui suit ne relance pas le
    // chargement, mais élargir la plage sur le site, si.
    const plage = debutPlage(texte);
    const liste = `${(texte.match(/^Paris (terminés|en cours)/m) || [""])[0]}|${plage}|${refs[0]}`;
    if (site.plus && liste !== listeChargee && boutonPlus()) {
      listeChargee = liste;
      // « Paris terminés » : jusqu'au premier pari déjà envoyé, sauf si la plage remonte avant tout ce qui a déjà été
      // chargé ; « en cours » : toujours tout.
      const { [CLE_PLANCHER]: plancher = null } = await stock.get(CLE_PLANCHER);
      const dejaCouverte = plage && plancher && plage >= plancher;
      const termines = Boolean(site.termines && site.termines.test(texte));
      const arretAuxConnus = termines && (plage ? dejaCouverte : true);
      const auBout = await toutAfficher(references, arretAuxConnus ? await dejaVus() : new Set());
      if (termines && auBout && plage && (!plancher || plage < plancher)) {
        await stock.set({ [CLE_PLANCHER]: plage });
      }
      return verifier();  // relire la page entière, une fois tout chargé
    }
    const nouvelles = refs.some((r) => !envoyes.has(r));
    const e = empreinte(texte);
    // Le détail d'un pari ouvert d'un clic (Sportaza) : envoyé tout de suite, même juste après un autre envoi.
    const details = site.detail ? (texte.match(site.detail) || []).join("¦") : "";
    const nouveauDetail = Boolean(details) && details !== derniersDetails;
    if (!nouvelles && !nouveauDetail && (e === derniereEmpreinte || Date.now() - dernierEnvoi < RENVOI_MIN)) return;
    derniersDetails = details;
    derniereEmpreinte = e;
    dernierEnvoi = Date.now();
    refs.forEach((r) => envoyes.add(r));
    try {
      const r = await envoyer(texte, location.href);
      if (site.plus && r && r.statut === "ok" && site.termines && site.termines.test(texte)) await noterVus(refs);
    } catch { /* extension rechargée : rien à faire */ }
  }

  let debutAttente = null;
  const planifier = () => {
    if (!vivant()) { arreter(); return; }
    const maintenant = Date.now();
    if (debutAttente === null) debutAttente = maintenant;
    clearTimeout(minuteur);
    const delai = Math.max(0, Math.min(ATTENTE, debutAttente + ATTENTE_MAX - maintenant));
    minuteur = setTimeout(() => { debutAttente = null; verifier().catch(arreter); }, delai);
  };
  /* Bouton « Copier le texte de la page » de l'icône : le cadre qui affiche des paris répond (l'historique bet365 est
     dans un cadre) ; à défaut, la page principale. */
  chrome.runtime.onMessage.addListener((message, _expediteur, repondre) => {
    if (message.type === "periodes") {
      if (window !== window.top) return false;
      if (!site.periodes) { repondre({ statut: "non" }); return false; }
      if (ouverture) { ouverture.arret = true; repondre({ statut: "arret" }); return false; }
      remonterPeriodes(message.debut);
      repondre({ statut: "lance" });
      return false;
    }
    if (message.type === "ouvrir_tous" && site.ouvrir === "details") {
      if (window !== window.top) return false;
      if (ouverture) { ouverture.arret = true; repondre({ statut: "arret" }); return false; }
      ouvrirDetails();
      repondre({ statut: "lance" });
      return false;
    }
    if (message.type === "ouvrir_tous") {
      if (window !== window.top && !references(texteDe(document.body)).length) return false;
      if (!site.ouvrir) { repondre({ statut: "non" }); return false; }
      if (ouverture) { ouverture.arret = true; repondre({ statut: "arret" }); return false; }
      ouvrirTous();
      repondre({ statut: "lance" });
      return false;
    }
    if (message.type === "demander_compte") {
      if (compteOnglet()) return false;  // déjà répondu dans cet onglet : la page renverra ce compte
      choisirCompte(message);
      return false;
    }
    if (message.type === "compte_choisi" && message.bookmaker === bookmaker) {  // choisi dans l'icône de l'extension
      retenirCompte(message.compte_id);
      if (window === window.top) { guideQuestion = null; dernierEnTete = null; setTimeout(verifier, 500); }
      return false;
    }
    if (message.type === "solde") {  // la page principale seule : c'est elle qui affiche le solde
      if (window !== window.top) return false;
      repondre({ bookmaker, solde: dernierSolde, lu: dernierEnTete !== null, copie: Boolean(site.copie) });
      return false;
    }
    if ((message.type !== "copier" && message.type !== "etat") || !document.body) return false;
    const texte = texteDe(document.body);
    const n = references(texte).length;
    const mouvements = !site.copie && estPageMouvements(texte) ? lignesMouvements(texte).length : 0;
    if (!n && !mouvements && !(message.toutePage && window === window.top)) return false;
    repondre({
      texte: message.type === "copier" ? texte : undefined, paris: n, mouvements, bookmaker,
      cadres: document.querySelectorAll("iframe").length, plus: Boolean(boutonPlus()), longueur: texte.length,
      copie: Boolean(site.copie), ouvrir: Boolean(site.ouvrir), periodes: site.periodes || 0,
    });
    return false;
  });

  observateur = new MutationObserver(planifier);
  observateur.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  /* Ce qui change dans un composant (« shadow DOM ») échappe à l'observation de la page : chaque composant est observé
     à son tour, dès qu'il apparaît (Sportaza : un pari ouvert d'un clic). */
  if (site.ombres) {
    const observees = new WeakSet();
    const observerOmbres = () => {
      if (!vivant()) return;
      for (const racine of racinesOmbre(document, site.ombres === "profond")) {
        if (observees.has(racine)) continue;
        observees.add(racine);
        observateur.observe(racine, { childList: true, subtree: true, characterData: true });
      }
    };
    observerOmbres();
    setInterval(observerOmbres, 3000);
  }
  // La remontée bet365 continue à chaque changement de la page (formulaire revenu, résultats affichés).
  if (site.plage) setTimeout(etapePlages, 1500);
  // Le guide de la page principale demande ce que voit ce cadre.
  if (window !== window.top) {
    window.addEventListener("message", (e) => {
      if (e.source !== window.parent || !e.data || e.data.suiviParisEtat !== true) return;
      versCadres(e.data);
      for (const cle of ["pageVide", "paris", "mvts"]) if (etatGuide[cle]) versGuide(cle, etatGuide[cle]);
    });
  }
  // bet365 : le guide de la page principale demande au cadre de l'historique de remonter les plages.
  if (site.plage && window !== window.top) {
    window.addEventListener("message", (e) => {
      if (e.source !== window.parent || !e.data || typeof e.data.suiviParisPlages !== "string") return;
      versCadres(e.data);  // un cadre dans le cadre
      if (e.data.suiviParisPlages === "arret") bulle("Suivi Paris : récupération arrêtée.");
      else if (/^\d{4}-\d{2}-\d{2}$/.test(e.data.suiviParisPlages)) etapePlages();
    });
  }
  /* « Récupérer tout mon historique » (fenêtre de l'extension) : le favori du site tourne dans la page et remet ici
     tout ce qu'il a relevé, envoyé d'un coup à l'appli. */
  if (window === window.top) {
    window.addEventListener("message", (e) => {
      if (e.source !== window || !e.data || typeof e.data.suiviParisHistorique !== "string") return;
      envoyer(e.data.suiviParisHistorique, location.href, "page");
    });
  }
  planifier();
  guide();

  /* Winamax : retenir l'adresse de l'historique, et le relire à chaque visite sur le site. */
  if (bookmaker === "winamax") {
    const ici = new URL(location.href);
    if (ici.pathname.includes("/account/history") && ici.searchParams.get("to_display") === "betting") {
      ici.searchParams.delete("page");
      stock.set({ winamaxHistorique: ici.href }).catch(() => {});
    } else {
      relireWinamax().catch(() => {});
    }
  }

  async function relireWinamax() {
    if (!vivant()) return;
    const { winamaxHistorique, winamaxLu = 0, actif = true } = await stock.get(["winamaxHistorique", "winamaxLu", "actif"]);
    if (!actif || !winamaxHistorique || Date.now() - winamaxLu < RELECTURE_WINAMAX) return;
    await stock.set({ winamaxLu: Date.now() });
    try {
      const adresse = new URL(winamaxHistorique);
      adresse.searchParams.set("page", "1");
      const texte = await texteDistant(adresse.href);
      if (references(texte).length) await envoyer(texte, adresse.href);
    } catch { /* hors connexion, pas connecté au site… : on réessaiera à la prochaine visite */ }
  }
})();
