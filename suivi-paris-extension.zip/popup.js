/* Suivi Paris : fenêtre de l'extension (état de l'appli, compte par bookmaker, derniers envois). */
const APPLI = "http://127.0.0.1:47830";
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const STATUTS = {
  ok: (j) => (j.nouveaux || j.mis_a_jour ? `${j.nouveaux ? `+${j.nouveaux}` : ""}${j.nouveaux && j.mis_a_jour ? ", " : ""}${j.mis_a_jour ? `${j.mis_a_jour} maj` : ""}`
    : j.deja_connus ? `${j.deja_connus} déjà dans l'appli` : "rien de neuf"),
  aucun_pari: () => "aucun pari", choisir_compte: () => "compte à choisir", aucun_compte: () => "compte à créer",
  non_reconnu: () => "page non reconnue", erreur: () => "erreur",
  boite: (j) => `${j.lus ? `${j.lus} lus, ` : ""}envoyé : enregistré à la prochaine ouverture de l'appli`,
};

const SITES_GUIDE = globalThis.SUIVI_GUIDE;  // guide.js : la fiche de chaque site, partagée avec la page

/* Une ligne de la fiche : son texte et sa pastille (ok, attente, non, info). */
function ligneFiche(cle, texte, pastille = "", classe = "") {
  const li = document.querySelector(`[data-ligne="${cle}"]`);
  li.querySelector("[data-texte]").innerHTML = texte;
  const em = li.querySelector("[data-pastille]");
  em.textContent = pastille;
  em.className = classe;
}
function ficheSite(nom, r) {
  const g = SITES_GUIDE[nom];
  if (!g) return;
  const [libelle, lettres, couleur, paris, mvts] = g;
  $("#site-nom").textContent = libelle;
  const logo = $("#site-logo");
  logo.textContent = lettres;
  logo.style.setProperty("--bk", couleur);
  $("#fiche").hidden = false;
  if (nom === "asianconnect") document.querySelector('[data-ligne="paris"]').hidden = document.querySelector('[data-ligne="solde"]').hidden = true;
  if (r && r.paris) ligneFiche("paris", `${r.paris} pari${r.paris > 1 ? "s" : ""} lu${r.paris > 1 ? "s" : ""} sur cette page (où ils en sont : « En attente » et « Derniers envois »)`, "Lu", "ok");
  else ligneFiche("paris", `Ouvre ${paris}`, "À ouvrir", "info");
  // Le dernier pari enregistré de ce site : jusqu'où remonter.
  appli.then((app) => {
    const derniers = ((app && app.comptes) || []).filter((c) => c.bookmaker === nom && c.dernier && c.dernier.date_pari)
      .map((c) => ({ nom: c.nom, date: c.dernier.date_pari })).sort((a, b) => (a.date < b.date ? 1 : -1));
    if (!derniers.length) return;
    const li = document.querySelector('[data-ligne="paris"] [data-texte]');
    li.insertAdjacentHTML("beforeend", `<br>Dernier enregistré : <b>${esc(new Date(derniers[0].date).toLocaleDateString("fr-FR"))}</b>${
      derniers.length > 1 ? ` (${esc(derniers[0].nom)})` : ""}`);
  });
  if (r && r.mouvements) ligneFiche("mvts", `${r.mouvements} lus sur cette page`, "Lu", "ok");
  else ligneFiche("mvts", mvts.ou, { ac: "AsianConnect", main: "À la main" }[mvts.mode] || "À ouvrir", mvts.mode === "main" ? "attente" : "info");
}

const euros = (x) => new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(x);
function resumeJournal(j) {
  if (j.type === "solde" && j.statut === "ok") return `solde ${euros(j.solde)}`;
  if (j.type === "mouvements" && j.statut === "ok") {
    const quoi = j.sens === "depot" ? "dépôt" : j.sens === "retrait" ? "retrait" : "mouvement";
    return `+${j.nouveaux} ${quoi}${j.nouveaux > 1 ? "s" : ""}`;
  }
  return (STATUTS[j.statut] || STATUTS.erreur)(j);
}

// L'état de l'appli, demandé une fois pour toute la fenêtre.
const appli = Promise.race([fetch(`${APPLI}/api/etat`).then((r) => r.json()), new Promise((ok) => setTimeout(() => ok(null), 3000))]).catch(() => null);
// Les sites où « Récupérer tout mon historique » lance le favori du site (dossier outils/).
const HISTORIQUES = { betclic: "betclic", winamax: "winamax", ps3838: "ps3838", pmu: "pmu", unibet: "unibet" };

async function afficher() {
  const { actif = true, journal = [], attente = [] } = await chrome.storage.local.get(["actif", "journal", "attente"]);
  $("#actif").checked = actif;

  let app = null;
  app = await appli;
  // Sans appli joignable (iPhone) : le code de liaison de la synchronisation.
  const { liaison } = await chrome.storage.local.get("liaison");
  const blocL = $("#bloc-liaison");
  blocL.hidden = Boolean(app) && !liaison;
  if (liaison) {
    $("#liaison-etat").innerHTML = "<b>Liée à ta synchronisation</b> : sans appli joignable, les pages partent chiffrées et l'appli (iPhone ou ordinateur) les enregistre à sa prochaine ouverture.";
    $("#code-liaison").hidden = true;
    $("#lier").textContent = "Délier";
  }
  $("#lier").onclick = async () => {
    const r = await chrome.runtime.sendMessage({ type: "lier", code: liaison ? "" : $("#code-liaison").value }).catch(() => null);
    if (r && r.statut === "illisible") { $("#liaison-etat").textContent = "Code illisible : recopie-le depuis l'ordinateur (Mes données → Avec l'iPhone)."; return; }
    afficher();
  };
  $("#etat-appli").innerHTML = app
    ? `<span class="ok">Appli ouverte</span>${app.demo ? " (démonstration)" : ""}`
    : liaison ? `<span class="ok">Envoi par la synchronisation (chiffré)</span>` : `<span class="ko">Appli fermée : les paris attendront son ouverture</span>`;

  const zone = $("#attente");
  // Prêt à envoyer (iPhone) : la liste de ce qui partira, et le bouton qui envoie tout en une fois.
  const prets = attente.filter((p) => p.statut === "a_envoyer");
  const autres = attente.filter((p) => p.statut !== "a_envoyer");
  const aChoisir = autres.filter((p) => p.statut === "choisir_compte" || p.statut === "aucun_compte");
  zone.hidden = !attente.length;
  zone.className = aChoisir.length ? "alerte" : prets.length && !autres.length ? "pret" : "";
  // Ce qui attend, et pourquoi : « Winamax : 1 page de paris et le solde, en attente du compte connecté ».
  const QUOI = { page: "page de paris", solde: "solde", mouvements: "page de dépôts ou retraits" };
  const QUOIS = { "page de paris": "pages de paris", solde: "soldes", "page de dépôts ou retraits": "pages de dépôts ou retraits" };
  const POURQUOI = { choisir_compte: "dis sur quel compte tu étais connecté (ci-dessous, ou sur le site)",
    aucun_compte: "crée d'abord ce compte dans l'appli (page Comptes)", en_attente: "l'appli était fermée : envoi à son ouverture",
    appli_fermee: "l'appli Suivi Paris ne répondait pas (fermée ?) : nouvel essai toutes les minutes, rien n'est perdu" };
  const groupes = {};
  for (const p of autres) {
    const cle = `${p.bookmaker}|${p.statut || "en_attente"}`;
    const g = (groupes[cle] ||= { bk: p.bookmaker, statut: p.statut || "en_attente", quoi: [] });
    g.quoi.push(QUOI[p.type || "page"] || "page");
    if (p.erreur) g.erreur = p.erreur;
  }
  const heure = (p) => (p.capture_le ? String(p.capture_le).slice(11, 16) : "");
  const nParis = prets.reduce((n, p) => n + (p.type === "page" || !p.type ? p.lus || 0 : 0), 0);
  const { pause_github: pause = 0, dernier_envoi: dernier = null } = await chrome.storage.local.get(["pause_github", "dernier_envoi"]);
  const enPause = pause > Date.now();
  zone.innerHTML = `${prets.length ? `<b>Prêt à envoyer</b>
      <ul class="attente-liste">${prets.map((p) => {
        const nom = (SITES_GUIDE[p.bookmaker] || [p.bookmaker])[0];
        const type = p.type || "page";
        const quoi = type === "page" ? `${p.lus || "?"} pari${p.lus > 1 ? "s" : ""}` : type === "solde" && p.apercu ? `solde ${p.apercu}` : QUOI[type] || type;
        const tete = `<b>${esc(nom)}</b>${p.compte_nom ? ` – ${esc(p.compte_nom)}` : ""} : ${esc(quoi)} <small>${esc(heure(p))}</small>`;
        // Le détail des paris lus (aperçu : c'est l'appli qui lit vraiment la page).
        if (!Array.isArray(p.apercu) || !p.apercu.length) return `<li>${tete}</li>`;
        return `<li><details><summary>${tete}</summary><ul class="apercu">${p.apercu.map((a) =>
          `<li><span>${esc(a.titre || a.ref)}</span><small>${esc([a.mise && `${a.mise}${a.cote ? ` à ${a.cote}` : ""}`,
            a.gains && `gains ${a.gains}`, a.etat && a.etat.toLowerCase()].filter(Boolean).join(" · "))}</small></li>`).join("")}</ul></details></li>`;
      }).join("")}</ul>
      ${dernier && dernier.erreur ? `<p class="note">Dernier essai : ${esc(dernier.erreur)}. Rien n'est perdu.</p>` : ""}
      <button id="vider" ${enPause ? "disabled" : ""}>${enPause
        ? `GitHub en pause jusqu'à ${new Date(pause).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`
        : `Envoyer vers l'appli${nParis ? ` (${nParis} paris)` : ""}`}</button>
      <p class="note">L'appli les enregistre à sa prochaine ouverture (ou synchronisation).</p>` : ""}
    ${autres.length ? `<b>En attente d'envoi</b><ul class="attente-liste">${Object.values(groupes).map((g) => {
        const nom = (SITES_GUIDE[g.bk] || [g.bk])[0];
        const quoi = [...new Set(g.quoi)].map((q) => { const n = g.quoi.filter((x) => x === q).length; return n > 1 ? `${n} ${QUOIS[q] || q}` : q; }).join(", ");
        const erreur = g.statut === "appli_fermee" && g.erreur
          ? `envoi à la synchronisation impossible (${g.erreur}) : nouvel essai toutes les minutes, rien n'est perdu` : null;
        return `<li><b>${esc(nom)}</b> : ${esc(quoi)}. ${esc(erreur || POURQUOI[g.statut] || "nouvel essai dans une minute")}.</li>`;
      }).join("")}</ul>${prets.length ? "" : `<button id="vider">Envoyer maintenant</button>`}` : ""}`;
  if ($("#vider")) $("#vider").addEventListener("click", () => {
    $("#vider").textContent = "Envoi…";
    $("#vider").disabled = true;
    // Un rappel plutôt qu'une promesse (Orion), et l'affichage refait au plus tard 30 s après.
    let fait = false;
    const fin = (r) => {
      if (fait) return;
      fait = true;
      chrome.storage.local.set({ dernier_envoi: r ? { erreur: r.erreur || null, le: Date.now() } : null }).catch(() => {}).finally(afficher);
    };
    try { chrome.runtime.sendMessage({ type: "vider" }, (r) => { void chrome.runtime.lastError; fin(r); }); } catch { fin(null); }
    setTimeout(() => fin(null), 30000);
  });

  /* Plusieurs comptes chez un bookmaker : le compte connecté dans cet onglet (demandé aussi sur le site), et celui
     des pages qui attendent un choix. Rien n'est retenu d'un onglet à l'autre : l'extension redemande. */
  const liste = $("#comptes");
  // Sans appli (iPhone) : les comptes proposés sont ceux gardés avec les pages en attente.
  const sansAppli = !app && aChoisir.some((p) => Array.isArray(p.comptes) && p.comptes.length);
  const source = app || (sansAppli ? {
    bookmakers: [...new Set(aChoisir.map((p) => p.bookmaker))].map((nom) => ({ nom, libelle: (SITES_GUIDE[nom] || [nom])[0] })),
    comptes: aChoisir.flatMap((p) => (p.comptes || []).map((c) => ({ ...c, bookmaker: p.bookmaker })))
      .filter((c, i, t) => t.findIndex((x) => x.bookmaker === c.bookmaker && x.id === c.id) === i),
  } : null);
  if (!source) {
    liste.innerHTML = "";
  } else {
    const [onglet] = await chrome.tabs.query({ active: true, currentWindow: true });
    const ici = onglet ? await chrome.tabs.sendMessage(onglet.id, { type: "solde" }, { frameId: 0 }).catch(() => undefined) : undefined;
    const bkIci = ici && ici.bookmaker;
    const enAttente = new Set(aChoisir.map((p) => p.bookmaker));
    const lignes = [];
    for (const b of source.bookmakers) {
      const comptes = source.comptes.filter((c) => c.bookmaker === b.nom);
      if (comptes.length < 2 || (b.nom !== bkIci && !enAttente.has(b.nom))) continue;
      const surOnglet = b.nom === bkIci;
      const actuel = surOnglet
        ? await chrome.runtime.sendMessage({ type: "compte_confirme", bookmaker: b.nom, onglet: onglet.id }).catch(() => null) : null;
      lignes.push(`<div class="ligne-compte"><b>${esc(b.libelle)}</b>
        <select data-bookmaker="${esc(b.nom)}" data-onglet="${surOnglet ? onglet.id : ""}" title="${surOnglet ? "Le compte connecté dans cet onglet" : "Le compte des pages en attente"}">
          <option value="" ${actuel ? "" : "selected"}>${surOnglet ? "Connecté ici : à choisir…" : "Pages en attente : à qui ?"}</option>
          ${comptes.map((c) => `<option value="${c.id}" ${c.id === actuel ? "selected" : ""}>${esc(c.nom)}</option>`).join("")}
        </select></div>`);
    }
    liste.innerHTML = lignes.join("");
    $("#bloc-comptes").hidden = !lignes.length;
    liste.querySelectorAll("select").forEach((s) => s.addEventListener("change", async () => {
      if (!s.value) return;
      s.disabled = true;
      // Un rappel plutôt qu'une promesse (Orion) ; sans l'appli, l'envoi passe par GitHub : quelques secondes.
      let fait = false;
      const fin = () => { if (!fait) { fait = true; afficher(); } };
      try {
        chrome.runtime.sendMessage({ type: "confirmer_compte", bookmaker: s.dataset.bookmaker, compte_id: Number(s.value),
          onglet: s.dataset.onglet ? Number(s.dataset.onglet) : null }, () => { void chrome.runtime.lastError; fin(); });
      } catch { fin(); }
      setTimeout(fin, 30000);
    }));
  }

  rendreJournal(journal);
  // Sur l'iPhone : ce que l'appli a fait des pages envoyées par la synchronisation (ses accusés), relu à l'ouverture.
  if (liaison && liaison.g) {
    const { accuses: avant = [] } = await chrome.storage.local.get("accuses");
    if (avant.length) rendreJournal(journal, avant);
    Promise.race([lireAccuses(liaison), new Promise((_, ko) => setTimeout(() => ko(new Error("délai")), 6000))]).then((accuses) => {
      chrome.storage.local.set({ accuses }).catch(() => {});
      rendreJournal(journal, accuses);
    }, () => {});
  }
}

/* Les derniers envois ; une page envoyée par la synchronisation prend l'accusé de l'appli quand il est arrivé. */
function rendreJournal(journal, accuses = []) {
  const recus = new Map(accuses.map((a) => [a.id, a]));
  journal = journal.map((j) => {
    const a = j.statut === "boite" && j.id && recus.get(j.id);
    return a ? { ...j, statut: a.statut, compte: a.compte || j.compte, nouveaux: a.nouveaux, mis_a_jour: a.mis_a_jour,
      deja_connus: a.deja_connus, solde: a.solde, details: a.details || [], recu: a.le } : j;
  });
  // Un envoi qui a ajouté ou changé des paris se déplie : lesquels, et ce qui a changé.
  $("#journal").innerHTML = journal.length ? journal.slice(0, 12).map((j) => {
    const tete = `<span><b>${esc(j.libelle)}</b>${j.compte ? ` – ${esc(j.compte)}` : ""} · ${esc(resumeJournal(j))}${
      j.recu ? ` <em class="ok">Dans l'appli</em>` : ""}</span>
      <span>${new Date(j.quand).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</span>`;
    if (!(j.details && j.details.length)) return `<li><div class="ligne-journal">${tete}</div></li>`;
    return `<li><details><summary class="ligne-journal">${tete}</summary><ul class="details-journal">${j.details.map((d) =>
      `<li><em class="${d.statut === "nouveau" ? "ok" : "info"}">${d.statut === "nouveau" ? "Nouveau" : "Mis à jour"}</em><span>${esc(d.resume)}${
        d.changements && d.changements.length ? `<small>${d.changements.map(esc).join(" · ")}</small>` : ""}</span></li>`).join("")}</ul></details></li>`;
  }).join("") : `<li class="vide">Rien d'envoyé pour l'instant.</li>`;
}

/* Interroge le script de la page ouverte : le cadre qui affiche des paris (ou des mouvements) répond, sinon la page
   principale. Rien ne répond : l'extension ne tourne pas sur ce site, ou la page date d'avant son installation. */
async function demander(type) {
  const [onglet] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!onglet) return { onglet: null, r: undefined };
  const essayer = async () => {
    let r = await chrome.tabs.sendMessage(onglet.id, { type }).catch(() => undefined);
    if (!r) r = await chrome.tabs.sendMessage(onglet.id, { type, toutePage: true }, { frameId: 0 }).catch(() => undefined);
    return r;
  };
  let r = await essayer();
  // Un site suivi dont la page date d'avant la dernière mise à jour de l'extension : son script ne répond plus.
  // Il est remis en place ici, sans recharger la page.
  if (!r && await siteSuivi(onglet)) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: onglet.id }, files: ["guide.js", "page.js"] });
      await new Promise((ok) => setTimeout(ok, 400));
      r = await essayer();
    } catch { /* page interdite (chrome://…) : rien à faire */ }
  }
  return { onglet, r };
}

/* Un site que l'extension lit (ceux du manifeste, et les adresses de Sportaza). */
async function siteSuivi(onglet) {
  let hote = "";
  try { hote = new URL(onglet.url || "").hostname; } catch { return false; }
  if (!hote) return false;
  if (/^(www\.)?sportaza-\d+\.com$/.test(hote)) return true;
  const motifs = chrome.runtime.getManifest().content_scripts.flatMap((c) => c.matches);
  return motifs.some((m) => {
    const domaine = m.replace(/^\*:\/\/\*?\.?/, "").split("/")[0];
    return hote === domaine || hote.endsWith(`.${domaine}`);
  });
}

/* Les cadres d'un autre site dans la page (la partie paris de Sportaza vient d'un autre fournisseur) : leur adresse,
   pour demander à les lire au clic sur « Copier ». */
let originesCadres = [];
async function chercherCadres(onglet) {
  try {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId: onglet.id },
      func: () => [...new Set([...document.querySelectorAll("iframe[src]")].map((f) => {
        try { return new URL(f.src, location.href).origin; } catch { return ""; }
      }).filter((o) => /^https?:/.test(o) && o !== location.origin
        // Pas les cadres techniques (« Je ne suis pas un robot » de Google, vidéos) : jamais des paris.
        && !/(^|\.)(google|gstatic|recaptcha|youtube|doubleclick|googletagmanager|facebook|hcaptcha)\.[a-z.]+$/.test(new URL(o).hostname)))],
    });
    return (r && r.result) || [];
  } catch {
    return [];
  }
}

async function etatPage() {
  const note = $("#etat-page");
  const { onglet, r } = await demander("etat");
  if (onglet) originesCadres = await chercherCadres(onglet);
  const cadres = originesCadres.length
    ? ` La page contient ${originesCadres.length > 1 ? "des cadres" : "un cadre"} de <b>${originesCadres.map((o) => esc(new URL(o).hostname)).join("</b>, <b>")}</b> : « Copier le texte de la page » demandera la permission de ${originesCadres.length > 1 ? "les" : "le"} lire aussi.`
    : "";
  let site = "";
  try { site = onglet && onglet.url ? new URL(onglet.url).hostname : ""; } catch { site = ""; }
  // Une adresse de Sportaza (« sportaza-5178.com ») pas encore autorisée : un clic l'ajoute.
  if (!r && /^(www\.)?sportaza-\d+\.com$/.test(site)) {
    const bouton = $("#lire-site");
    bouton.hidden = false;
    note.innerHTML = `<b>${esc(site)}</b> est une adresse de Sportaza : clique sur « Lire ce site automatiquement » (Chrome demande la permission), puis recharge la page.`;
    bouton.addEventListener("click", async () => {
      const ok = await chrome.permissions.request({ origins: [`https://${site}/*`] }).catch(() => false);
      if (!ok) { note.textContent = "Permission refusée : rien n'est lu sur ce site."; return; }
      await chrome.runtime.sendMessage({ type: "inscrire_miroirs" }).catch(() => null);
      await chrome.tabs.reload(onglet.id);
      note.innerHTML = `<b>${esc(site)}</b> : c'est bon, la page se recharge et l'extension la lit désormais.`;
      bouton.hidden = true;
    });
    return;
  }
  if (!r) {
    if (site) $("#site-nom").textContent = site;
    note.textContent = site
      ? "Pas un site suivi, ou la page date d'avant l'extension : recharge-la (F5). La copie du texte marche quand même."
      : "L'extension ne lit pas cette page.";
    if (cadres) note.innerHTML = esc(note.textContent) + cadres;
    return;
  }
  ficheSite(r.bookmaker, r);
  if (r.copie) {
    note.innerHTML = `<b>${esc(r.bookmaker)}</b> : pas encore lu par l'appli. Copie le texte de la page (bouton ci-dessous) et envoie-le pour que sa lecture soit ajoutée.${cadres}`;
    return;
  }
  const quoi = r.paris ? `${r.paris} pari${r.paris > 1 ? "s" : ""} repéré${r.paris > 1 ? "s" : ""}`
    : r.mouvements ? `${r.mouvements} dépôt${r.mouvements > 1 ? "s" : ""} ou retrait${r.mouvements > 1 ? "s" : ""} repéré${r.mouvements > 1 ? "s" : ""}`
    : "aucun pari repéré sur cette page";
  note.innerHTML = `${esc(quoi[0].toUpperCase() + quoi.slice(1))}${r.plus ? " · « Afficher plus » présent" : ""}.${cadres}`;
  // Tout l'historique : le favori du site, lancé dans la page ; bwin : par périodes ; Sportaza : chaque pari ouvert.
  const tout = $("#tout-historique");
  if (HISTORIQUES[r.bookmaker] || r.periodes || r.ouvrir) {
    tout.hidden = false;
    tout.addEventListener("click", async () => {
      if (r.periodes) { $("#periodes").hidden = false; $("#debut-periodes").focus(); return; }
      if (r.ouvrir) { $("#ouvrir-tous").click(); return; }
      try {
        await chrome.scripting.executeScript({ target: { tabId: onglet.id }, world: "MAIN", func: () => { window.__suiviParisExtension = true; } });
        await chrome.scripting.executeScript({ target: { tabId: onglet.id }, world: "MAIN", files: [`outils/${HISTORIQUES[r.bookmaker]}-historique.js`] });
        note.innerHTML = "C'est parti : réponds à la question sur la page. La bulle en bas à droite suit ; tout part vers l'appli à la fin.";
        window.close();
      } catch (e) { note.textContent = `Impossible ici : ${e.message || e}`; }
    });
  }
  // bwin « Évalué » : 90 jours par filtre ; l'extension enchaîne les périodes depuis la date choisie.
  if (r.periodes) {
    const champ = $("#debut-periodes");
    const ilYaUnAn = new Date();
    ilYaUnAn.setFullYear(ilYaUnAn.getFullYear() - 1);
    if (!champ.value) champ.value = ilYaUnAn.toISOString().slice(0, 10);
    $("#lancer-periodes").addEventListener("click", async () => {
      if (!champ.value) { note.textContent = "Choisis d'abord la date de début."; return; }
      const rep = await chrome.tabs.sendMessage(onglet.id, { type: "periodes", debut: champ.value }, { frameId: 0 }).catch(() => null);
      note.innerHTML = rep && rep.statut === "arret" ? "Lecture des périodes arrêtée."
        : rep && rep.statut === "lance" ? `Lecture par périodes de ${r.periodes} jours depuis le ${esc(new Date(champ.value).toLocaleDateString("fr-FR"))} (la bulle en bas à droite suit). Reclique pour arrêter.`
        : "Impossible ici : ouvre Mes paris → Évalué sur bwin, recharge la page, puis réessaie.";
    });
  }
  // Sportaza : le détail (choix, date de l'événement) ne s'affiche qu'un pari ouvert à la fois.
  if (r.ouvrir && r.paris) {
    const bouton = $("#ouvrir-tous");
    bouton.addEventListener("click", async () => {
      const rep = await chrome.tabs.sendMessage(onglet.id, { type: "ouvrir_tous" }).catch(() => null);
      note.innerHTML = rep && rep.statut === "arret" ? "Ouverture des paris arrêtée."
        : rep && rep.statut === "lance" ? "Les paris s'ouvrent un par un sur la page (la bulle en bas à droite suit). Reclique ici pour arrêter."
        : "Impossible ici : recharge la page, puis réessaie.";
    });
  }
}

const fmtEuros = (x) => (Number.isFinite(x) ? new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(x) : "Solde lu");

/* Le solde lu en haut de la page ouverte, ou pourquoi il ne l'a pas été. */
async function etatSolde() {
  const note = $("#etat-solde");
  const [onglet] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!onglet) return;
  const r = await chrome.tabs.sendMessage(onglet.id, { type: "solde" }, { frameId: 0 }).catch(() => undefined);
  if (!r || r.copie) return;  // site pas encore lu : pas de solde à attendre
  ficheSite(r.bookmaker, null);
  const s = r.solde;
  let texte;
  if (!s) texte = r.lu ? "Envoi en cours…" : "Pas encore lu : recharge la page.";
  else if (s.statut === "ok") texte = `<b>${esc(fmtEuros(s.solde))}</b> sur ${esc(s.compte)}`;
  else if (s.statut === "aucun_solde") texte = "Pas en haut de cette page : ouvre l'accueil du site, connecté.";
  else if (s.statut === "choisir_compte") texte = `<b>${esc(fmtEuros(s.solde))}</b> : choisis ci-dessous le compte connecté ici.`;
  else if (s.statut === "aucun_compte") texte = `Crée d'abord ton compte ${esc(s.libelle || "")} dans l'appli (page Comptes) : sans lui, rien de ce site n'est enregistré.`;
  else if (s.statut === "boite") texte = "Envoyé, chiffré : enregistré à la prochaine ouverture de l'appli (iPhone ou ordinateur).";
  else if (s.statut === "a_envoyer") texte = "Prêt : part avec le reste quand tu touches <b>Envoyer vers l'appli</b>.";
  else if (s.statut === "en_attente" && s.erreur) texte = `Envoi impossible (${esc(s.erreur)}) : nouvel essai toutes les minutes, rien n'est perdu.`;
  else if (s.statut === "en_attente") texte = "Appli fermée : envoyé à son ouverture.";
  else if (s.statut === "autre_devise") texte = `En ${esc(s.devise)} : règle la monnaie du compte dans l'appli (page Comptes).`;
  else texte = esc(s.message || s.statut);
  // Dans la fiche : le texte sans « Solde : », et une pastille qui dit où on en est.
  const [pastille, classe] = !s ? ["…", "info"] : { ok: ["Relevé", "ok"], aucun_solde: ["Pas trouvé", "non"], choisir_compte: ["Compte ?", "attente"],
    aucun_compte: ["Compte ?", "attente"], en_attente: ["En attente", "attente"], a_envoyer: ["Prêt", "ok"], boite: ["Envoyé", "ok"], autre_devise: ["Monnaie ?", "attente"] }[s.statut] || ["Erreur", "non"];
  ligneFiche("solde", texte, pastille, classe);
}

/* Le script de page ne répond pas (onglet ouvert avant une mise à jour de l'extension, site pas encore suivi) : le
   texte de l'onglet est lu directement, avec la permission que donne le clic sur l'icône (activeTab), et celui des
   cadres d'autres sites que tu as autorisés, chacun à la suite, sous son adresse. */
async function texteDirect(onglet) {
  try {
    const resultats = await chrome.scripting.executeScript({
      target: { tabId: onglet.id, allFrames: true },
      func: () => {
        const casse = document.createElement("style");
        casse.textContent = "*,*::before,*::after{text-transform:none!important}";
        (document.head || document.documentElement).append(casse);
        let texte = document.body ? document.body.innerText : "";
        // Les composants web (« shadow DOM ») ne sont pas dans innerText : leur texte est ajouté à la suite, à tous
        // les niveaux (la partie paris de certains sites en est faite).
        const parts = [];
        const fouiller = (racine) => {
          for (const e of racine.querySelectorAll("*")) {
            if (!e.shadowRoot) continue;
            const t = [...e.shadowRoot.children].map((x) => x.innerText || "").join("\n").trim();
            if (t) parts.push(t);
            fouiller(e.shadowRoot);
          }
        };
        if (document.body) fouiller(document.body);
        if (parts.length) texte += "\n=== Composants de la page ===\n" + parts.join("\n");
        casse.remove();
        return { texte, hote: location.hostname || location.href.split(":")[0], principal: window === window.top,
                 adresse: location.href };
      },
    });
    const lus = resultats.map((x) => x.result).filter((x) => x && x.texte && x.texte.trim());
    lus.sort((a, b) => Number(b.principal) - Number(a.principal));
    const texte = lus.map((x) => (x.principal ? `=== Page : ${x.adresse} ===\n${x.texte}` : `=== Cadre : ${x.hote} ===\n${x.texte}`)).join("\n\n");
    return texte ? { texte, paris: 0, cadres: lus.filter((x) => !x.principal).length } : null;
  } catch {
    return null;
  }
}

/* Le texte de la page, préparé dès l'ouverture de la fenêtre : au clic, la copie se fait tout de suite. Sur l'iPhone,
   Safari et Orion n'autorisent le presse-papier (et le partage) que dans l'instant du toucher, pas après une attente. */
let textePrepare = null;
demander("copier").then(({ r }) => { if (r && r.texte) textePrepare = r; }, () => {});

function montrerTexte(texte) {
  const zone = $("#texte-copie");
  zone.value = texte;
  zone.hidden = false;
}

async function copierPage() {
  const note = $("#copie");
  const pret = textePrepare;
  try {
    let r = pret;
    let copie = false;
    if (pret) copie = await navigator.clipboard.writeText(pret.texte).then(() => true, () => false);
    if (!pret || (!copie && originesCadres.length)) {
      // Des cadres d'un autre site : la permission de les lire se demande tout de suite (au clic).
      const autorises = originesCadres.length
        ? await chrome.permissions.request({ origins: originesCadres.map((o) => `${o}/*`) }).catch(() => false) : false;
      let d = await demander("copier");
      r = d.r;
      if (d.onglet && (autorises || !r || (!r.paris && !r.mouvements))) r = (await texteDirect(d.onglet)) || r;
      if (r && r.texte) copie = await navigator.clipboard.writeText(r.texte).then(() => true, () => false);
    }
    if (!r || !r.texte) { note.textContent = "Rien à copier ici : recharge la page, puis réessaie."; return; }
    textePrepare = r;
    montrerTexte(r.texte);
    if (!copie) {
      note.innerHTML = navigator.share
        ? "Copie refusée ici : touche <b>Partager le texte</b> (Notes, Claude…), ou copie-le dans le cadre ci-dessous."
        : "Copie refusée ici : copie le texte dans le cadre ci-dessous (Tout sélectionner, Copier).";
      $("#partager").hidden = !navigator.share;
      return;
    }
    note.innerHTML = `${r.paris
      ? `<b>Copié</b> (${r.paris} pari${r.paris > 1 ? "s" : ""} repéré${r.paris > 1 ? "s" : ""}) : colle-le dans la page Importer de l'appli.`
      : `<b>Copié</b>${r.cadres ? ` (avec ${r.cadres} cadre${r.cadres > 1 ? "s" : ""})` : ""} : colle-le dans la page Importer de l'appli.`}`;
  } catch (e) {
    note.textContent = `Copie impossible : ${e.message || e}`;
  }
}
/* Partager : la feuille de partage de l'iPhone (Notes, Claude, Messages…), sans passer par le presse-papier. Appelée
   tout de suite au toucher, avec le texte déjà prêt. */
$("#partager").addEventListener("click", () => {
  if (!textePrepare || !navigator.share) return;
  navigator.share({ title: "Page Suivi Paris", text: textePrepare.texte }).catch((e) => {
    if (e && e.name !== "AbortError") $("#copie").textContent = `Partage impossible : ${e.message || e}`;
  });
});
$("#copier").addEventListener("click", copierPage);
etatPage();
etatSolde();
$("#actif").addEventListener("change", (e) => chrome.storage.local.set({ actif: e.target.checked }));
chrome.runtime.sendMessage({ type: "vu" });
afficher();

/* Sans l'appli de l'ordinateur (Orion, sur l'iPhone), l'extension ne se met pas à jour seule : la fenêtre compare
   sa version à la dernière publiée avec l'appli téléphone, et propose de la télécharger. */
const plusRecenteQue = (a, b) => {
  const pa = String(a).split(".").map(Number), pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
};
(async () => {
  if (await appli) return;  // l'appli de l'ordinateur répond : elle met l'extension à jour elle-même
  try {
    const r = await Promise.race([fetch(`${PAGES_APPLI}extension.json`, { cache: "no-cache" }), new Promise((_, ko) => setTimeout(ko, 5000))]);
    const { version, fichier } = await r.json();
    if (!version || !plusRecenteQue(version, chrome.runtime.getManifest().version)) return;
    const zone = $("#maj-extension");
    zone.innerHTML = `<b>Nouvelle version de l'extension : ${esc(version)}</b>
      <ol><li><a href="${esc(PAGES_APPLI + (fichier || "suivi-paris-extension.zip"))}" target="_blank" rel="noopener">Télécharge-la</a>, puis dans Fichiers, range-la dans <b>Sur mon iPhone → Orion</b>.</li>
        <li>Orion : ••• → <b>Extensions</b>, supprime Suivi Paris, touche <b>+</b> et choisis le fichier.</li>
        <li>Rouvre cette fenêtre et recolle ton code de liaison (<b>Sans l'appli → Lier</b>).</li></ol>
      <small>Ce qui est prêt à envoyer : envoie-le d'abord, une réinstallation l'efface.</small>`;
    zone.hidden = false;
  } catch { /* hors connexion : la prochaine fois */ }
})();
