/* Suivi Paris : sur la page de mise à jour de l'extension (GitHub Pages de l'appli), dans Orion sur l'iPhone.

   Une réinstallation de l'extension efface sa liaison avec la synchronisation (le code « SP1-… »). Pour ne pas avoir à
   le recoller, l'extension en garde une copie dans le stockage de cette page, propre au navigateur et qui survit à la
   réinstallation ; l'extension réinstallée la reprend en rouvrant la page. La copie ne quitte pas le téléphone. Si
   l'appli iPhone elle-même tourne dans ce navigateur, sa liaison (« synchro ») sert aussi. */
(() => {
  const COPIE = "suivi-paris-liaison-extension";
  const lire = (cle) => { try { return JSON.parse(localStorage.getItem(cle) || "null"); } catch { return null; } };
  const valide = (l) => (l && l.g && l.t && l.k ? { g: l.g, t: l.t, k: l.k } : null);
  const versExtension = (message) => new Promise((ok) => {
    try {
      chrome.runtime.sendMessage(message, (r) => { void chrome.runtime.lastError; ok(r || null); });
    } catch { ok(null); }
    setTimeout(() => ok(null), 5000);
  });
  const dire = (texte, ok) => {
    const zone = document.getElementById("etat-liaison");
    if (!zone) return;
    zone.textContent = texte;
    zone.dataset.etat = ok ? "ok" : "info";
  };

  (async () => {
    const connue = valide(lire("synchro")) || valide(lire(COPIE));
    const r = await versExtension({ type: "liaison_page", lien: connue });
    if (!r) return;
    if (r.lien) {
      try { localStorage.setItem(COPIE, JSON.stringify(r.lien)); } catch { /* stockage plein ou refusé */ }
    }
    if (r.statut === "lie") dire("Extension Suivi Paris reliée à ta synchronisation : rien à recoller.", true);
    else if (r.statut === "deja") dire("Extension Suivi Paris installée et reliée. Liaison gardée pour la prochaine mise à jour.", true);
    else dire("Extension Suivi Paris installée, mais pas encore reliée : colle ton code dans sa fenêtre (Sans l'appli → Lier), une seule fois.", false);
  })();
})();
