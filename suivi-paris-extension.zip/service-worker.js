/* Suivi Paris : service worker de l'extension.

   Reçoit ce que le script de page relève sur les sites des bookmakers (paris, dépôts et retraits, solde) et
   l'envoie à l'appli Suivi Paris de l'ordinateur (http://127.0.0.1:47830). Si l'appli est fermée, la page est gardée et renvoyée toutes les minutes
   jusqu'à ce qu'elle soit ouverte. Rien ne part ailleurs que vers l'appli de l'ordinateur. */
const APPLI = "http://127.0.0.1:47830";
const MAX_ATTENTE = 60;
const MAX_JOURNAL = 20;

async function lire(cles) { return chrome.storage.local.get(cles); }

const VERSION = chrome.runtime.getManifest().version;

function plusRecente(a, b) {
  const pa = String(a).split(".").map(Number), pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  }
  return false;
}

/* Après une mise à jour de l'appli, son dossier « extension » contient une version plus récente que celle qui tourne :
   l'extension (chargée depuis ce dossier, en mode développeur) se recharge d'elle-même, comme la flèche circulaire de
   chrome://extensions. Une seule tentative par version : si elle a été chargée depuis un autre dossier, la recharger
   ne changerait rien (la page Importer de l'appli le signale). */
async function suivreVersion(r) {
  const fournie = r && r.version_extension;
  if (!fournie || !plusRecente(fournie, VERSION)) return;
  const soi = await chrome.management.getSelf().catch(() => null);
  if (!soi || soi.installType !== "development") return;
  const { rechargeVers } = await lire("rechargeVers");
  if (rechargeVers === fournie) return;
  await chrome.storage.local.set({ rechargeVers: fournie });
  setTimeout(() => chrome.runtime.reload(), 1000);
}

importScripts("boite.js", "guide.js");  // la boîte chiffrée de la synchronisation, quand aucune appli ne répond
const libelleSite = (bk) => ((globalThis.SUIVI_GUIDE || {})[bk] || [bk])[0];
// Une réponse en temps limité (sans AbortController : pas partout, Orion sur l'iPhone).
const avecDelai = (promesse, ms) => Promise.race([promesse, new Promise((_, ko) => setTimeout(() => ko(new Error("délai dépassé")), ms))]);
const ROUTES = { page: "importer", solde: "solde", mouvements: "mouvements" };

/* Plusieurs comptes chez un même bookmaker : rien n'est enregistré tant que tu n'as pas dit, sur le site, sur quel
   compte tu es connecté. Ta réponse vaut pour cet onglet (3 heures au plus) : un autre onglet, ou plus tard, et
   l'extension redemande. Retenue à trois endroits, car Orion (iPhone) perd parfois la mémoire de session : par la page
   elle-même (qui la renvoie avec chaque envoi), en mémoire de session, et dans le stockage de l'extension. */
const DUREE_CONFIRMATION = 3 * 3600 * 1000;
const cleConfirmation = (onglet, bookmaker) => `compte:${onglet}:${bookmaker}`;
const confirmations = {};  // tant que le service worker vit

async function compteConfirme(onglet, bookmaker) {
  if (onglet == null) return null;
  const cle = cleConfirmation(onglet, bookmaker);
  const valide = (c) => (c && Date.now() - c.le < DUREE_CONFIRMATION ? c.compte_id : null);
  if (valide(confirmations[cle])) return valide(confirmations[cle]);
  // Orion (iPhone) : stockage de session parfois sans réponse ; 2 s au plus, puis le stockage de l'extension.
  const session = chrome.storage.session
    ? (await avecDelai(Promise.resolve(chrome.storage.session.get(cle)), 2000).catch(() => null)) || {} : {};
  if (valide(session[cle])) return valide(session[cle]);
  const { confirmations_comptes: o = {} } = await avecDelai(lire("confirmations_comptes"), 2000).catch(() => ({}));
  return valide(o[cle]);
}

async function confirmerCompte(onglet, bookmaker, compteId) {
  if (onglet == null) return;
  const cle = cleConfirmation(onglet, bookmaker), c = { compte_id: compteId, le: Date.now() };
  confirmations[cle] = c;
  if (chrome.storage.session) {
    await avecDelai(Promise.resolve(chrome.storage.session.set({ [cle]: c })), 2000).catch(() => {});
  }
  const { confirmations_comptes: o = {} } = await avecDelai(lire("confirmations_comptes"), 2000).catch(() => ({}));
  const garder = Object.fromEntries(Object.entries(o).filter(([, v]) => v && Date.now() - v.le < DUREE_CONFIRMATION));
  await avecDelai(chrome.storage.local.set({ confirmations_comptes: { ...garder, [cle]: c } }), 2000).catch(() => {});
  // La page de l'onglet le retient aussi (choix fait dans l'icône) : elle le renverra avec ses envois.
  try {
    const p = chrome.tabs.sendMessage(onglet, { type: "compte_choisi", bookmaker, compte_id: compteId }, () => void chrome.runtime.lastError);
    if (p && p.catch) p.catch(() => {});
  } catch { /* onglet fermé */ }
}

/* Demande à la page principale de l'onglet d'afficher le choix du compte. */
function demanderCompte(onglet, r) {
  if (onglet == null) return;
  try {  // Orion (iPhone) ne rend pas toujours de promesse : un rappel, et rien si l'onglet est fermé
    const p = chrome.tabs.sendMessage(onglet, { type: "demander_compte", bookmaker: r.bookmaker, libelle: r.libelle, comptes: r.comptes },
      { frameId: 0 }, () => void chrome.runtime.lastError);
    if (p && p.catch) p.catch(() => {});
  } catch { /* onglet fermé */ }
}

async function envoyerAppli(page) {
  // Sur l'iPhone, l'adresse de l'appli ne répond jamais (rien n'y écoute) : 4 s au plus, puis la boîte.
  const reponse = await avecDelai(fetch(`${APPLI}/api/extension/${ROUTES[page.type] || "importer"}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Suivi-Paris": "1" },
    body: JSON.stringify({ texte: page.texte, bookmaker: page.bookmaker, capture_le: page.capture_le, url: page.url,
      compte_id: page.compte_id || null, version_extension: VERSION }),
  }), 4000);
  const r = await reponse.json();
  suivreVersion(r);
  if (!reponse.ok) return { statut: "erreur", message: r.erreur || `erreur ${reponse.status}` };
  return r;
}

async function mettreEnAttente(page, statut, erreur = null, comptes = null) {
  const { attente = [] } = await lire("attente");
  // Une seule page gardée par bookmaker, sorte et adresse (un seul solde par bookmaker) : la plus récente suffit.
  // Prête à envoyer (iPhone) : une page n'en remplace une autre que si elle contient tous ses paris (même relue
  // après un changement de cotes) ; sinon les deux restent, rien n'est perdu.
  const contient = (p) => Array.isArray(p.refs) && Array.isArray(page.refs) && p.refs.every((x) => page.refs.includes(x));
  const meme = (p) => p.bookmaker === page.bookmaker && (p.type || "page") === (page.type || "page")
    && (page.type === "solde" || (statut === "a_envoyer" && p.statut === "a_envoyer" ? p.texte === page.texte || contient(p) : p.url === page.url));
  const reste = attente.filter((p) => !meme(p));
  reste.push({ ...page, statut, erreur, comptes });
  await chrome.storage.local.set({ attente: reste.slice(-MAX_ATTENTE) });
  chrome.alarms.create("vider", { periodInMinutes: 1 });
  await majBadge();
}

async function noter(r, page) {
  const type = page.type || "page";
  // Le journal ne garde que ce qui change quelque chose : un solde inchangé, une page sans rien, non.
  if (type === "solde" && !(r.statut === "ok" && r.change) && r.statut !== "boite") return;
  if (type === "mouvements" && r.statut === "ok" && !r.nouveaux) return;
  if (type !== "page" && (r.statut === "aucun_solde" || r.statut === "aucun_mouvement" || r.statut === "non_reconnu")) return;
  const { journal = [] } = await lire("journal");
  journal.unshift({ quand: new Date().toISOString(), type, bookmaker: page.bookmaker, libelle: r.libelle || page.bookmaker,
    compte: r.compte || null, statut: r.statut, nouveaux: r.nouveaux || 0, mis_a_jour: r.mis_a_jour || 0,
    id: r.id || null, lus: page.lus || 0,  // id : la page déposée dans la boîte, dont l'appli renverra l'accusé
    solde: r.solde ?? null, sens: r.sens || null,
    // Les paris nouveaux ou mis à jour, et en quoi (« état : en_cours → gagne ») : visibles dans la fenêtre.
    details: (r.details || []).slice(0, 25) });
  await chrome.storage.local.set({ journal: journal.slice(0, MAX_JOURNAL) });
  if (type === "page" && r.statut === "ok" && (r.nouveaux || r.mis_a_jour)) {
    const { nonLus = 0 } = await lire("nonLus");
    await chrome.storage.local.set({ nonLus: nonLus + r.nouveaux + r.mis_a_jour });
    const parts = [];
    if (r.nouveaux) parts.push(`${r.nouveaux} nouveau${r.nouveaux > 1 ? "x" : ""} pari${r.nouveaux > 1 ? "s" : ""}`);
    if (r.mis_a_jour) parts.push(`${r.mis_a_jour} mis à jour`);
    chrome.notifications.create({ type: "basic", iconUrl: "icone.png", title: `Suivi Paris – ${r.libelle}`,
      message: `${parts.join(", ")} sur le compte ${r.compte}.` });
  }
  await majBadge();
}

async function majBadge() {
  const { attente = [], nonLus = 0 } = await lire(["attente", "nonLus"]);
  const choix = attente.some((p) => p.statut === "choisir_compte" || p.statut === "aucun_compte");
  if (choix) {
    chrome.action.setBadgeBackgroundColor({ color: "#E5334F" });
    chrome.action.setBadgeText({ text: "!" });
  } else if (attente.length) {
    chrome.action.setBadgeBackgroundColor({ color: "#8A6100" });
    chrome.action.setBadgeText({ text: String(attente.length) });
  } else {
    chrome.action.setBadgeBackgroundColor({ color: "#5B3DF5" });
    chrome.action.setBadgeText({ text: nonLus ? `+${nonLus}` : "" });
  }
}

/* Une page reçue : envoyée tout de suite, sinon gardée. */
async function traiter(page, onglet) {
  let r;
  // Le compte dit par la page (choisi dans cet onglet), sinon celui retenu par l'extension pour l'onglet.
  const retenu = await compteConfirme(onglet, page.bookmaker);
  const choisi = Number(page.compte_id) || retenu;
  if (choisi && choisi !== retenu) await confirmerCompte(onglet, page.bookmaker, choisi);
  try {
    r = await envoyerAppli({ ...page, compte_id: choisi || null });
  } catch {
    // Pas d'appli ici (iPhone, ou ordinateur fermé) : dans la boîte de la synchronisation, si l'extension est liée.
    const { liaison } = await lire("liaison");
    let erreurBoite = null;
    if (liaison && liaison.g) {
      try {
        // Comme l'appli le ferait : le compte choisi sur ce site, sinon le seul ; plusieurs comptes → on demande.
        // La liste des comptes (gardée 10 min) manque : le compte sera vérifié à l'envoi.
        const comptes = await lireComptesBoite(liaison).catch(() => null);
        const c = compteBoite(comptes, page.bookmaker, choisi || null);
        const libelle = libelleSite(page.bookmaker);
        if (!c.ok) {
          const r = { statut: c.statut, bookmaker: page.bookmaker, libelle, comptes: c.comptes };
          await mettreEnAttente(page, c.statut, null, c.comptes);
          if (c.statut === "choisir_compte") demanderCompte(onglet, r);
          await noter(r, page).catch(() => {});
          return r;
        }
        // Pas d'envoi tout de suite : la page est gardée ici, et tout part en une fois quand tu touches « Envoyer
        // vers l'appli » dans la fenêtre de l'extension (un seul passage par GitHub, qui limite les écritures).
        const compte = c.compte || null;
        await mettreEnAttente({ ...page, compte_id: compte ? compte.id : choisi || null, compte_nom: compte ? compte.nom : null }, "a_envoyer");
        return { statut: "a_envoyer", libelle, compte: compte ? compte.nom : null };
      } catch (e) {  // hors connexion, ou GitHub qui refuse : gardée ci-dessous, renvoyée plus tard, avec la raison
        erreurBoite = String((e && e.message) || e);
      }
    }
    await mettreEnAttente(page, "appli_fermee", erreurBoite);
    // Sur l'iPhone, l'appli de l'ordinateur ne répond jamais : la vraie raison est celle de la synchronisation.
    return { statut: "en_attente", erreur: erreurBoite };
  }
  if (r.statut === "choisir_compte" || r.statut === "aucun_compte") {
    await mettreEnAttente(page, r.statut);
    if (r.statut === "choisir_compte") demanderCompte(onglet, r);
  }
  await noter(r, page);
  return r;
}

/* Le compte d'un bookmaker vient d'être choisi (sur le site ou dans l'icône) : les pages de ce bookmaker qui
   attendaient partent sur ce compte. */
async function attribuer(bookmaker, compteId) {
  const { attente = [] } = await lire("attente");
  let reste = [];
  const resultats = [];
  let fermee = false;
  for (const page of attente) {
    if (page.bookmaker !== bookmaker) { reste.push(page); continue; }
    try {
      if (fermee) throw new Error("appli injoignable");
      const r = await envoyerAppli({ ...page, compte_id: compteId });
      if (r.statut === "choisir_compte" || r.statut === "aucun_compte") reste.push(page);
      await noter(r, page);
      resultats.push({ ...r, type: page.type || "page" });
    } catch {
      fermee = true;
      reste.push(page);
    }
  }
  // Pas d'appli (iPhone) : les pages de ce site sont prêtes à envoyer, sur le compte choisi.
  const { liaison } = await lire("liaison");
  if (fermee && liaison && liaison.g) {
    const comptes = await lireComptesBoite(liaison).catch(() => null);
    const c = compteBoite(comptes, bookmaker, compteId);
    const compte = c.ok ? c.compte : null;
    reste = reste.map((p) => {
      if (p.bookmaker !== bookmaker) return p;
      resultats.push({ statut: "a_envoyer", libelle: libelleSite(bookmaker), compte: compte ? compte.nom : null, type: p.type || "page" });
      return { ...p, statut: "a_envoyer", comptes: null, compte_id: compte ? compte.id : compteId, compte_nom: compte ? compte.nom : null };
    });
  }
  await chrome.storage.local.set({ attente: reste });
  await majBadge();
  return resultats;
}

/* Renvoie les pages gardées ; s'arrête à la première si l'appli est toujours fermée. */
/* Renvoie les pages gardées à l'appli de l'ordinateur (toutes les minutes). Sans appli (iPhone), elles ne partent
   vers la synchronisation que sur demande (`manuel` : « Envoyer vers l'appli » dans la fenêtre), en un seul envoi. */
async function vider({ manuel = false } = {}) {
  const { attente = [] } = await lire("attente");
  const reste = [];
  let fermee = false;
  for (const page of attente) {
    if (fermee) { reste.push(page); continue; }
    try {
      const r = await envoyerAppli(page);
      if (r.statut === "choisir_compte" || r.statut === "aucun_compte") reste.push({ ...page, statut: r.statut });
      if (r.statut !== page.statut) await noter(r, page); // pas une ligne de journal par minute d'attente
    } catch {
      fermee = true;
      reste.push(page);
    }
  }
  // Appli toujours injoignable : ce qui attend part dans la boîte de la synchronisation, si l'extension est liée.
  // (Une page dont le compte reste à choisir attend ; celle d'un compte créé depuis part.)
  const { liaison } = await lire("liaison");
  let erreur = null, envoyees = 0;
  if (manuel && fermee && liaison && liaison.g && reste.length) {
    try {
      const comptes = await lireComptesBoite(liaison);
      const partir = [], garder = [];
      for (const p of reste) {
        const c = compteBoite(comptes, p.bookmaker, p.compte_id || null);
        if (c.ok) partir.push(pageBoite(p, c.compte)); else garder.push({ ...p, statut: c.statut, comptes: c.comptes });
      }
      if (partir.length) {
        await deposerDansBoite(liaison, partir);
        envoyees = partir.length;
        for (const p of partir) {
          await noter({ statut: "boite", id: p.id, libelle: libelleSite(p.bookmaker), compte: p.compte_nom }, p).catch(() => {});
        }
      }
      reste.splice(0, reste.length, ...garder);
    } catch (e) { erreur = String((e && e.message) || e); }  // rien n'est perdu : elles restent prêtes
  }
  await chrome.storage.local.set({ attente: reste });
  if (!reste.length) chrome.alarms.clear("vider");
  await majBadge();
  return { restantes: reste.length, appliFermee: fermee, envoyees, erreur };
}

/* Sites aux adresses changeantes (Sportaza : « sportaza-5178.com ») : le manifeste ne peut pas les nommer à l'avance.
   Autorisée depuis l'icône (Chrome demande la permission), une adresse reçoit le script de page, comme les autres
   sites ; au démarrage, les adresses déjà autorisées sont réinscrites. */
const MIROIRS = [/^(www\.)?sportaza-\d+\.com$/];
const estMiroir = (hote) => MIROIRS.some((m) => m.test(hote));
async function inscrireMiroirs() {
  const { origins = [] } = await chrome.permissions.getAll();
  const hotes = [...new Set(origins.map((o) => { try { return new URL(o.replace("/*", "/")).hostname; } catch { return ""; } })
    .filter(estMiroir))];
  const deja = new Set((await chrome.scripting.getRegisteredContentScripts()).map((s) => s.id));
  const nouveaux = hotes.filter((h) => !deja.has(`miroir-${h}`)).map((h) => ({
    id: `miroir-${h}`, matches: [`*://${h}/*`], js: ["guide.js", "page.js"], runAt: "document_idle", persistAcrossSessions: true,
  }));
  if (nouveaux.length) await chrome.scripting.registerContentScripts(nouveaux);
  return hotes;
}

chrome.runtime.onMessage.addListener((message, expediteur, repondre) => {
  // « Récupérer tout mon historique » depuis le guide du site : la lecture du site (outils/), dans la page elle-même.
  if (message.type === "historique" && expediteur.tab && /^[a-z0-9]+$/.test(message.site || "")) {
    const cible = { tabId: expediteur.tab.id };
    chrome.scripting.executeScript({ target: cible, world: "MAIN", func: () => { window.__suiviParisExtension = true; } })
      .then(() => chrome.scripting.executeScript({ target: cible, world: "MAIN", files: [`outils/${message.site}-historique.js`] }))
      .then(() => repondre({ statut: "lance" }), (e) => repondre({ statut: "erreur", message: String(e && e.message || e) }));
    return true;
  }
  // Le dernier pari enregistré d'un site (guide du site : jusqu'où remonter).
  if (message.type === "dernier") {
    avecDelai(fetch(`${APPLI}/api/etat`), 3000).then((r) => r.json()).then((app) => {
      const dates = (app.comptes || []).filter((c) => c.bookmaker === message.bookmaker && c.dernier && c.dernier.date_pari)
        .map((c) => c.dernier.date_pari).sort();
      repondre(dates.length ? new Date(dates[dates.length - 1]).toLocaleDateString("fr-FR") : null);
    }, () => repondre(null));
    return true;
  }
  // Le code de liaison de la synchronisation (fenêtre de l'extension) : pour déposer les pages sans appli.
  if (message.type === "lier") {
    const l = message.code ? lireCodeLiaison(message.code) : null;
    if (message.code && !l) { repondre({ statut: "illisible" }); return false; }
    (l ? chrome.storage.local.set({ liaison: l }) : chrome.storage.local.remove("liaison"))
      .then(() => vider()).then(() => repondre({ statut: l ? "lie" : "delie" }), () => repondre({ statut: "erreur" }));
    return true;
  }
  if (message.type === "inscrire_miroirs") {
    inscrireMiroirs().then(repondre, () => repondre(null));
    return true;
  }
  const onglet = message.onglet ?? (expediteur.tab ? expediteur.tab.id : null);
  if (message.type === "page" || message.type === "solde" || message.type === "mouvements") {
    traiter(message, onglet).then(repondre, () => repondre(null));
    return true;
  }
  if (message.type === "confirmer_compte") {  // réponse au choix du compte (sur le site, ou dans l'icône)
    confirmerCompte(onglet, message.bookmaker, message.compte_id)
      .then(() => attribuer(message.bookmaker, message.compte_id)).then(repondre, () => repondre(null));
    return true;
  }
  if (message.type === "compte_confirme") {
    compteConfirme(onglet, message.bookmaker).then(repondre, () => repondre(null));
    return true;
  }
  if (message.type === "vider") {
    vider({ manuel: true }).then(repondre, () => repondre(null));
    return true;
  }
  if (message.type === "vu") {
    bonjour();
    chrome.storage.local.set({ nonLus: 0 }).then(majBadge).then(() => repondre(true));
    return true;
  }
  return false;
});

chrome.alarms.onAlarm.addListener((alarme) => {
  if (alarme.name === "vider") vider();
  if (alarme.name === "bonjour") bonjour(); // de temps en temps : suivre une mise à jour de l'appli sans attendre un envoi
});
/* Se signaler à l'appli (page Importer : « extension installée »), sans rien envoyer d'autre. */
async function bonjour() {
  try {
    const reponse = await avecDelai(fetch(`${APPLI}/api/extension/bonjour`, { method: "POST",
      headers: { "Content-Type": "application/json", "X-Suivi-Paris": "1" }, body: JSON.stringify({ version_extension: VERSION }) }), 3000);
    await suivreVersion(await reponse.json());
  } catch { /* appli fermée */ }
}
chrome.runtime.onStartup.addListener(() => { inscrireMiroirs().catch(() => {}); bonjour(); vider(); chrome.alarms.create("bonjour", { periodInMinutes: 30 }); });
/* Après une mise à jour de l'extension, les onglets déjà ouverts sur les sites gardent un script coupé d'elle : le
   nouveau y est remis tout de suite, sans avoir à recharger les pages. */
async function reinjecter() {
  const motifs = chrome.runtime.getManifest().content_scripts.flatMap((c) => c.matches);
  for (const onglet of await chrome.tabs.query({ url: motifs })) {
    await chrome.scripting.executeScript({ target: { tabId: onglet.id }, files: ["guide.js", "page.js"] }).catch(() => {});
  }
}
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install" || details.reason === "update") reinjecter().catch(() => {});
  inscrireMiroirs().catch(() => {});
  bonjour();
  majBadge();
  chrome.alarms.create("bonjour", { periodInMinutes: 30 });
});
