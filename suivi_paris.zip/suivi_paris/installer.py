"""Crée les raccourcis : icône sur le bureau (et menu Démarrer / menu des applications).

Appelé par « Installer Suivi Paris.cmd » (Windows) ou « installer-suivi-paris.sh » (macOS, Linux).
Usage : python -m suivi_paris.installer [--retirer]
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

from .chemins import RACINE_PROJET
from .version import VERSION

ICONES = RACINE_PROJET / "assets"


def _python_fenetre() -> Path:
    """Le Python de l'environnement du projet ; sous Windows, pythonw (aucune fenêtre noire)."""
    if sys.platform == "win32":
        pythonw = RACINE_PROJET / ".venv" / "Scripts" / "pythonw.exe"
        return pythonw if pythonw.exists() else Path(sys.executable).with_name("pythonw.exe")
    return RACINE_PROJET / ".venv" / "bin" / "python"


def _powershell(script: str) -> str:
    sortie = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                            capture_output=True, text=True, check=True)
    return sortie.stdout.strip()


def _windows(retirer: bool) -> list[str]:
    bureau = Path(_powershell("[Environment]::GetFolderPath('Desktop')"))
    programmes = Path(_powershell("[Environment]::GetFolderPath('Programs')"))
    raccourcis = [
        (bureau / "Suivi Paris.lnk", "-m suivi_paris.lanceur"),
        (programmes / "Suivi Paris.lnk", "-m suivi_paris.lanceur"),
        (programmes / "Suivi Paris (démonstration).lnk", "-m suivi_paris.lanceur --demo"),
    ]
    faits = []
    for chemin, arguments in raccourcis:
        if retirer:
            chemin.unlink(missing_ok=True)
            continue
        script = (
            "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('{lnk}');"
            "$s.TargetPath='{cible}';$s.Arguments='{args}';$s.WorkingDirectory='{dossier}';"
            "$s.IconLocation='{icone}';$s.Description='Suivi de paris sportifs';$s.Save()"
        ).format(lnk=str(chemin).replace("'", "''"), cible=_python_fenetre(), args=arguments,
                 dossier=str(RACINE_PROJET).replace("'", "''"), icone=ICONES / "icone.ico")
        _powershell(script)
        faits.append(str(chemin))
    return faits


def _macos(retirer: bool) -> list[str]:
    """Une vraie application « Suivi Paris » dans ~/Applications (elle s'ouvre sans fenêtre de Terminal), et un
    raccourci sur le bureau."""
    appli = Path.home() / "Applications" / "Suivi Paris.app"
    bureau = Path.home() / "Desktop" / "Suivi Paris.app"
    ancien = Path.home() / "Desktop" / "Suivi Paris.command"  # raccourci des premières versions
    ancien.unlink(missing_ok=True)
    if bureau.is_symlink() or bureau.exists():
        bureau.unlink()
    if retirer:
        shutil.rmtree(appli, ignore_errors=True)
        return []
    shutil.rmtree(appli, ignore_errors=True)
    executable = appli / "Contents" / "MacOS" / "SuiviParis"
    ressources = appli / "Contents" / "Resources"
    executable.parent.mkdir(parents=True)
    ressources.mkdir(parents=True)
    # LSUIElement (Info.plist) : le serveur n'a pas de fenêtre à lui ; sans cette clé, son icône sautillerait dans le
    # Dock sans fin. La fenêtre de l'appli est celle de Chrome, qui a son icône.
    executable.write_text(
        f'#!/bin/sh\ncd "{RACINE_PROJET}"\nexec "{_python_fenetre()}" -m suivi_paris.lanceur "$@"\n', encoding="utf-8")
    executable.chmod(0o755)
    # L'icône, toute prête (assets/icone.icns) : sans elle, le Finder montre une application blanche.
    shutil.copy2(ICONES / "icone.icns", ressources / "icone.icns")
    (appli / "Contents" / "Info.plist").write_text(f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>Suivi Paris</string>
  <key>CFBundleDisplayName</key><string>Suivi Paris</string>
  <key>CFBundleIdentifier</key><string>fr.suiviparis.app</string>
  <key>CFBundleExecutable</key><string>SuiviParis</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>{VERSION}</string>
  <key>CFBundleIconFile</key><string>icone</string>
  <key>NSAppSleepDisabled</key><true/>
  <key>LSUIElement</key><true/>
</dict></plist>
""", encoding="utf-8")
    os.utime(appli)  # le Finder relit l'icône d'une application modifiée
    # Pas d'App Nap : sans fenêtre à elle (la fenêtre est celle de Chrome), macOS ralentirait l'appli. Le lanceur le
    # demande aussi lui-même ; ce réglage en est la seconde ceinture.
    try:
        subprocess.run(["defaults", "write", "fr.suiviparis.app", "NSAppSleepDisabled", "-bool", "YES"],
                       capture_output=True, check=False)
    except OSError:
        pass
    faits = [str(appli)]
    if bureau.parent.exists():
        bureau.symlink_to(appli)
        faits.append(str(bureau))
    return faits


def _linux(retirer: bool) -> list[str]:
    applications = Path.home() / ".local" / "share" / "applications"
    entrees = [("suivi-paris.desktop", "Suivi Paris", ""),
               ("suivi-paris-demo.desktop", "Suivi Paris (démonstration)", " --demo")]
    faits = []
    for fichier, nom, option in entrees:
        cible = applications / fichier
        if retirer:
            cible.unlink(missing_ok=True)
            (Path.home() / "Desktop" / fichier).unlink(missing_ok=True)
            continue
        applications.mkdir(parents=True, exist_ok=True)
        contenu = (
            "[Desktop Entry]\nType=Application\n"
            f"Name={nom}\nComment=Suivi de paris sportifs\n"
            f'Exec="{_python_fenetre()}" -m suivi_paris.lanceur{option}\n'
            f"Path={RACINE_PROJET}\nIcon={ICONES / 'icone.png'}\nTerminal=false\nCategories=Office;Finance;\n"
        )
        cible.write_text(contenu, encoding="utf-8")
        cible.chmod(0o755)
        faits.append(str(cible))
        bureau = Path.home() / "Desktop"
        if not option and bureau.exists():
            (bureau / fichier).write_text(contenu, encoding="utf-8")
            (bureau / fichier).chmod(0o755)
            faits.append(str(bureau / fichier))
    return faits


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--retirer", action="store_true", help="supprimer les raccourcis")
    args = ap.parse_args()
    fonction = {"win32": _windows, "darwin": _macos}.get(sys.platform, _linux)
    faits = fonction(args.retirer)
    if args.retirer:
        print("Raccourcis supprimés.")
    else:
        print("Raccourcis créés :")
        for f in faits:
            print(f"  {f}")


if __name__ == "__main__":
    main()
