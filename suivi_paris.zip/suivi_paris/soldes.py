"""Le solde d'un compte, lu dans l'en-tête des pages du bookmaker (l'extension Chrome le relève à chaque visite).

Chaque site l'affiche en haut de toutes ses pages, une fois connecté :

    Betclic   « 40 » (en direct), « 1 € », « 1 234,56 € »         le dernier montant sous le bandeau légal
    Winamax   « 4 567,89 € », « 7,00 € », pseudo                   le premier montant avant le pseudo
    Unibet    « 3 456,78€ », « BonusBet12,00€ »                     le montant seul (le BonusBet n'est pas du cash)
    PMU       « 2 345,67 € » entre le menu et « Déconnexion »
    ps3838    « 1,456.78EURAB12345678 »                               solde puis numéro de compte, collés
    PIWI247   comme ps3838 (même logiciel), numéro « PIW_12345 »
    Olybet    « DÉPÔT », prénom, « 425.66 € »                          point décimal
    bwin      « Dépôt », « 1 234,56 € »                                 le montant qui suit le bouton Dépôt
    Sportaza  « Solde réel », « 54,66 € » ; le titulaire avant « Dernière session »
    OrbitX    « Balance:1,721.59 » ; le pseudo juste avant
    NetBet    « Réel », « 380,69 € » (dans le cadre du compte, pam.netbet.fr)
    bet365    « Récompenses », « 1 234,56 € »                          le montant qui suit le bouton Récompenses

Seul le haut de la page est lu : plus bas, les montants sont des cotes, des mises ou des gains.
L'extension lit la page affichée (innerText) : elle voit aussi ce qu'un Ctrl+A ne copie pas, comme les menus
non sélectionnables (Betclic) ; les fenêtres de recherche autour de chaque repère en tiennent compte.
"""
from __future__ import annotations

import re

from .adaptateurs import sportaza
from .modeles import montant

_MONTANT = re.compile(r"^\d{1,3}(?:[   ]?\d{3})*(?:,\d{1,2})?\s*€$")
_PS3838 = re.compile(r"^(\d[\d,]*\.\d{2})\s*EUR\s*([A-Z]{2}\d{5,}|PIW_\d{3,})$")
_POINT_DECIMAL = re.compile(r"^(\d{1,3}(?:[ ,]?\d{3})*\.\d{2})\s*€$")
_MONTANT_DEVISE = re.compile(r"^(\d{1,3}(?:[   ]?\d{3})*(?:,\d{1,2})?)\s*(€|CHF|£|\$)$")
# « CHF 360.61 », « € 54.66 » (site en anglais) : la monnaie devant, point décimal.
_MONTANT_DEVISE_AVANT = re.compile(r"^(?:CHF|€|£|\$)\s*(\d[\d,  ]*(?:\.\d{1,2})?)$")
_DEVISES = {"€": "EUR", "CHF": "CHF", "£": "GBP", "$": "USD"}


def _nombre_libre(brut: str) -> float:
    """« 1 234,56 », « 1,234.56 », « 360.61 » -> nombre."""
    n = re.sub(r"[\s  ]", "", brut)
    if "," in n and "." in n:
        n = n.replace(",", "")
    elif "," in n:
        n = n.replace(",", ".") if re.search(r",\d{1,2}$", n) else n.replace(",", "")
    return float(n)
_LIGNES = 60
# Ce qui n'est plus l'en-tête : une date, une heure, les mots d'un pari ou d'un mouvement.
_FIN_EN_TETE = re.compile(r"\d{2}/\d{2}/\d{4}|\b\d{1,2}[:h]\d{2}\b|^(Mise|Gains|Simple|Combin|Système|Réf|Retour)\b",
                          re.IGNORECASE)


_ESPACES = str.maketrans({"\u00a0": " ", "\u202f": " ", "\u2007": " ", "\u2009": " ", "\u200b": ""})


def _lignes(texte: str) -> list[str]:
    """Les premières lignes non vides, espaces insécables ramenées à des espaces. Relevée par l'extension (innerText),
    la page peut couper un montant de son « € » : « 1 234,56 » puis « € » ne font qu'une ligne."""
    lignes: list[str] = []
    for brute in texte.translate(_ESPACES).splitlines()[:300]:
        l = re.sub(r"\s+", " ", brute).strip()
        if not l:
            continue
        if l == "€" and lignes and re.fullmatch(r"[\d ,]+(?:[.,]\d{1,2})?", lignes[-1]):
            lignes[-1] += " €"
            continue
        lignes.append(l)
    return lignes[:_LIGNES]


def _indice(lignes: list[str], libelle: str) -> int | None:
    """La première ligne qui vaut `libelle`, sans tenir compte de la casse."""
    cible = libelle.lower()
    return next((i for i, l in enumerate(lignes) if l.lower() == cible), None)


def lire(bookmaker: str, texte: str) -> tuple[float | None, str | None]:
    """Renvoie (solde, identifiant du compte s'il est affiché), ou (None, None) si l'en-tête ne le montre pas
    (pas connecté, page sans en-tête)."""
    lignes = _lignes(texte)
    montants = [(i, l) for i, l in enumerate(lignes) if _MONTANT.match(l)]
    if bookmaker in ("ps3838", "piwi247"):
        for l in lignes[:10]:
            m = _PS3838.match(l.replace(" ", ""))
            if m:
                return float(m.group(1).replace(",", "")), m.group(2)
        return None, None
    if bookmaker == "orbitx":
        from .adaptateurs import orbitx

        for l in lignes[:40]:
            m = re.match(r"^Balance\s*:\s*(\d[\d,]*(?:\.\d{1,2})?)$", l)
            if m:
                return float(m.group(1).replace(",", "")), orbitx.identifiant(texte)
        return None, None
    if bookmaker == "netbet":
        debut = _indice(lignes, "Réel")
        if debut is None:
            return None, None
        apres = [(i, l) for i, l in montants if debut < i <= debut + 2]
        return (montant(apres[0][1]) if apres else None), None
    if bookmaker == "sportaza":
        # En euros (« 54,66 € ») ou en francs suisses (« 360,61 CHF ») : le montant du site, dans la monnaie du compte.
        debut = next((i for i, l in enumerate(lignes) if l.lower() in ("solde réel", "real balance")), None)
        if debut is None:
            return None, None
        for l in lignes[debut + 1:debut + 3]:
            m = _MONTANT_DEVISE.match(l) or _MONTANT_DEVISE_AVANT.match(l)
            if m:
                return _nombre_libre(m.group(1)), sportaza.identifiant(texte)  # le titulaire
        return None, None
    if bookmaker == "bwin":
        debut = _indice(lignes, "Dépôt")
        if debut is None:
            return None, None
        apres = [(i, l) for i, l in montants if debut < i <= debut + 2]
        return (montant(apres[0][1]) if apres else None), None
    if bookmaker == "olybet":
        # Le bouton « DÉPÔT », le prénom, puis le solde (« 425.66 € », point décimal).
        debut = _indice(lignes, "Dépôt")
        if debut is None:
            return None, None
        for l in lignes[debut + 1:debut + 4]:
            m = _POINT_DECIMAL.match(l)
            if m:
                return float(m.group(1).replace(",", "").replace(" ", "")), None
        return None, None
    if bookmaker == "winamax":
        fin = _indice(lignes, "Mon espace perso")
        if fin is None:
            return None, None
        avant = [(i, l) for i, l in montants if fin - 15 <= i < fin]
        pseudo = lignes[fin - 1] if fin and re.fullmatch(r"[\w.\-]{3,30}", lignes[fin - 1]) else None
        return (montant(avant[0][1]) if avant else None), pseudo
    if bookmaker == "betclic":
        # Juste sous le bandeau « … JOUEURS-INFO-SERVICE.FR … » : le nombre de matchs en direct, les freebets
        # éventuels, puis le solde. Plus bas (page des dépôts…), un montant n'est pas le solde.
        debut = next((i for i, l in enumerate(lignes) if "JOUEURS-INFO-SERVICE" in l.upper()), None)
        if debut is None:
            return None, None
        # Après le bandeau : le menu du site (« Sport », « Live », « Turf »… que l'extension voit, pas un Ctrl+A),
        # puis les freebets (« 1 € ») et le solde, à la suite. Le solde est le dernier montant de cette première
        # suite. Une date ou une heure arrête la lecture : plus bas, ce sont des dépôts ou des paris.
        dernier = None
        for l in lignes[debut + 1:debut + 25]:
            if _MONTANT.match(l):
                dernier = l
            elif dernier or _FIN_EN_TETE.search(l):
                break
        return (montant(dernier) if dernier else None), None
    if bookmaker == "pmu":
        # Menu du profil ouvert : le solde juste avant « Déconnexion ». Sinon (PMU Sport) : juste après « PLAY ZONE »,
        # le dernier onglet de l'en-tête, avant « Accueil ».
        fin = _indice(lignes, "Déconnexion")
        if fin is not None:
            avant = [(i, l) for i, l in montants if fin - 10 <= i < fin]
            if avant:
                return montant(avant[-1][1]), None
        debut = _indice(lignes, "PLAY ZONE")
        if debut is None:
            return None, None
        for l in lignes[debut + 1:debut + 4]:
            if _MONTANT.match(l):
                return montant(l), None
            if l.lower() == "accueil":
                break
        return None, None
    if bookmaker == "unibet":
        # Le solde suit l'onglet « Mes paris » de l'en-tête ; « BonusBet12,00€ » (lettres collées) est écarté.
        debut = _indice(lignes, "Mes paris")
        if debut is None:
            return None, None
        apres = [(i, l) for i, l in montants if debut < i <= debut + 8]
        return (montant(apres[0][1]) if apres else None), None
    if bookmaker == "bet365":
        debut = _indice(lignes, "Récompenses")
        if debut is None:
            return None, None
        apres = [(i, l) for i, l in montants if debut < i <= debut + 8]
        return (montant(apres[0][1]) if apres else None), None
    return None, None


def devise(texte: str) -> str | None:
    """La monnaie des montants de l'en-tête (« 360,61 CHF » -> « CHF »), si l'en-tête en montre un."""
    for l in _lignes(texte):
        m = _MONTANT_DEVISE.match(l)
        if m:
            return _DEVISES[m.group(2)]
        m = re.match(r"^(CHF|€|£|\$)\s*\d[\d,  ]*(?:\.\d{1,2})?$", l)
        if m:
            return _DEVISES[m.group(1)]
    return None
