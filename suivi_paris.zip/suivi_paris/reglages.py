"""Réglages de l'application (résumé iPhone, accès depuis l'iPhone…), dans reglages.json à côté de la base."""
from __future__ import annotations

import json
from pathlib import Path

from .chemins import dossier_donnees


def _chemin() -> Path:
    return dossier_donnees() / "reglages.json"


def lire() -> dict:
    try:
        return json.loads(_chemin().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def ecrire(**valeurs) -> dict:
    r = lire() | valeurs
    chemin = _chemin()
    temporaire = chemin.with_suffix(".tmp")
    temporaire.write_text(json.dumps(r, ensure_ascii=False, indent=2), encoding="utf-8")
    temporaire.replace(chemin)
    return r
