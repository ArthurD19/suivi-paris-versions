"""Résumé iPhone : une page HTML autonome du tableau de bord, faite pour l'écran d'un téléphone.

Un seul fichier, sans script ni connexion : les polices sont intégrées, les graphiques sont dessinés en SVG.
Il s'ouvre donc aussi bien dans Safari que dans l'aperçu de l'app Fichiers (iCloud Drive). Trois périodes
(saison, 30 jours, 7 jours) se choisissent par des onglets en CSS pur.
"""
from __future__ import annotations

import base64
import os
import sys
from datetime import datetime, timedelta
from html import escape
from pathlib import Path

import pandas as pd

from . import analyse, stockage
from . import reglages as reglages_appli
from .chemins import dossier_donnees
from .modeles import LIBELLES_ETATS

WEB = Path(__file__).resolve().parent / "web"
NOM_FICHIER = "Suivi Paris - résumé.html"

SPORTS = {
    "Cyclisme": ("🚴", "#F5B700"), "Tennis": ("🎾", "#E2663B"), "Tennis de table": ("🏓", "#C2410C"),
    "Football": ("⚽", "#2F80ED"), "Basketball": ("🏀", "#1FB5A8"), "Moto": ("🏍️", "#EB4D7C"),
    "Formule 1": ("🏎️", "#3D3D5C"), "Athlétisme": ("🏃", "#00A3E0"), "Hockey sur glace": ("🏒", "#7A8CA8"),
    "Rugby": ("🏉", "#8B5E3C"), "Handball": ("🤾", "#A35BE0"), "Combiné": ("🧩", "#5B3DF5"),
    "Multi-sports": ("🧩", "#5B3DF5"), "Ski": ("⛷️", "#3BA3D9"), "Sports d'hiver": ("⛸️", "#6CB4E8"),
    "Golf": ("⛳", "#2E9E5B"), "MMA": ("🥊", "#B23A48"), "Boxe": ("🥊", "#D64545"),
    "Volley-ball": ("🏐", "#F2994A"), "Football américain": ("🏈", "#9C6644"), "Biathlon": ("🎯", "#2D9CDB"),
    "Ski alpin": ("⛷️", "#3BA3D9"), "Ski de fond": ("🎿", "#56CCF2"),
}
MOIS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."]


# --------------------------------------------------------------------------- #
# Où ranger le résumé
# --------------------------------------------------------------------------- #
def dossier_icloud() -> Path | None:
    """Le dossier iCloud Drive de l'ordinateur, s'il existe (Mac, ou iCloud pour Windows)."""
    candidats = []
    if sys.platform == "darwin":
        candidats.append(Path.home() / "Library" / "Mobile Documents" / "com~apple~CloudDocs")
    elif sys.platform == "win32":
        candidats += [Path(os.environ.get("USERPROFILE", Path.home())) / "iCloudDrive", Path.home() / "iCloudDrive"]
    for c in candidats:
        if c.is_dir():
            return c
    return None


def destination(icloud_autorise: bool = True) -> tuple[Path, bool]:
    """(chemin du fichier, True si c'est dans iCloud Drive)."""
    icloud = dossier_icloud() if icloud_autorise else None
    if icloud:
        dossier = icloud / "Suivi Paris"
        dossier.mkdir(exist_ok=True)
        return dossier / NOM_FICHIER, True
    dossier = dossier_donnees() / "resume"
    dossier.mkdir(exist_ok=True)
    return dossier / NOM_FICHIER, False


def reglages() -> dict:
    return reglages_appli.lire()


def enregistrer_reglages(**valeurs) -> dict:
    return reglages_appli.ecrire(**valeurs)


# --------------------------------------------------------------------------- #
# Mise en forme
# --------------------------------------------------------------------------- #
def _euros(x, signe=False, rond=False) -> str:
    if x is None or pd.isna(x):
        return "—"
    v = abs(x)
    texte = f"{v:,.0f}" if rond else f"{v:,.2f}"
    texte = texte.replace(",", " ").replace(".", ",") + " €"
    if x < 0:
        return "−" + texte
    return ("+" + texte) if signe and x > 0 else texte


def _pct(ratio, signe=True) -> str:
    if ratio is None or pd.isna(ratio):
        return "—"
    v = ratio * 100
    t = f"{abs(v):.1f}".replace(".", ",") + " %"
    if not signe:
        return t
    return ("+" if v > 0 else "−" if v < 0 else "") + t


def _classe(x) -> str:
    return "gain" if x and x > 0 else "perte" if x and x < 0 else ""


def _date(iso) -> str:
    if not iso:
        return "—"
    d = pd.Timestamp(iso)
    return f"{d.day} {MOIS[d.month - 1]}"


def _sport(s: str) -> tuple[str, str]:
    return SPORTS.get(s, ("🎯", "#A7A3BF"))


def _police(nom: str) -> str:
    donnees = base64.b64encode((WEB / "polices" / nom).read_bytes()).decode()
    return f"url(data:font/woff2;base64,{donnees}) format('woff2')"


# --------------------------------------------------------------------------- #
# Graphiques SVG
# --------------------------------------------------------------------------- #
def _courbe(points: list[list], largeur=340, hauteur=150) -> str:
    if len(points) < 2:
        return '<p class="vide-graphe">Pas assez de paris réglés pour tracer la courbe.</p>'
    dates = [pd.Timestamp(p[0]).value for p in points]
    valeurs = [p[1] for p in points]
    x0, x1 = min(dates), max(dates)
    bas, haut = min(0.0, min(valeurs)), max(0.0, max(valeurs))
    marge = (haut - bas) * 0.08 or 1
    bas, haut = bas - marge, haut + marge

    def xy(d, v):
        x = (d - x0) / (x1 - x0 or 1) * largeur
        y = hauteur - (v - bas) / (haut - bas) * hauteur
        return f"{x:.1f},{y:.1f}"

    ligne = " ".join(xy(d, v) for d, v in zip(dates, valeurs))
    zero = hauteur - (0 - bas) / (haut - bas) * hauteur
    aire = f"0,{zero:.1f} {ligne} {largeur},{zero:.1f}"
    i_max = max(range(len(valeurs)), key=valeurs.__getitem__)
    sx, sy = xy(dates[i_max], valeurs[i_max]).split(",")
    return f"""<svg class="courbe" viewBox="0 -6 {largeur} {hauteur + 12}" preserveAspectRatio="none" role="img"
      aria-label="Profit cumulé : de 0 à {escape(_euros(valeurs[-1], True))}">
      <defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#fff" stop-opacity=".45"/><stop offset="1" stop-color="#fff" stop-opacity="0"/>
      </linearGradient></defs>
      <line x1="0" y1="{zero:.1f}" x2="{largeur}" y2="{zero:.1f}" stroke="#fff" stroke-opacity=".45" stroke-dasharray="4 4"/>
      <polygon points="{aire}" fill="url(#g)"/>
      <polyline points="{ligne}" fill="none" stroke="#fff" stroke-width="2.6" stroke-linejoin="round"
        vector-effect="non-scaling-stroke"/>
      <circle cx="{sx}" cy="{sy}" r="4.5" fill="#FFC53D" stroke="#1B1340" stroke-width="1.5"/>
    </svg>
    <div class="axe"><span>{_date(points[0][0])}</span><span>sommet {escape(_euros(valeurs[i_max], True, True))}</span>
      <span>{_date(points[-1][0])}</span></div>"""


def _sparkline(valeurs: list[float], couleur: str) -> str:
    if len(valeurs) < 2:
        return ""
    bas, haut = min(valeurs), max(valeurs)
    etendue = (haut - bas) or 1
    pts = " ".join(f"{i / (len(valeurs) - 1) * 100:.1f},{30 - (v - bas) / etendue * 28:.1f}" for i, v in enumerate(valeurs))
    return (f'<svg class="spark" viewBox="0 0 100 32" preserveAspectRatio="none" aria-hidden="true">'
            f'<polyline points="{pts}" fill="none" stroke="{couleur}" stroke-width="2.2" '
            f'vector-effect="non-scaling-stroke" stroke-linejoin="round"/></svg>')


# --------------------------------------------------------------------------- #
# Blocs
# --------------------------------------------------------------------------- #
def _panneau_periode(t: dict, titre: str) -> str:
    k = t["indicateurs"]
    comptes = [c for c in t["comptes"] if c["n"] or c["en_cours"]]
    sports = sorted(t["par_sport"], key=lambda l: -l["profit"])
    max_abs = max([abs(l["profit"]) for l in sports] or [1]) or 1
    types = sorted(t["par_type"], key=lambda l: -l["profit"])

    lignes_sports = "".join(
        f"""<li><span class="emb" style="background:{_sport(l['cle'])[1]}2e">{_sport(l['cle'])[0]}</span>
          <span class="nom"><b>{escape(l['cle'])}</b><small>{l['paris']} paris, ROI {_pct((l['roi'] or 0) / 100)}</small>
            <i class="jauge"><i style="width:{abs(l['profit']) / max_abs * 100:.0f}%;background:{'#0E9F62' if l['profit'] >= 0 else '#E5334F'}"></i></i></span>
          <b class="{_classe(l['profit'])}">{_euros(l['profit'], True, True)}</b></li>"""
        for l in sports
    ) or '<li class="discret">Aucun pari réglé sur cette période.</li>'

    cartes = "".join(
        f"""<div class="compte" style="--c:{c['couleur']}">
          <div class="qui"><span class="av">{escape(c['nom'][:1].upper())}</span>
            <span><b>{escape(c['nom'])}</b><small>{escape(c['bookmaker'].capitalize())}</small></span></div>
          <b class="montant {_classe(c['profit'])}">{_euros(c['profit'], True, True)}</b>
          <small>ROI {_pct(c['roi'])}, {c['n']} paris</small>
          {_sparkline(c['sparkline'], c['couleur'])}
        </div>"""
        for c in comptes
    )

    lignes_types = "".join(
        f"<tr><td>{escape(l['cle'])}</td><td>{l['paris']}</td>"
        f"<td class='{_classe(l['profit'])}'>{_euros(l['profit'], True, True)}</td>"
        f"<td class='{_classe(l['roi'])}'>{_pct((l['roi'] or 0) / 100)}</td></tr>"
        for l in types
    )

    return f"""
    <section class="heros">
      <p class="titre-periode">{escape(titre)}</p>
      <p class="profit">{_euros(k['profit'], True, abs(k['profit'] or 0) >= 1000)}</p>
      <p class="legende">de profit sur {_euros(k['mise'], rond=True)} misés</p>
      <div class="stats">
        <div><b>{_pct(k['roi'])}</b><span>ROI</span></div>
        <div><b>{k['n']}</b><span>paris réglés</span></div>
        <div><b>{_pct(k['reussite'], False)}</b><span>réussite</span></div>
      </div>
      {_courbe(t['courbe']['total'])}
    </section>
    {f'<h2>Comptes</h2><div class="comptes">{cartes}</div>' if cartes else ''}
    <h2>Par sport</h2>
    <ul class="sports">{lignes_sports}</ul>
    <details><summary>Par type de pari</summary>
      <table><thead><tr><th></th><th>Paris</th><th>Profit</th><th>ROI</th></tr></thead><tbody>{lignes_types}</tbody></table>
    </details>
    <div class="regul">
      <div><b>{_euros(k['meilleur_gain'] or 0, signe=True, rond=True) if k['meilleur_gain'] else '—'}</b><span>plus gros gain</span></div>
      <div><b>{k['meilleure_serie'] if k['meilleure_serie'] is not None else '—'}</b><span>gagnés d'affilée au mieux</span></div>
      <div><b>{_euros(k['mise_moyenne'])}</b><span>mise moyenne</span></div>
    </div>"""


def _liste_paris(df: pd.DataFrame) -> str:
    if df.empty:
        return '<p class="discret">Aucun.</p>'
    lignes = []
    for _, r in df.iterrows():
        emoji = _sport(r["sport"])[0]
        jouee = r.get("mise_jouee", r["mise"])
        mise = f"freebet de {_euros(jouee)}" if r.get("freebet") == 1 else f"mise {_euros(jouee)}"
        montant = (f"<b class='{_classe(r['profit'])}'>{_euros(r['profit'], True)}</b>" if pd.notna(r["profit"])
                   else f"<b>{_euros(r['mise'])}</b>")
        lignes.append(
            f"""<li><span class="emb">{emoji}</span>
              <span class="nom"><b>{escape(str(r['resume']))}</b>
                <small>{_date(r['date_ref'])}, {escape(str(r['compte_nom']))} ({escape(r['bookmaker_libelle'])}),
                  {escape(LIBELLES_ETATS.get(r['etat'], r['etat']).lower())}, {mise}</small></span>
              {montant}</li>""")
    return f'<ul class="paris">{"".join(lignes)}</ul>'


# --------------------------------------------------------------------------- #
# Page complète
# --------------------------------------------------------------------------- #
def generer(cx, maintenant: datetime | None = None) -> str:
    maintenant = maintenant or datetime.now()
    df = analyse.charger(cx)
    comptes = stockage.lister_comptes(cx)
    if df.empty:
        corps = '<p class="discret" style="padding:40px 0">Aucun pari pour l\'instant : importe ton historique sur ton ordinateur.</p>'
        onglets = ""
    else:
        fin = df["date_ref"].max().date()
        periodes = [("saison", "Saison", None), ("j30", "30 jours", fin - timedelta(days=29)),
                    ("j7", "7 jours", fin - timedelta(days=6))]
        onglets = "".join(
            f'<input type="radio" name="periode" id="p-{cle}" {"checked" if i == 0 else ""}>'
            for i, (cle, _, _) in enumerate(periodes)
        ) + '<nav class="onglets">' + "".join(
            f'<label for="p-{cle}">{libelle}</label>' for cle, libelle, _ in periodes
        ) + "</nav>"
        panneaux = "".join(
            f'<div class="periode" id="v-{cle}">'
            + _panneau_periode(
                analyse.tableau(df, comptes, debut=debut),
                f"Du {_date(df['date_ref'].min().isoformat())} au {_date(fin.isoformat())}" if debut is None
                else f"Depuis le {_date(debut.isoformat())}")
            + "</div>"
            for cle, libelle, debut in periodes
        )
        en_cours = df[df["etat"] == "en_cours"].sort_values("date_ref")
        derniers = df[df["regle"] | (df["etat"] == "annule")].sort_values("date_ref", ascending=False).head(25)
        corps = panneaux + f"""
          <h2>En cours <small>{len(en_cours)} paris, {_euros(en_cours['mise'].sum())} engagés</small></h2>
          {_liste_paris(en_cours.head(30))}
          <h2>Derniers paris réglés</h2>
          {_liste_paris(derniers)}"""

    return f"""<!doctype html>
<html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="light">
<title>Suivi Paris</title>
<style>
@font-face {{ font-family: Bricolage; src: {_police("bricolage-grotesque-latin-standard-normal.woff2")}; font-weight: 200 800; font-stretch: 75% 100%; }}
@font-face {{ font-family: Manrope; src: {_police("manrope-latin-wght-normal.woff2")}; font-weight: 200 800; }}
:root {{ --encre:#1B1340; --brume:#6E6890; --fond:#F4F2FB; --gain:#0E9F62; --perte:#E5334F; --violet:#5B3DF5; }}
* {{ box-sizing: border-box; }}
html {{ -webkit-text-size-adjust: 100%; }}
body {{ margin: 0; background: var(--fond); color: var(--encre); font: 15px/1.45 Manrope, -apple-system, system-ui, sans-serif;
  font-variant-numeric: tabular-nums; padding: max(18px, env(safe-area-inset-top)) 16px 40px; }}
main {{ max-width: 520px; margin: 0 auto; }}
h1, h2, .profit, .stats b, .montant, .regul b {{ font-family: Bricolage, Manrope, sans-serif; }}
header {{ display: flex; align-items: baseline; justify-content: space-between; gap: 10px; margin-bottom: 12px; }}
h1 {{ font-size: 26px; margin: 0; letter-spacing: -.01em; }}
header small {{ color: var(--brume); font-size: 12.5px; font-weight: 600; text-align: right; }}
h2 {{ font-size: 19px; margin: 26px 0 10px; }}
h2 small {{ font-family: Manrope, sans-serif; font-size: 13px; color: var(--brume); font-weight: 600; margin-left: 6px; }}
.discret {{ color: var(--brume); }}
.gain {{ color: var(--gain); }} .perte {{ color: var(--perte); }}
input[name=periode] {{ position: absolute; opacity: 0; pointer-events: none; }}
.onglets {{ display: flex; gap: 6px; background: #fff; padding: 4px; border-radius: 999px; margin-bottom: 14px;
  box-shadow: 0 1px 2px rgba(27,19,64,.06); }}
.onglets label {{ flex: 1; text-align: center; padding: 8px 6px; border-radius: 999px; font-weight: 700; font-size: 14px; color: var(--brume); }}
.periode {{ display: none; }}
#p-saison:checked ~ #v-saison, #p-j30:checked ~ #v-j30, #p-j7:checked ~ #v-j7 {{ display: block; }}
#p-saison:checked ~ .onglets label[for=p-saison], #p-j30:checked ~ .onglets label[for=p-j30],
#p-j7:checked ~ .onglets label[for=p-j7] {{ background: var(--encre); color: #fff; }}
.heros {{ border-radius: 26px; padding: 20px 18px 14px; color: #fff;
  background: radial-gradient(120% 140% at 100% 0%, rgba(255,197,61,.22), rgba(255,197,61,0) 45%),
              linear-gradient(135deg, #3F24C9, #5B3DF5 50%, #8B5CF6); box-shadow: 0 20px 44px -24px rgba(63,36,201,.7); }}
.titre-periode {{ margin: 0 0 4px; font-size: 13px; font-weight: 700; color: rgba(255,255,255,.8); }}
.profit {{ margin: 0; font-size: 50px; font-weight: 800; line-height: 1; font-stretch: 88%; }}
.legende {{ margin: 6px 0 14px; color: rgba(255,255,255,.85); font-weight: 600; font-size: 14px; }}
.stats {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-bottom: 12px; }}
.stats b {{ display: block; font-size: 21px; line-height: 1.1; }}
.stats span {{ font-size: 12px; color: rgba(255,255,255,.78); font-weight: 600; }}
.courbe {{ width: 100%; height: 150px; display: block; }}
.axe {{ display: flex; justify-content: space-between; font-size: 11.5px; color: rgba(255,255,255,.75); font-weight: 600; margin-top: 4px; }}
.vide-graphe {{ font-size: 13px; color: rgba(255,255,255,.8); }}
.comptes {{ display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }}
.compte {{ background: #fff; border-radius: 18px; padding: 12px; box-shadow: 0 1px 2px rgba(27,19,64,.06); border-top: 4px solid var(--c); }}
.compte .qui {{ display: flex; gap: 8px; align-items: center; margin-bottom: 6px; }}
.compte .qui b {{ display: block; font-size: 14px; line-height: 1.15; }}
.compte small {{ color: var(--brume); font-size: 12px; font-weight: 600; }}
.av {{ width: 26px; height: 26px; border-radius: 50%; background: var(--c); color: #fff; display: grid; place-items: center;
  font-weight: 800; font-size: 13px; flex: none; }}
.montant {{ display: block; font-size: 21px; line-height: 1.1; }}
.spark {{ width: 100%; height: 30px; margin-top: 6px; display: block; }}
ul.sports, ul.paris {{ list-style: none; margin: 0; padding: 0; background: #fff; border-radius: 18px; box-shadow: 0 1px 2px rgba(27,19,64,.06); }}
ul.sports li, ul.paris li {{ display: grid; grid-template-columns: 34px 1fr auto; gap: 10px; align-items: center; padding: 11px 12px; border-bottom: 1px solid #EFECF8; }}
ul.sports li:last-child, ul.paris li:last-child {{ border-bottom: 0; }}
.emb {{ width: 34px; height: 34px; border-radius: 11px; display: grid; place-items: center; font-size: 18px; background: var(--fond); }}
.nom b {{ display: block; font-size: 14px; line-height: 1.25; }}
.nom small {{ display: block; color: var(--brume); font-size: 12px; font-weight: 600; line-height: 1.3; }}
.jauge {{ display: block; position: relative; height: 6px; background: var(--fond); border-radius: 9px; margin-top: 5px; overflow: hidden; }}
.jauge i {{ position: absolute; inset: 0 auto 0 0; border-radius: 9px; }}
ul.paris li > b, ul.sports li > b {{ font-size: 14px; white-space: nowrap; }}
details {{ margin-top: 14px; background: #fff; border-radius: 18px; padding: 12px 14px; box-shadow: 0 1px 2px rgba(27,19,64,.06); }}
summary {{ font-weight: 750; font-family: Bricolage, sans-serif; font-size: 16px; }}
table {{ width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 13px; }}
th {{ text-align: right; color: var(--brume); font-size: 12px; padding: 6px 4px; }}
td {{ padding: 7px 4px; border-top: 1px solid #EFECF8; text-align: right; white-space: nowrap; }}
td:first-child, th:first-child {{ text-align: left; white-space: normal; }}
.regul {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-top: 14px; }}
.regul div {{ background: #fff; border-radius: 16px; padding: 10px; box-shadow: 0 1px 2px rgba(27,19,64,.06); }}
.regul b {{ display: block; font-size: 18px; }}
.regul span {{ font-size: 11.5px; color: var(--brume); font-weight: 600; line-height: 1.2; display: block; }}
footer {{ margin-top: 28px; font-size: 12px; color: var(--brume); text-align: center; }}
</style></head>
<body><main>
  <header><h1>Suivi Paris</h1><small>Mis à jour le {maintenant.day} {MOIS[maintenant.month - 1]}<br>à {maintenant:%H:%M}</small></header>
  {onglets}
  {corps}
  <footer>Résumé en lecture seule, créé sur ton ordinateur. Pour le mettre à jour, importe tes paris dans l'appli.</footer>
</main></body></html>"""


def ecrire(cx, icloud_autorise: bool = True) -> dict:
    chemin, icloud = destination(icloud_autorise)
    html = generer(cx)
    chemin.write_text(html, encoding="utf-8")
    return {"chemin": str(chemin), "icloud": icloud, "taille": len(html.encode()),
            "date": datetime.now().isoformat(timespec="seconds")}
