"""Où sont rangées les données : hors du dossier du projet, pour qu'elles n'atterrissent jamais sur GitHub."""
from __future__ import annotations

import os
import sys
from pathlib import Path

RACINE_PROJET = Path(__file__).resolve().parent.parent


def dossier_donnees() -> Path:
    if os.environ.get("SUIVI_PARIS_DONNEES"):
        dossier = Path(os.environ["SUIVI_PARIS_DONNEES"])
    elif sys.platform == "win32":
        dossier = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "SuiviParis"
    elif sys.platform == "darwin":
        dossier = Path.home() / "Library" / "Application Support" / "SuiviParis"
    else:
        dossier = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "suivi-paris"
    dossier.mkdir(parents=True, exist_ok=True)
    return dossier


def mode_demo() -> bool:
    return os.environ.get("SUIVI_PARIS_DEMO") == "1"


def base(demo: bool | None = None) -> Path:
    demo = mode_demo() if demo is None else demo
    return dossier_donnees() / ("demo.db" if demo else "paris.db")
