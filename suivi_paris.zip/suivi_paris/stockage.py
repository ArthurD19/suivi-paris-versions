"""Base SQLite locale : les comptes, et un pari par ligne identifié par (bookmaker, référence).

- Recoller une page déjà importée ne crée aucun doublon ; un pari « en cours » est mis à jour quand il est
  réglé ; un pari réglé ne repasse jamais « en cours » ; un sport corrigé à la main n'est jamais écrasé.
- Chaque pari appartient à un compte (« Betclic – Elsa », « Winamax – Thomas »…). Un pari déjà rattaché à un
  compte n'en change jamais lors d'un import : on le déplace explicitement, dans « Mes paris ».
- Un pari peut être modifié à la main (passer un pari en cours en gagné…) : les valeurs du bookmaker sont
  gardées, et le bookmaker l'emporte dès qu'un import montre le pari réglé. Un pari peut être marqué
  « partagé » : l'heure du partage et son état à ce moment sont figés.
- Les dépôts et retraits de chaque compte (table « mouvements ») donnent le bilan d'argent réel ; une page
  sans référence est dédoublonnée par (compte, sens, date, montant, rang du mouvement identique).
- Le schéma est versionné (PRAGMA user_version). À l'ouverture d'une base plus ancienne, une copie de
  sécurité est faite dans le dossier « sauvegardes », puis la base est mise à niveau sans perdre un pari.
"""
from __future__ import annotations

import json
import re
import secrets
import sqlite3
from collections import Counter
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

from .modeles import ETATS_REGLES, Mouvement, Pari, Selection, _ressemble_a_un_nom, sans_accents

VERSION = 15

COULEURS_COMPTES = ["#5B3DF5", "#FF8A3D", "#16A6B6", "#E85D9E", "#F5B700", "#2F80ED", "#A35BE0", "#7A8CA8"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS comptes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    bookmaker    TEXT NOT NULL,
    nom          TEXT NOT NULL,
    couleur      TEXT NOT NULL,
    identifiant  TEXT,
    cree_le      TEXT NOT NULL,
    solde        REAL,
    solde_le     TEXT,
    devise       TEXT NOT NULL DEFAULT 'EUR',   -- la monnaie du compte chez le bookmaker (montants gardés tels quels)
    taux         REAL,                          -- sa valeur en euros (1 CHF = 1,07 €), fixée à la main
    UNIQUE (bookmaker, nom)
);
CREATE TABLE IF NOT EXISTS paris (
    bookmaker        TEXT NOT NULL,
    reference        TEXT NOT NULL,
    compte_id        INTEGER REFERENCES comptes(id),
    date_pari        TEXT NOT NULL,
    date_evenement   TEXT,
    type             TEXT NOT NULL,
    nb_selections    INTEGER NOT NULL DEFAULT 1,
    etat             TEXT NOT NULL,
    etat_brut        TEXT,
    mise             REAL NOT NULL,
    gains            REAL,
    cote_boostee     INTEGER NOT NULL DEFAULT 0,
    cote             REAL,
    sport            TEXT NOT NULL,
    sport_corrige    INTEGER NOT NULL DEFAULT 0,
    sport_devine     INTEGER NOT NULL DEFAULT 0,
    evenement        TEXT,
    competition      TEXT,
    marche           TEXT,
    categorie_marche TEXT,
    choix            TEXT,
    resume           TEXT,
    selections       TEXT NOT NULL,
    importe_le       TEXT NOT NULL,
    modifie_le       TEXT NOT NULL,
    modifie_main     INTEGER NOT NULL DEFAULT 0,
    valeurs_import   TEXT,
    partage          INTEGER NOT NULL DEFAULT 0,
    partage_le       TEXT,
    etat_au_partage  TEXT,
    partage_source   TEXT,
    partage_pct      REAL,
    manuel           INTEGER NOT NULL DEFAULT 0,
    champs_corriges  TEXT,
    freebet          INTEGER NOT NULL DEFAULT 0,   -- mise offerte (freebet) : elle ne coûte rien, les gains ne la rendent pas
    PRIMARY KEY (bookmaker, reference)
);
CREATE TABLE IF NOT EXISTS sites (
    nom          TEXT PRIMARY KEY,
    libelle      TEXT NOT NULL,
    cree_le      TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS parametres (
    cle          TEXT PRIMARY KEY,
    valeur       TEXT
);
CREATE TABLE IF NOT EXISTS paris_supprimes (
    bookmaker    TEXT NOT NULL,
    reference    TEXT NOT NULL,
    supprime_le  TEXT NOT NULL,
    PRIMARY KEY (bookmaker, reference)
);
CREATE TABLE IF NOT EXISTS mouvements (
    compte_id    INTEGER NOT NULL REFERENCES comptes(id),
    sens         TEXT NOT NULL,
    date         TEXT NOT NULL,
    montant      REAL NOT NULL,
    rang         INTEGER NOT NULL,
    moyen        TEXT,
    importe_le   TEXT NOT NULL,
    PRIMARY KEY (compte_id, sens, date, montant, rang)
);
CREATE TABLE IF NOT EXISTS imports (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    date        TEXT NOT NULL,
    bookmaker   TEXT NOT NULL,
    compte_id   INTEGER,
    lus         INTEGER NOT NULL,
    nouveaux    INTEGER NOT NULL,
    mis_a_jour  INTEGER NOT NULL
);
"""


# --------------------------------------------------------------------------- #
# Ouverture et mises à niveau
# --------------------------------------------------------------------------- #
def _maintenant() -> str:
    return datetime.now().isoformat(timespec="seconds")


def sauvegarder(cx: sqlite3.Connection, chemin: Path, motif: str) -> Path:
    dossier = chemin.parent / "sauvegardes"
    dossier.mkdir(parents=True, exist_ok=True)
    cible = dossier / f"{chemin.stem}-{motif}-{datetime.now():%Y%m%d-%H%M%S}.db"
    with sqlite3.connect(cible) as copie:
        cx.backup(copie)
    return cible


def _migrer_v0_vers_v1(cx: sqlite3.Connection) -> None:
    """Ajoute les comptes : chaque bookmaker déjà présent reçoit un compte « Principal » qui garde ses paris."""
    cx.execute(SCHEMA.split(";")[0])  # table comptes
    bookmakers = [r[0] for r in cx.execute("SELECT DISTINCT bookmaker FROM paris ORDER BY bookmaker")]
    for i, bk in enumerate(bookmakers):
        cx.execute(
            "INSERT INTO comptes (bookmaker, nom, couleur, cree_le) VALUES (?, 'Principal', ?, ?)",
            (bk, COULEURS_COMPTES[i % len(COULEURS_COMPTES)], _maintenant()),
        )
    colonnes_paris = {r[1] for r in cx.execute("PRAGMA table_info(paris)")}
    if "compte_id" not in colonnes_paris:
        cx.execute("ALTER TABLE paris ADD COLUMN compte_id INTEGER REFERENCES comptes(id)")
    cx.execute("UPDATE paris SET compte_id = (SELECT id FROM comptes c WHERE c.bookmaker = paris.bookmaker)")
    colonnes_imports = {r[1] for r in cx.execute("PRAGMA table_info(imports)")}
    if "compte_id" not in colonnes_imports:
        cx.execute("ALTER TABLE imports ADD COLUMN compte_id INTEGER")
    cx.execute("UPDATE imports SET compte_id = (SELECT id FROM comptes c WHERE c.bookmaker = imports.bookmaker)")


def _migrer_v1_vers_v2(cx: sqlite3.Connection) -> None:
    """Ajoute la cote totale des paris (connue pour Unibet). Les paris déjà enregistrés la gardent vide."""
    if "cote" not in {r[1] for r in cx.execute("PRAGMA table_info(paris)")}:
        cx.execute("ALTER TABLE paris ADD COLUMN cote REAL")


def _migrer_v2_vers_v3(cx: sqlite3.Connection) -> None:
    """Ajoute les dépôts et retraits (table mouvements) et le solde actuel, facultatif, de chaque compte."""
    # execute (pas executescript, qui validerait la transaction en cours) : la migration reste d'un seul tenant.
    cx.execute(next(b for b in SCHEMA.split(";") if "TABLE IF NOT EXISTS mouvements" in b))
    if "solde" not in {r[1] for r in cx.execute("PRAGMA table_info(comptes)")}:
        cx.execute("ALTER TABLE comptes ADD COLUMN solde REAL")


def _migrer_v3_vers_v4(cx: sqlite3.Connection) -> None:
    """Ajoute la modification à la main et le partage des paris. Les paris déjà enregistrés ne sont ni modifiés
    ni partagés."""
    existantes = {r[1] for r in cx.execute("PRAGMA table_info(paris)")}
    for colonne, definition in (("modifie_main", "INTEGER NOT NULL DEFAULT 0"), ("valeurs_import", "TEXT"),
                                ("partage", "INTEGER NOT NULL DEFAULT 0"), ("partage_le", "TEXT"),
                                ("etat_au_partage", "TEXT")):
        if colonne not in existantes:
            cx.execute(f"ALTER TABLE paris ADD COLUMN {colonne} {definition}")


def _migrer_v4_vers_v5(cx: sqlite3.Connection) -> None:
    """Retient si le sport d'un pari a été deviné : Betclic et PMU ne l'affichent jamais, Winamax pas sur « Mes
    paris » (ses sélections y ont la compétition égale à l'événement, contrairement à l'historique de compte)."""
    if "sport_devine" not in {r[1] for r in cx.execute("PRAGMA table_info(paris)")}:
        cx.execute("ALTER TABLE paris ADD COLUMN sport_devine INTEGER NOT NULL DEFAULT 0")
    cx.execute("UPDATE paris SET sport_devine=1 WHERE bookmaker IN ('betclic', 'pmu')")
    for r in cx.execute("SELECT reference, selections FROM paris WHERE bookmaker='winamax'").fetchall():
        sels = json.loads(r["selections"] or "[]")
        if sels and all(x.get("competition") == x.get("evenement") for x in sels):
            cx.execute("UPDATE paris SET sport_devine=1 WHERE bookmaker='winamax' AND reference=?", (r["reference"],))
    reclasser_sports(cx)


def _migrer_v5_vers_v6(cx: sqlite3.Connection) -> None:
    """Ajoute les paramètres (bankroll) et l'origine d'un partage (« Discord – auteur », mise conseillée en %)."""
    cx.execute(next(b for b in SCHEMA.split(";") if "TABLE IF NOT EXISTS parametres" in b))
    existantes = {r[1] for r in cx.execute("PRAGMA table_info(paris)")}
    for colonne, definition in (("partage_source", "TEXT"), ("partage_pct", "REAL")):
        if colonne not in existantes:
            cx.execute(f"ALTER TABLE paris ADD COLUMN {colonne} {definition}")


def _migrer_v6_vers_v7(cx: sqlite3.Connection) -> None:
    """Ajoute la date du solde d'un compte (relevé par l'extension ou saisi à la main)."""
    if "solde_le" not in {r[1] for r in cx.execute("PRAGMA table_info(comptes)")}:
        cx.execute("ALTER TABLE comptes ADD COLUMN solde_le TEXT")


def _migrer_v7_vers_v8(cx: sqlite3.Connection) -> None:
    """Betclic n'écrit pas l'année d'un événement : elle était parfois devinée un an trop tard (un pari réglé en
    2026 sur un événement daté de 2027). Un pari réglé n'a pas d'événement dans le futur : il recule d'un an."""
    cx.execute("""UPDATE paris SET date_evenement = strftime('%Y-%m-%dT%H:%M:%S', date_evenement, '-1 year')
                  WHERE etat != 'en_cours' AND date_evenement IS NOT NULL
                    AND date_evenement > strftime('%Y-%m-%dT%H:%M:%S', 'now', 'localtime', '+2 days')""")


def _migrer_v8_vers_v9(cx: sqlite3.Connection) -> None:
    """Paris saisis à la main (`manuel`), champs corrigés à la main qu'un import ne remplace plus
    (`champs_corriges`), et sites ajoutés par l'utilisateur, que l'appli ne lit pas encore (`sites`)."""
    colonnes = {r[1] for r in cx.execute("PRAGMA table_info(paris)")}
    if "manuel" not in colonnes:
        cx.execute("ALTER TABLE paris ADD COLUMN manuel INTEGER NOT NULL DEFAULT 0")
    if "champs_corriges" not in colonnes:
        cx.execute("ALTER TABLE paris ADD COLUMN champs_corriges TEXT")
    cx.execute("CREATE TABLE IF NOT EXISTS sites (nom TEXT PRIMARY KEY, libelle TEXT NOT NULL, cree_le TEXT NOT NULL)")


def _migrer_v9_vers_v10(cx: sqlite3.Connection) -> None:
    """Nouveaux sports (volley-ball, boxe, football américain) et ski précisé (biathlon, ski alpin, ski de fond) :
    les paris déjà enregistrés en « Ski », ou au sport resté « Autre », sont reclassés quand leur texte le dit. Un
    sport corrigé à la main ne bouge pas."""
    from .sports import deviner_sport, preciser_ski

    nouveaux = {"Volley-ball", "Boxe", "Football américain"}
    lignes = cx.execute("""SELECT bookmaker, reference, sport, selections FROM paris
                           WHERE sport_corrige = 0 AND sport IN ('Ski', 'Autre', 'Multi-sports')""").fetchall()
    for r in lignes:
        sels = json.loads(r["selections"] or "[]")
        change = False
        for sel in sels:
            nouveau = None
            if sel.get("sport") == "Ski":
                nouveau = preciser_ski(f"{sel.get('evenement', '')} {sel.get('competition', '')}")
            elif sel.get("sport") == "Autre":
                devine = deviner_sport(sel.get("marche", ""), sel.get("choix", ""), sel.get("evenement", ""))
                nouveau = devine if devine in nouveaux else None
            if nouveau:
                sel["sport"], change = nouveau, True
        if change:
            sports = {sel.get("sport") for sel in sels if sel.get("sport")}
            sport = sports.pop() if len(sports) == 1 else "Multi-sports"
            cx.execute("UPDATE paris SET sport=?, selections=? WHERE bookmaker=? AND reference=?",
                       (sport, json.dumps(sels, ensure_ascii=False), r["bookmaker"], r["reference"]))


def _migrer_v10_vers_v11(cx: sqlite3.Connection) -> None:
    """Comptes dans une autre monnaie que l'euro (Sportaza en francs suisses) : la monnaie et son taux en euros. Les
    montants restent ceux du bookmaker ; l'analyse les convertit."""
    colonnes = {r[1] for r in cx.execute("PRAGMA table_info(comptes)")}
    if "devise" not in colonnes:
        cx.execute("ALTER TABLE comptes ADD COLUMN devise TEXT NOT NULL DEFAULT 'EUR'")
    if "taux" not in colonnes:
        cx.execute("ALTER TABLE comptes ADD COLUMN taux REAL")


def _migrer_v11_vers_v12(cx: sqlite3.Connection) -> None:
    """Sports d'hiver mieux devinés (« Jeux Olympiques d'Hiver » n'est plus du tennis, « Nove Mesto » est du biathlon,
    « Drammen (C) » du ski de fond) : les paris au sport deviné sont devinés à nouveau, puis corrigés par les noms
    déjà vus. Seules les sélections devinées « Tennis », « Cyclisme » ou « Autre » qui se révèlent d'hiver changent
    (le reste a pu être deviné avec ce que la page montrait, les scores, qui n'est pas gardé). Un sport donné par le
    site ou corrigé à la main ne bouge pas."""
    from .sports import deviner_sport

    hiver = {"Sports d'hiver", "Ski de fond", "Ski alpin", "Biathlon", "Ski"}
    lignes = cx.execute("""SELECT bookmaker, reference, sport, selections FROM paris
                           WHERE sport_devine = 1 AND sport_corrige = 0
                             AND sport IN ('Tennis', 'Cyclisme', 'Autre', 'Multi-sports')""").fetchall()
    for r in lignes:
        sels = json.loads(r["selections"] or "[]")
        change = False
        for sel in sels:
            if sel.get("sport") not in ("Tennis", "Cyclisme", "Autre"):
                continue
            nouveau = deviner_sport(sel.get("marche", ""), sel.get("choix", ""), sel.get("evenement", ""))
            if nouveau in hiver:
                sel["sport"], change = nouveau, True
        if not change:
            continue
        sports = {sel.get("sport") for sel in sels if sel.get("sport")}
        sport = sports.pop() if len(sports) == 1 else "Multi-sports"
        cx.execute("UPDATE paris SET sport=?, selections=? WHERE bookmaker=? AND reference=?",
                   (sport, json.dumps(sels, ensure_ascii=False), r["bookmaker"], r["reference"]))
    reclasser_sports(cx)


def _migrer_v12_vers_v13(cx: sqlite3.Connection) -> None:
    """Un match (« Vainqueur 1 2 : Danemark (F) - Japon (F) »), le Dakar ou les Mondiaux de Lenzerheide n'étaient pas
    du cyclisme : les paris devinés « Cyclisme » de ce genre sont devinés à nouveau. Le reste ne bouge pas."""
    from .sports import deviner_sport

    lignes = cx.execute("""SELECT bookmaker, reference, selections FROM paris
                           WHERE sport_devine = 1 AND sport_corrige = 0 AND sport IN ('Cyclisme', 'Multi-sports')""")
    for r in lignes.fetchall():
        sels = json.loads(r["selections"] or "[]")
        change = False
        for sel in sels:
            marche, evenement = sel.get("marche", ""), sel.get("evenement", "")
            if sel.get("sport") != "Cyclisme" or not (
                    re.search(r"\b1 ?x? ?2\b", marche.lower()) or re.search(r"dakar|lenzerheide", evenement.lower())):
                continue
            nouveau = deviner_sport(marche, sel.get("choix", ""), evenement) or "Autre"
            if nouveau != "Cyclisme":
                sel["sport"], change = nouveau, True
        if change:
            sports = {sel.get("sport") for sel in sels if sel.get("sport")}
            sport = sports.pop() if len(sports) == 1 else "Multi-sports"
            cx.execute("UPDATE paris SET sport=?, selections=? WHERE bookmaker=? AND reference=?",
                       (sport, json.dumps(sels, ensure_ascii=False), r["bookmaker"], r["reference"]))


def _migrer_v13_vers_v14(cx: sqlite3.Connection) -> None:
    """Freebets : un pari joué avec une mise offerte ne coûte rien s'il perd, et ses gains ne rendent pas la mise
    (Betclic : 18,75 € offerts à 13 rapportent 225 €). Les paris déjà en base restent des paris en argent réel : un
    freebet se reconnaît au prochain import des paris en cours, ou se coche à la main."""
    colonnes = {r[1] for r in cx.execute("PRAGMA table_info(paris)")}
    if "freebet" not in colonnes:
        cx.execute("ALTER TABLE paris ADD COLUMN freebet INTEGER NOT NULL DEFAULT 0")


def _migrer_v14_vers_v15(cx: sqlite3.Connection) -> None:
    """Supprimer un pari importé : sa clé est gardée, pour qu'aucun import ni la synchronisation ne le ramène."""
    cx.execute("""CREATE TABLE IF NOT EXISTS paris_supprimes (bookmaker TEXT NOT NULL, reference TEXT NOT NULL,
                  supprime_le TEXT NOT NULL, PRIMARY KEY (bookmaker, reference))""")


MIGRATIONS = {0: _migrer_v0_vers_v1, 1: _migrer_v1_vers_v2, 2: _migrer_v2_vers_v3, 3: _migrer_v3_vers_v4,
              4: _migrer_v4_vers_v5, 5: _migrer_v5_vers_v6, 6: _migrer_v6_vers_v7,
              7: _migrer_v7_vers_v8, 8: _migrer_v8_vers_v9, 9: _migrer_v9_vers_v10,
              10: _migrer_v10_vers_v11, 11: _migrer_v11_vers_v12,
              12: _migrer_v12_vers_v13, 13: _migrer_v13_vers_v14, 14: _migrer_v14_vers_v15}


def ouvrir(chemin: Path | str) -> sqlite3.Connection:
    chemin = Path(chemin)
    cx = sqlite3.connect(chemin, check_same_thread=False)
    cx.row_factory = sqlite3.Row
    cx.execute("PRAGMA foreign_keys = ON")
    tables = {r[0] for r in cx.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    version = cx.execute("PRAGMA user_version").fetchone()[0]
    if "paris" not in tables:
        cx.executescript(SCHEMA)
        cx.execute(f"PRAGMA user_version = {VERSION}")
    elif version < VERSION:
        mouvements = "mouvements" in tables and cx.execute("SELECT COUNT(*) FROM mouvements").fetchone()[0]
        if cx.execute("SELECT COUNT(*) FROM paris").fetchone()[0] or mouvements:
            sauvegarder(cx, chemin, f"avant-v{VERSION}")
        with cx:
            for v in range(version, VERSION):
                MIGRATIONS[v](cx)
            cx.execute(f"PRAGMA user_version = {VERSION}")
    cx.commit()
    return cx


# --------------------------------------------------------------------------- #
# Comptes
# --------------------------------------------------------------------------- #
def lister_comptes(cx: sqlite3.Connection) -> list[dict]:
    """Les comptes, avec leur nombre de paris, la date du plus ancien (premier_pari) et le pari le plus récent
    (dernier : référence, date, résumé, état, mise), pour savoir où reprendre l'enregistrement."""
    lignes = cx.execute(
        """SELECT c.*, COUNT(p.reference) AS n_paris, MIN(p.date_pari) AS premier_pari
           FROM comptes c LEFT JOIN paris p ON p.compte_id = c.id
           GROUP BY c.id ORDER BY c.bookmaker, c.nom"""
    ).fetchall()
    comptes = [dict(l) for l in lignes]
    for c in comptes:
        dernier = cx.execute(
            """SELECT reference, date_pari, resume, etat, mise FROM paris WHERE compte_id=?
               ORDER BY date_pari DESC, reference DESC LIMIT 1""",
            (c["id"],),
        ).fetchone()
        c["dernier"] = dict(dernier) if dernier else None
    return comptes


def compte(cx: sqlite3.Connection, compte_id: int) -> dict | None:
    ligne = cx.execute("SELECT * FROM comptes WHERE id=?", (compte_id,)).fetchone()
    return dict(ligne) if ligne else None


def creer_compte(cx: sqlite3.Connection, bookmaker: str, nom: str, couleur: str | None = None,
                 identifiant: str | None = None) -> int:
    nom = nom.strip()
    if not nom:
        raise ValueError("Donne un nom au compte.")
    if cx.execute("SELECT 1 FROM comptes WHERE bookmaker=? AND lower(nom)=lower(?)", (bookmaker, nom)).fetchone():
        raise ValueError(f"Il existe déjà un compte « {nom} » sur ce bookmaker.")
    if couleur is None:
        n = cx.execute("SELECT COUNT(*) FROM comptes").fetchone()[0]
        couleur = COULEURS_COMPTES[n % len(COULEURS_COMPTES)]
    cur = cx.execute(
        "INSERT INTO comptes (bookmaker, nom, couleur, identifiant, cree_le) VALUES (?,?,?,?,?)",
        (bookmaker, nom, couleur, identifiant, _maintenant()),
    )
    cx.commit()
    return cur.lastrowid


# Les monnaies proposées pour un compte ; l'euro est celle de l'appli (tous les chiffres sont en euros).
DEVISES = {"EUR": "€", "CHF": "CHF", "GBP": "£", "USD": "$"}


def taux_compte(c: dict) -> float:
    """Ce que vaut 1 unité de la monnaie du compte, en euros (1 pour un compte en euros)."""
    return 1.0 if (c.get("devise") or "EUR") == "EUR" else float(c.get("taux") or 1.0)


def modifier_compte(cx: sqlite3.Connection, compte_id: int, nom: str | None = None,
                    couleur: str | None = None, solde: float | None = None, effacer_solde: bool = False,
                    devise: str | None = None, taux: float | None = None) -> None:
    """`solde` : l'argent encore sur le compte (dans sa monnaie), compté dans le bilan ; `effacer_solde` le remet à
    vide. `devise`, `taux` : la monnaie du compte et ce qu'en vaut une unité en euros."""
    c = compte(cx, compte_id)
    if c is None:
        raise ValueError("Compte introuvable.")
    if devise is not None:
        if devise not in DEVISES:
            raise ValueError("Monnaie inconnue.")
        if devise == "EUR":
            taux = None
        elif taux is None:
            taux = c["taux"] if c["devise"] == devise else None
        if devise != "EUR" and (taux is None or taux <= 0):
            raise ValueError(f"Indique ce que vaut 1 {devise} en euros (par exemple 1,07).")
        cx.execute("UPDATE comptes SET devise=?, taux=? WHERE id=?", (devise, taux, compte_id))
    if nom is not None:
        nom = nom.strip()
        if not nom:
            raise ValueError("Donne un nom au compte.")
        doublon = cx.execute("SELECT 1 FROM comptes WHERE bookmaker=? AND lower(nom)=lower(?) AND id<>?",
                             (c["bookmaker"], nom, compte_id)).fetchone()
        if doublon:
            raise ValueError(f"Il existe déjà un compte « {nom} » sur ce bookmaker.")
        cx.execute("UPDATE comptes SET nom=? WHERE id=?", (nom, compte_id))
    if couleur is not None:
        cx.execute("UPDATE comptes SET couleur=? WHERE id=?", (couleur, compte_id))
    if solde is not None or effacer_solde:
        if solde is not None and solde < 0:
            raise ValueError("Le solde ne peut pas être négatif.")
        cx.execute("UPDATE comptes SET solde=?, solde_le=? WHERE id=?",
                   (None if effacer_solde else round(solde, 2), None if effacer_solde else _maintenant(), compte_id))
    cx.commit()


def supprimer_compte(cx: sqlite3.Connection, compte_id: int, avec_donnees: bool = False) -> None:
    """Supprime un compte vide ; `avec_donnees` : aussi ses paris et ses dépôts/retraits (pour repartir de zéro).
    Ces paris ne sont pas marqués supprimés : un nouvel import les ramène."""
    if avec_donnees:
        cx.execute("DELETE FROM paris WHERE compte_id=?", (compte_id,))
        cx.execute("DELETE FROM mouvements WHERE compte_id=?", (compte_id,))
    n = cx.execute("SELECT COUNT(*) FROM paris WHERE compte_id=?", (compte_id,)).fetchone()[0]
    if n:
        raise ValueError(f"Ce compte contient {n} pari(s) : déplace-les vers un autre compte avant de le supprimer.")
    n = cx.execute("SELECT COUNT(*) FROM mouvements WHERE compte_id=?", (compte_id,)).fetchone()[0]
    if n:
        raise ValueError(f"Ce compte contient {n} mouvement(s) d'argent : efface-les (page Argent) avant de le supprimer.")
    cx.execute("UPDATE imports SET compte_id=NULL WHERE compte_id=?", (compte_id,))
    cx.execute("DELETE FROM comptes WHERE id=?", (compte_id,))
    cx.commit()


def compte_par_identifiant(cx: sqlite3.Connection, bookmaker: str, identifiant: str | None) -> dict | None:
    if not identifiant:
        return None
    ligne = cx.execute("SELECT * FROM comptes WHERE bookmaker=? AND identifiant=?", (bookmaker, identifiant)).fetchone()
    return dict(ligne) if ligne else None


def rattacher_identifiant(cx: sqlite3.Connection, compte_id: int, identifiant: str) -> None:
    """Retient le numéro de compte chez le bookmaker (lu ailleurs que sur son site : AsianConnect)."""
    with cx:
        cx.execute("UPDATE comptes SET identifiant=? WHERE id=? AND (identifiant IS NULL OR identifiant='')",
                   (identifiant, compte_id))


def deplacer_paris(cx: sqlite3.Connection, bookmaker: str, references: list[str], compte_id: int) -> int:
    c = compte(cx, compte_id)
    if c is None or c["bookmaker"] != bookmaker:
        raise ValueError("Ce compte n'appartient pas au même bookmaker que ces paris.")
    marques = ",".join("?" * len(references))
    cur = cx.execute(
        f"UPDATE paris SET compte_id=?, modifie_le=? WHERE bookmaker=? AND reference IN ({marques})",
        [compte_id, _maintenant(), bookmaker, *references],
    )
    cx.commit()
    return cur.rowcount


# --------------------------------------------------------------------------- #
# Paris
# --------------------------------------------------------------------------- #
def _selection(s) -> dict:
    """Une sélection en JSON. La cote n'y figure que si elle est connue : les paris Betclic et Winamax déjà
    enregistrés gardent ainsi exactement le même JSON, et ne passent pas pour « mis à jour » à chaque import."""
    d = asdict(s)
    if d.get("cote") is None:
        d.pop("cote", None)
    return d


def _ligne(p: Pari) -> dict:
    premiere = p.selections[0] if p.selections else None
    if p.type == "combine":
        categorie = "Combiné"
    elif p.type == "mycombi":
        categorie = "Combiné même match"
    elif p.cote_boostee:
        categorie = "Cote boostée"
    else:
        categorie = premiere.categorie_marche if premiere else "Inconnu"
    return {
        "bookmaker": p.bookmaker,
        "reference": p.reference,
        "date_pari": p.date_pari.isoformat(),
        "date_evenement": p.date_evenement.isoformat() if p.date_evenement else None,
        "type": p.type,
        "nb_selections": p.nb_selections,
        "etat": p.etat,
        "etat_brut": p.etat_brut,
        "mise": p.mise,
        "gains": p.gains,
        "cote_boostee": int(p.cote_boostee),
        "freebet": int(p.freebet),
        "cote": p.cote,
        "sport": p.sport if p.type != "combine" or p.selections else "Combiné",
        "sport_devine": int(p.sport_devine),
        "evenement": premiere.evenement if premiere else "",
        "competition": premiere.competition if premiere else "",
        "marche": premiere.marche if premiere else "",
        "categorie_marche": categorie,
        "choix": premiere.choix if premiere else "",
        "resume": p.resume,
        "selections": json.dumps([_selection(s) for s in p.selections], ensure_ascii=False),
    }


def _meme_minute_moins_precise(ancienne: str | None, nouvelle: str | None) -> bool:
    """« 2026-10-11T15:37:00 » face à « 2026-10-11T15:37:23 » : la même minute, sans les secondes."""
    return bool(ancienne and nouvelle and nouvelle != ancienne and nouvelle[:16] == ancienne[:16]
                and nouvelle[16:19] in ("", ":00"))


def _autre_annee(ancienne: str | None, nouvelle: str | None, corriges: str | None, groupe: str) -> bool:
    """Une date relue avec une autre année (et pas corrigée à la main)."""
    return bool(ancienne and nouvelle and ancienne[:4] != nouvelle[:4] and groupe not in (corriges or ""))


def comparer(cx: sqlite3.Connection, paris: list[Pari], compte_id: int | None = None) -> dict[str, dict]:
    """Pour chaque référence, sans rien écrire : statut (« nouveau », « mis à jour », « déjà connu ») et,
    si le pari est déjà rattaché à un autre compte que `compte_id`, le nom de ce compte."""
    resultat = {}
    supprimes = {(r[0], r[1]) for r in cx.execute("SELECT bookmaker, reference FROM paris_supprimes")}
    for p in paris:
        if (p.bookmaker, p.reference) in supprimes:  # supprimé à la main : aucun import ne le ramène
            resultat[p.reference] = {"statut": "supprimé", "autre_compte": None}
            continue
        ex = cx.execute(
            """SELECT p.etat, p.gains, p.mise, p.cote, p.type, p.resume, p.selections, p.compte_id, p.champs_corriges,
                      p.date_evenement, p.date_pari, p.freebet,
                      c.nom AS compte_nom
               FROM paris p LEFT JOIN comptes c ON c.id = p.compte_id
               WHERE p.bookmaker=? AND p.reference=?""",
            (p.bookmaker, p.reference),
        ).fetchone()
        nouveau = _ligne(p) if ex is not None else None
        if ex is None:
            statut = "nouveau"
        elif ex["etat"] in ETATS_REGLES | {"annule"} and p.etat == "en_cours":
            statut = "déjà connu"
        elif p.etat == "inconnu" and ex["etat"] != "inconnu":
            statut = "déjà connu"  # une lecture qui ne voit pas l'état n'efface pas celui déjà connu
        elif (ex["etat"], ex["gains"], ex["mise"]) != (p.etat, p.gains, p.mise):
            statut = "mis à jour"
        elif ex["cote"] is None and p.cote is not None:
            statut = "mis à jour"  # une cote enfin connue (Winamax « Mes paris », Betclic en cours)
        elif ex["date_evenement"] is None and p.date_evenement is not None:
            statut = "mis à jour"  # le jour de l'événement enfin connu (Winamax « Mes paris »)
        elif p.freebet and not ex["freebet"] and "freebet" not in (ex["champs_corriges"] or ""):
            statut = "mis à jour"  # un freebet enfin reconnu (Betclic : la cote affichée face aux gains possibles)
        elif _autre_annee(ex["date_pari"], nouveau["date_pari"], ex["champs_corriges"], "date_pari") or (
                nouveau["date_evenement"] and _autre_annee(ex["date_evenement"], nouveau["date_evenement"],
                                                          ex["champs_corriges"], "date_evenement")):
            statut = "mis à jour"  # une année mieux lue (Sportaza n'écrit pas l'année : elle se déduit de la liste)
        elif p.detail_partiel or "details" in (ex["champs_corriges"] or ""):
            statut = "déjà connu"  # une lecture moins détaillée, ou un détail corrigé à la main, ne le remplace pas
        elif (ex["type"], ex["resume"], _sans_sport(ex["selections"], p.sport_devine)) != (
                nouveau["type"], nouveau["resume"], _sans_sport(nouveau["selections"], p.sport_devine)):
            # Même résultat, mais le détail est mieux lu qu'avant (lecteur amélioré) : on le corrige.
            statut = "mis à jour"
        else:
            statut = "déjà connu"
        autre = ex is not None and compte_id is not None and ex["compte_id"] not in (None, compte_id)
        resultat[p.reference] = {"statut": statut, "autre_compte": ex["compte_nom"] if autre else None}
    return resultat


# Ce qu'un import peut changer d'un pari connu, et comment le dire (journal de l'extension).
_SUIVIS = ("etat", "gains", "mise", "cote", "date_pari", "date_evenement", "freebet", "type", "resume", "selections")
_NOMS_SUIVIS = {"etat": "état", "gains": "gains", "mise": "mise", "cote": "cote", "date_pari": "date du pari",
                "date_evenement": "date de l'événement", "freebet": "freebet", "type": "type", "resume": "détail",
                "selections": "sélections"}


def _changements(avant: sqlite3.Row, apres: dict) -> list[str]:
    """« état : en_cours → gagne », « cote : 12 → 13 »… (le détail des sélections : juste « sélections »)."""
    sortie = []
    for k in _SUIVIS:
        if k not in apres or apres[k] == avant[k] or k == "selections":
            continue
        a, b = (x if x is not None else "—" for x in (avant[k], apres[k]))
        sortie.append(f"{_NOMS_SUIVIS[k]} : {a} → {b}")
    if ("selections" in apres and apres["selections"] != avant["selections"]
            and not any(x.startswith("détail") for x in sortie)):
        sortie.append("sélections mieux lues")
    return sortie


def enregistrer(cx: sqlite3.Connection, paris: list[Pari], bookmaker: str, compte_id: int,
                identifiant: str | None = None) -> dict[str, int]:
    c = compte(cx, compte_id)
    if c is None or c["bookmaker"] != bookmaker:
        raise ValueError("Choisis un compte de ce bookmaker.")
    etat = comparer(cx, paris, compte_id)
    maintenant = _maintenant()
    bilan = {"lus": len(paris), "nouveaux": 0, "mis_a_jour": 0, "deja_connus": 0, "autre_compte": 0, "details": []}
    with cx:
        for p in paris:
            s = etat[p.reference]
            if s["autre_compte"]:
                bilan["autre_compte"] += 1
            ligne = _ligne(p)
            if s["statut"] == "nouveau":
                ligne |= {"compte_id": compte_id, "importe_le": maintenant, "modifie_le": maintenant}
                cx.execute(f"INSERT INTO paris ({', '.join(ligne)}) VALUES ({', '.join('?' * len(ligne))})",
                           list(ligne.values()))
                bilan["nouveaux"] += 1
                bilan["details"].append({"resume": p.resume, "statut": "nouveau", "changements": []})
            elif s["statut"] == "mis à jour":
                ex = cx.execute("""SELECT sport_corrige, sport_devine, champs_corriges, selections, date_pari FROM paris
                                   WHERE bookmaker=? AND reference=?""", (p.bookmaker, p.reference)).fetchone()
                if ex["sport_corrige"]:
                    ligne.pop("sport")
                elif p.sport_devine and not ex["sport_devine"]:
                    # Le sport était sûr (donné par le site, pari PMU ouvert d'un clic) : une lecture qui le devine
                    # ne le remplace pas.
                    ligne.pop("sport")
                    ligne.pop("sport_devine")
                    anciennes = json.loads(ex["selections"] or "[]")
                    nouvelles = json.loads(ligne["selections"])
                    if len(anciennes) == len(nouvelles):
                        for a, n in zip(anciennes, nouvelles, strict=True):
                            if a.get("sport"):
                                n["sport"] = a["sport"]
                        ligne["selections"] = json.dumps(nouvelles, ensure_ascii=False)
                for groupe in json.loads(ex["champs_corriges"] or "[]"):  # corrigé à la main : la correction reste
                    for k in GROUPES_CORRIGES.get(groupe, ()):
                        ligne.pop(k, None)
                if _meme_minute_moins_precise(ex["date_pari"], ligne.get("date_pari")):
                    # Winamax « Mes paris » donne la minute, l'historique de compte la seconde : la seconde reste.
                    ligne.pop("date_pari")
                if not ligne.get("freebet", 1):
                    # Une page qui ne montre pas le freebet (Betclic « Terminés ») n'efface pas celui reconnu avant.
                    ligne.pop("freebet", None)
                if ligne["cote"] is None:
                    # Une cote lue plus tôt (pari en cours chez Betclic) reste : la page des paris réglés ne la
                    # montre plus.
                    ligne.pop("cote")
                if ligne.get("date_evenement") is None:
                    ligne.pop("date_evenement", None)  # une page sans la date (historique Winamax) ne l'efface pas
                ligne["modifie_le"] = maintenant
                if p.detail_partiel:
                    # Seul le résultat change : le détail (sport, sélections) lu ailleurs reste.
                    ligne = {k: v for k, v in ligne.items()
                             if k in ("etat", "etat_brut", "mise", "gains", "cote", "date_evenement", "date_pari",
                                      "freebet", "modifie_le")}
                # Le bookmaker l'emporte sur une modification à la main (il ne montre jamais un pari réglé
                # comme « en cours » ici : ce cas reste « déjà connu »).
                ligne["modifie_main"], ligne["valeurs_import"] = 0, None
                cles = {k: v for k, v in ligne.items() if k not in ("bookmaker", "reference")}
                avant = cx.execute(f"SELECT {', '.join(_SUIVIS)} FROM paris WHERE bookmaker=? AND reference=?",
                                   (p.bookmaker, p.reference)).fetchone()
                bilan["details"].append({"resume": p.resume, "statut": "mis à jour",
                                         "changements": _changements(avant, cles)})
                cx.execute(f"UPDATE paris SET {', '.join(f'{k}=?' for k in cles)} WHERE bookmaker=? AND reference=?",
                           [*cles.values(), p.bookmaker, p.reference])
                bilan["mis_a_jour"] += 1
            elif s["statut"] == "supprimé":
                bilan["supprimes"] = bilan.get("supprimes", 0) + 1
            else:
                bilan["deja_connus"] += 1
                if p.etat != "en_cours":
                    # Le bookmaker confirme la modification à la main : le pari redevient « tel qu'importé ».
                    cx.execute("""UPDATE paris SET modifie_main=0, valeurs_import=NULL
                                  WHERE bookmaker=? AND reference=? AND modifie_main=1""", (p.bookmaker, p.reference))
        if identifiant and not c["identifiant"]:
            cx.execute("UPDATE comptes SET identifiant=? WHERE id=?", (identifiant, compte_id))
        cx.execute(
            "INSERT INTO imports (date, bookmaker, compte_id, lus, nouveaux, mis_a_jour) VALUES (?,?,?,?,?,?)",
            (maintenant, bookmaker, compte_id, bilan["lus"], bilan["nouveaux"], bilan["mis_a_jour"]),
        )
        reclasser_sports(cx)
    return bilan


ETATS_MODIFIABLES = ("en_cours", "gagne", "perdu", "annule", "cashout")


def modifier_pari(cx: sqlite3.Connection, bookmaker: str, reference: str, etat: str,
                  gains: float | None = None, mise: float | None = None, cote: float | None = None) -> dict:
    """Modifie à la main l'état d'un pari (et ses gains, sa mise, sa cote). Les valeurs du bookmaker sont gardées
    la première fois, pour pouvoir le signaler ; le prochain import qui montre le pari réglé l'emporte.

    Gains : 0 pour un pari perdu, aucun pour un pari en cours ; la mise rendue pour un remboursement s'ils ne sont
    pas donnés ; obligatoires pour un pari gagné ou un cash-out."""
    ex = cx.execute("SELECT * FROM paris WHERE bookmaker=? AND reference=?", (bookmaker, reference)).fetchone()
    if ex is None:
        raise ValueError("Pari introuvable.")
    if etat not in ETATS_MODIFIABLES:
        raise ValueError("État inconnu.")
    mise = ex["mise"] if mise is None else float(mise)
    if mise <= 0:
        raise ValueError("La mise doit être positive.")
    if etat == "perdu":
        gains = 0.0
    elif etat == "en_cours":
        gains = None
    elif etat == "annule":
        gains = mise if gains is None else float(gains)
    elif gains is None:
        raise ValueError("Indique le montant gagné (mise comprise).")
    if gains is not None and gains < 0:
        raise ValueError("Les gains ne peuvent pas être négatifs.")
    valeurs_import = ex["valeurs_import"]
    if not ex["modifie_main"]:
        valeurs_import = json.dumps({k: ex[k] for k in ("etat", "etat_brut", "gains", "mise", "cote")},
                                    ensure_ascii=False)
    with cx:
        cx.execute(
            """UPDATE paris SET etat=?, gains=?, mise=?, cote=?, modifie_main=1, valeurs_import=?, modifie_le=?
               WHERE bookmaker=? AND reference=?""",
            (etat, None if gains is None else round(gains, 2), round(mise, 2),
             ex["cote"] if cote is None else float(cote), valeurs_import, _maintenant(), bookmaker, reference),
        )
    return dict(cx.execute("SELECT * FROM paris WHERE bookmaker=? AND reference=?", (bookmaker, reference)).fetchone())


def partager_pari(cx: sqlite3.Connection, bookmaker: str, reference: str, partage: bool) -> dict:
    """Marque un pari comme partagé (ou plus). L'heure du partage et l'état du pari à ce moment sont figés : ils
    montrent si le pari a été partagé avant d'être réglé."""
    ex = cx.execute("SELECT partage, etat FROM paris WHERE bookmaker=? AND reference=?", (bookmaker, reference)).fetchone()
    if ex is None:
        raise ValueError("Pari introuvable.")
    with cx:
        if partage and not ex["partage"]:
            cx.execute("UPDATE paris SET partage=1, partage_le=?, etat_au_partage=? WHERE bookmaker=? AND reference=?",
                       (_maintenant(), ex["etat"], bookmaker, reference))
        elif not partage:
            cx.execute("""UPDATE paris SET partage=0, partage_le=NULL, etat_au_partage=NULL, partage_source=NULL,
                          partage_pct=NULL WHERE bookmaker=? AND reference=?""", (bookmaker, reference))
    return dict(cx.execute("SELECT * FROM paris WHERE bookmaker=? AND reference=?", (bookmaker, reference)).fetchone())


SPORTS_VAGUES = {"Autre", "Inconnu", "Multi-sports", "Combiné"}


def _sans_sport(selections: str, devine: bool) -> str:
    """Les sélections sans leur sport, quand il est deviné : le sport corrigé par reclasser_sports ne doit pas
    faire passer le pari pour « mis à jour » à chaque import."""
    if not devine:
        return selections
    return json.dumps([{k: v for k, v in s.items() if k != "sport"} for s in json.loads(selections or "[]")],
                      ensure_ascii=False, sort_keys=True)


def _noms(selection: dict) -> list[str]:
    """Les noms propres d'une sélection (coureur, joueur, équipe) : « Eric Perrot », « Lausanne HC ». Les mots seuls
    (« France », « Movistar ») et ce qui porte un chiffre (« Tour de Guangxi 2026 ») sont écartés : trop ambigus."""
    morceaux = [selection.get("choix") or "", *re.split(r"\s+/\s+|\s+-\s+|\s+v\.?\s+", selection.get("evenement") or "")]
    return [m.strip() for m in morceaux if m and _ressemble_a_un_nom(m.strip())]


def reclasser_sports(cx: sqlite3.Connection) -> int:
    """Corrige le sport deviné d'un pari grâce aux noms déjà vus avec un sport sûr : donné par le bookmaker
    (historique Winamax, Unibet, ps3838) ou corrigé à la main. Un nom compte s'il est rattaché à un même sport au
    moins 8 fois sur 10. Les sports corrigés à la main ne sont jamais touchés. Renvoie le nombre de paris corrigés."""
    connus: dict[str, Counter] = {}
    for r in cx.execute("""SELECT sport, sport_corrige, selections FROM paris
                           WHERE sport_devine = 0 OR sport_corrige = 1""").fetchall():
        sels = json.loads(r["selections"] or "[]")
        for sel in sels:
            # Corrigé à la main : le sport du pari vaut pour sa sélection, s'il n'en a qu'une.
            sport = r["sport"] if r["sport_corrige"] and len(sels) == 1 else sel.get("sport")
            if sport and sport not in SPORTS_VAGUES:
                for nom in _noms(sel):
                    connus.setdefault(nom.lower(), Counter())[sport] += 1
    if not connus:
        return 0

    def sport_sur(nom: str) -> str | None:
        c = connus.get(nom.lower())
        if not c:
            return None
        sport, n = c.most_common(1)[0]
        return sport if n >= 0.8 * sum(c.values()) else None

    corriges = 0
    for r in cx.execute("""SELECT bookmaker, reference, sport, type, selections FROM paris
                           WHERE sport_devine = 1 AND sport_corrige = 0""").fetchall():
        sels = json.loads(r["selections"] or "[]")
        change = False
        for sel in sels:
            trouves = {s for s in (sport_sur(n) for n in _noms(sel)) if s}
            if len(trouves) == 1 and sel.get("sport") != (nouveau := trouves.pop()):
                sel["sport"], change = nouveau, True
        if not change:
            continue
        sports = {sel.get("sport") for sel in sels if sel.get("sport")}
        sport = sports.pop() if len(sports) == 1 else ("Multi-sports" if sports else r["sport"])
        cx.execute("UPDATE paris SET sport=?, selections=? WHERE bookmaker=? AND reference=?",
                   (sport, json.dumps(sels, ensure_ascii=False), r["bookmaker"], r["reference"]))
        corriges += 1
    return corriges


def corriger_sport(cx: sqlite3.Connection, bookmaker: str, reference: str, sport: str) -> None:
    """Corrige le sport d'un pari ; les autres paris au sport deviné qui portent les mêmes noms suivent."""
    with cx:
        cx.execute(
            "UPDATE paris SET sport=?, sport_corrige=1, modifie_le=? WHERE bookmaker=? AND reference=?",
            (sport, _maintenant(), bookmaker, reference),
        )
        reclasser_sports(cx)



# --------------------------------------------------------------------------- #
# Sites ajoutés par l'utilisateur, paris saisis à la main, corrections complètes
# --------------------------------------------------------------------------- #
def lister_sites(cx: sqlite3.Connection) -> list[dict]:
    """Les sites ajoutés par l'utilisateur : l'appli ne les lit pas (pas d'import ni d'extension), on y saisit
    paris, solde, dépôts et retraits à la main."""
    return [dict(r) for r in cx.execute("SELECT nom, libelle FROM sites ORDER BY libelle COLLATE NOCASE")]


def supprimer_site(cx: sqlite3.Connection, nom: str) -> None:
    """Retire un site ajouté à la main, une fois vide (ses comptes supprimés, donc ses paris et mouvements aussi)."""
    if not nom.startswith("site-") or not cx.execute("SELECT 1 FROM sites WHERE nom=?", (nom,)).fetchone():
        raise ValueError("Seul un site ajouté à la main se supprime.")
    n = cx.execute("SELECT COUNT(*) FROM comptes WHERE bookmaker=?", (nom,)).fetchone()[0]
    if n:
        raise ValueError(f"Ce site a encore {n} compte(s) : supprime-les d'abord.")
    with cx:
        cx.execute("DELETE FROM sites WHERE nom=?", (nom,))


def creer_site(cx: sqlite3.Connection, libelle: str, reserves: dict[str, str]) -> str:
    """Le nom interne du site `libelle` (créé s'il n'existe pas). `reserves` : {nom: libellé} des bookmakers que
    l'appli lit déjà ; taper « Betclic » renvoie le vrai Betclic plutôt qu'un doublon."""
    libelle = " ".join(libelle.split())
    if not libelle:
        raise ValueError("Donne le nom du site.")
    if len(libelle) > 40:
        raise ValueError("Nom de site trop long (40 caractères au plus).")
    for nom, nom_affiche in reserves.items():
        if libelle.lower() in (nom_affiche.lower(), nom):
            return nom
    existant = cx.execute("SELECT nom FROM sites WHERE lower(libelle)=lower(?)", (libelle,)).fetchone()
    if existant:
        return existant["nom"]
    base = "site-" + (re.sub(r"[^a-z0-9]+", "-", sans_accents(libelle).lower()).strip("-") or "perso")
    nom, i = base, 2
    while cx.execute("SELECT 1 FROM sites WHERE nom=?", (nom,)).fetchone():
        nom, i = f"{base}-{i}", i + 1
    cx.execute("INSERT INTO sites (nom, libelle, cree_le) VALUES (?,?,?)", (nom, libelle, _maintenant()))
    cx.commit()
    return nom


TYPES_SAISIS = ("simple", "combine", "mycombi", "systeme")

# Champs qu'une correction à la main protège des imports suivants (le résultat, lui, suit la règle de
# modifier_pari : le bookmaker l'emporte dès qu'il montre le pari réglé).
GROUPES_CORRIGES = {
    "date_pari": ("date_pari",),
    "date_evenement": ("date_evenement",),
    "details": ("type", "nb_selections", "evenement", "competition", "marche", "categorie_marche", "choix", "resume",
                "selections"),
    "cote_boostee": ("cote_boostee",),
    "freebet": ("freebet",),
}
_COMPARES = {"details": ("type", "nb_selections", "evenement", "competition", "marche", "choix", "selections")}


def _gains_saisis(etat: str, mise: float, gains: float | None, cote: float | None,
                  freebet: bool = False) -> float | None:
    """Les gains d'un pari saisi : ceux indiqués, sinon mise × cote (un freebet ne rend pas sa mise : mise × (cote − 1))."""
    if etat == "perdu":
        return 0.0
    if etat == "en_cours":
        return None
    if etat == "annule":
        return mise if gains is None else gains
    if gains is None:
        if etat == "gagne" and cote:
            return round(mise * (cote - 1 if freebet else cote), 2)
        raise ValueError("Indique le montant gagné (mise comprise), ou la cote.")
    return gains


def _verifier_saisie(d: dict) -> None:
    if d.get("type") not in TYPES_SAISIS:
        raise ValueError("Type de pari inconnu.")
    if d.get("etat") not in ETATS_MODIFIABLES:
        raise ValueError("État inconnu.")
    if not d.get("mise") or d["mise"] <= 0:
        raise ValueError("La mise doit être positive.")
    if d.get("cote") is not None and d["cote"] < 1:
        raise ValueError("Une cote vaut au moins 1.")
    if d.get("gains") is not None and d["gains"] < 0:
        raise ValueError("Les gains ne peuvent pas être négatifs.")
    if d.get("date_pari") is None:
        raise ValueError("Indique la date du pari.")
    remplies = [s for s in d.get("selections") or [] if any((s.get(k) or "").strip() for k in ("evenement", "marche", "choix"))]
    if d["type"] == "simple" and not remplies:
        raise ValueError("Décris le pari : au moins l'événement, le marché ou ton choix.")


def _resume_saisi(p: Pari) -> str:
    """Le résumé d'un pari saisi ou corrigé, sans « : » orphelin quand un champ est laissé vide."""
    if p.type == "combine":
        return f"Combiné de {p.nb_selections} sélections"
    if p.type == "systeme":
        return f"Système ({p.nb_selections} sélections)"
    if not p.selections:
        return "?"
    s = p.selections[0]
    texte = " : ".join(x for x in (s.marche, s.choix) if x)
    if p.type == "mycombi":
        return f"{s.evenement or texte} — combiné même match ({p.nb_selections} sélections)"
    if texte and s.evenement:
        return f"{texte} — {s.evenement}"
    return texte or s.evenement or "?"


def _pari_saisi(bookmaker: str, reference: str, d: dict, anciennes: list[dict] | None = None,
                garder_sports: bool = False) -> Pari:
    """Le pari décrit par le formulaire. `anciennes` : les sélections déjà connues (pour garder ce que le formulaire
    ne montre pas, comme l'étape) ; `garder_sports` : le sport n'a pas été changé, celui de chaque sélection reste."""
    anciennes = anciennes or []
    champs = set(Selection.__dataclass_fields__)
    selections = []
    for i, s in enumerate(d.get("selections") or []):
        texte = {k: (s.get(k) or "").strip() for k in ("evenement", "marche", "choix", "competition")}
        if not any(texte[k] for k in ("evenement", "marche", "choix")):
            continue
        base = {k: v for k, v in (anciennes[i] if i < len(anciennes) else {}).items() if k in champs}
        sport = base.get("sport") if garder_sports and base.get("sport") else (s.get("sport") or d["sport"])
        if d["type"] == "simple" and not garder_sports:
            sport = d["sport"]
        base.update(texte, sport=sport, cote=s.get("cote"))
        selections.append(Selection(**base))
    if d["type"] == "simple":
        nb = 1
    else:
        nb = int(d.get("nb_selections") or 0) or len(selections) or 2
    return Pari(bookmaker, reference, d["date_pari"], d["type"], d["etat"], "Saisi à la main", round(d["mise"], 2),
                None if d.get("gains") is None else round(d["gains"], 2), cote_boostee=bool(d.get("cote_boostee")),
                freebet=bool(d.get("freebet")), nb_selections=nb, date_evenement=d.get("date_evenement"), selections=selections, cote=d.get("cote"))


def _colonnes_saisies(p: Pari, d: dict) -> dict:
    ligne = _ligne(p)
    ligne["resume"] = _resume_saisi(p)
    ligne["sport"] = (d.get("sport") or "").strip() or "Autre"
    ligne["sport_devine"] = 0
    return ligne


def ajouter_pari(cx: sqlite3.Connection, d: dict) -> dict:
    """Un pari saisi à la main (un site que l'appli ne lit pas, un pari oublié). Sa référence « MAN-… » ne
    correspond à aucun pari de bookmaker : aucun import ne le touchera."""
    _verifier_saisie(d)
    c = compte(cx, d.get("compte_id"))
    if c is None:
        raise ValueError("Choisis le compte du pari.")
    d = {**d, "gains": _gains_saisis(d["etat"], d["mise"], d.get("gains"), d.get("cote"), bool(d.get("freebet")))}
    reference = f"MAN-{datetime.now():%Y%m%d%H%M%S}-{secrets.token_hex(2).upper()}"
    ligne = _colonnes_saisies(_pari_saisi(c["bookmaker"], reference, d), d)
    maintenant = _maintenant()
    ligne |= {"compte_id": c["id"], "importe_le": maintenant, "modifie_le": maintenant, "manuel": 1, "sport_corrige": 1}
    with cx:
        cx.execute(f"INSERT INTO paris ({', '.join(ligne)}) VALUES ({', '.join('?' * len(ligne))})", list(ligne.values()))
    return dict(cx.execute("SELECT * FROM paris WHERE bookmaker=? AND reference=?", (c["bookmaker"], reference)).fetchone())


def editer_pari(cx: sqlite3.Connection, bookmaker: str, reference: str, d: dict) -> dict:
    """Corrige tout un pari : compte, dates, type, sport, sélections, cote, mise, état, gains.

    Pari importé : il reste chez son bookmaker (l'import le retrouverait sinon) ; ce qui est corrigé (dates, détail,
    cote boostée, sport) n'est plus remplacé par les imports suivants ; le résultat garde la règle des modifications
    à la main (le bookmaker l'emporte dès qu'il montre le pari réglé). Pari saisi à la main : tout se change, site
    compris."""
    ex = cx.execute("SELECT * FROM paris WHERE bookmaker=? AND reference=?", (bookmaker, reference)).fetchone()
    if ex is None:
        raise ValueError("Pari introuvable.")
    _verifier_saisie(d)
    c = compte(cx, d.get("compte_id"))
    if c is None:
        raise ValueError("Choisis le compte du pari.")
    if c["bookmaker"] != bookmaker and not ex["manuel"]:
        raise ValueError("Un pari importé reste chez son bookmaker (le prochain import le retrouverait) : choisis un "
                         "compte du même site. Seuls les paris ajoutés à la main peuvent changer de site.")
    d = {**d, "gains": _gains_saisis(d["etat"], d["mise"], d.get("gains"), d.get("cote"), bool(d.get("freebet")))}
    sport_change = (d.get("sport") or "").strip() != ex["sport"]
    p = _pari_saisi(c["bookmaker"], reference, d, json.loads(ex["selections"] or "[]"), garder_sports=not sport_change)
    ligne = _colonnes_saisies(p, d)
    maj = {k: v for k, v in ligne.items() if k not in ("bookmaker", "reference", "etat_brut")}

    corriges = set(json.loads(ex["champs_corriges"] or "[]"))
    for groupe, colonnes in GROUPES_CORRIGES.items():
        if any(ligne[k] != ex[k] for k in _COMPARES.get(groupe, colonnes)):
            corriges.add(groupe)
        elif groupe not in corriges:
            for k in colonnes:  # inchangé : on garde exactement ce qu'avait lu l'import
                maj.pop(k, None)
    if sport_change:
        maj["sport_corrige"] = 1
    else:
        maj.pop("sport")
        maj.pop("sport_devine")
    resultat = ("etat", "gains", "mise", "cote")
    if not ex["manuel"] and any(ligne[k] != ex[k] for k in resultat):
        maj["modifie_main"] = 1
        maj["valeurs_import"] = ex["valeurs_import"] if ex["modifie_main"] else json.dumps(
            {k: ex[k] for k in ("etat", "etat_brut", "gains", "mise", "cote")}, ensure_ascii=False)
    maj |= {"compte_id": c["id"], "modifie_le": _maintenant(),
            "champs_corriges": json.dumps(sorted(corriges)) if corriges and not ex["manuel"] else None}
    if c["bookmaker"] != bookmaker:
        maj["bookmaker"] = c["bookmaker"]
    with cx:
        cx.execute(f"UPDATE paris SET {', '.join(f'{k}=?' for k in maj)} WHERE bookmaker=? AND reference=?",
                   [*maj.values(), bookmaker, reference])
    return dict(cx.execute("SELECT * FROM paris WHERE bookmaker=? AND reference=?", (c["bookmaker"], reference)).fetchone())


def supprimer_pari(cx: sqlite3.Connection, bookmaker: str, reference: str) -> None:
    """Supprime un pari. Sa clé (bookmaker, référence) est gardée dans paris_supprimes : un import qui le relit
    l'ignore, et la synchronisation le supprime aussi sur l'autre appareil."""
    ex = cx.execute("SELECT 1 FROM paris WHERE bookmaker=? AND reference=?", (bookmaker, reference)).fetchone()
    if ex is None:
        raise ValueError("Pari introuvable.")
    with cx:
        cx.execute("DELETE FROM paris WHERE bookmaker=? AND reference=?", (bookmaker, reference))
        cx.execute("INSERT OR REPLACE INTO paris_supprimes (bookmaker, reference, supprime_le) VALUES (?,?,?)",
                   (bookmaker, reference, _maintenant()))


def ajouter_mouvement(cx: sqlite3.Connection, compte_id: int, sens: str, quand: datetime, montant: float) -> dict:
    """Un dépôt ou un retrait saisi à la main. Deux saisies identiques sont deux mouvements (rangs différents)."""
    if sens not in SENS:
        raise ValueError("Dépôt ou retrait ?")
    if not montant or montant <= 0:
        raise ValueError("Le montant doit être positif.")
    if compte(cx, compte_id) is None:
        raise ValueError("Compte introuvable.")
    date = quand.replace(microsecond=0).isoformat()
    rang = 1 + cx.execute("SELECT COALESCE(MAX(rang), 0) FROM mouvements WHERE compte_id=? AND sens=? AND date=? AND montant=?",
                          (compte_id, sens, date, round(montant, 2))).fetchone()[0]
    with cx:
        cx.execute("""INSERT INTO mouvements (compte_id, sens, date, montant, rang, moyen, importe_le)
                      VALUES (?,?,?,?,?,?,?)""", (compte_id, sens, date, round(montant, 2), rang, "Saisi à la main",
                                                  _maintenant()))
    return {"nouveaux": 1}


def supprimer_mouvement(cx: sqlite3.Connection, compte_id: int, sens: str, date: str, montant: float, rang: int) -> int:
    with cx:
        return cx.execute("DELETE FROM mouvements WHERE compte_id=? AND sens=? AND date=? AND montant=? AND rang=?",
                          (compte_id, sens, date, round(montant, 2), rang)).rowcount

def imports(cx: sqlite3.Connection) -> list[dict]:
    lignes = cx.execute(
        """SELECT i.date, i.bookmaker, c.nom AS compte, i.lus, i.nouveaux, i.mis_a_jour
           FROM imports i LEFT JOIN comptes c ON c.id = i.compte_id ORDER BY i.id DESC LIMIT 200"""
    ).fetchall()
    return [dict(l) for l in lignes]


def supprimer_tout(cx: sqlite3.Connection) -> None:
    with cx:
        cx.execute("DELETE FROM paris")
        cx.execute("DELETE FROM paris_supprimes")
        cx.execute("DELETE FROM mouvements")
        cx.execute("DELETE FROM parametres")
        cx.execute("DELETE FROM imports")
        cx.execute("DELETE FROM comptes")


# --------------------------------------------------------------------------- #
# Dépôts et retraits
# --------------------------------------------------------------------------- #
SENS = ("depot", "retrait")


def _sens(m: Mouvement, sens: str) -> str:
    """Le sens lu sur la page (PMU) l'emporte ; sinon celui choisi pour toute la page (Betclic)."""
    return m.sens or sens


def _avec_rangs(mouvements: list[Mouvement], sens: str) -> list[tuple[Mouvement, int]]:
    """Les mouvements validés, numérotés parmi ceux de même sens, date et montant : deux dépôts de 10 € la même
    minute sont deux mouvements (rangs 1 et 2), et recoller la page retrouve les mêmes rangs."""
    vus: dict[tuple, int] = {}
    resultat = []
    for m in mouvements:
        if not m.valide:
            continue
        cle = (_sens(m, sens), m.date, round(m.montant, 2))
        vus[cle] = vus.get(cle, 0) + 1
        resultat.append((m, vus[cle]))
    return resultat


def _cle_mouvement(m: Mouvement, sens: str, rang: int) -> tuple:
    return (_sens(m, sens), m.date.isoformat(), round(m.montant, 2), rang)


def comparer_mouvements(cx: sqlite3.Connection, compte_id: int, sens: str, mouvements: list[Mouvement]) -> dict:
    """Sans rien écrire : combien de mouvements validés sont nouveaux, déjà connus, et combien sont ignorés
    (refusés, en cours…), avec le statut de chacun pour l'aperçu. `sens` vaut pour les mouvements dont la page
    ne dit pas le sens."""
    connus = {(r["sens"], r["date"], r["montant"], r["rang"]) for r in cx.execute(
        "SELECT sens, date, montant, rang FROM mouvements WHERE compte_id=?", (compte_id,))}
    rangs = {id(m): r for m, r in _avec_rangs(mouvements, sens)}
    lignes = []
    for m in mouvements:
        if id(m) not in rangs:
            statut = "ignoré"
        else:
            statut = "déjà connu" if _cle_mouvement(m, sens, rangs[id(m)]) in connus else "nouveau"
        lignes.append({"date": m.date.isoformat(), "montant": m.montant, "statut_site": m.statut, "moyen": m.moyen,
                       "sens": _sens(m, sens), "statut": statut})
    return {
        "lignes": lignes,
        "nouveaux": sum(l["statut"] == "nouveau" for l in lignes),
        "deja_connus": sum(l["statut"] == "déjà connu" for l in lignes),
        "ignores": sum(l["statut"] == "ignoré" for l in lignes),
        "total_valide": round(sum(m.montant for m in mouvements if m.valide), 2),
        "totaux": {s: round(sum(m.montant for m in mouvements if m.valide and _sens(m, sens) == s), 2) for s in SENS},
    }


def enregistrer_mouvements(cx: sqlite3.Connection, compte_id: int, sens: str, mouvements: list[Mouvement]) -> dict:
    if any(_sens(m, sens) not in SENS for m in mouvements if m.valide):
        raise ValueError("Indique s'il s'agit de dépôts ou de retraits.")
    if compte(cx, compte_id) is None:
        raise ValueError("Compte introuvable.")
    avant = comparer_mouvements(cx, compte_id, sens, mouvements)
    maintenant = _maintenant()
    with cx:
        for m, rang in _avec_rangs(mouvements, sens):
            cx.execute(
                """INSERT OR IGNORE INTO mouvements (compte_id, sens, date, montant, rang, moyen, importe_le)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (compte_id, _sens(m, sens), m.date.isoformat(), round(m.montant, 2), rang, m.moyen or None, maintenant),
            )
    return {"nouveaux": avant["nouveaux"], "deja_connus": avant["deja_connus"], "ignores": avant["ignores"]}


def lister_mouvements(cx: sqlite3.Connection, compte_id: int | None = None) -> list[dict]:
    """`montant` : dans la monnaie du compte (la clé du mouvement) ; `montant_eur` : en euros."""
    sql = """SELECT m.compte_id, m.sens, m.date, m.montant, m.rang, m.moyen, c.devise, c.taux
             FROM mouvements m JOIN comptes c ON c.id = m.compte_id"""
    args: tuple = ()
    if compte_id is not None:
        sql += " WHERE m.compte_id=?"
        args = (compte_id,)
    lignes = [dict(r) for r in cx.execute(sql + " ORDER BY m.date DESC, m.rang DESC", args)]
    for l in lignes:
        l["montant_eur"] = round(l["montant"] * taux_compte(l), 2)
        del l["taux"]
    return lignes


def effacer_mouvements(cx: sqlite3.Connection, compte_id: int, sens: str | None = None) -> int:
    """Efface les dépôts, les retraits ou les deux d'un compte (pour recoller une page mal rangée)."""
    sql, args = "DELETE FROM mouvements WHERE compte_id=?", [compte_id]
    if sens is not None:
        if sens not in SENS:
            raise ValueError("Sens inconnu.")
        sql += " AND sens=?"
        args.append(sens)
    with cx:
        return cx.execute(sql, args).rowcount


def bilan_argent(cx: sqlite3.Connection) -> dict:
    """Par compte (tous, même sans mouvement ni solde) : déposé, retiré, solde, bilan (retiré + solde − déposé),
    et, pour comparer, le profit des paris enregistrés sur ce compte."""
    lignes = cx.execute(
        """SELECT c.id, c.bookmaker, c.nom, c.couleur, c.solde, c.solde_le, c.devise, c.taux,
                  COALESCE(SUM(CASE WHEN m.sens='depot' THEN m.montant END), 0) AS depose,
                  COALESCE(SUM(CASE WHEN m.sens='retrait' THEN m.montant END), 0) AS retire,
                  COUNT(CASE WHEN m.sens='depot' THEN 1 END) AS n_depots,
                  COUNT(CASE WHEN m.sens='retrait' THEN 1 END) AS n_retraits,
                  MIN(m.date) AS premier, MAX(m.date) AS dernier
           FROM comptes c LEFT JOIN mouvements m ON m.compte_id = c.id
           GROUP BY c.id
           ORDER BY c.bookmaker, c.nom"""
    ).fetchall()
    regles = tuple(sorted(ETATS_REGLES))
    comptes = []
    for l in lignes:
        c = dict(l)
        p = cx.execute(
            f"""SELECT COUNT(*) AS n, COALESCE(SUM(COALESCE(gains, 0) - mise), 0) AS profit FROM paris
                WHERE compte_id=? AND etat IN ({",".join("?" * len(regles))})""",
            (c["id"], *regles),
        ).fetchone()
        # Tout en euros ; le solde aussi dans la monnaie du compte (celle que l'on tape et que le site affiche).
        t = taux_compte(c)
        c["solde_devise"] = c["solde"]
        c["solde"] = None if c["solde"] is None else round(c["solde"] * t, 2)
        c["depose"], c["retire"] = round(c["depose"] * t, 2), round(c["retire"] * t, 2)
        c["bilan"] = round(c["retire"] + (c["solde"] or 0) - c["depose"], 2)
        c["n_paris_regles"], c["profit_paris"] = p["n"], round(p["profit"] * t, 2)
        comptes.append(c)
    total = {k: round(sum(c[k] or 0 for c in comptes), 2) for k in ("depose", "retire", "solde", "bilan")}
    return {"comptes": comptes, "total": total}


# --------------------------------------------------------------------------- #
# Paramètres (bankroll)
# --------------------------------------------------------------------------- #
def bankroll(cx: sqlite3.Connection) -> float | None:
    ligne = cx.execute("SELECT valeur FROM parametres WHERE cle='bankroll'").fetchone()
    return float(ligne["valeur"]) if ligne and ligne["valeur"] else None


def definir_bankroll(cx: sqlite3.Connection, montant: float | None) -> None:
    """La bankroll de référence : les mises s'expriment aussi en % de cette somme. None l'efface."""
    if montant is not None and montant <= 0:
        raise ValueError("La bankroll doit être positive.")
    with cx:
        if montant is None:
            cx.execute("DELETE FROM parametres WHERE cle='bankroll'")
        else:
            cx.execute("INSERT INTO parametres (cle, valeur) VALUES ('bankroll', ?) "
                       "ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur", (str(round(montant, 2)),))


# --------------------------------------------------------------------------- #
# Pronos Discord reliés aux paris
# --------------------------------------------------------------------------- #
def _paris_pour_rapprochement(cx: sqlite3.Connection) -> list[dict]:
    lignes = cx.execute("""SELECT p.bookmaker, p.reference, p.date_pari, p.date_evenement, p.type, p.etat, p.mise,
                                  p.gains, p.cote, p.selections, p.partage, p.partage_source, p.freebet,
                                  c.nom AS compte_nom
                           FROM paris p LEFT JOIN comptes c ON c.id = p.compte_id""").fetchall()
    paris = []
    for l in lignes:
        d = dict(l)
        d["date_pari"] = datetime.fromisoformat(d["date_pari"])
        d["date_evenement"] = datetime.fromisoformat(d["date_evenement"]) if d["date_evenement"] else None
        d["selections"] = json.loads(d["selections"] or "[]")
        paris.append(d)
    return paris


def etat_au_partage_discord(quand: datetime | None, pari: dict) -> str | None:
    """« en_cours » quand le message prouve un partage avant le résultat : avant que le pari soit pris, ou avant
    l'heure de l'événement si le bookmaker la donne. Sinon on ne sait pas (None) : rien n'est affirmé."""
    if quand is None:
        return None
    if quand <= pari["date_pari"]:
        return "en_cours"
    if pari.get("date_evenement") and quand < pari["date_evenement"]:
        return "en_cours"
    return None


def relier_discord(cx: sqlite3.Connection, texte: str, appliquer: bool = False) -> dict:
    """Lit un message de pronos Discord et le rapproche des paris enregistrés. `appliquer` : marque les paris
    retrouvés « partagés sur Discord » à la date du message. Renvoie l'aperçu."""
    from . import discord

    pronos = discord.rapprocher(discord.lire(texte), _paris_pour_rapprochement(cx))
    libelles = {"gagne": "gagné", "perdu": "perdu", "annule": "remboursé", "en_cours": "en cours", "cashout": "cash-out"}
    lignes = []
    for p in pronos:
        ligne = {"ligne": p.ligne, "titre": p.titre, "auteur": p.auteur, "date": p.date.isoformat() if p.date else None,
                 "nom": p.nom, "marche": p.marche, "adversaire": p.adversaire, "cote": p.cote, "pct": p.pct,
                 "rembourse": p.rembourse, "resultat": p.resultat, "bookmakers": p.bookmakers,
                 "autres_bookmakers": p.autres_bookmakers, "paris": []}
        for r in p.rapproches:
            sel = r["selections"][0] if r["selections"] else {}
            alertes = []
            if p.bookmakers and r["bookmaker"] not in p.bookmakers:
                alertes.append("Pris chez un autre bookmaker que ceux du prono.")
            if p.resultat and r["etat"] not in (p.resultat, "en_cours"):
                alertes.append(f"Le message dit {libelles[p.resultat]}, le bookmaker {libelles.get(r['etat'], r['etat'])}.")
            ligne["paris"].append({
                "bookmaker": r["bookmaker"], "reference": r["reference"], "compte": r["compte_nom"],
                "date_pari": r["date_pari"].isoformat(), "choix": sel.get("choix"), "marche": sel.get("marche"),
                "cote": r["cote"], "mise": r["mise"], "etat": r["etat"], "deja_partage": bool(r["partage"]),
                "source": r["partage_source"], "alertes": alertes})
        lignes.append(ligne)
    if appliquer:
        with cx:
            for p in pronos:
                for r in p.rapproches:
                    source = f"Discord – {p.auteur}" if p.auteur else "Discord"
                    if p.date is None:
                        source += " (date du message non copiée)"
                    cx.execute(
                        """UPDATE paris SET partage=1, partage_le=?, etat_au_partage=?, partage_source=?, partage_pct=?
                           WHERE bookmaker=? AND reference=?""",
                        ((p.date or datetime.now()).isoformat(timespec="seconds"), etat_au_partage_discord(p.date, r),
                         source, p.pct, r["bookmaker"], r["reference"]),
                    )
    return {"pronos": lignes, "n": len(lignes), "retrouves": sum(1 for l in lignes if l["paris"]),
            "paris": sum(len(l["paris"]) for l in lignes),
            "sans_date": sum(1 for l in lignes if l["paris"] and not l["date"])}


def releve_solde(cx: sqlite3.Connection, compte_id: int, solde: float, quand: str | None = None,
                 identifiant: str | None = None) -> bool:
    """Le solde lu par l'extension dans l'en-tête du site. Retient aussi l'identifiant du compte (pseudo Winamax,
    numéro ps3838) s'il n'en a pas. Renvoie True si le solde a changé."""
    c = compte(cx, compte_id)
    if c is None:
        raise ValueError("Compte introuvable.")
    with cx:
        cx.execute("UPDATE comptes SET solde=?, solde_le=? WHERE id=?",
                   (round(solde, 2), quand or _maintenant(), compte_id))
        if identifiant and not c["identifiant"]:
            cx.execute("UPDATE comptes SET identifiant=? WHERE id=?", (identifiant, compte_id))
    return c["solde"] is None or round(c["solde"], 2) != round(solde, 2)


def garder_solde_en_attente(cx: sqlite3.Connection, bookmaker: str, solde: float, quand: str | None = None,
                            identifiant: str | None = None) -> None:
    """Un solde lu par l'extension sans savoir à quel compte il revient (plusieurs comptes chez ce bookmaker, et le
    site n'affiche pas lequel est connecté) : gardé, le dernier par bookmaker, jusqu'à ce que l'utilisateur
    l'attribue dans la page Soldes."""
    valeur = json.dumps({"solde": round(solde, 2), "quand": quand or _maintenant(), "identifiant": identifiant})
    with cx:
        cx.execute("INSERT INTO parametres (cle, valeur) VALUES (?, ?) "
                   "ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur", (f"solde_attente:{bookmaker}", valeur))


def soldes_en_attente(cx: sqlite3.Connection) -> list[dict]:
    lignes = cx.execute("SELECT cle, valeur FROM parametres WHERE cle LIKE 'solde_attente:%' ORDER BY cle").fetchall()
    return [{"bookmaker": l["cle"].split(":", 1)[1], **json.loads(l["valeur"])} for l in lignes]


def oublier_solde_en_attente(cx: sqlite3.Connection, bookmaker: str) -> None:
    with cx:
        cx.execute("DELETE FROM parametres WHERE cle=?", (f"solde_attente:{bookmaker}",))


def attribuer_solde_en_attente(cx: sqlite3.Connection, bookmaker: str, compte_id: int) -> float:
    """Range le solde en attente du bookmaker sur ce compte. Renvoie le solde."""
    attente = next((s for s in soldes_en_attente(cx) if s["bookmaker"] == bookmaker), None)
    c = compte(cx, compte_id)
    if attente is None:
        raise ValueError("Plus de solde en attente pour ce bookmaker.")
    if c is None or c["bookmaker"] != bookmaker:
        raise ValueError("Ce compte n'est pas chez ce bookmaker.")
    releve_solde(cx, compte_id, attente["solde"], attente["quand"], attente["identifiant"])
    oublier_solde_en_attente(cx, bookmaker)
    return attente["solde"]


def noter_extension(cx: sqlite3.Connection) -> None:
    """L'extension vient d'envoyer quelque chose : la page Importer peut dire qu'elle est active."""
    with cx:
        cx.execute("INSERT INTO parametres (cle, valeur) VALUES ('extension_vue_le', ?) "
                   "ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur", (_maintenant(),))


def extension_vue_le(cx: sqlite3.Connection) -> str | None:
    ligne = cx.execute("SELECT valeur FROM parametres WHERE cle='extension_vue_le'").fetchone()
    return ligne["valeur"] if ligne else None


def fusionner(cx: sqlite3.Connection, octets: bytes) -> dict:
    """Ajoute à la base ce qu'une autre base de l'appli contient en plus (celle de l'iPhone sur l'ordinateur, ou
    l'inverse). Rien n'est perdu ni doublé : un compte se reconnaît à son site et son nom, un pari à sa clé
    (bookmaker, référence), un mouvement au sien. Un pari connu des deux côtés garde la version modifiée en dernier,
    sauf qu'un pari réglé ne repasse jamais « en cours ». Le solde d'un compte : le relevé le plus récent."""
    import tempfile

    bilan = {"comptes_nouveaux": 0, "paris_nouveaux": 0, "paris_mis_a_jour": 0, "mouvements_nouveaux": 0}
    with tempfile.TemporaryDirectory() as dossier:
        chemin = Path(dossier) / "autre.db"
        chemin.write_bytes(octets)
        try:
            autre = ouvrir(chemin)  # mise à niveau, si elle vient d'une version plus ancienne de l'appli
        except sqlite3.DatabaseError as exc:
            raise ValueError("Ce fichier n'est pas une base de Suivi Paris.") from exc
        try:
            if not autre.execute("SELECT name FROM sqlite_master WHERE name='paris'").fetchone():
                raise ValueError("Ce fichier n'est pas une base de Suivi Paris.")
            with cx:
                for s in autre.execute("SELECT * FROM sites"):
                    cx.execute("INSERT OR IGNORE INTO sites (nom, libelle, cree_le) VALUES (?,?,?)",
                               (s["nom"], s["libelle"], s["cree_le"]))
                ids: dict[int, int] = {}
                for c in autre.execute("SELECT * FROM comptes"):
                    ici = cx.execute("SELECT * FROM comptes WHERE bookmaker=? AND lower(nom)=lower(?)",
                                     (c["bookmaker"], c["nom"])).fetchone()
                    if ici is None:
                        cur = cx.execute(
                            """INSERT INTO comptes (bookmaker, nom, couleur, identifiant, cree_le, solde, solde_le, devise, taux)
                               VALUES (?,?,?,?,?,?,?,?,?)""",
                            (c["bookmaker"], c["nom"], c["couleur"], c["identifiant"], c["cree_le"], c["solde"],
                             c["solde_le"], c["devise"], c["taux"]))
                        ids[c["id"]] = cur.lastrowid
                        bilan["comptes_nouveaux"] += 1
                        continue
                    ids[c["id"]] = ici["id"]
                    if c["solde_le"] and (not ici["solde_le"] or c["solde_le"] > ici["solde_le"]):
                        cx.execute("UPDATE comptes SET solde=?, solde_le=? WHERE id=?", (c["solde"], c["solde_le"], ici["id"]))
                    if c["identifiant"] and not ici["identifiant"]:
                        cx.execute("UPDATE comptes SET identifiant=? WHERE id=?", (c["identifiant"], ici["id"]))
                # Les paris supprimés d'un côté le sont aussi de l'autre (et ne reviennent pas avec cette base).
                for s in autre.execute("SELECT * FROM paris_supprimes"):
                    cx.execute("INSERT OR IGNORE INTO paris_supprimes (bookmaker, reference, supprime_le) VALUES (?,?,?)",
                               (s["bookmaker"], s["reference"], s["supprime_le"]))
                cur = cx.execute("""DELETE FROM paris WHERE EXISTS (SELECT 1 FROM paris_supprimes s
                                    WHERE s.bookmaker = paris.bookmaker AND s.reference = paris.reference)""")
                bilan["paris_supprimes"] = cur.rowcount
                supprimes = {(r[0], r[1]) for r in cx.execute("SELECT bookmaker, reference FROM paris_supprimes")}
                chez_autre = {r[1] for r in autre.execute("PRAGMA table_info(paris)")}
                colonnes = [r[1] for r in cx.execute("PRAGMA table_info(paris)") if r[1] in chez_autre]
                for p in autre.execute("SELECT * FROM paris"):
                    if (p["bookmaker"], p["reference"]) in supprimes:
                        continue
                    ligne = {k: p[k] for k in colonnes}
                    ligne["compte_id"] = ids.get(p["compte_id"])
                    ici = cx.execute("SELECT etat, modifie_le FROM paris WHERE bookmaker=? AND reference=?",
                                     (p["bookmaker"], p["reference"])).fetchone()
                    if ici is None:
                        cx.execute(f"INSERT INTO paris ({', '.join(ligne)}) VALUES ({', '.join('?' * len(ligne))})",
                                   list(ligne.values()))
                        bilan["paris_nouveaux"] += 1
                    elif (p["modifie_le"] or "") > (ici["modifie_le"] or "") and not (
                            ici["etat"] != "en_cours" and p["etat"] == "en_cours"):
                        maj = {k: v for k, v in ligne.items() if k not in ("bookmaker", "reference", "compte_id")}
                        cx.execute(f"UPDATE paris SET {', '.join(f'{k}=?' for k in maj)} WHERE bookmaker=? AND reference=?",
                                   [*maj.values(), p["bookmaker"], p["reference"]])
                        bilan["paris_mis_a_jour"] += 1
                for m in autre.execute("SELECT * FROM mouvements"):
                    if m["compte_id"] not in ids:
                        continue
                    cur = cx.execute(
                        """INSERT OR IGNORE INTO mouvements (compte_id, sens, date, montant, rang, moyen, importe_le)
                           VALUES (?,?,?,?,?,?,?)""",
                        (ids[m["compte_id"]], m["sens"], m["date"], m["montant"], m["rang"], m["moyen"], m["importe_le"]))
                    bilan["mouvements_nouveaux"] += cur.rowcount
        finally:
            autre.close()
    return bilan
