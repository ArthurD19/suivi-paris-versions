"""Démarre Suivi Paris et l'ouvre dans sa propre fenêtre.

- Lance le serveur local (127.0.0.1 uniquement : rien n'est exposé sur le réseau).
- Ouvre Chrome, Edge ou Chromium en mode « application » (une fenêtre sans barre d'adresse) ;
  fermer cette fenêtre arrête l'application.
- Sans ces navigateurs, ouvre un onglet du navigateur habituel ; l'application s'arrête quand l'onglet est
  fermé depuis une minute, ou avec le bouton « Quitter ».
- Si l'accès depuis l'iPhone est activé, fermer la fenêtre laisse l'appli tourner pour le téléphone ;
  « Quitter » l'arrête.

Usage : python -m suivi_paris.lanceur [--demo] [--sans-fenetre]
"""
from __future__ import annotations

import argparse
import os
import shutil
import signal
import subprocess
import sys
import time
import webbrowser
from collections.abc import Callable
from pathlib import Path

from . import serveur as srv
from .chemins import RACINE_PROJET, dossier_donnees


def trouver_navigateur() -> str | None:
    if sys.platform == "win32":
        bases = [os.environ.get(v, "") for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")]
        relatifs = [r"Google\Chrome\Application\chrome.exe", r"Microsoft\Edge\Application\msedge.exe",
                    r"Chromium\Application\chrome.exe"]
        for rel in relatifs:
            for base in bases:
                if base and (Path(base) / rel).exists():
                    return str(Path(base) / rel)
        return None
    if sys.platform == "darwin":
        for app in ("Google Chrome", "Microsoft Edge", "Chromium", "Brave Browser"):
            chemin = Path(f"/Applications/{app}.app/Contents/MacOS/{app}")
            if chemin.exists():
                return str(chemin)
        return None
    for nom in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge"):
        if chemin := shutil.which(nom):
            return chemin
    return None


_ACTIVITE_MAC = None  # gardée tant que l'appli tourne : la relâcher rendrait macOS libre de la ralentir


def sans_app_nap() -> None:
    """macOS met en veille (« App Nap ») une application sans fenêtre : c'est le cas du serveur quand il est lancé
    par l'icône Suivi Paris (la fenêtre est celle de Chrome). Ses réponses arrivent alors au ralenti. On déclare une
    activité en cours (NSProcessInfo beginActivityWithOptions:reason:), par ctypes comme le paquet « appnope »."""
    global _ACTIVITE_MAC
    if sys.platform != "darwin" or _ACTIVITE_MAC is not None:
        return
    try:
        import ctypes
        import ctypes.util

        objc = ctypes.cdll.LoadLibrary(ctypes.util.find_library("objc"))
        ctypes.cdll.LoadLibrary(ctypes.util.find_library("Foundation"))
        objc.objc_getClass.restype = ctypes.c_void_p
        objc.objc_getClass.argtypes = [ctypes.c_char_p]
        objc.sel_registerName.restype = ctypes.c_void_p
        objc.sel_registerName.argtypes = [ctypes.c_char_p]
        envoi = objc.objc_msgSend
        envoi.restype = ctypes.c_void_p

        envoi.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_char_p]
        raison = envoi(objc.objc_getClass(b"NSString"), objc.sel_registerName(b"stringWithUTF8String:"),
                       b"Suivi Paris sert ses pages")
        envoi.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        infos = envoi(objc.objc_getClass(b"NSProcessInfo"), objc.sel_registerName(b"processInfo"))
        if not infos or not raison:
            return
        # NSActivityUserInitiatedAllowingIdleSystemSleep | NSActivityLatencyCritical : pas de mise en veille de
        # l'appli, mais l'ordinateur garde le droit de s'endormir.
        options = (0x00FFFFFF & ~(1 << 20)) | 0xFF00000000
        envoi.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint64, ctypes.c_void_p]
        _ACTIVITE_MAC = envoi(infos, objc.sel_registerName(b"beginActivityWithOptions:reason:"), options, raison)
        envoi.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        envoi(_ACTIVITE_MAC, objc.sel_registerName(b"retain"))
    except (OSError, AttributeError, TypeError) as exc:
        journaliser(f"App Nap non désactivé : {exc!r}")


def ouvrir_fenetre(navigateur: str, url: str, profil: Path) -> tuple[subprocess.Popen, Callable[[], None]]:
    """La fenêtre de l'appli (Chrome en mode « application », avec son propre profil). Renvoie le processus à
    surveiller (il s'arrête avec le navigateur) et de quoi la fermer.

    Sur Mac, Chrome est lancé par `open` : il devient alors une application à part entière. Lancé directement, il
    dépendrait de l'application Suivi Paris, qui n'a pas de fenêtre à elle : macOS le traiterait comme une
    application en arrière-plan et le ralentirait au point que la page ne réponde plus."""
    options = [f"--app={url}", f"--user-data-dir={profil}", "--no-first-run", "--no-default-browser-check",
               "--window-size=1440,920"]
    if sys.platform == "darwin" and ".app/Contents/MacOS/" in navigateur:
        appli = navigateur.split(".app/Contents/MacOS/")[0] + ".app"
        # -n : une instance à part (le Chrome de tous les jours peut être ouvert) ; -W : `open` attend qu'elle se ferme.
        fenetre = subprocess.Popen(["open", "-n", "-W", "-a", appli, "--args", *options])

        def fermer() -> None:
            quitter_instance(profil)
            fenetre.terminate()

        return fenetre, fermer
    fenetre = subprocess.Popen([navigateur, *options])
    return fenetre, fenetre.terminate


def pid_instance(profil: Path) -> int | None:
    """Le processus de l'instance de Chrome qui utilise ce profil : Chrome le note dans le lien « SingletonLock »
    du profil (« nom-de-la-machine-12345 »)."""
    try:
        cible = os.readlink(profil / "SingletonLock")
    except OSError:
        return None
    morceaux = cible.rsplit("-", 1)
    return int(morceaux[1]) if len(morceaux) == 2 and morceaux[1].isdigit() else None


def quitter_instance(profil: Path, attente: float = 5.0) -> None:
    """Quitte l'instance de Chrome de la fenêtre de l'appli (sur Mac, fermer sa fenêtre ne la quitte pas) : comme
    « Quitter » dans le Dock (SIGTERM, que Chrome traite comme une fermeture normale), puis de force si elle traîne.
    Le Chrome de tous les jours, qui a son propre profil, n'est pas touché."""
    pid = pid_instance(profil)
    if pid is None:  # pas de verrou lisible : par la ligne de commande (« -- » : le motif commence par un tiret)
        subprocess.run(["pkill", "-f", "--", f"--user-data-dir={profil}"], capture_output=True, check=False)
        return
    try:
        os.kill(pid, signal.SIGTERM)
        fin = time.time() + attente
        while time.time() < fin:
            time.sleep(0.2)
            os.kill(pid, 0)  # ProcessLookupError quand il est parti
        os.kill(pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass


DELAI_FERMETURE = 4  # secondes : une page rechargée se signale avant (/api/ping dès son ouverture)


def fenetre_fermee(app, maintenant: float | None = None) -> bool:
    """La fenêtre de l'appli a été fermée : sa page a prévenu en se fermant (/api/fermeture) et aucune page ne s'est
    rouverte depuis. Sur Mac, fermer la dernière fenêtre ne quitte pas Chrome : sans cela, il fallait encore
    « Quitter » l'icône du Dock pour arrêter l'appli."""
    maintenant = time.time() if maintenant is None else maintenant
    if app.fermeture_le is None or maintenant - app.fermeture_le < DELAI_FERMETURE:
        return False
    return app.dernier_signe is None or app.dernier_signe <= app.fermeture_le


def journaliser(message: str) -> None:
    with open(dossier_donnees() / "journal.txt", "a", encoding="utf-8") as f:
        f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {message}\n")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true", help="ouvrir avec des paris inventés")
    ap.add_argument("--sans-fenetre", action="store_true", help="ne pas ouvrir de fenêtre (affiche l'adresse)")
    ap.add_argument("--port", type=int, default=0)
    args = ap.parse_args()
    sans_app_nap()

    try:
        port = args.port or (0 if args.demo else srv.PORT_LOCAL)  # la démonstration n'est jamais visible de l'extension
        try:
            serveur, app, url = srv.demarrer(port=port, mode_demo=args.demo, acces_reseau=False)
        except OSError:
            # Port pris (une autre fenêtre ouverte ?) : port au hasard, l'extension ne verra pas cette fenêtre.
            journaliser(f"Port {port} indisponible, port au hasard (l'extension Chrome ne verra pas cette fenêtre).")
            serveur, app, url = srv.demarrer(port=0, mode_demo=args.demo, acces_reseau=False)
    except Exception as exc:
        journaliser(f"Démarrage impossible : {exc!r}")
        raise
    journaliser(f"Démarré sur {url}")

    try:
        navigateur = None if args.sans_fenetre else trouver_navigateur()
        if navigateur:
            profil = dossier_donnees() / ("profil-fenetre-demo" if args.demo else "profil-fenetre")
            fenetre, fermer = ouvrir_fenetre(navigateur, url, profil)
            while fenetre.poll() is None and not app.arret.is_set() and not fenetre_fermee(app):
                time.sleep(0.5)
            if fenetre.poll() is None:
                fermer()
            # Accès iPhone actif : fermer la fenêtre ne coupe pas l'appli, seul « Quitter » l'arrête.
            # Rouvrir l'icône pendant ce temps relance une fenêtre sur un nouveau serveur local.
            while app.serveur_distant is not None and not app.arret.is_set():
                time.sleep(1)
        else:
            if args.sans_fenetre:
                print(f"Suivi Paris : {url}  (Ctrl+C pour arrêter)")
            else:
                webbrowser.open(url)
            debut = time.time()
            while not app.arret.is_set():
                time.sleep(1)
                signe = app.dernier_signe
                # L'onglet envoie un signe toutes les 15 s : sans nouvelles depuis 60 s, il a été fermé.
                if not args.sans_fenetre and signe and time.time() - signe > 60:
                    break
                if not args.sans_fenetre and signe is None and time.time() - debut > 300:
                    break
    except KeyboardInterrupt:
        pass
    finally:
        app.arreter_distant()
        serveur.shutdown()
        journaliser("Arrêté")
    if app.relancer:  # après une mise à jour : la nouvelle version, dans une nouvelle fenêtre
        journaliser("Redémarrage après mise à jour")
        subprocess.Popen([sys.executable, "-m", "suivi_paris.lanceur", *sys.argv[1:]], cwd=RACINE_PROJET,
                         start_new_session=True)


if __name__ == "__main__":
    main()
