"""La version de l'appli, et où en trouver les nouvelles.

Pour publier une version : `uv run python outils/publier.py 1.1.0 --envoyer` (voir le README, « Publier une version »).
C'est ce numéro que le bouton « Rechercher une mise à jour » compare à la dernière version publiée.
"""
VERSION = "1.5.0"

# Le dépôt GitHub public où sont publiées les versions (une « release » par version, avec le ZIP de l'appli).
# Le dépôt de développement peut rester privé : seule l'appli prête à installer est publiée ici.
DEPOT_VERSIONS = "ArthurD19/suivi-paris-versions"
