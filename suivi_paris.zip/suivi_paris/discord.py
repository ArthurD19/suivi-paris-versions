"""Pronos partagés sur Discord, reliés aux vrais paris de l'utilisateur.

Un message de pronos se colle dans la page Importer, tel que Discord le copie :

    1. PLUS FC GRUEL 37 — 11/09/2026 11:59      auteur et date du message (« Aujourd'hui à 11:59 » aussi)
    Vuelta                                       la course : un titre libre
    Meeus @6.5 (0.25%)                           coureur, cote, mise en % de bankroll
    T3 @2.1 (1%)                                 même coureur, autre marché (Top 3)
    Braet T3 @26 (0.1%)                          coureur et marché sur la même ligne
    T10                                          titre de marché : vaut pour les lignes suivantes du groupe
    Soder @1.66 (1%)
    Hoole > Foss @1.79 (0.75%)                   face-à-face : Hoole devant Foss
    Almeida @7 (0.7%):Winamax: :Unibet:          bookmakers (émojis du serveur, « :PMU~1: » compris)
    Braet T3 @26 (0.1%):PMU~1: ✅                 résultat : ✅ gagné, ❌ perdu, ⚪️ remboursé
    @Cyclisme                                    mention de rôle : ignorée

Une ligne vide termine un groupe : le coureur et le marché repartent de zéro.

Ces pronos ne créent pas de paris : chacun est rapproché d'un pari déjà enregistré (même coureur, même marché,
cote proche, pris peu avant ou après le message), qui est marqué « partagé sur Discord » à la date du message.
Quand le prono indique ses bookmakers, il est d'abord rapproché des paris de ces bookmakers, un par bookmaker (le
même prono joué sur Winamax et sur Unibet, ce sont deux paris). L'émoji dit où la cote est proposée, pas toujours
où le pari a été pris : sans pari chez ces bookmakers, un pari pris ailleurs est retenu, et signalé.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

from .modeles import categorie_marche, sans_accents

_ENTETE = re.compile(
    r"^(?:\d+\.\s*)?(?P<auteur>.+?)\s+[—–-]\s+"
    r"(?:(?P<date>\d{1,2}/\d{1,2}/\d{4})\s+(?P<h>\d{1,2}):(?P<m>\d{2})"
    r"|(?P<rel>Aujourd['’]hui|Hier)\s+à\s+(?P<h2>\d{1,2}):(?P<m2>\d{2}))\s*$",
    re.IGNORECASE,
)
_PRONO = re.compile(
    r"^(?P<corps>.*?)\s*@\s*(?P<cote>\d+(?:[.,]\d+)?)\s*\(\s*(?P<pct>\d+(?:[.,]\d+)?)\s*%\s*\)\s*(?P<fin>.*)$"
)
_MARCHE = re.compile(r"\b(?:T|Top)\s?(\d{1,2})\b", re.IGNORECASE)
_MARCHE_SEUL = re.compile(r"^(?:T|Top)\s?(\d{1,2})$", re.IGNORECASE)
_VAINQUEUR = re.compile(r"\b(vainqueur|winner|win)\b", re.IGNORECASE)
_MENTION = re.compile(r"^@\S")
_REMBOURSE = re.compile("[\u26aa\u26ab]|rembours|void|annul", re.IGNORECASE)  # ⚪ ⚫
_EMOJI = re.compile(r":([A-Za-z0-9_]+?)(?:~\d+)?:")  # « :PMU~1: », « :Winamax: »
_GAGNE = re.compile("[\u2705\u2714]")  # ✅ ✔
_PERDU = re.compile("[\u274c\u2716]")  # ❌ ✖
BOOKMAKERS = {"pmu": "pmu", "winamax": "winamax", "wina": "winamax", "unibet": "unibet", "betclic": "betclic",
              "ps3838": "ps3838", "pinnacle": "ps3838",
              "bet365": "bet365", "b365": "bet365", "piwi": "piwi247", "piwi247": "piwi247", "olybet": "olybet", "bwin": "bwin", "netbet": "netbet", "orbitx": "orbitx", "orbit": "orbitx"}

FENETRE_AVANT = timedelta(days=14)  # pari pris jusqu'à 14 jours avant le message…
FENETRE_APRES = timedelta(days=2)   # … ou jusqu'à 2 jours après
ECART_COTE = 0.15                   # cotes à 15 % près : les bookmakers ne proposent pas tous la même


@dataclass
class Prono:
    nom: str
    marche: str  # « Vainqueur », « Top 3 », « Face-à-face »…
    cote: float
    pct: float  # mise en % de bankroll
    ligne: str
    auteur: str = ""
    date: datetime | None = None
    titre: str = ""  # « Vuelta », « CLM MONDIAUX »…
    adversaire: str = ""
    rembourse: bool = False
    resultat: str | None = None  # « gagne », « perdu », « annule » si le message le dit
    bookmakers: list[str] = field(default_factory=list)  # bookmakers suivis par l'appli
    autres_bookmakers: list[str] = field(default_factory=list)  # émojis de bookmakers inconnus de l'appli
    rapproches: list[dict] = field(default_factory=list, repr=False)

    @property
    def rapproche(self) -> dict | None:
        return self.rapproches[0] if self.rapproches else None


def reconnait(texte: str) -> bool:
    """Au moins deux lignes « … @cote (x%) » : un message de pronos, pas une page de bookmaker."""
    return sum(1 for l in texte.splitlines() if _PRONO.match(l.strip())) >= 2


def _num(texte: str) -> float:
    return float(texte.replace(",", "."))


def lire(texte: str, aujourd_hui: date | None = None) -> list[Prono]:
    aujourd_hui = aujourd_hui or date.today()
    pronos: list[Prono] = []
    auteur, quand, titre = "", None, ""
    nom = marche = ""
    for brute in texte.splitlines():
        ligne = brute.strip()
        if not ligne:
            nom = marche = ""
            continue
        e = _ENTETE.match(ligne)
        if e:
            auteur = e.group("auteur").strip()
            if e.group("date"):
                quand = datetime.strptime(f"{e.group('date')} {e.group('h')}:{e.group('m')}", "%d/%m/%Y %H:%M")
            else:
                jour = aujourd_hui - timedelta(days=0 if e.group("rel").lower().startswith("aujourd") else 1)
                quand = datetime(jour.year, jour.month, jour.day, int(e.group("h2")), int(e.group("m2")))
            titre = nom = marche = ""
            continue
        if _MENTION.match(ligne):
            continue
        m_seul = _MARCHE_SEUL.match(ligne)
        if m_seul:
            marche, nom = f"Top {int(m_seul.group(1))}", ""
            continue
        p = _PRONO.match(ligne)
        if not p:
            titre, nom, marche = ligne, "", ""  # un titre : la course
            continue
        corps = p.group("corps").strip()
        adversaire = ""
        if ">" in corps:
            gauche, _, droite = corps.partition(">")
            corps, adversaire = gauche.strip(), droite.strip()
        m = _MARCHE.search(corps)
        marche_ligne = f"Top {int(m.group(1))}" if m else ("Vainqueur" if _VAINQUEUR.search(corps) else "")
        corps = _VAINQUEUR.sub("", _MARCHE.sub("", corps)).strip(" -:")
        if corps:
            nom = corps
        if not nom:
            continue
        if adversaire:
            marche_prono = "Face-à-face"
        else:
            marche_prono = marche_ligne or marche or "Vainqueur"
        fin = p.group("fin")
        bookmakers, autres = [], []
        for emoji in _EMOJI.findall(fin):
            cle = next((v for k, v in BOOKMAKERS.items() if emoji.lower().startswith(k)), None)
            (bookmakers if cle else autres).append(cle or emoji)
        rembourse = bool(_REMBOURSE.search(_EMOJI.sub("", fin)))
        resultat = "annule" if rembourse else "gagne" if _GAGNE.search(fin) else "perdu" if _PERDU.search(fin) else None
        pronos.append(Prono(nom=nom, marche=marche_prono, cote=_num(p.group("cote")), pct=_num(p.group("pct")),
                            ligne=ligne, auteur=auteur, date=quand, titre=titre, adversaire=adversaire,
                            rembourse=rembourse, resultat=resultat, bookmakers=list(dict.fromkeys(bookmakers)),
                            autres_bookmakers=autres))
    return pronos


# --------------------------------------------------------------------------- #
# Rapprochement avec les paris enregistrés
# --------------------------------------------------------------------------- #
def _compact(texte: str) -> str:
    return re.sub(r"[^a-z0-9]", "", sans_accents(texte).lower())


def _mots(texte: str) -> list[str]:
    return [m for m in re.split(r"[^a-z0-9]+", sans_accents(texte).lower()) if m]


def nom_correspond(nom_prono: str, choix: str) -> bool:
    """« Soder » ↔ « Jakob Söderqvist », « De Bruyne » ↔ « Ramses Debruyne », « Mcnulty » ↔ « Brandon McNulty » :
    le nom du prono (au moins 3 lettres, sans espaces ni accents) commence à un mot du choix."""
    cible = _compact(nom_prono)
    if len(cible) < 3:
        return False
    mots = _mots(choix)
    return any("".join(mots[i:]).startswith(cible) for i in range(len(mots)))


def _categorie(marche: str) -> str:
    c = categorie_marche(marche)
    return "Top 3" if c == "Podium" else c


def _candidat(prono: Prono, pari: dict) -> float | None:
    """Un score (plus petit = meilleur) si le pari peut être ce prono, sinon None."""
    sels = pari["selections"]
    if len(sels) != 1 or pari["type"] not in ("simple",):
        return None
    s = sels[0]
    if not nom_correspond(prono.nom, s.get("choix") or ""):
        return None
    if _categorie(s.get("marche") or "") != prono.marche:
        return None
    if prono.adversaire and not nom_correspond(prono.adversaire, f"{s.get('marche', '')} {s.get('evenement', '')}"):
        return None
    ecart_temps = 0.0
    if prono.date is not None:
        delta = pari["date_pari"] - prono.date
        if delta < -FENETRE_AVANT or delta > FENETRE_APRES:
            return None
        ecart_temps = abs(delta.total_seconds()) / 86400
    cote = pari["cote"] or (pari["gains"] / pari["mise"] + (1 if pari.get("freebet") else 0)
                            if pari["etat"] == "gagne" and pari["gains"] else None)
    if cote:
        ecart = abs(cote - prono.cote) / prono.cote
        if ecart > ECART_COTE:
            return None
    else:
        ecart = 0.08  # cote inconnue (pari perdu chez Betclic) : accepté, mais moins sûr
        if prono.date is None or ecart_temps > 1.5:
            return None
    return ecart * 10 + ecart_temps


def rapprocher(pronos: list[Prono], paris: list[dict]) -> list[Prono]:
    """Associe à chaque prono ses meilleurs paris enregistrés : un par bookmaker indiqué (un seul s'il n'en indique
    pas), chaque pari au plus une fois. `paris` : des dicts avec
    bookmaker, reference, date_pari (datetime), type, etat, mise, gains, cote, selections (liste de dicts)."""
    couples = []
    for i, prono in enumerate(pronos):
        for j, pari in enumerate(paris):
            score = _candidat(prono, pari)
            if score is not None:
                couples.append((score, i, j))
    pris_p: set[tuple] = set()  # (prono, bookmaker) déjà servis : un pari par bookmaker indiqué
    pris_q: set[int] = set()
    indique = lambda i, j: paris[j]["bookmaker"] in pronos[i].bookmakers
    # 1. Chez les bookmakers indiqués par le prono, un pari par bookmaker.
    for _score, i, j in sorted(c for c in couples if indique(c[1], c[2])):
        cle = (i, paris[j]["bookmaker"])
        if cle in pris_p or j in pris_q:
            continue
        pronos[i].rapproches.append(paris[j])
        pris_p.add(cle)
        pris_q.add(j)
    # 2. Rien chez eux (ou aucun indiqué) : le meilleur pari pris ailleurs, un seul.
    for _score, i, j in sorted(c for c in couples if not indique(c[1], c[2])):
        if pronos[i].rapproches or j in pris_q:
            continue
        pronos[i].rapproches.append(paris[j])
        pris_q.add(j)
    for p in pronos:
        p.rapproches.sort(key=lambda x: p.bookmakers.index(x["bookmaker"]) if x["bookmaker"] in p.bookmakers else 0)
    return pronos
