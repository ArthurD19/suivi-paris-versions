"""Deviner le sport d'un pari quand le bookmaker ne l'affiche pas (cas de Betclic).

Règles simples et lisibles, appliquées dans l'ordre. Ce qui n'est pas reconnu devient « Autre » :
le sport se corrige ensuite à la main dans l'écran « Mes paris », et la correction est conservée.
"""
from __future__ import annotations

import re

from .modeles import categorie_marche, sans_accents

SPORTS = [
    "Cyclisme",
    "Tennis",
    "Tennis de table",
    "Football",
    "Basketball",
    "Moto",
    "Formule 1",
    "Athlétisme",
    "Hockey sur glace",
    "Rugby",
    "Handball",
    "Volley-ball",
    "Football américain",
    "Biathlon",
    "Ski alpin",
    "Ski de fond",
    "Ski",
    "Sports d'hiver",
    "Golf",
    "MMA",
    "Boxe",
    "Rallye",
    "Autre",
]

# Grandes familles, pour ne pas aligner quinze sports dans les filtres. Un sport absent d'ici (« Badminton »,
# « Autre »…) va dans « Autres sports ».
FAMILLES = [
    ("Cyclisme", ["Cyclisme"]),
    ("Sports collectifs", ["Football", "Basketball", "Rugby", "Handball", "Hockey sur glace", "Volley-ball",
                           "Football américain", "Baseball"]),
    ("Raquettes", ["Tennis", "Tennis de table", "Badminton", "Squash", "Padel"]),
    ("Sports mécaniques", ["Formule 1", "Moto", "Nascar", "Rallye"]),
    ("Sports d'hiver", ["Biathlon", "Ski alpin", "Ski de fond", "Ski", "Sports d'hiver"]),
    ("Combat", ["MMA", "Boxe", "Judo"]),
    ("Combinés", ["Combiné", "Multi-sports"]),
]
AUTRES_SPORTS = "Autres sports"
_FAMILLE_DE = {sport: nom for nom, sports in FAMILLES for sport in sports}


def famille(sport: str) -> str:
    return _FAMILLE_DE.get(sport, AUTRES_SPORTS)


# Libellés Winamax -> libellés communs
ALIAS = {
    "basket": "Basketball",
    "basket-ball": "Basketball",
    "foot": "Football",
    "foot us": "Football américain",
    "hockey/glace": "Hockey sur glace",
    "formula 1": "Formule 1",
    "f1": "Formule 1",
    "formule1": "Formule 1",
    "motogp": "Moto",
    "moto gp": "Moto",
    "athletisme": "Athlétisme",
    "hockey": "Hockey sur glace",
    # Libellés Unibet (« Compétition de cycling »…)
    "cycling": "Cyclisme",
    "football": "Football",
    "tennis": "Tennis",
    "basketball": "Basketball",
    "athletics": "Athlétisme",
    "rugby": "Rugby",
    "rugby13": "Rugby",
    "rugby league": "Rugby",
    "moto": "Moto",
    "golf": "Golf",
    "ski": "Ski",
    "biathlon": "Biathlon",
    "ski alpin": "Ski alpin",
    "alpine skiing": "Ski alpin",
    "alpine-skiing": "Ski alpin",
    "ski de fond": "Ski de fond",
    "cross-country skiing": "Ski de fond",
    "cross-country": "Ski de fond",
    "saut a ski": "Ski",
    "volley-ball": "Volley-ball",
    "volleyball": "Volley-ball",
    "volley": "Volley-ball",
    "beach volley": "Volley-ball",
    "beach-volley": "Volley-ball",
    "boxe": "Boxe",
    "boxing": "Boxe",
    "football americain": "Football américain",
    "american football": "Football américain",
    "american-football": "Football américain",
    "nfl": "Football américain",
    "soccer": "Football",
    "table-tennis": "Tennis de table",
    "ice-hockey": "Hockey sur glace",
    "handball": "Handball",
    "mma": "MMA",
    "ufc/mma": "MMA",
    "curling": "Sports d'hiver",
    "formula-1": "Formule 1",
    "motorsport": "Moto",
}


def normaliser_sport(nom: str, evenement: str = "") -> str:
    """Le libellé commun d'un sport donné par le bookmaker. « Ski » tout court est précisé (biathlon, alpin, fond)
    quand l'événement le dit."""
    cle = sans_accents(nom).lower().strip()
    sport = ALIAS.get(cle, nom.strip())
    return preciser_ski(evenement) or sport if sport == "Ski" else sport


_BIATHLON = re.compile(r"\b(biathlon|ibu|hochfilzen|oberhof|ruhpolding|anterselva|antholz|ostersund|kontiolahti|lenzerheide"
                       r"|nove mesto|pokljuka|grand-bornand|7[.,]5 ?km|12[.,]5 ?km)\b")
_SKI_ALPIN = re.compile(r"\b(ski alpin|alpine|slalom|geant|descente|downhill|super ?-?g|combine alpin|kitzbuhel|wengen"
                        r"|val d'isere|val gardena|adelboden|schladming|solden|lake louise|beaver creek|kranjska gora"
                        r"|bormio|crans-montana|garmisch|killington|saalbach|courchevel)\b")
_SKI_FOND = re.compile(r"\b(ski de fond|cross-country|skiathlon|tour de ski|style libre|style classique|classique"
                       r"|libre|classic|free|ruka|davos|falun|val di fiemme|toblach|dobbiaco)\b")


def preciser_ski(texte: str) -> str | None:
    """Biathlon, ski alpin ou ski de fond, quand le texte (l'événement) le dit ; sinon None (le sport reste
    « Ski »)."""
    t = " " + sans_accents(texte).lower() + " "
    for regle, sport in ((_BIATHLON, "Biathlon"), (_SKI_ALPIN, "Ski alpin"), (_SKI_FOND, "Ski de fond")):
        if regle.search(t):
            return sport
    return None


_VOLLEY = re.compile(r"\b(volley|volleyball|volley-ball|superlega|plusliga|cev)\b")
_BOXE = re.compile(r"\b(boxe|boxing|wbc|wba|ibf|wbo|titre mondial des lourds)\b")
_FOOT_US = re.compile(r"\b(nfl|ncaaf|super bowl|touchdowns?|yards?|quarterback|field goal|football americain"
                      r"|chiefs|bills|eagles|cowboys|49ers|packers|ravens|bengals|steelers|browns|dolphins|patriots"
                      r"|texans|colts|jaguars|titans|broncos|raiders|chargers|commanders|bears|vikings|falcons"
                      r"|saints|buccaneers|seahawks)\b")


_TENNIS = re.compile(r"\b(aces?|tie-break|sets?|jeux(?! olympiques)|breaks?|wta|atp|itf|challenger|roland|wimbledon|open)\b")
# Jeux olympiques d'hiver (« Milan Cortina 2026 ») : un sport d'hiver, précisé si l'épreuve le dit.
_JO_HIVER = re.compile(r"\b(jeux olympiques d.hiver|olympiques d.hiver|winter olympics|milan cortina)\b")
# Ski de fond : une distance ou un sprint avec le style (« 50km (C) Mass Start », « Sprint Féminin, Drammen (C) »).
_FOND_STYLE = re.compile(r"(\b\d+ ?km\b|\bsprint\b|\bmass start\b|\bskiathlon\b|\brelais\b).*\((c|f|l)\)"
                         r"|\((c|f|l)\).*(\b\d+ ?km\b|\bsprint\b|\bmass start\b)|\bdrammen\b")
# « Vainqueur du classement par points » est un classement cycliste, pas des points de basket.
_BASKET = re.compile(r"(?<!classement par )\b(points?|pts|passes decisives|rebonds|paniers?|interceptions)\b")
_FOOT = re.compile(r"\b(buteur|buts?|passeur|penalty|corners?|cartons?|mi-temps|clean sheet)\b")
# « Lausanne HC », « HC Ajoie », « HK Nitra », ligues de hockey.
_HOCKEY = re.compile(r"\b(hc|hk|nhl|khl|shl|ahl|liiga|extraliga|hockey|national league)\b")
# « Coupe du Monde 2026/27 » : une saison sur deux ans, celle des sports d'hiver, pas le Mondial de football.
_FOOT_COMPETITION = re.compile(r"\b(uefa|ligue des champions|champions league|premier league|coupe du monde 20\d\d(?!/))\b")
_CYCLISME_EVT = re.compile(
    r"\b(etape|tour|classic|classique|coppa|giro|vuelta|contre-la-montre|course en ligne|cycliste|criterium"
    r"|gran fondo|gp cycliste|trofeo|memorial|omloop|kuurne|strade|liege|roubaix|lombardie|flandres?)\b"
)
_CATEGORIES_COURSE = {"Vainqueur", "Podium", "Face-à-face", "Classements annexes", "Double chance"}


def course_cycliste(evenement: str) -> bool:
    """L'événement nomme-t-il une course cycliste (« Tour de Lombardie », « Étape 3 (…) ») ?"""
    return bool(_CYCLISME_EVT.search(" " + sans_accents(evenement).lower() + " "))


def deviner_sport(
    marche: str, choix: str, evenement: str, scores: list[int] | None = None, score_tiret: bool = False
) -> str:
    """`scores` : les nombres seuls lus sous l'événement (scores de sets, de quart-temps…), s'il y en a.
    `score_tiret` : un score affiché « 1 - 4 », typique du football."""
    ev = " " + sans_accents(evenement).lower() + " "
    tout = " " + sans_accents(f"{marche} {choix} {evenement}").lower() + " "
    categorie = categorie_marche(marche)

    if re.search(r"\bmoto(gp|2|3|e)?\b", ev):
        return "Moto"
    cycliste = bool(_CYCLISME_EVT.search(ev))
    if _FOND_STYLE.search(ev) and not cycliste:
        return "Ski de fond"
    if _JO_HIVER.search(ev):
        precis = preciser_ski(ev) if re.search(r"\b(slalom|descente|downhill|super ?-?g|geant|biathlon|ski)\b", ev) else None
        if precis:
            return precis
        if re.search(r"\b(skeleton|bob|luge|curling|short track|patinage|hockey)\b", ev):
            return "Hockey sur glace" if "hockey" in ev else "Sports d'hiver"
        return "Sports d'hiver"
    if not cycliste and (_BIATHLON.search(ev) or _SKI_ALPIN.search(ev) or re.search(r"\bdownhill\b", ev)):
        return preciser_ski(ev) or "Ski alpin"
    if re.search(r"\b(snowboard|slalom|descente|super g|biathlon|ski|ibu)\b", ev):
        return preciser_ski(ev) or "Ski"
    if _VOLLEY.search(tout):
        return "Volley-ball"
    if _BOXE.search(tout):
        return "Boxe"
    if _FOOT_US.search(tout):
        return "Football américain"
    if re.search(r"\b(skeleton|monobob|bobsleigh|bob|luge|curling|short track|patinage|vitesse - \d+m)\b", ev):
        return "Sports d'hiver"
    if "marathon" in tout or "athle" in tout or re.match(r"^\s*\d{3,5} ?m\b", ev):  # « 800m F. (Birmingham) »
        return "Athlétisme"
    if re.search(r"\b(rallye|wrc|dakar)\b", ev):
        return "Rallye"
    if _FOOT_COMPETITION.search(ev):
        return "Football"
    # « GP de Monaco », « Course : GP de Grande-Bretagne », « Sprint : GP d'Italie »
    if re.match(r"^\s*(?:(?:course|sprint|qualifications?)\s*:\s*)?gp (de |d'|du )", ev) and "cycliste" not in ev:
        return "Formule 1"
    if "formule 1" in tout or re.search(r"\bf1\b", tout):
        return "Formule 1"
    if _HOCKEY.search(ev) and not (scores and max(scores) > 15):  # « HC Vardar 31 - 28 » : du handball
        return "Hockey sur glace"
    if _TENNIS.search(tout):
        return "Tennis"
    if _BASKET.search(tout):
        return "Basketball"
    if _FOOT.search(tout):
        return "Football"
    if score_tiret:
        return "Football"
    if scores:
        if max(scores) > 40:
            return "Basketball"
        if max(scores) <= 7:
            return "Tennis"
    if _CYCLISME_EVT.search(ev):
        return "Cyclisme"
    if re.search(r"\b20\d\d/\d\d\b", ev):
        # Une saison à cheval sur deux ans (« Classement Général 2026/27 ») : sport d'hiver, championnat… pas une
        # course cycliste, dont la saison tient dans l'année. Sans autre indice, le sport reste à préciser.
        return "Autre"
    # « Vainqueur 1 2 », « 1X2 » : le vainqueur d'un match (« Danemark (F) - Japon (F) »), pas d'une course.
    match = bool(re.search(r"\b1 ?x? ?2\b", sans_accents(marche).lower()))
    if not scores and not match and (categorie in _CATEGORIES_COURSE or categorie.startswith("Top ")):
        # Une course sans score affiché, avec un marché de classement : sur ce profil, c'est du vélo.
        return "Cyclisme"
    return "Autre"
