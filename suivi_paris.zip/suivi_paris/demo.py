"""Données de démonstration : des paris inventés, pour essayer l'application sans son propre historique."""
from __future__ import annotations

import random
from datetime import datetime, timedelta

from . import stockage
from .modeles import ANNULE, COMBINE, EN_COURS, GAGNE, PERDU, SIMPLE, Pari, Selection

PRENOMS = ["Léo", "Hugo", "Malo", "Noé", "Enzo", "Tom", "Axel", "Jules", "Luca", "Nils", "Arno", "Rémi"]
NOMS = ["Perrin", "Vasseur", "Kerjean", "Dumont", "Leroux", "Tanguy", "Morvan", "Garnier", "Bodin", "Rivière"]

SPORTS = {
    "Cyclisme": (0.50, ["Vainqueur", "Top 3", "Top 10", "Podium", "Face-à-face"],
                 ["Tour des Collines 2026", "Classique du Littoral 2026", "Grand Prix des Monts 2026",
                  "Tour de l'Ouest 2026 – Étape 3", "Tour de l'Ouest 2026 – Étape 5"]),
    "Tennis": (0.15, ["Vainqueur du match", "Nombre total d'aces dans le match", "Tie-break dans le match"],
               ["Joueur A / Joueur B", "Joueuse C / Joueuse D"]),
    "Basketball": (0.12, ["Nombre de points du joueur (paliers)", "Nombre de passes décisives du joueur (paliers)"],
                   ["Les Requins / Les Aigles", "Les Ours / Les Loups"]),
    "Moto": (0.08, ["Vainqueur de la Course", "Podium de la Course", "Face-à-face (course)"],
             ["GP des Lacs MotoGP", "GP des Lacs MotoGP - Sprint"]),
    "Football": (0.08, ["Buteur", "Boost - 10€ max"], ["FC Rivière / AS Plateau", "Olympique Nord / Stade Sud"]),
    "Athlétisme": (0.04, ["Vainqueur Compétition"], ["Marathon de la Côte 2026"]),
    "Formule 1": (0.03, ["Top 10", "Face à face Course"], ["GP des Dunes"]),
}


def generer(n: int = 260, graine: int = 7) -> list[Pari]:
    rnd = random.Random(graine)
    sports, poids = list(SPORTS), [v[0] for v in SPORTS.values()]
    debut = datetime(2026, 6, 1, 9, 0)
    paris = []
    for i in range(n):
        date_evt = debut + timedelta(days=rnd.uniform(0, 135), hours=rnd.randint(0, 10))
        date_pari = date_evt - timedelta(hours=rnd.choice([0.3, 2, 5, 14, 30, 90, 240]))
        bookmaker = rnd.choice(["betclic", "betclic", "betclic", "winamax", "winamax"])
        mise = rnd.choice([5, 10, 10, 20, 25, 25, 50, 50, 75, 100, 150])
        if rnd.random() < 0.04:
            cote = round(rnd.uniform(2.5, 15), 2)
            etat = GAGNE if rnd.random() < 0.95 / cote else PERDU
            paris.append(Pari(bookmaker, f"DEMO{i:05d}", date_pari, COMBINE, etat, etat.capitalize(), mise,
                              round(mise * cote, 2) if etat == GAGNE else 0.0, nb_selections=rnd.randint(2, 5),
                              date_evenement=date_evt))
            continue
        sport = rnd.choices(sports, poids)[0]
        _, marches, evenements = SPORTS[sport]
        marche = rnd.choice(marches)
        cote = round(min(25, rnd.lognormvariate(0.9, 0.55) + 0.25), 2)
        avantage = 1.10 if sport == "Cyclisme" else 0.97  # un parieur meilleur en vélo qu'ailleurs
        r = rnd.random()
        etat = ANNULE if r < 0.03 else (GAGNE if r < 0.03 + avantage / cote else PERDU)
        gains = mise if etat == ANNULE else (round(mise * cote, 2) if etat == GAGNE else 0.0)
        if date_evt > debut + timedelta(days=131):  # les derniers jours : pas encore réglés
            etat, gains = EN_COURS, None
        choix = f"{rnd.choice(PRENOMS)} {rnd.choice(NOMS)}"
        paris.append(
            Pari(bookmaker, f"DEMO{i:05d}", date_pari, SIMPLE, etat, etat.replace("_", " ").capitalize(), mise, gains,
                 cote_boostee="Boost" in marche, date_evenement=date_evt,
                 selections=[Selection(sport, rnd.choice(evenements), marche, choix)])
        )
    return paris


COMPTES = [("betclic", "Lucie"), ("betclic", "Hugo"), ("winamax", "Lucie"), ("winamax", "Malo")]


def remplir(cx) -> None:
    """Crée les comptes de démonstration et y répartit les paris inventés."""
    rnd = random.Random(3)
    ids = {cle: stockage.creer_compte(cx, *cle) for cle in COMPTES}
    par_compte: dict[tuple, list[Pari]] = {cle: [] for cle in COMPTES}
    for p in generer():
        choix = [c for c in COMPTES if c[0] == p.bookmaker]
        par_compte[rnd.choices(choix, weights=[3, 1][: len(choix)])[0]].append(p)
    for cle, paris in par_compte.items():
        stockage.enregistrer(cx, paris, cle[0], ids[cle])
