"""Synchronisation chiffrée entre l'ordinateur et l'iPhone, par un « gist » secret du compte GitHub de l'utilisateur.

Le gist contient deux fichiers : la base de l'ordinateur et celle de l'iPhone, chacune compressée puis chiffrée
(AES-256-GCM). La clé n'existe que sur l'ordinateur et le téléphone (passée une fois par le code de liaison) :
GitHub ne voit que des données illisibles. Chaque appareil écrit son fichier quand sa base change, lit celui de
l'autre quand il change, et l'ajoute à sa base (stockage.fusionner : rien n'est perdu ni doublé). Le même format est
lu et écrit par l'appli iPhone (mobile/mobile.js, avec WebCrypto).

Le jeton GitHub (droit « gist » seulement), le numéro du gist et la clé sont dans reglages.json, à côté de la base.
"""
from __future__ import annotations

import base64
import gzip
import hashlib
import json
import os
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime

from . import reglages, stockage

API = "https://api.github.com"
FICHIER_PC = "suivi-paris-pc.bin"
FICHIER_IPHONE = "suivi-paris-iphone.bin"
FICHIER_BOITE = "suivi-paris-boite.bin"  # les pages lues par l'extension sans appli joignable (extension/boite.js)
FICHIER_COMPTES = "suivi-paris-comptes.bin"  # la liste des comptes, pour que l'extension sans appli demande le bon
ROUTES_BOITE = {"page": "/api/extension/importer", "solde": "/api/extension/solde", "mouvements": "/api/extension/mouvements"}
FICHIER_ACCUSES = "suivi-paris-accuses.bin"  # ce que l'appli a fait de chaque page de la boîte, lu par l'extension
MAX_ACCUSES = 60
GARDER = {"choisir_compte", "aucun_compte"}  # pages laissées dans la boîte : le compte n'est pas encore connu
PERIODE = 90  # secondes entre deux regards sur le gist, quand rien ne change ici


class ErreurSynchro(Exception):
    pass


def chiffrer(cle: bytes, donnees: bytes) -> str:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    nonce = os.urandom(12)
    return base64.b64encode(nonce + AESGCM(cle).encrypt(nonce, gzip.compress(donnees), None)).decode()


def dechiffrer(cle: bytes, texte: str) -> bytes:
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    brut = base64.b64decode(texte)
    try:
        return gzip.decompress(AESGCM(cle).decrypt(brut[:12], brut[12:], None))
    except InvalidTag:
        raise ErreurSynchro("Données illisibles : la clé ne correspond pas (relie à nouveau l'iPhone).") from None


def _api(jeton: str, methode: str, chemin: str, corps: dict | None = None) -> dict:
    requete = urllib.request.Request(
        chemin if chemin.startswith("https://") else API + chemin,
        data=json.dumps(corps).encode() if corps is not None else None, method=methode,
        headers={"Authorization": f"Bearer {jeton}", "Accept": "application/vnd.github+json",
                 "User-Agent": "Suivi-Paris", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(requete, timeout=60) as r:
            texte = r.read()
    except urllib.error.HTTPError as exc:
        if exc.code == 403 and ("rate limit" in exc.read().decode(errors="replace").lower()
                                or exc.headers.get("x-ratelimit-remaining") == "0"):
            raise ErreurSynchro("GitHub limite les synchronisations pour l'instant : nouvel essai plus tard.") from None
        if exc.code in (401, 403):
            raise ErreurSynchro("GitHub refuse le jeton (expiré, supprimé, ou sans le droit « gist »).") from None
        if exc.code == 404:
            raise ErreurSynchro("Le gist de synchronisation n'existe plus : désactive puis réactive.") from None
        raise ErreurSynchro(f"GitHub a répondu {exc.code}.") from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise ErreurSynchro("Pas de connexion à GitHub pour l'instant.") from None
    return json.loads(texte or b"{}")


def code_liaison(cfg: dict) -> str:
    """Ce que l'iPhone doit connaître : le gist, le jeton, la clé. À ne donner qu'à son propre téléphone."""
    brut = json.dumps({"g": cfg["gist"], "t": cfg["jeton"], "k": cfg["cle"]}, separators=(",", ":")).encode()
    return "SP1-" + base64.urlsafe_b64encode(brut).decode().rstrip("=")


class Synchro:
    """Côté ordinateur : un fil qui envoie la base quand elle change et récupère celle de l'iPhone."""

    def __init__(self, app):
        self.app = app
        self.signal = threading.Event()
        self.fil: threading.Thread | None = None
        self.erreur: str | None = None

    # ---------------------------------------------------------------- réglages
    @staticmethod
    def config() -> dict:
        return reglages.lire().get("synchro") or {}

    @staticmethod
    def _garder(**valeurs) -> dict:
        cfg = Synchro.config() | valeurs
        reglages.ecrire(synchro=cfg)
        return cfg

    def etat(self) -> dict:
        cfg = self.config()
        actif = bool(cfg.get("gist"))
        code = code_liaison(cfg) if actif else None
        qr = None
        if code:
            try:
                import segno

                qr = segno.make(code, error="l").svg_inline(scale=4, dark="#0B1020", light="#ffffff")
            except Exception:  # noqa: BLE001
                qr = None
        return {"actif": actif, "code": code, "qr": qr, "envoye_le": cfg.get("envoye_le"),
                "recu_le": cfg.get("recu_le"), "iphone_vu_le": cfg.get("iphone_vu_le"), "erreur": self.erreur,
                "possible": _cryptographie_presente()}

    def activer(self, jeton: str) -> dict:
        jeton = (jeton or "").strip()
        if not jeton:
            raise ErreurSynchro("Colle le jeton GitHub.")
        gist = _api(jeton, "POST", "/gists", {
            "description": "Suivi Paris : synchronisation chiffrée (illisible sans la clé de tes appareils)",
            "public": False, "files": {FICHIER_PC: {"content": "vide"}}})
        self._garder(jeton=jeton, gist=gist["id"], cle=base64.b64encode(os.urandom(32)).decode(),
                     empreinte_envoyee=None, iphone_version=None)
        self.erreur = None
        self.signaler()
        return self.etat()

    def desactiver(self) -> dict:
        cfg = self.config()
        if cfg.get("gist"):
            try:
                _api(cfg["jeton"], "DELETE", f"/gists/{cfg['gist']}")
            except ErreurSynchro:
                pass  # déjà supprimé, ou hors connexion : on oublie quand même
        reglages.ecrire(synchro={})
        return self.etat()

    # ---------------------------------------------------------------- travail
    def signaler(self) -> None:
        """La base vient de changer : envoyer bientôt."""
        self.signal.set()

    def demarrer(self) -> None:
        if self.fil is None:
            self.fil = threading.Thread(target=self._boucle, daemon=True)
            self.fil.start()

    def _boucle(self) -> None:
        time.sleep(3)
        while not self.app.arret.is_set():
            if self.config().get("gist"):
                try:
                    self.cycle()
                    self.erreur = None
                except ErreurSynchro as exc:
                    self.erreur = str(exc)
                except Exception as exc:  # noqa: BLE001
                    self.erreur = f"Synchronisation impossible : {exc}"
            self.signal.wait(PERIODE)
            self.signal.clear()
            time.sleep(5)  # plusieurs enregistrements d'affilée (extension) : un seul envoi

    def cycle(self) -> None:
        cfg = self.config()
        cle = base64.b64decode(cfg["cle"])
        maintenant = datetime.now().isoformat(timespec="seconds")
        g = _api(cfg["jeton"], "GET", f"/gists/{cfg['gist']}")
        # L'iPhone a écrit une nouvelle version de sa base : elle est ajoutée ici.
        f = (g.get("files") or {}).get(FICHIER_IPHONE)
        if f and f.get("raw_url") != cfg.get("iphone_version"):
            texte = f["content"] if not f.get("truncated") else _brut(f["raw_url"])
            octets = dechiffrer(cle, texte)
            with self.app.verrou:
                stockage.fusionner(self.app.cx, octets)
                self.app._donnees, self.app._tableaux = None, {}
            cfg = self._garder(iphone_version=f["raw_url"], recu_le=maintenant, iphone_vu_le=g.get("updated_at"))
        self.vider_boite(g, cle)
        # Puis la base d'ici, si elle a changé depuis le dernier envoi.
        with self.app.verrou:
            base = self.app.copie_base()
        empreinte = hashlib.sha256(base).hexdigest()
        if empreinte != cfg.get("empreinte_envoyee"):
            _api(cfg["jeton"], "PATCH", f"/gists/{cfg['gist']}", {"files": {FICHIER_PC: {"content": chiffrer(cle, base)}}})
            cfg = self._garder(empreinte_envoyee=empreinte, envoye_le=maintenant)
        # Et la liste des comptes (site, nom), lue par l'extension quand aucune appli ne lui répond.
        with self.app.verrou:
            comptes = [{"id": c["id"], "bookmaker": c["bookmaker"], "nom": c["nom"]} for c in stockage.lister_comptes(self.app.cx)]
        texte = json.dumps(comptes, sort_keys=True).encode()
        empreinte = hashlib.sha256(texte).hexdigest()
        if empreinte != cfg.get("empreinte_comptes"):
            _api(cfg["jeton"], "PATCH", f"/gists/{cfg['gist']}", {"files": {FICHIER_COMPTES: {"content": chiffrer(cle, texte)}}})
            self._garder(empreinte_comptes=empreinte)


    def vider_boite(self, g: dict, cle: bytes) -> int:
        """Les pages que l'extension a déposées (iPhone, ou appli fermée) : enregistrées ici, puis retirées de la
        boîte (sauf celles dont le compte reste à choisir)."""
        cfg = self.config()
        f = (g.get("files") or {}).get(FICHIER_BOITE)
        if not f or f.get("content") == "vide":
            return 0
        pages = json.loads(dechiffrer(cle, f["content"] if not f.get("truncated") else _brut(f["raw_url"])))
        traitees = set()
        accuses = []
        for p in pages:
            corps = {k: p.get(k) for k in ("texte", "bookmaker", "capture_le", "url", "compte_id", "compte_nom")}
            try:
                with self.app.verrou:
                    r = self.app.traiter("POST", ROUTES_BOITE.get(p.get("type") or "page", ROUTES_BOITE["page"]), {}, corps)
            except Exception:  # noqa: BLE001 — une page illisible ne bloque pas les autres
                r = {"statut": "erreur"}
            if r.get("statut") not in GARDER:
                traitees.add(p.get("id"))
                accuses.append(accuse(p, r))
        if traitees:
            # Relue juste avant d'écrire : l'extension a pu déposer entre-temps.
            g2 = _api(cfg["jeton"], "GET", f"/gists/{cfg['gist']}")
            f2 = (g2.get("files") or {}).get(FICHIER_BOITE) or {}
            actuelles = [] if f2.get("content") in (None, "vide") else json.loads(
                dechiffrer(cle, f2["content"] if not f2.get("truncated") else _brut(f2["raw_url"])))
            reste = [p for p in actuelles if p.get("id") not in traitees]
            contenu = chiffrer(cle, json.dumps(reste).encode()) if reste else "vide"
            fichiers = {FICHIER_BOITE: {"content": contenu}}
            try:  # les accusés : un souci de lecture ne doit pas bloquer la boîte
                f3 = (g2.get("files") or {}).get(FICHIER_ACCUSES) or {}
                anciens = [] if f3.get("content") in (None, "vide") else json.loads(
                    dechiffrer(cle, f3["content"] if not f3.get("truncated") else _brut(f3["raw_url"])))
                fichiers[FICHIER_ACCUSES] = {"content": chiffrer(cle, json.dumps((accuses + anciens)[:MAX_ACCUSES]).encode())}
            except Exception:  # noqa: BLE001, S110
                pass
            _api(cfg["jeton"], "PATCH", f"/gists/{cfg['gist']}", {"files": fichiers})
            with self.app.verrou:
                self.app._donnees, self.app._tableaux = None, {}
        return len(traitees)


def accuse(page: dict, r: dict) -> dict:
    """Ce que l'appli a fait d'une page de la boîte, pour la fenêtre de l'extension (sans le texte de la page)."""
    return {"id": page.get("id"), "type": page.get("type") or "page", "bookmaker": page.get("bookmaker"),
            "statut": r.get("statut"), "compte": r.get("compte"), "nouveaux": r.get("nouveaux") or 0,
            "mis_a_jour": r.get("mis_a_jour") or 0, "deja_connus": r.get("deja_connus") or 0, "solde": r.get("solde"),
            "details": (r.get("details") or [])[:25], "le": datetime.now().isoformat(timespec="seconds")}


def _brut(url: str) -> str:
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Suivi-Paris"}), timeout=60) as r:
        return r.read().decode()


def _cryptographie_presente() -> bool:
    try:
        import cryptography  # noqa: F401
    except ImportError:
        return False
    return True
