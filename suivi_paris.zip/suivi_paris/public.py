"""Suivi public : une page HTML autonome des seuls paris marqués « partagés », à envoyer à une communauté.

Pour chaque pari, la page montre quand il a été pris et quand il a été partagé, s'il l'a été avant d'être réglé,
et si son résultat vient du bookmaker ou a été modifié à la main (avec la valeur du bookmaker). Les données de la
page sont jointes en JSON, avec leur empreinte SHA-256 : publier l'empreinte en même temps que la page permet à
chacun de vérifier qu'elle n'a pas été retouchée ensuite. Ce n'est pas une certification par un tiers : la page
est produite à partir des données de l'utilisateur, et le dit.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from html import escape

import pandas as pd

from . import analyse, stockage
from .modeles import LIBELLES_TYPES
from .resume import _classe, _euros, _pct, _police, _sport

ETATS = {"gagne": "Gagné", "perdu": "Perdu", "en_cours": "En cours", "annule": "Remboursé", "cashout": "Cash-out"}


def _quand(iso) -> str:
    if not iso or pd.isna(iso):
        return "—"
    d = pd.Timestamp(iso)
    return d.strftime("%d/%m/%Y à %H:%M")


def _donnees(d: pd.DataFrame) -> list[dict]:
    """Ce qui est publié, sous une forme stable (pour l'empreinte)."""
    lignes = []
    for _, p in d.iterrows():
        valeurs = json.loads(p["valeurs_import"]) if isinstance(p.get("valeurs_import"), str) else None
        lignes.append({
            "bookmaker": p["bookmaker"], "reference": p["reference"],
            "pris_le": p["date_pari"].isoformat(), "partage_le": p["partage_le"],
            "etat_au_partage": p["etat_au_partage"] if isinstance(p["etat_au_partage"], str) else None, "type": p["type"], "nb_selections": int(p["nb_selections"]),
            "selections": [{k: s.get(k) for k in ("sport", "evenement", "marche", "choix", "cote")}
                           for s in json.loads(p["selections"] or "[]")],
            # La mise jouée (un freebet affiche sa mise offerte, mais n'a rien coûté : marqué à part).
            "mise": p.get("mise_jouee", p["mise"]), **({"freebet": True} if p.get("freebet") == 1 else {}),
            "cote": None if pd.isna(p["cote"]) else p["cote"], "etat": p["etat"],
            "gains": None if pd.isna(p["gains"]) else p["gains"],
            "modifie_a_la_main": bool(p["modifie_main"]), "valeurs_du_bookmaker": valeurs,
            "partage_source": p.get("partage_source") if isinstance(p.get("partage_source"), str) else None,
            "mise_conseillee_pct": None if pd.isna(p.get("partage_pct")) else p.get("partage_pct"),
        })
    return lignes


def _delai(debut: str, fin: str) -> str:
    minutes = round((pd.Timestamp(fin) - pd.Timestamp(debut)).total_seconds() / 60)
    if minutes < 60:
        return f"{minutes} min"
    if minutes < 48 * 60:
        return f"{minutes // 60} h {minutes % 60:02d}"
    return f"{minutes // (24 * 60)} jours"


def _nombre(x: float) -> str:
    return f"{x:.2f}".rstrip("0").rstrip(".").replace(".", ",")


def _pct_bk(montant, bankroll) -> str:
    if not bankroll or montant is None:
        return ""
    return f"{montant / bankroll * 100:.2f}".rstrip("0").rstrip(".").replace(".", ",") + " %"


def _ticket(p: dict, libelle_bk: str, bankroll: float | None = None) -> str:
    sels = p["selections"] or [{"sport": "", "choix": "Sélections non détaillées par le bookmaker",
                                "marche": "", "evenement": ""}]
    type_ = LIBELLES_TYPES.get(p["type"], p["type"])
    if p["type"] == "simple" and p["nb_selections"] > 1:
        type_ = f"{p['nb_selections']} simples"
    elif p["type"] != "simple":
        type_ += f" ({p['nb_selections']})"
    profit = None
    if p["etat"] in ("gagne", "perdu", "cashout"):
        profit = (p["gains"] or 0) - (0 if p.get("freebet") else p["mise"])
    elif p["etat"] == "annule":
        profit = 0.0
    source = p.get("partage_source") or ""
    if p["etat_au_partage"] == "en_cours":
        moment = '<span class="ok">Partagé avant le résultat</span>'
    elif p["etat_au_partage"] is None:
        # Partage relevé dans un message (Discord) sans preuve du moment du résultat : on dit ce qu'on sait.
        if p["partage_le"] and "date du message" not in source:
            moment = f'<span class="neutre">Partagé {_delai(p["pris_le"], p["partage_le"])} après la prise du pari</span>'
        else:
            moment = '<span class="neutre">Moment du partage non prouvé</span>'
    else:
        moment = '<span class="tard">Partagé après le résultat</span>'
    preuves = [
        moment,
        '<span class="tard">Résultat modifié à la main</span>' if p["modifie_a_la_main"]
        else '<span class="ok">Résultat lu chez le bookmaker</span>',
    ]
    if p["modifie_a_la_main"] and p["valeurs_du_bookmaker"]:
        v = p["valeurs_du_bookmaker"]
        preuves.append(f'<small>Le bookmaker indiquait : {escape(ETATS.get(v.get("etat"), str(v.get("etat"))))}'
                       f'{", gains " + _euros(v["gains"]) if v.get("gains") is not None else ""}</small>')
    lignes_sel = "".join(
        f'<div class="sel"><span>{_sport(s.get("sport") or "")[0]}</span><div><b>{escape(s.get("choix") or "")}</b>'
        f'<i>{escape(s.get("marche") or "")}</i><small>{escape(s.get("evenement") or "")}</small></div></div>'
        for s in sels)
    return f"""<article class="ticket etat-{escape(p['etat'])}">
      <header><b>{escape(libelle_bk)}</b><span>{escape(type_)}</span><em>{escape(ETATS.get(p['etat'], p['etat']))}</em></header>
      <div class="sels">{lignes_sel}</div>
      <div class="pied">
        <div><small>Mise{" (freebet)" if p.get("freebet") else ""}</small><b>{_euros(p['mise'])}</b>{f"<i class='pct'>{_pct_bk(p['mise'], bankroll)} de bankroll</i>" if bankroll else ""}</div>
        <div><small>Cote</small><b>{f"{p['cote']:.2f}".replace(".", ",") if p['cote'] else "—"}</b></div>
        <div><small>Profit</small><b class="{_classe(profit)}">{_euros(profit, signe=True) if profit is not None else "en cours"}</b></div>
      </div>
      <details class="infos"><summary aria-label="Détails du bet">+</summary>
        <p>Pris le {_quand(p['pris_le'])}<br>Partagé le {_quand(p['partage_le'])}{f" ({escape(source)})" if source else ""}<br>Réf. {escape(p['reference'])}{f"<br>Mise conseillée : {_nombre(p['mise_conseillee_pct'])} % de bankroll" if p.get('mise_conseillee_pct') else ""}</p>
        <div class="preuves">{''.join(preuves)}</div></details>
    </article>"""


def generer(cx, titre: str = "Suivi public", maintenant: datetime | None = None) -> str:
    maintenant = maintenant or datetime.now()
    df = analyse.charger(cx)
    d = analyse.filtrer(df, partages=True) if not df.empty else df
    d = d.sort_values("date_pari", ascending=False) if not d.empty else d
    donnees = _donnees(d) if not d.empty else []
    # « < » échappé dans le JSON même : le bloc joint à la page est, octet pour octet, ce qui est haché.
    canon = json.dumps(donnees, ensure_ascii=False, sort_keys=True, separators=(",", ":")).replace("<", "\\u003c")
    empreinte = hashlib.sha256(canon.encode("utf-8")).hexdigest()
    k = analyse.indicateurs(d) if not d.empty else None
    bk = stockage.bankroll(cx)
    libelles = dict(zip(d["bookmaker"], d["bookmaker_libelle"], strict=False)) if not d.empty else {}
    n_avant = sum(1 for p in donnees if p["etat_au_partage"] == "en_cours")
    n_main = sum(1 for p in donnees if p["modifie_a_la_main"])

    chiffres = "" if k is None else f"""<div class="chiffres">
      <div class="grand"><small>Profit</small><b class="{_classe(k['profit'])}">{_euros(k['profit'], signe=True)}</b>{f"<span class='bk'>{'+' if k['profit'] > 0 else ''}{_pct_bk(k['profit'], bk)} de bankroll</span>" if bk else ""}</div>
      <div><small>ROI</small><b>{_pct(k['roi'])}</b></div>
      <div><small>Réussite</small><b>{_pct(k['reussite'], signe=False)}</b></div>
      <div><small>Réglés</small><b>{k['n']}</b></div>
      <div><small>En cours</small><b>{k['n_en_cours']}</b></div>
      <div><small>Misé</small><b>{_euros(k['mise'], rond=True)}</b></div>
    </div>
    <p class="note">{len(donnees)} bets partagés, dont {n_avant} avant leur résultat. {n_main} résultat{"s" if n_main > 1 else ""} modifié{"s" if n_main > 1 else ""} à la main, signalé{"s" if n_main > 1 else ""} sur le ticket.</p>"""
    tickets = "".join(_ticket(p, libelles.get(p["bookmaker"], p["bookmaker"]), bk) for p in donnees) \
        or '<p class="note">Aucun bet partagé pour l\'instant.</p>'

    return f"""<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{escape(titre)}</title>
<style>
@font-face {{ font-family: "Archivo"; src: {_police("archivo-latin-wdth-italic.woff2")}; font-weight: 100 900; font-stretch: 62% 125%; font-style: italic; }}
@font-face {{ font-family: "Manrope"; src: {_police("manrope-latin-wght-normal.woff2")}; font-weight: 200 800; }}
@font-face {{ font-family: "JetBrains Mono"; src: {_police("jetbrains-mono-latin-400-normal.woff2")}; font-weight: 400; }}
:root {{ --encre: #EEF1FA; --brume: #8C97B5; --fond: #090D1A; --carte: #111829; --carte-2: #0D1323; --trait: #232C45;
  --gain: #2FD38A; --perte: #FF5C73; --peloton: #3D69FF; --jaune: #FFC928; color-scheme: dark; }}
* {{ box-sizing: border-box; }}
body {{ margin: 0; background: radial-gradient(90% 60% at 100% 0%, rgba(36,80,245,.22), transparent 60%), var(--fond);
  color: var(--encre); font: 15px/1.45 Manrope, system-ui, sans-serif; min-height: 100vh; }}
main {{ max-width: 760px; margin: 0 auto; padding: 28px 16px 48px; }}
h1 {{ font-family: Archivo, sans-serif; font-style: italic; font-weight: 850; font-stretch: 118%; font-size: 34px; margin: 0;
  letter-spacing: -.015em; }}
h1::after {{ content: ""; display: block; width: 46px; height: 5px; margin-top: 8px; border-radius: 2px; background: var(--jaune);
  transform: skewX(-18deg); }}
.sous {{ color: var(--brume); margin: 10px 0 22px; font: 13px "JetBrains Mono", ui-monospace, monospace; }}
.gain {{ color: var(--gain); }} .perte {{ color: var(--perte); }}
.chiffres {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }}
.chiffres div {{ background: var(--carte); border: 1px solid var(--trait); border-radius: 16px; padding: 12px 14px; }}
.chiffres .grand {{ grid-column: span 3; background: linear-gradient(135deg, #1534C8, #2450F5 52%, #3D6BFF); border: 0; color: #fff; }}
.chiffres .grand .gain {{ color: #fff; }} .chiffres .grand .perte {{ color: #FFD0D7; }}
.chiffres small, .pied small {{ display: block; font-size: 12px; font-weight: 650; color: var(--brume); }}
.chiffres .grand small {{ color: rgba(255,255,255,.75); }}
.chiffres b, .pied b {{ font-family: Archivo, sans-serif; font-style: italic; font-weight: 800; font-stretch: 112%; font-size: 22px; }}
.chiffres .grand b {{ font-size: 40px; font-weight: 900; }}
.chiffres .grand .bk {{ display: block; color: rgba(255,255,255,.8); font-weight: 700; font-size: 13px; }}
.note {{ color: var(--brume); font-size: 13.5px; margin: 12px 0 22px; }}
.ticket {{ background: var(--carte); border: 1px solid var(--trait); border-radius: 18px; overflow: hidden; margin-bottom: 14px; }}
.ticket header {{ display: flex; gap: 10px; align-items: center; padding: 11px 16px; background: #182036; color: #fff; }}
.ticket header span {{ flex: 1; opacity: .8; font-weight: 600; }}
.ticket header em {{ font-style: normal; font-weight: 800; font-size: 12px; padding: 3px 10px; border-radius: 99px; background: #fff; color: #0E1324; }}
.etat-gagne header em {{ background: #DFF7EA; color: #0B7A48; }} .etat-perdu header em {{ background: #FFE1E6; color: #B0223B; }}
.etat-en_cours header em {{ background: #FFF1CC; color: #7A5600; }}
.sels {{ padding: 12px 16px 4px; }}
.sel {{ display: grid; grid-template-columns: 24px 1fr; gap: 10px; padding-bottom: 10px; }}
.sel b {{ display: block; }} .sel i {{ display: block; font-style: normal; font-size: 13px; }} .sel small {{ color: var(--brume); font-size: 12.5px; }}
.pied {{ display: grid; grid-template-columns: repeat(3, 1fr); padding: 10px 16px; border-top: 2px dashed var(--trait); }}
.pied b {{ font-size: 18px; }}
.infos {{ position: relative; padding: 0 16px; background: var(--carte-2); font-size: 12.5px; color: var(--brume); }}
.infos summary {{ list-style: none; cursor: pointer; position: absolute; right: 12px; top: -38px; width: 26px; height: 26px;
  border-radius: 50%; background: #182036; color: var(--encre); font-weight: 800; font-size: 17px; line-height: 26px; text-align: center; }}
.infos summary::-webkit-details-marker {{ display: none; }}
.infos[open] summary {{ background: var(--peloton); color: #fff; }}
.infos p {{ margin: 0; padding-top: 10px; }}
.infos[open] {{ padding-bottom: 12px; }}
.preuves {{ display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; align-items: center; }}
.preuves span {{ font-weight: 800; font-size: 11.5px; padding: 2px 9px; border-radius: 99px; }}
.preuves .ok {{ background: rgba(47,211,138,.14); color: var(--gain); }} .preuves .tard {{ background: rgba(255,201,40,.14); color: #FFD866; }}
.preuves .neutre {{ background: rgba(140,151,181,.14); color: #A9B2CC; }}
.pied .pct {{ display: block; font-style: normal; font-size: 11.5px; color: var(--brume); font-family: "JetBrains Mono", monospace; }}
.verif {{ margin-top: 28px; padding: 16px; background: var(--carte); border: 1px solid var(--trait); border-radius: 16px; font-size: 13px; color: var(--brume); }}
.verif code {{ display: block; word-break: break-all; color: var(--encre); font: 12.5px "JetBrains Mono", monospace; margin: 6px 0; }}
</style></head>
<body><main>
  <h1>{escape(titre)}</h1>
  <p class="sous">Bets partagés, mis à jour le {maintenant:%d/%m/%Y à %H:%M}</p>
  {chiffres}
  {tickets}
  <section class="verif">
    <b>Comment lire cette page.</b> Chaque bet indique quand il a été pris et quand il a été partagé ; « partagé avant
    le résultat » veut dire qu'il était encore en cours au moment du partage. Un résultat modifié à la main est
    signalé, avec ce qu'affichait le bookmaker. Cette page est produite par l'appli Suivi Paris à partir des
    historiques du parieur : ce n'est pas une certification par un tiers.
    <br><br><b>Empreinte des données (SHA-256)</b>
    <code>{empreinte}</code>
    Publie cette empreinte en même temps que la page : les données sont jointes à la page (bloc
    « donnees-partagees »), et toute retouche ultérieure change l'empreinte.
  </section>
</main>
<script type="application/json" id="donnees-partagees">{canon}</script>
</body></html>"""
