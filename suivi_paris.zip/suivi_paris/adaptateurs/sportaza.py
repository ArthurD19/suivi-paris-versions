"""Adaptateur Sportaza (sportaza.com et ses adresses changeantes, « sportaza-5178.com »).

L'en-tête de chaque page donne le solde (« Solde réel », puis « 54,66 € » ou « 360,61 CHF ») et le nom du titulaire
du compte (juste avant « Dernière session »), qui reconnaît le compte quand il y en a plusieurs. Les dépôts et
retraits : Historique des transactions, filtre « Dépôt » et « Retraits » (voir mouvements.py).

Les paris (Sport → Mes paris, onglets « Ouvrir » et « Calculé ») sont dans des composants de page, que l'extension
lit (et le bouton « Copier le texte de la page ») :

    Tour d'Italie 2026 - Étape 19 - Top 3        événement - marché (une ligne par sélection)
    PERDU                                         état : GAGNÉ, PERDU, NUL…
    Cotes totales / 3.85
    Mise totale / CHF 34.00                       dans la monnaie du compte
    Gain total / CHF 1.67                         (rien si perdu)
    29/05 • 00:01                                 date du pari, sans l'année
    Numéro d'identification: 4997348004           la référence (clé anti-doublon)

La liste n'affiche pas le choix (le coureur, le joueur) ni la date de l'événement : un pari ouvert d'un clic (un à la
fois) les donne, entre l'état et « Cotes totales », pour chaque sélection :

    David Muñoz                                   choix
    3.00                                          cote de la sélection
    Grand Prix d'Italie 2026 - Course Moto3 - Top 3   (deux fois)
    31/05 • 11:00                                 date de l'événement

Un pari lu fermé ne remplace jamais le détail lu ouvert (`detail_partiel`). L'année d'une date est celle du jour de
la lecture, ou la précédente si la date tomberait dans le futur (l'événement : au plus tôt le jour du pari). Le sport
est deviné.
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

from ..modeles import (
    ANNULE,
    CASHOUT,
    COMBINE,
    EN_COURS,
    GAGNE,
    INCONNU,
    PERDU,
    SIMPLE,
    Pari,
    Selection,
    categorie_marche,
    sans_accents,
)
from ..sports import deviner_sport

NOM = "sportaza"
LIBELLE = "Sportaza"
CONSIGNE = (
    "Sur Sportaza : Sport → Mes paris, onglet « Calculé » (et « Ouvrir »). Les paris sont dans des composants que "
    "Ctrl+A ne copie pas : utilise l'extension, ou son bouton « Copier le texte de la page », puis colle ici."
)

# Le site parle français ou anglais selon le compte (« Cotes totales » / « Total odds »…) : les deux sont lus.
_ID = re.compile(r"^(?:Numéro d'identification|ID)\s*:\s*(\d{6,})$")
_DATE_ET_ID = re.compile(r"^(\d{2}/\d{2}\s*•\s*\d{1,2}:\d{2})\s+((?:Numéro d'identification|ID)\s*:.*)$")
_COTES = ("Cotes totales", "Total odds")
_MISE = ("Mise totale", "Total stake")
_GAIN = ("Gain total", "Total win", "Total Win", "Gain")
_DATE = re.compile(r"^(\d{2})/(\d{2})\s*•\s*(\d{1,2}):(\d{2})$")
_MONTANT = re.compile(r"^(?:CHF|EUR|€|£|\$)?\s*(\d[\d\s,]*(?:\.\d+)?)\s*(?:CHF|EUR|€|£|\$)?$")
_ETAT = re.compile(r"^(GAGNÉ|PERDU|NUL|REMBOURSÉ|ANNULÉ|CASH ?OUT|RETIRÉ|EN COURS|OUVERT|EN ATTENTE"
                   r"|WON|LOST|VOID|PUSH|REFUNDED|CANCELL?ED|CASHED ?OUT|OPEN|PENDING|HALF ?WON|HALF ?LOST)$",
                   re.IGNORECASE)
_SUITES_ONGLETS = (["Ouvrir", "Calculé", "Gagné", "Perdu", "Retirer"], ["Open", "Settled", "Won", "Lost", "Cashout"])
_ONGLETS = {"Ouvrir", "Calculé", "Gagné", "Perdu", "Retirer", "Open", "Settled", "Won", "Lost", "Cashout",
            "=== Composants de la page ==="}


def reconnait(texte: str) -> bool:
    return "sportaza" in texte.lower() and any(m in texte for m in (
        "Solde réel", "Numéro d'identification", "Total odds", "Real balance", "Real Balance"))


def identifiant(texte: str) -> str | None:
    """Le nom du titulaire, affiché dans le menu du compte juste avant « Dernière session »."""
    lignes = [l.strip() for l in texte.splitlines() if l.strip()]
    for i, l in enumerate(lignes):
        if l.startswith(("Dernière session", "Last session")) and i and re.fullmatch(r"[^\d€]{3,60}", lignes[i - 1]) \
                and lignes[i - 1] not in ("Historique des transactions", "Se déconnecter", "Transaction history",
                                          "Log out", "Logout"):
            return lignes[i - 1]
    return None


def _montant(brut: str) -> float | None:
    """« CHF 18.75 », « 1,234.50 », « 54,66 € » -> nombre."""
    m = _MONTANT.match(brut.strip())
    if not m:
        return None
    n = m.group(1).replace(" ", "")
    if "," in n and "." in n:
        n = n.replace(",", "")
    elif "," in n:
        n = n.replace(",", ".") if re.search(r",\d{1,2}$", n) else n.replace(",", "")
    return float(n)


def _etat(brut: str) -> str:
    e = sans_accents(brut).lower()
    if "cash" in e or e.startswith("retir"):
        return CASHOUT
    if e.startswith(("gagn", "won", "half won", "halfwon")):
        return GAGNE
    if e.startswith(("perd", "lost", "half lost", "halflost")):
        return PERDU
    if e.startswith(("nul", "rembours", "annul", "void", "push", "refund", "cancel")):
        return ANNULE
    if e in ("en cours", "ouvert", "en attente", "open", "pending"):
        return EN_COURS
    return INCONNU


def _selection(titre: str) -> Selection:
    """« Tour d'Italie 2026 - Étape 19 - Top 3 » : l'événement, puis le marché après le dernier « - »."""
    morceaux = [m.strip() for m in titre.split(" - ")]
    marche = morceaux[-1] if len(morceaux) > 1 else ""
    evenement = " - ".join(morceaux[:-1]) if len(morceaux) > 1 else titre
    etape = re.search(r"[ÉE]tape (\d+)", evenement)
    return Selection(deviner_sport(marche, "", evenement) or "Autre", evenement, marche, "", evenement,
                     int(etape.group(1)) if etape else None)


def _detail(lignes: list[str], date_pari: datetime) -> tuple[list[Selection], list[datetime]]:
    """Le détail d'un pari ouvert : par sélection, choix, cote, titre (deux fois), date de l'événement."""
    selections, jours, groupe = [], [], []
    for l in lignes:
        m = _DATE.match(l)
        if not m:
            groupe.append(l)
            continue
        jour, mois, h, mi = (int(x) for x in m.groups())
        quand = datetime(date_pari.year, mois, jour, h, mi)
        if quand < date_pari - timedelta(days=1):  # un événement de janvier pour un pari de décembre
            quand = quand.replace(year=quand.year + 1)
        jours.append(quand)
        if groupe:
            selections.append(_selection_detail(groupe))
        groupe = []
    if groupe:  # une sélection sans date d'événement (le site ne la donne pas toujours)
        selections.append(_selection_detail(groupe))
    return selections, jours


def _selection_detail(groupe: list[str]) -> Selection:
    """Choix, cote, puis l'événement et le marché : deux fois le même titre (« Grand Prix d'Italie 2026 - Course
    Moto3 - Top 3 »), ou l'événement (« A vs. B ») puis le marché."""
    choix = groupe[0]
    cote = _montant(groupe[1]) if len(groupe) > 1 and re.fullmatch(r"\d+(?:\.\d+)?", groupe[1]) else None
    reste = groupe[2 if cote is not None else 1:]
    # Un match : le marché, puis les deux joueurs (ou équipes) de part et d'autre du score (« Jeux handicap »,
    # « Zakharova, Anastasia », « 2:0 », « Sramkova, Rebecca »).
    k_score = next((k for k, l in enumerate(reste) if re.fullmatch(r"\d+\s*[:-]\s*\d+", l) and 0 < k < len(reste) - 1), None)
    if k_score is not None:
        marche = reste[0] if k_score > 1 else ""
        evenement = f"{reste[k_score - 1]} / {reste[k_score + 1]}"
        s = Selection(deviner_sport(marche, choix, evenement) or "Autre", evenement, marche, choix, "")
    elif len(reste) >= 2 and reste[0] != reste[1]:
        evenement, marche = reste[0], reste[1]
        etape = re.search(r"[ÉE]tape (\d+)", evenement)
        s = Selection(deviner_sport(marche, choix, evenement) or "Autre", evenement, marche, choix, evenement,
                      int(etape.group(1)) if etape else None)
    else:
        s = _selection(reste[0]) if reste else Selection("Autre", "", "", "")
        s.choix = choix
        if not s.marche and re.search(r"\svs\.?\s", s.evenement):
            # « Haaser, Raphael vs. McGrath, Atle Lie » sans autre marché : un face-à-face.
            s.evenement, s.marche = _vs(s.evenement), "Face-à-face"
        # Le sport : d'après l'événement (un « face-à-face » seul ferait penser au vélo à tort).
        s.sport = deviner_sport("" if s.marche == "Face-à-face" and " - " not in s.evenement else s.marche, choix,
                                s.evenement) or "Autre"
    s.cote = cote
    return s


def _vs(titre: str) -> str:
    """« Anastasia Zakharova vs. Rebecca Sramkova » -> « Anastasia Zakharova / Rebecca Sramkova »."""
    return re.sub(r"\s+vs\.?\s+", " / ", titre)


class _Annees:
    """L'année des paris, que la liste ne donne pas. La liste va du plus récent au plus ancien : le premier pari est de
    l'année de la lecture (la précédente si sa date tomberait dans le futur), et chaque fois qu'un pari a une date
    plus tardive dans l'année que le précédent, on est passé à l'année d'avant. Un titre daté (« Paris - Tours 2025 »)
    plus ancien que l'année ainsi trouvée la corrige (une année sans pari ne se voit pas autrement)."""

    def __init__(self, aujourd_hui: date):
        self.aujourd_hui = aujourd_hui
        self.annee: int | None = None
        self.precedent: tuple[int, int, int, int] | None = None

    def date(self, m: re.Match, titres: list[str]) -> datetime:
        jour, mois, h, mi = (int(x) for x in m.groups())
        cle = (mois, jour, h, mi)
        if self.annee is None:
            self.annee = self.aujourd_hui.year
            if (mois, jour) > (self.aujourd_hui.month, self.aujourd_hui.day):
                self.annee -= 1
        elif self.precedent is not None and cle > self.precedent:
            self.annee -= 1
        annees = [int(a) for t in titres for a in re.findall(r"\b(20\d{2})\b(?![/-]\d)", t)]
        # Seulement à partir de mars : en janvier, un pari peut porter sur une épreuve nommée de l'année d'avant.
        if annees and mois >= 3 and self.annee - 2 <= min(annees) < self.annee:
            self.annee = min(annees)
        self.precedent = cle
        return datetime(self.annee, mois, jour, h, mi)


def parser(texte: str, aujourd_hui: date | None = None) -> tuple[list[Pari], list[str]]:
    aujourd_hui = aujourd_hui or date.today()
    lignes = []
    for brute in texte.splitlines():
        l = brute.strip()
        m = _DATE_ET_ID.match(l)  # « 31/05 • 10:40 ID: 5005715455 » sur une seule ligne
        lignes += [m.group(1), m.group(2)] if m else ([l] if l else [])
    paris: list[Pari] = []
    avertissements: list[str] = []
    fin_precedent = None
    annees = _Annees(aujourd_hui)
    for i, ligne in enumerate(lignes):
        ident = _ID.match(ligne)
        if not ident:
            continue
        reference = ident.group(1)
        debut_zone = fin_precedent if fin_precedent is not None else 0
        fin_precedent = i + 1
        zone = lignes[debut_zone:i]
        k_cotes = max((k for k, l in enumerate(zone) if l in _COTES), default=None)
        date_m = _DATE.match(zone[-1]) if zone else None
        if k_cotes is None or not date_m:
            avertissements.append(f"Sportaza {reference} : pari illisible, ignoré.")
            continue
        suite = zone[k_cotes:]

        def valeur(libelles: tuple[str, ...], suite: list[str] = suite) -> str | None:
            return next((suite[k + 1] for k in range(len(suite) - 1) if suite[k].startswith(libelles)), None)

        cote = _montant(valeur(_COTES) or "")
        mise = _montant(valeur(_MISE) or "")
        gain_brut = valeur(_GAIN)
        gains_lus = _montant(gain_brut) if gain_brut and not _DATE.match(gain_brut) else None
        if mise is None:
            avertissements.append(f"Sportaza {reference} : mise illisible, ignoré.")
            continue
        # Avant « Cotes totales » : les sélections (titres), l'état, puis le détail si le pari est ouvert. Le premier
        # pari suit les onglets (« Open, Settled, Won, Lost, Cashout ») : « Lost » y est un onglet, pas un état.
        avant = zone[:k_cotes]
        if debut_zone == 0:
            fin_onglets = max((k + len(o) for o in _SUITES_ONGLETS for k in range(len(avant))
                               if avant[k:k + len(o)] == o), default=None)
            if fin_onglets is not None:
                avant = avant[fin_onglets:]
        k_etat = next((k for k, l in enumerate(avant) if _ETAT.match(l)), None)
        etat_brut = avant[k_etat] if k_etat is not None else ""
        detail = avant[k_etat + 1:] if k_etat is not None else []
        avant = avant[:k_etat] if k_etat is not None else avant
        if debut_zone == 0:  # le premier pari : après les onglets (« Ouvrir », « Calculé »…)
            onglets = [k for k, l in enumerate(avant) if l in _ONGLETS]
            avant = avant[onglets[-1] + 1:] if onglets else avant[-1:]
        titres = [l for l in avant if l not in _ONGLETS]
        etat = _etat(etat_brut) if etat_brut else EN_COURS
        date_pari = annees.date(date_m, titres + [l for l in detail if " - " in l])
        if etat == PERDU:
            gains = 0.0
        elif etat == ANNULE:
            gains = gains_lus if gains_lus is not None else mise
        elif etat in (GAGNE, CASHOUT):
            gains = gains_lus
            if gains is None:
                avertissements.append(f"Sportaza {reference} : gain introuvable.")
        else:
            gains = None
        if etat == INCONNU:
            avertissements.append(f"Sportaza {reference} : état « {etat_brut} » non reconnu.")
        # « Combiné » (lu fermé) : ni le nombre ni le détail des sélections ; un combiné ouvert les donne.
        combine_ferme = not detail and len(titres) == 1 and re.match(r"^Combin[ée]", titres[0])
        if combine_ferme:
            selections, jours = [], []
        else:
            selections, jours = _detail(detail, date_pari) if detail else ([_selection(t) for t in titres], [])
            if not selections:
                selections = [_selection(t) for t in titres]
        # Un match (« A vs. B ») : le titre est l'événement, plus lisible que les noms du détail (« Nom, Prénom »).
        if len(selections) == 1 and len(titres) == 1 and re.search(r"\svs\.?\s", titres[0]) and " - " not in titres[0]:
            selections[0].evenement = _vs(titres[0])
        # « Bonus part 100% » : la mise vient du solde de bonus (le site le dit sous les gains).
        bonus = next((zone[k + 1] for k in range(len(zone) - 1) if zone[k] in ("Bonus part", "Part de bonus")), None)
        if bonus and etat_brut:
            etat_brut = f"{etat_brut.capitalize()} (mise bonus {bonus})"
        paris.append(Pari(
            bookmaker=NOM, reference=reference, date_pari=date_pari, detail_partiel=not detail,
            date_evenement=max(jours) if jours else None,
            type=COMBINE if len(selections) > 1 or combine_ferme else SIMPLE, etat=etat,
            etat_brut=etat_brut.capitalize() if etat_brut else "En cours", mise=mise,
            gains=round(gains, 2) if gains is not None else None,
            cote_boostee=any(categorie_marche(s.marche) == "Cote boostée" for s in selections),
            nb_selections=len(selections) if combine_ferme else max(1, len(selections)), selections=selections,
            cote=cote, sport_devine=True,
        ))
    _sport_par_evenement(paris)
    return paris, avertissements


def _sport_par_evenement(paris: list[Pari]) -> None:
    """Un face-à-face sans compétition (« Haaser, Raphael vs. McGrath, Atle Lie ») n'a pas de sport devinable. S'il
    a lieu à la même heure qu'autre chose dont le sport est connu (le slalom géant de Sölden, le 26/10 à 10:00),
    c'est ce sport-là."""
    par_heure: dict[datetime, set[str]] = {}
    for p in paris:
        if p.date_evenement and isinstance(p.date_evenement, datetime):
            for s in p.selections:
                if s.sport and s.sport != "Autre":
                    par_heure.setdefault(p.date_evenement, set()).add(s.sport)
    for p in paris:
        sports = par_heure.get(p.date_evenement) if isinstance(p.date_evenement, datetime) else None
        if sports and len(sports) == 1:
            for s in p.selections:
                if s.sport == "Autre":
                    s.sport = next(iter(sports))
