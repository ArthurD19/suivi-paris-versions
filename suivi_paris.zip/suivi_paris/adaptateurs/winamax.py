"""Adaptateur Winamax : deux pages, copiées en entier.

1. « Mon compte > Historique de compte > Paris Sportifs » : chaque pari tient en une ligne d'en-tête (référence,
   date, type, état, mise, gains, séparés par des tabulations), suivie de paires de lignes
   « Sport - Compétition - … - Événement » / « Marché : Choix ». La plus détaillée : sport et sélections des
   combinés.

2. « Paris Sportifs > Mes paris » (onglets « En cours », « Terminés ») : un ticket par pari, une information par
   ligne :

       Simple | Combiné / (9)              type (et nombre de sélections)
       En cours | Gagné | Perdu | Remboursé
       14/10 / Lausanne HC / 6 / 3 / HC Ajoie   date et match avec son score, s'il y en a un ; ou un événement :
       Tour de Guangxi 2026 - Étape 4 (…)       « Tour de Guangxi 2026 - Étape 4 (Bama › Tian'e) »
       Vainqueur                             marché
       Søren Kragh Andersen                  choix
       150 | 4,75 / 1,00                     cote (et cote réglée, pour un remboursement)
       Cote totale / 9,32                    à la place des sélections, pour un combiné
       Mise / 3,00 €
       Gains potentiels | Gains | Remboursé / 450,00 €
       Réf : 6K5VBD7A                        même référence que dans l'historique
       16h47 - 15 octobre 2026

   Elle donne la cote, mais ni le sport ni les sélections des combinés : ces paris sont lus en « détail
   partiel », qui met à jour le résultat d'un pari déjà connu sans effacer le détail lu dans l'historique.

Les menus et le pied de page autour sont ignorés.
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

from ..modeles import (
    ANNULE,
    COMBINE,
    EN_COURS,
    GAGNE,
    INCONNU,
    MYCOMBI,
    PERDU,
    SIMPLE,
    SYSTEME,
    Pari,
    Selection,
    categorie_marche,
    montant,
    normaliser_etat,
    sans_accents,
)
from ..sports import deviner_sport, normaliser_sport

NOM = "winamax"
LIBELLE = "Winamax"
CONSIGNE = (
    "Sur winamax.fr : Mes paris (onglet « En cours » ou « Terminés »), ou Mon compte → Historique de compte → "
    "onglet « Paris Sportifs ». Sélectionne toute la page (Ctrl+A), copie (Ctrl+C), puis colle ici (Ctrl+V)."
)

_MONTANT = r"\d[\d   ]*,\d{2}"
_ENTETE = re.compile(
    rf"^(?P<ref>[0-9A-Z]{{6,}}(?:-\d+)?)\s+"
    r"(?P<date>\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}(?::\d{2})?)\s+"
    r"(?P<type>Simple|Multiple|Combin\S*|Syst\S*)\s+"
    rf"(?P<etat>.+?)\s+(?P<mise>{_MONTANT})(?:\s+(?P<gains>{_MONTANT}))?\s*$"
)
_FIN_DE_LISTE = re.compile(r"^(Précédent|Suivant|Winamax$|=== Suivi Paris : page)")
# Pagination affichée une entrée par ligne (« 1 », « 2 », « … », « Suivant ») : fin des paris de la page.
_PAGINATION = re.compile(r"^(\d+|\.\.\.|…|Précédent.*|Suivant)$")
# Une référence seule sur sa ligne, reste de mise en page : à ignorer.
_REFERENCE_SEULE = re.compile(r"^[0-9A-Z]{6,}(?:-\d+)?$")


def reconnait(texte: str) -> bool:
    return "winamax" in texte.lower() or "Historique des Paris Sportifs" in texte or bool(
        re.search(r"^[0-9A-Z]{8}(?:-\d+)?\t\d{2}/\d{2}/\d{4}", texte, re.MULTILINE)
    )


def identifiant(texte: str) -> str | None:
    """Le pseudo du compte, affiché dans le menu juste avant « Mon espace perso » (s'il a été copié)."""
    lignes = [l.strip() for l in texte.splitlines()]
    for i, ligne in enumerate(lignes):
        if ligne == "Mon espace perso":
            precedentes = [l for l in lignes[max(0, i - 4) : i] if l]
            if precedentes and re.fullmatch(r"[\w.\-]{3,30}", precedentes[-1]):
                return precedentes[-1]
    return None


def _lire_evenement(ligne: str) -> tuple[Selection, bool]:
    brut = ligne.lstrip("+").strip()
    boost = brut.lower().startswith("cotes boostées")
    if boost:
        brut = brut.split(" - ", 1)[1] if " - " in brut else brut
    sport, _, reste = brut.partition(" - ")
    morceaux = [m.strip() for m in reste.split(" - ") if m.strip()]
    competition = morceaux[0] if morceaux else ""
    dernier = morceaux[-1] if morceaux else ""
    annee = re.search(r"\b20\d{2}\b", reste)

    if " : " in reste:  # « La Grosse Cote Boostée : Arsenal - Lille »
        evenement = reste.rsplit(" : ", 1)[1].strip()
    elif re.search(r"[ÉE]tape", dernier):
        base = competition if not annee or annee.group(0) in competition else f"{competition} {annee.group(0)}"
        evenement = f"{base} – {dernier}"
    elif "/" in dernier:
        evenement = dernier
    elif annee and annee.group(0) not in competition:
        evenement = f"{competition} {annee.group(0)}"
    else:
        evenement = competition

    etape = re.search(r"[ÉE]tape (\d+)", brut)
    selection = Selection(
        sport=normaliser_sport(sport, brut),
        evenement=evenement,
        marche="",
        choix="",
        competition=competition,
        etape=int(etape.group(1)) if etape else None,
    )
    return selection, boost


def _lire_choix(ligne: str) -> tuple[str, str]:
    if " : " in ligne:
        marche, choix = ligne.split(" : ", 1)
        return marche.strip(), choix.strip()
    return ligne.strip(), ""


def _est_evenement(ligne: str) -> bool:
    """« Sport - Compétition - … - Événement » ; les lignes de choix, elles, ont toujours « Marché : Choix »."""
    return ligne.startswith("+") or ligne.lower().startswith("cotes boostées") or " : " not in ligne


def _type(brut: str) -> str:
    t = sans_accents(brut).lower()
    if t.startswith("simple"):
        return SIMPLE
    if t.startswith("syst"):
        return SYSTEME
    return COMBINE


def parser(texte: str) -> tuple[list[Pari], list[str]]:
    """Renvoie (paris, avertissements), pour l'historique de compte comme pour « Mes paris »."""
    if any(_ENTETE.match(l.strip()) for l in texte.splitlines()):
        return _parser_historique(texte)
    return _parser_mes_paris(texte)


def _parser_historique(texte: str) -> tuple[list[Pari], list[str]]:
    paris: list[Pari] = []
    avertissements: list[str] = []
    courant: dict | None = None
    corps: list[str] = []

    def cloturer() -> None:
        if courant is None:
            return
        lignes = []
        for l in (x.strip() for x in corps):
            if not l or _REFERENCE_SEULE.match(l):
                continue
            if _PAGINATION.match(l):
                break
            lignes.append(l)
        # Un événement peut porter plusieurs choix (« Créer mon pari » : plusieurs marchés du même match).
        groupes: list[list] = []
        for l in lignes:
            if _est_evenement(l):
                groupes.append([l, []])
            elif groupes:
                groupes[-1][1].append(l)
            else:
                avertissements.append(f"Winamax {courant['ref']} : choix sans événement (« {l} »), vérifie ce pari.")
        selections, boost = [], False
        for evenement, choix in groupes:
            for ligne_choix in choix or [""]:
                selection, b = _lire_evenement(evenement)
                selection.marche, selection.choix = _lire_choix(ligne_choix) if ligne_choix else ("", "")
                boost = boost or b or categorie_marche(selection.marche) == "Cote boostée"
                selections.append(selection)
        etat = normaliser_etat(courant["etat"])
        if etat == INCONNU:
            avertissements.append(f"Winamax {courant['ref']} : état « {courant['etat']} » non reconnu.")
        date_txt = re.sub(r"\s+", " ", courant["date"])
        fmt = "%d/%m/%Y %H:%M:%S" if date_txt.count(":") == 2 else "%d/%m/%Y %H:%M"
        type_pari = _type(courant["type"])
        if type_pari == SIMPLE and len(groupes) == 1 and len(selections) > 1:
            type_pari = MYCOMBI
        paris.append(
            Pari(
                bookmaker=NOM,
                reference=courant["ref"],
                date_pari=datetime.strptime(date_txt, fmt),
                type=type_pari,
                etat=etat,
                etat_brut=courant["etat"],
                mise=montant(courant["mise"]),
                gains=montant(courant["gains"]) if courant["gains"] else (0.0 if etat == "perdu" else None),
                cote_boostee=boost,
                nb_selections=max(1, len(selections)),
                selections=selections,
            )
        )

    for ligne in texte.splitlines():
        propre = ligne.strip()
        m = _ENTETE.match(propre)
        if m:
            cloturer()
            courant, corps = m.groupdict(), []
        elif courant is not None:
            if _FIN_DE_LISTE.match(propre):
                cloturer()
                courant, corps = None, []
            else:
                corps.append(ligne)
    cloturer()
    return paris, avertissements


# --------------------------------------------------------------------------- #
# « Mes paris »
# --------------------------------------------------------------------------- #
_REF_MES_PARIS = re.compile(r"^Réf\s*:\s*([0-9A-Z]{6,}(?:-\d+)?)$")
_DATE_MES_PARIS = re.compile(r"^(\d{1,2})h(\d{2})\s*-\s*(\d{1,2})\s+([^\W\d_]+)\.?\s+(\d{4})$")
_TYPE_MES_PARIS = re.compile(r"^(Simple|Combiné|Système.*)$")
_NB = re.compile(r"^\((\d+)\)$")
_COTE_MES_PARIS = re.compile(r"^\d+(?:,\d+)?$")
_JOUR = re.compile(r"^\d{1,2}/\d{1,2}$")
_BOOST = re.compile(r"^(?:La Grosse |La Super )?Cote Boost[ée]e\s*:\s*(.*)$", re.IGNORECASE)
_MOIS = {"janv": 1, "fevr": 2, "mars": 3, "avr": 4, "mai": 5, "juin": 6, "juil": 7, "aout": 8,
         "sept": 9, "oct": 10, "nov": 11, "dec": 12}
_LIBELLES_ARGENT = ("Gains potentiels", "Gains", "Remboursé", "Combo booster", "Cash out", "Cash-out")


def _date_mes_paris(ligne: str) -> datetime | None:
    m = _DATE_MES_PARIS.match(ligne)
    if not m:
        return None
    heure, minute, jour, mois_brut, annee = m.groups()
    mois = next((n for cle, n in _MOIS.items() if sans_accents(mois_brut).lower().startswith(cle)), None)
    return datetime(int(annee), mois, int(jour), int(heure), int(minute)) if mois else None


def _jour_evenement(contenu: list[str], date_pari: datetime) -> date | None:
    """« 14/10 », affiché au-dessus d'un match : le jour de l'événement. L'année est celle du pari, ou la suivante
    quand le jour tombe nettement avant le pari (pari de décembre pour un match de janvier)."""
    jour = next((l for l in contenu if _JOUR.match(l)), None)
    if jour is None:
        return None
    j, m = (int(x) for x in jour.split("/"))
    try:
        quand = date(date_pari.year, m, j)
        if quand < date_pari.date() - timedelta(days=60):
            quand = date(date_pari.year + 1, m, j)
    except ValueError:
        return None
    return quand


def _montant_sur(texte: str) -> float | None:
    """Un montant, ou None si la ligne n'en est pas un (au lieu d'arrêter tout l'import)."""
    try:
        return montant(texte)
    except ValueError:
        return None


def _cote_mp(texte: str) -> float | None:
    return float(texte.replace(",", ".")) if _COTE_MES_PARIS.match(texte) else None


def _selection_mes_paris(contenu: list[str]) -> tuple[Selection | None, bool]:
    """Les lignes d'un simple, entre l'état et la cote : (sélection, cote boostée)."""
    lignes = [l for l in contenu if not _JOUR.match(l)]
    scores = [int(l) for l in lignes if l.isdigit()]
    texte = [l for l in lignes if not l.isdigit()]
    if not texte:
        return None, False
    boost = False
    if len(texte) >= 3:
        evenement = " / ".join(texte[:-2][:2]) if len(texte) > 3 else texte[0]
        marche, choix = texte[-2], texte[-1]
    elif len(texte) == 2:
        evenement, marche, choix = texte[0], "", texte[1]
    else:
        evenement, marche, choix = "", "", texte[0]
    m = _BOOST.match(evenement)
    if m:
        evenement, boost = m.group(1).strip(), True
        marche = marche or "Cote boostée"
    sport = deviner_sport(marche, choix, evenement, scores or None)
    etape = re.search(r"[ÉE]tape (\d+)", evenement)
    return Selection(sport, evenement, marche, choix, evenement, int(etape.group(1)) if etape else None), boost


def _parser_mes_paris(texte: str) -> tuple[list[Pari], list[str]]:
    lignes = [l.strip() for l in texte.splitlines()]
    lignes = [l for l in lignes if l]
    refs = [i for i, l in enumerate(lignes) if _REF_MES_PARIS.match(l)]
    paris: list[Pari] = []
    avertissements: list[str] = []
    for k, r in enumerate(refs):
        reference = _REF_MES_PARIS.match(lignes[r]).group(1)
        date_pari = _date_mes_paris(lignes[r + 1]) if r + 1 < len(lignes) else None
        if date_pari is None:
            avertissements.append(f"Winamax {reference} : date du pari introuvable, pari ignoré.")
            continue
        debut = refs[k - 1] + 2 if k else 0
        t = max((i for i in range(debut, r) if _TYPE_MES_PARIS.match(lignes[i])), default=None)
        if t is None:
            avertissements.append(f"Winamax {reference} : type du pari introuvable, pari ignoré.")
            continue
        bloc = lignes[t + 1 : r]
        nb = int(_NB.match(bloc[0]).group(1)) if bloc and _NB.match(bloc[0]) else None
        if nb is not None:
            bloc = bloc[1:]
        e = next((i for i, l in enumerate(bloc) if normaliser_etat(l) != INCONNU), None)
        if e is None or "Mise" not in bloc:
            avertissements.append(f"Winamax {reference} : état ou mise introuvable, pari ignoré.")
            continue
        etat_brut = bloc[e]
        etat = normaliser_etat(etat_brut)
        im = bloc.index("Mise")
        contenu = bloc[e + 1 : im]
        mise = _montant_sur(bloc[im + 1]) if im + 1 < len(bloc) else None
        if mise is None:
            avertissements.append(f"Winamax {reference} : mise illisible, pari ignoré.")
            continue
        gains = potentiel = None
        i = im + 2
        while i < len(bloc):
            libelle = bloc[i]
            if libelle == "Combo booster":  # « 4 % », puis le bonus en euros : déjà compris dans les gains
                i += 3
                continue
            if libelle in _LIBELLES_ARGENT and i + 1 < len(bloc):
                valeur = _montant_sur(bloc[i + 1])
                if libelle == "Gains potentiels":
                    potentiel = valeur
                else:
                    gains = valeur
                i += 2
                continue
            i += 1

        cote = None
        if "Cote totale" in contenu:
            j = contenu.index("Cote totale")
            cote = _cote_mp(contenu[j + 1]) if j + 1 < len(contenu) else None
            contenu = contenu[:j]
        else:
            cotes = []
            while contenu and _cote_mp(contenu[-1]) is not None:
                cotes.insert(0, _cote_mp(contenu.pop()))
            if cotes:
                cote = cotes[0]  # « 4,75 / 1,00 » : la cote prise, puis celle du règlement (remboursement)
        if etat == ANNULE and cote == 1.0:
            cote = None
        if cote is None and potentiel and mise:
            cote = round(potentiel / mise, 2)

        jour = _jour_evenement(contenu, date_pari)
        if _TYPE_MES_PARIS.match(lignes[t]).group(1) == "Simple":
            selection, boost = _selection_mes_paris(contenu)
            selections, type_pari, nb_sel = ([selection] if selection else []), SIMPLE, 1
        else:
            # Les sélections d'un combiné ne s'affichent pas sur cette page (l'historique de compte les donne).
            selections, boost, nb_sel = [], False, nb or 2
            type_pari = SYSTEME if lignes[t].startswith("Système") else COMBINE
        if etat == GAGNE and gains is None:
            avertissements.append(f"Winamax {reference} : pari gagné sans montant de gain, pari ignoré.")
            continue
        if etat == PERDU:
            gains = 0.0
        elif etat == EN_COURS:
            gains = None
        elif etat == ANNULE and gains is None:
            gains = mise
        paris.append(Pari(
            bookmaker=NOM, reference=reference, date_pari=date_pari, type=type_pari, etat=etat, etat_brut=etat_brut,
            mise=mise, gains=gains, cote_boostee=boost or any(categorie_marche(s.marche) == "Cote boostée" for s in selections),
            nb_selections=nb_sel, selections=selections, cote=cote, detail_partiel=True, sport_devine=True,
            date_evenement=jour,
        ))
    return paris, avertissements
