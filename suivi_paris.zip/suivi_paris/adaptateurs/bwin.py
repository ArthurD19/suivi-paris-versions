"""Adaptateur bwin (bwin.fr) : Mes paris, onglets « Ouvert » et « Évalué ».

Le site empêche Ctrl+A : la page est lue par l'extension (ou copiée avec son bouton « Copier le texte de la page »).
Un pari s'y lit ainsi (onglet « Évalué » ; « Ouvert » n'a ni jour, ni état, ni « Résultat », et dit « Gains
possibles ») :

    25/09/2026                      jour du pari (en-tête de groupe)
    Perdu                           état
    T. Gibson                       choix          ┐
    Vainqueur du tournoi            marché         │ une sélection (un combiné en a plusieurs)
    Résultat : Perdu                               │
    WTA Singapour 2026 (SGP)        compétition    │
    27/09/2026 04:00                événement      ┘
    Mise / Cotes / Gains            puis leurs valeurs : « 100,00 € », « 4.50 », « - » (perdu)
    Détail                          (« Épingler (en haut) » dans « Ouvert »)
    25/09/2026 18:17                date du pari, à la minute

La page n'affiche pas de numéro de pari : la référence est faite de la date du pari, de la mise et du choix, que les
deux onglets donnent pareil (un pari ouvert devenu évalué est mis à jour, pas doublé). Le sport n'est pas affiché :
il est deviné, sinon « Autre ».
"""
from __future__ import annotations

import hashlib
import re
from datetime import datetime

from ..modeles import (
    ANNULE,
    CASHOUT,
    COMBINE,
    EN_COURS,
    GAGNE,
    INCONNU,
    PERDU,
    SIMPLE,
    Pari,
    Selection,
    categorie_marche,
    montant,
    sans_accents,
)
from ..sports import deviner_sport

NOM = "bwin"
LIBELLE = "bwin"
CONSIGNE = (
    "Sur bwin.fr : Mes paris, onglets « Ouvert » puis « Évalué » (Filtre : 90 jours au plus par période). Le site "
    "empêche Ctrl+A : utilise l'extension, ou son bouton « Copier le texte de la page », puis colle ici."
)

_HORODATAGE = re.compile(r"^(\d{2}/\d{2}/\d{4}) (\d{2}:\d{2})$")
_JOUR = re.compile(r"^\d{2}/\d{2}/\d{4}$")
_PLAGE = re.compile(r"^\d{2}/\d{2}/\d{4}\s*-\s*\d{2}/\d{2}/\d{4}$")
_EUROS = re.compile(r"^-?\d[\d  ]*,\d{2}\s*€$")
_COTE = re.compile(r"^\d+(?:[.,]\d+)?$")
_RESULTAT = re.compile(r"^Résultat\s*:", re.IGNORECASE)
_ETATS = re.compile(r"^(Gagné|Perdu|Remboursé|Annulé|Cash ?out|Encaissé|Nul)$", re.IGNORECASE)
_FIN_PARI = ("Détail", "Épingler (en haut)")
_ENTETE = {"Ouvert", "Évalué", "Filtre", "Imprimer", "En direct"}
# Le panneau du filtre (« Filtrer mes paris par … Afficher résultats ») peut s'afficher avant la liste.
_FILTRE = re.compile(r"Afficher (les )?résultats|Date de (début|fin)|Intervalle de temps|Filtrer mes paris")


def reconnait(texte: str) -> bool:
    # « BES SAS … 521353235 » : la société de bwin en France, en bas de chaque page.
    return "521353235" in texte or "bwin" in texte.lower() or ("Épingler (en haut)" in texte and "Mise\nCotes" in texte)


def identifiant(texte: str) -> str | None:
    """La page n'affiche pas d'identifiant de compte."""
    return None


def _etat(brut: str) -> str:
    e = sans_accents(brut).lower().strip()
    if "cash" in e or e.startswith("encaiss"):
        return CASHOUT
    if e.startswith("gagn"):
        return GAGNE
    if e.startswith("perd"):
        return PERDU
    if e.startswith(("rembours", "annul", "nul")):
        return ANNULE
    return INCONNU


def _etat_par_les_gains(mise: float, gains: float | None) -> tuple[str, float]:
    """Un pari évalué sans étiquette d'état : ce que disent ses gains."""
    if gains is None or gains == 0:
        return PERDU, 0.0
    if abs(gains - mise) < 0.005:
        return ANNULE, gains
    return (GAGNE, gains) if gains > mise else (CASHOUT, gains)


def _selections(lignes: list[str]) -> tuple[list[Selection], list[datetime]]:
    """Les lignes d'avant « Mise » : chaque sélection finit par la date de son événement."""
    groupes, courant = [], []
    for l in lignes:
        courant.append(l)
        if _HORODATAGE.match(l):
            groupes.append(courant)
            courant = []
    if courant:
        groupes.append(courant)
    selections, dates = [], []
    for g in groupes:
        h = _HORODATAGE.match(g[-1])
        if h:
            dates.append(datetime.strptime(f"{h.group(1)} {h.group(2)}", "%d/%m/%Y %H:%M"))
            g = g[:-1]
        g = [l for l in g if not _RESULTAT.match(l)]
        if not g:
            continue
        choix = g[0]
        marche = g[1] if len(g) > 2 else ""
        evenement = g[-1] if len(g) > 1 else ""
        sport = deviner_sport(marche, choix, evenement) or "Autre"
        selections.append(Selection(sport, evenement, marche, choix, evenement))
    return selections, dates


def _reference(date_pari: datetime, mise: float, selections: list[Selection]) -> str:
    choix = "|".join(s.choix for s in selections)
    empreinte = hashlib.sha1(choix.encode("utf-8")).hexdigest()[:6]
    return f"{date_pari:%Y%m%d%H%M}-{mise:.2f}-{empreinte}"


def parser(texte: str) -> tuple[list[Pari], list[str]]:
    lignes = [l.strip() for l in texte.splitlines() if l.strip()]
    paris: list[Pari] = []
    avertissements: list[str] = []
    vues: dict[str, int] = {}
    debut = 0  # première ligne du pari à lire
    # Le premier pari suit les onglets (« Ouvert », « 4 », « Évalué ») et le filtre de dates.
    k_mises = [k for k in range(len(lignes) - 2) if lignes[k] == "Mise" and lignes[k + 1] == "Cotes"
               and lignes[k + 2].startswith("Gains")]
    if k_mises:
        avant = [k for k in range(k_mises[0]) if lignes[k] in _ENTETE or _FILTRE.search(lignes[k]) or _PLAGE.match(lignes[k])]
        debut = avant[-1] + 1 if avant else 0
    for k in k_mises:
        en_cours = lignes[k + 2] == "Gains possibles"
        valeurs = lignes[k + 3:k + 6]
        fin = next((j for j in range(k + 3, min(k + 12, len(lignes) - 1)) if lignes[j] in _FIN_PARI
                    and _HORODATAGE.match(lignes[j + 1])), None)
        if len(valeurs) < 3 or fin is None or not _EUROS.match(valeurs[0]) or not _COTE.match(valeurs[1]):
            avertissements.append(f"bwin : un pari illisible (ligne {k + 1}), ignoré.")
            continue
        h = _HORODATAGE.match(lignes[fin + 1])
        date_pari = datetime.strptime(f"{h.group(1)} {h.group(2)}", "%d/%m/%Y %H:%M")
        corps = lignes[debut:k]
        debut = fin + 2
        # En tête du pari (onglet « Évalué ») : le jour, puis l'état.
        etat_brut = ""
        while corps and (_JOUR.match(corps[0]) or _ETATS.match(corps[0])):
            if _ETATS.match(corps[0]):
                etat_brut = corps[0]
            corps = corps[1:]
        mise = montant(valeurs[0])
        cote = float(valeurs[1].replace(",", "."))
        gains_lus = montant(valeurs[2]) if _EUROS.match(valeurs[2]) else None
        if en_cours:
            etat, etat_brut, gains = EN_COURS, "En cours", None
        elif not etat_brut:
            # L'étiquette « Gagné » / « Perdu » manque souvent (elle ne s'affiche pas pour tous les paris de la
            # liste). Les gains, eux, le disent : « - » perdu, la mise rendue remboursé, plus que la mise gagné.
            etat, gains = _etat_par_les_gains(mise, gains_lus)
            etat_brut = {GAGNE: "Gagné", PERDU: "Perdu", ANNULE: "Remboursé", CASHOUT: "Cash-out"}[etat]
        else:
            etat = _etat(etat_brut)
            if etat == PERDU:
                gains = 0.0
            elif etat == ANNULE:
                gains = gains_lus if gains_lus is not None else mise
            else:
                gains = gains_lus
            if etat == INCONNU:
                avertissements.append(f"bwin : pari du {date_pari:%d/%m/%Y %H:%M}, état « {etat_brut or '?'} » "
                                      "non reconnu.")
            elif etat in (GAGNE, CASHOUT) and gains is None:
                avertissements.append(f"bwin : pari du {date_pari:%d/%m/%Y %H:%M}, gain introuvable.")
        selections, jours = _selections(corps)
        if not selections:
            avertissements.append(f"bwin : pari du {date_pari:%d/%m/%Y %H:%M}, sélection illisible.")
        reference = _reference(date_pari, mise, selections)
        # Deux paris identiques à la même minute (même mise, même choix) : le second prend un suffixe.
        vues[reference] = vues.get(reference, 0) + 1
        if vues[reference] > 1:
            reference = f"{reference}-{vues[reference]}"
        paris.append(Pari(
            bookmaker=NOM,
            reference=reference,
            date_pari=date_pari,
            type=COMBINE if len(selections) > 1 else SIMPLE,
            etat=etat,
            etat_brut=etat_brut,
            mise=mise,
            gains=round(gains, 2) if gains is not None else None,
            cote_boostee=any(categorie_marche(s.marche) == "Cote boostée" for s in selections),
            nb_selections=max(1, len(selections)),
            selections=selections,
            cote=cote,
            date_evenement=max(jours) if jours else None,
            sport_devine=True,
        ))
    return paris, avertissements
