"""Adaptateur PokerStars Sports (pokerstars.fr/sports) : Mes paris → Terminés (et En cours).

Un pari simple terminé :

    Vous avez gagné 170,10 €                               (en tête des paris gagnés)
    Jaime Jaquez Jr. - Plus                                titre
    Jaime Jaquez Jr. - Points + passes décisives @ 1,62    marché @ cote
    Gagné                                                  état de la sélection
    Jaime Jaquez Jr. - Plus (+16.5)                        choix
    Milwaukee Bucks @ Orlando Magic                        événement
    samedi 14 novembre 2026 à 01:11                        date de l'événement
    Simple / @ 1,62                                        type, cote totale
    Mise : / 105,00 € / Retour : / 170,10 €                (en cours : « Gains potentiels : »)
    Détails du pari                                        fin du pari

Un « Mon Pari » (plusieurs sélections sur un même match) donne l'événement et sa date d'abord, puis chaque sélection :
marché (« Marque au moins 20 points »), choix (« Giannis Antetokounmpo »), et son état une fois réglé. En cours, son
en-tête est « 100,00 € - Mon Pari @ 1,92 » suivi de « (1 événement - 2 sélections) ».

La page n'affiche ni la référence du pari ni la date où il a été pris : la référence est fabriquée à partir de la date
de l'événement, de la mise et des choix (la même en cours et une fois réglé), et la date du pari est celle de
l'événement. L'état se lit au retour : plus que la mise gagné, la mise rendue remboursé, rien perdu.
"""
from __future__ import annotations

import hashlib
import re
from datetime import datetime

from ..modeles import (
    ANNULE,
    CASHOUT,
    COMBINE,
    EN_COURS,
    GAGNE,
    MYCOMBI,
    PERDU,
    SIMPLE,
    Pari,
    Selection,
    montant,
    sans_accents,
)
from ..sports import deviner_sport

NOM = "pokerstars"
LIBELLE = "PokerStars"
CONSIGNE = (
    "Sur pokerstars.fr/sports : Mes paris → Terminés (puis En cours). Copie toute la page (Ctrl+A, Ctrl+C) ou "
    "utilise l'extension."
)

_FIN = "Détails du pari"
_MOIS = {m: i for i, m in enumerate(("janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout",
                                      "septembre", "octobre", "novembre", "decembre"), start=1)}
# « samedi 14 novembre 2026 à 01:11 », « Demain, 17 novembre 2026 à 02:10 », « Aujourd'hui, … »
_DATE = re.compile(r"^(?:[a-zà-ü']+,?\s+)?(\d{1,2})(?:er)?\s+([a-zéû]+)\s+(\d{4})\s+à\s+(\d{1,2}):(\d{2})$", re.IGNORECASE)
_MARCHE_COTE = re.compile(r"^(.*\S)\s+@\s+(\d+(?:,\d+)?)$")
_COTE_SEULE = re.compile(r"^@\s*(\d+(?:,\d+)?)$")
_ENTETE_EN_COURS = re.compile(r"^(\d[\d\s]*,\d{2})\s*€\s*-\s*(.*?)\s+@\s+(\d+(?:,\d+)?)$")
_ETAT_SELECTION = re.compile(r"^(gagné|perdu|annulé|remboursé|nul|cash ?out)$", re.IGNORECASE)
_EUROS = re.compile(r"^\d[\d\s]*,\d{2}\s*€$")
_BRUIT = re.compile(r"^(Mes paris \| PokerStars Sports|Pariez sur tous les sports majeurs.*|Ajouter au bulletin de pari"
                    r"|Les informations en direct peuvent.*)$")


def reconnait(texte: str) -> bool:
    return "pokerstars" in texte.lower() and _FIN in texte


def identifiant(texte: str) -> str | None:
    """Le pseudo, sous le solde en haut de page (« 794,33 € », « NicoFalcaoQ7 », « Dépôt »)."""
    lignes = [l.strip() for l in texte.splitlines() if l.strip()][:40]
    for i, l in enumerate(lignes[2:], start=2):
        if l == "Dépôt" and _EUROS.match(lignes[i - 2]) and not _EUROS.match(lignes[i - 1]):
            return lignes[i - 1]
    return None


def _date(ligne: str) -> datetime | None:
    m = _DATE.match(ligne)
    mois = _MOIS.get(sans_accents(m.group(2)).lower()) if m else None
    return datetime(int(m.group(3)), mois, int(m.group(1)), int(m.group(4)), int(m.group(5))) if mois else None


def _apres(bloc: list[str], libelle: str) -> float | None:
    i = next((k for k, l in enumerate(bloc) if l.rstrip(" :") == libelle), None)
    return montant(bloc[i + 1]) if i is not None and i + 1 < len(bloc) and _EUROS.match(bloc[i + 1]) else None


def _reference(quand: datetime, mise: float, selections: list[Selection]) -> str:
    choix = "|".join(f"{s.marche}={s.choix}" for s in selections)
    return f"PS-{quand:%Y%m%d%H%M}-{mise:.2f}-{hashlib.sha1(choix.encode('utf-8')).hexdigest()[:6]}"


def _selections(bloc: list[str]) -> tuple[list[Selection], bool]:
    """(sélections, « Mon Pari »)."""
    dates = [k for k, l in enumerate(bloc) if _date(l)]
    if not dates:
        return [], False
    mon_pari = any(l.startswith("Mon Pari") or re.match(r"^\(\d+ événements? - \d+ sélections?\)$", l) for l in bloc) \
        or any("- Mon Pari @" in l for l in bloc)
    selections: list[Selection] = []
    for n, k in enumerate(dates):
        evenement = re.sub(r"\s+@\s+", " / ", bloc[k - 1]) if k >= 1 else ""
        if mon_pari:
            # Après la date : marché, choix (et état), jusqu'à la date suivante ou la fin du pari.
            fin = dates[n + 1] - 1 if n + 1 < len(dates) else len(bloc)
            lignes = [l for l in bloc[k + 1:fin] if not _ETAT_SELECTION.match(l)]
            lignes = lignes[:next((j for j, l in enumerate(lignes) if l.startswith(("Mon Pari", "Mise"))
                                   or _COTE_SEULE.match(l)), len(lignes))]
            for j in range(0, len(lignes) - 1, 2):
                marche, choix = lignes[j], lignes[j + 1]
                selections.append(Selection(deviner_sport(marche, choix, evenement) or "Autre", evenement, marche, choix,
                                            ""))
        else:
            # Avant l'événement : « marché @ cote », l'état, puis le choix.
            debut = max((j for j in range(k - 1) if _MARCHE_COTE.match(bloc[j])), default=None)
            if debut is None:
                continue
            m = _MARCHE_COTE.match(bloc[debut])
            choix = next((l for l in reversed(bloc[debut + 1:k - 1]) if not _ETAT_SELECTION.match(l)), "")
            marche = m.group(1)
            selections.append(Selection(deviner_sport(marche, choix, evenement) or "Autre", evenement, marche, choix, "",
                                        cote=montant(m.group(2))))
    return selections, mon_pari


def parser(texte: str) -> tuple[list[Pari], list[str]]:
    lignes = [l.strip() for l in texte.splitlines() if l.strip() and not _BRUIT.match(l.strip())]
    paris: list[Pari] = []
    avertissements: list[str] = []
    # Le premier pari commence après les onglets « Mes mises / En cours / Terminés ».
    debut = max((i + 1 for i, l in enumerate(lignes) if l == "Terminés" and i < (lignes.index(_FIN) if _FIN in lignes
                                                                                    else len(lignes))), default=0)
    for i, ligne in enumerate(lignes):
        if ligne != _FIN:
            continue
        bloc, debut = lignes[debut:i], i + 1
        mise = _apres(bloc, "Mise")
        selections, mon_pari = _selections(bloc)
        entete = next((m for m in map(_ENTETE_EN_COURS.match, bloc) if m), None)
        if mise is None and entete:
            mise = montant(entete.group(1))
        if mise is None or not selections:
            avertissements.append(f"PokerStars : pari illisible (« {' / '.join(bloc[:3])[:80]} »), ignoré.")
            continue
        cote_l = next((m.group(1) for m in map(_COTE_SEULE.match, reversed(bloc)) if m), None)
        cote = montant(cote_l) if cote_l else montant(entete.group(3)) if entete else None
        retour = _apres(bloc, "Retour")
        if retour is None:
            etat, gains, etat_brut = EN_COURS, None, "En cours"
        else:
            gains = retour
            cash = any(re.search(r"cash ?out", l, re.IGNORECASE) for l in bloc)
            etat = (GAGNE if retour > mise + 0.005 else ANNULE if abs(retour - mise) < 0.005 else PERDU if retour == 0
                    else CASHOUT if cash else PERDU)
            etat_brut = {GAGNE: "Gagné", ANNULE: "Remboursé", PERDU: "Perdu", CASHOUT: "Cash out"}[etat]
        quand = min(_date(l) for l in bloc if _date(l))
        type_pari = MYCOMBI if mon_pari else COMBINE if len(selections) > 1 else SIMPLE
        paris.append(Pari(
            bookmaker=NOM, reference=_reference(quand, mise, selections), date_pari=quand, type=type_pari, etat=etat,
            etat_brut=etat_brut, mise=mise, gains=gains, cote_boostee=False, nb_selections=len(selections),
            selections=selections, cote=cote,
        ))
    return paris, avertissements



