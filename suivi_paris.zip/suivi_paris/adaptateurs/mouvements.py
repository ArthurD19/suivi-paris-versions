"""Lecture d'une page de dépôts ou de retraits copiée en entier.

Betclic les liste ainsi, une information par ligne ; la date n'est écrite qu'au premier mouvement du jour :

    14/12/2024           date
    Carte bancaire       moyen de paiement (page des dépôts seulement)
    09:43                heure
    250,00 €             montant
    Validé | Refusé      statut

PMU (« Mon historique de mouvements », onglet « Appro / Retrait ») :

    04/09/2026           date
    16h21                heure
    Appro. web           libellé
    APPROVISIONNEMENT    type : APPROVISIONNEMENT ou RETRAIT (les autres types, paris et bonus, sont ignorés)
    Réf. M0LEWG310X      référence
    + 200 €              montant signé

bet365 (Historique → « Dépôts » ou « Retraits ») :

    Montant du dépôt | Montant du retrait    sens
    500,00 €                                 montant
    Dépôt Carte de débit 8853                moyen de paiement (gardé sans les chiffres de la carte)
    Référence: D6199465624DC                 référence
    02/09/2026 10:23:02                      date et heure

Winamax (Mon compte → Historique de compte → onglet « Dépôts » ou « Retraits ») : un tableau, une ligne par
mouvement, colonnes séparées par des tabulations :

    Historique des retraits du 01/10/2018 au 31/10/2026          sens
    18/06/2021 15:52:35  Virement  71,46  0,00  21/06/2021 07:59:50   date, moyen, montant, frais, traitement
    Historique des dépôts du 01/10/2018 au 31/10/2026
    15/06/2021 19:33:29  Carte de crédit  15,00                       date, moyen, montant

Un retrait sans date de traitement n'est pas encore versé : « En attente », il ne compte pas.

Unibet (Mon compte → Transactions, onglets « Compte » et « Archivé », d'avant la fusion avec PSEL) : une date en
toutes lettres, puis pour chaque mouvement un libellé et un montant signé, sans heure :

    Mercredi 8 avril 2026
    PayPal | Dépôt par carte bancaire        + 40,00 €   dépôt
    Virement instantané | Retrait par …      - 1250,00 €  retrait
    Transfert … (ancien compte …)            ± …         ignoré : argent passé d'un compte à l'autre à la fusion
    Crédit BonusBet | Bonus crédit de jeu …  + …         ignoré : un bonus n'est pas un dépôt

Sportaza (Historique des transactions, filtre « Dépôt » et « Retraits ») : le type, la date, le montant (précédé
d'un « - » pour un retrait), le solde après le mouvement, le statut :

    Retrait | Dépôt          sens
    26.08.2026, 08:33        date et heure
    -                        (retrait)
    500,00 €                 montant
    /
    54,66 €                  solde réel après le mouvement (ignoré)
    Complété | Annulé        statut

Un freebet, un bonus ou un crédit offert (« Freebet », « Bonus de bienvenue », « Parrainage » à la place du moyen de
paiement) n'est pas un dépôt : il est ignoré. Seuls les mouvements validés comptent dans le bilan. La page Betclic ne dit pas s'il s'agit de dépôts ou de
retraits : la présence d'un moyen de paiement le laisse deviner, et l'utilisateur le confirme. La page PMU le dit
pour chaque mouvement.
"""
from __future__ import annotations

import re
from datetime import datetime

from ..modeles import DEPOT, RETRAIT, Mouvement, montant, sans_accents

_DATE = re.compile(r"^(\d{2})/(\d{2})/(\d{4})$")
_HEURE = re.compile(r"^(\d{1,2})[:h](\d{2})$")
_MONTANT = re.compile(r"^(?P<signe>[+\-−])?\s*(?P<valeur>\d[\d\s]*(?:[.,]\d{1,2})?)\s*€$")
_STATUT = re.compile(r"^(validée?|refusée?|en cours|en attente|annulée?|effectuée?|acceptée?|terminée?|échouée?"
                     r"|complétée?|completed|cancell?ed|pending|declined|rejected|failed|approved|success(?:ful)?)$",
                     re.IGNORECASE)
_REF = re.compile(r"^Réf\.?\s*:?\s*(\S+)$", re.IGNORECASE)
_TYPE = re.compile(r"^[A-ZÀÂÇÉÈÊËÎÏÔÛÙÜ][A-ZÀÂÇÉÈÊËÎÏÔÛÙÜ' -]{3,}$")  # « APPROVISIONNEMENT », « RETRAIT », « MISE »…
_ESPACES = str.maketrans({" ": " ", " ": " ", " ": " "})
_OFFERT = re.compile(r"free ?bet|bonus|offert|cadeau|parrainage|cr[ée]dit de jeu|promo|remboursement de mise",
                     re.IGNORECASE)
_MAX_LIGNES_ENTRE = 4  # entre l'heure et le montant : libellé, type, référence


def _ligne(brute: str) -> str:
    # Une page copiée en Markdown met les liens entre crochets : « [0 €](https://…) ».
    ligne = brute.translate(_ESPACES).strip().lstrip("*").strip()
    m = re.match(r"^\[(.*)\]\([^)]*\)$", ligne)
    return (m.group(1) if m else ligne).strip()


def _sens_du_type(type_: str) -> str | None:
    t = sans_accents(type_).upper()
    if t.startswith(("APPRO", "DEPOT", "DEPOSIT")):
        return DEPOT
    if t.startswith(("RETRAIT", "WITHDRAW")):
        return RETRAIT
    return None


_BET365_TETE = re.compile(r"^Montant du (dépôt|retrait)\s*(.*)$", re.IGNORECASE)
_DATE_HEURE = re.compile(r"^(\d{2})/(\d{2})/(\d{4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?$")


def _lire_bet365(lignes: list[str]) -> tuple[list[Mouvement], list[str]]:
    mouvements: list[Mouvement] = []
    avertissements: list[str] = []
    debuts = [i for i, l in enumerate(lignes) if _BET365_TETE.match(l)]
    for n, i in enumerate(debuts):
        tete = _BET365_TETE.match(lignes[i])
        bloc = [tete.group(2).strip()] + lignes[i + 1:debuts[n + 1] if n + 1 < len(debuts) else len(lignes)]
        sens = DEPOT if sans_accents(tete.group(1)).lower() == "depot" else RETRAIT
        valeur = next((_MONTANT.match(l) for l in bloc if _MONTANT.match(l)), None)
        quand = next((_DATE_HEURE.match(l) for l in bloc if _DATE_HEURE.match(l)), None)
        if not valeur or not quand:
            avertissements.append(f"{lignes[i]} : montant ou date illisible, ignoré.")
            continue
        j, mo, a, h, mi, s = quand.groups()
        date = datetime(int(a), int(mo), int(j), int(h), int(mi), int(s or 0))
        statut = next((l for l in bloc if _STATUT.match(l)), "Effectué")
        libelle = next((l for l in bloc if re.match(r"^(Dépôt|Retrait)\s", l, re.IGNORECASE)), "")
        moyen = re.sub(r"^(Dépôt|Retrait)\s+", "", libelle, flags=re.IGNORECASE)
        moyen = re.sub(r"\s*(?:\*+\s*)?\d{4}$", "", moyen).strip()  # « Carte de débit 8853 » -> « Carte de débit »
        mouvements.append(Mouvement(date, montant(valeur.group("valeur")), statut.capitalize(), moyen, sens))
    return mouvements, avertissements


_WINAMAX_TABLEAU = re.compile(r"^Historique des (dépôts|retraits) du \d{2}/\d{2}/\d{4} au \d{2}/\d{2}/\d{4}$",
                              re.IGNORECASE)
_WINAMAX_LIGNE = re.compile(r"^(\d{2})/(\d{2})/(\d{4}) (\d{2}):(\d{2}):(\d{2})\t+([^\t]*)\t+(\d[\d ]*,\d{2})"
                            r"(?:\t+(\d[\d ]*,\d{2}))?(?:\t+(.*))?$")


def _lire_winamax(brutes: list[str]) -> tuple[list[Mouvement], list[str]]:
    mouvements: list[Mouvement] = []
    sens = None
    for brute in brutes:
        ligne = brute.translate(_ESPACES).strip()
        tete = _WINAMAX_TABLEAU.match(ligne)
        if tete:
            sens = DEPOT if sans_accents(tete.group(1)).lower() == "depots" else RETRAIT
            continue
        m = _WINAMAX_LIGNE.match(ligne)
        if not m or sens is None:
            continue
        j, mo, a, h, mi, s = (int(x) for x in m.groups()[:6])
        traite = (m.group(10) or "").strip()
        statut = "Effectué" if sens == DEPOT or re.match(r"\d{2}/\d{2}/\d{4}", traite) else "En attente"
        mouvements.append(Mouvement(datetime(a, mo, j, h, mi, s), montant(m.group(8)), statut,
                                    m.group(7).strip(), sens))
    return mouvements, []


_MOIS = {m: i for i, m in enumerate(("janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout",
                                      "septembre", "octobre", "novembre", "decembre"), start=1)}
_DATE_LONGUE = re.compile(r"^(?:lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche)\s+(\d{1,2})(?:er)?\s+(\w+)\s+(\d{4})$",
                          re.IGNORECASE)
_MONTANT_SIGNE = re.compile(r"^(?P<signe>[+\-−])\s*(?P<valeur>\d[\d ]*(?:,\d{1,2})?)\s*€$")
_IGNORES_UNIBET = re.compile(r"transfert|bonus|cr[ée]dit|fusion|gain|remboursement|annulation", re.IGNORECASE)
_MOYENS = re.compile(r"paypal|carte|\bcb\b|visa|mastercard|paysafe|apple pay|google pay|neteller|skrill|virement",
                     re.IGNORECASE)


def _date_longue(ligne: str) -> datetime | None:
    m = _DATE_LONGUE.match(ligne)
    mois = _MOIS.get(sans_accents(m.group(2)).lower()) if m else None
    return datetime(int(m.group(3)), mois, int(m.group(1))) if mois else None


def _lire_unibet(lignes: list[str]) -> tuple[list[Mouvement], list[str]]:
    mouvements: list[Mouvement] = []
    avertissements: list[str] = []
    jour = None
    for i, ligne in enumerate(lignes):
        d = _date_longue(ligne)
        if d:
            jour = d
            continue
        m = _MONTANT_SIGNE.match(ligne)
        if not m or jour is None or i == 0:
            continue
        libelle = lignes[i - 1]
        if _IGNORES_UNIBET.search(libelle):
            continue  # transfert entre l'ancien et le nouveau compte, bonus : ni dépôt ni retrait
        credit = m.group("signe") == "+"
        if re.match(r"^d[ée]p[ôo]t", libelle, re.IGNORECASE) or (credit and _MOYENS.search(libelle)):
            sens = DEPOT
        elif re.match(r"^retrait", libelle, re.IGNORECASE) or (not credit and _MOYENS.search(libelle)):
            sens = RETRAIT
        else:
            avertissements.append(f"« {libelle} » ({ligne}) du {jour:%d/%m/%Y} : ni dépôt ni retrait reconnu, ignoré.")
            continue
        moyen = re.sub(r"^(d[ée]p[ôo]t|retrait)\s+(par|en)\s+", "", libelle, flags=re.IGNORECASE)
        mouvements.append(Mouvement(jour, montant(m.group("valeur")), "Effectué", moyen[:1].upper() + moyen[1:], sens))
    return mouvements, avertissements


# Montant dans la monnaie du compte : « 500,00 € », « 120,00 CHF ».
_MONTANT_SPORTAZA = re.compile(r"^(?:(?:€|CHF|£|\$)\s*)?(?P<valeur>\d[\d\s,]*(?:[.,]\d{1,2})?)\s*(?:€|CHF|£|\$)?$")
_SPORTAZA_DATE = re.compile(r"^(\d{2})\.(\d{2})\.(\d{4}),\s*(\d{1,2}):(\d{2})$")


def _lire_sportaza(lignes: list[str]) -> tuple[list[Mouvement], list[str]]:
    mouvements: list[Mouvement] = []
    avertissements: list[str] = []
    for i, ligne in enumerate(lignes):
        d = _SPORTAZA_DATE.match(ligne)
        if not d or i == 0:
            continue
        sens = _sens_du_type(lignes[i - 1])
        if sens is None:
            continue  # un bonus, un pari… : pas un dépôt ni un retrait
        suite = lignes[i + 1:i + 7]
        valeur = next((_MONTANT_SPORTAZA.match(l) for l in suite if _MONTANT_SPORTAZA.match(l)), None)
        statut = next((l for l in suite if _STATUT.match(l)), "")
        if not valeur or not statut:
            avertissements.append(f"Mouvement du {ligne} illisible, ignoré.")
            continue
        j, mo, a, h, mi = d.groups()
        brut = re.sub(r"\s", "", valeur.group("valeur"))
        if "," in brut and "." in brut:  # « 1,054.66 » (site en anglais)
            brut = brut.replace(",", "")
        mouvements.append(Mouvement(datetime(int(a), int(mo), int(j), int(h), int(mi)), montant(brut),
                                    statut.capitalize(), "", sens))
    return mouvements, avertissements


def lire(texte: str) -> tuple[list[Mouvement], list[str]]:
    """Renvoie (mouvements, avertissements), dans l'ordre de la page."""
    if re.search(r"^\s*Historique des (dépôts|retraits) du ", texte, re.MULTILINE | re.IGNORECASE):
        return _lire_winamax(texte.splitlines())
    lignes = [l for l in (_ligne(x) for x in texte.splitlines()) if l]
    if any(_BET365_TETE.match(l) for l in lignes):
        return _lire_bet365(lignes)
    if any(_SPORTAZA_DATE.match(l) for l in lignes):
        return _lire_sportaza(lignes)
    if any(_date_longue(l) for l in lignes) and any(_MONTANT_SIGNE.match(l) for l in lignes):
        return _lire_unibet(lignes)
    mouvements: list[Mouvement] = []
    avertissements: list[str] = []
    jour = None
    for i, ligne in enumerate(lignes):
        d = _DATE.match(ligne)
        if d:
            jour = datetime(int(d.group(3)), int(d.group(2)), int(d.group(1)))
            continue
        h = _HEURE.match(ligne)
        if not h or jour is None:
            continue
        quand = jour.replace(hour=int(h.group(1)), minute=int(h.group(2)))
        # Après l'heure : quelques lignes (libellé, type, référence) puis le montant, et parfois le statut.
        j = i + 1
        entre: list[str] = []
        while j < len(lignes) and len(entre) <= _MAX_LIGNES_ENTRE and not _MONTANT.match(lignes[j]) \
                and not _HEURE.match(lignes[j]) and not _DATE.match(lignes[j]):
            entre.append(lignes[j])
            j += 1
        m = _MONTANT.match(lignes[j]) if j < len(lignes) else None
        if not m:
            avertissements.append(f"Mouvement du {jour:%d/%m/%Y} à {ligne} illisible, ignoré.")
            continue
        statut = lignes[j + 1] if j + 1 < len(lignes) and _STATUT.match(lignes[j + 1]) else ""
        types = [l for l in entre if _TYPE.match(l)]
        sens = _sens_du_type(types[0]) if types else None
        if types and sens is None:
            continue  # un pari, un gain, un bonus… : pas un dépôt ni un retrait
        if not statut and not sens:
            avertissements.append(f"Mouvement du {jour:%d/%m/%Y} à {ligne} sans statut, ignoré.")
            continue
        if sens is None and m.group("signe"):
            sens = DEPOT if m.group("signe") == "+" else RETRAIT  # « + 200 € » / « - 50 € »
        libelles = [l for l in entre if not _TYPE.match(l) and not _REF.match(l) and not _STATUT.match(l)]
        moyen = libelles[0] if libelles else ""
        if not entre:  # Betclic : le moyen de paiement est juste avant l'heure
            avant = lignes[i - 1] if i else ""
            moyen = "" if _DATE.match(avant) or _STATUT.match(avant) or _MONTANT.match(avant) else avant
        if _OFFERT.search(moyen) or any(_OFFERT.search(l) for l in entre):
            continue  # un freebet ou un bonus offert : pas de l'argent déposé
        mouvements.append(Mouvement(quand, montant(m.group("valeur")), (statut or "Effectué").capitalize(),
                                    moyen, sens or ""))
    return mouvements, avertissements


def deviner_sens(mouvements: list[Mouvement]) -> str:
    """« mixte » si la page donne le sens de chaque mouvement (PMU) ; sinon, une page de dépôts Betclic affiche
    le moyen de paiement, celle des retraits non."""
    if mouvements and all(m.sens for m in mouvements):
        return "page"
    return DEPOT if any(m.moyen for m in mouvements) else RETRAIT
