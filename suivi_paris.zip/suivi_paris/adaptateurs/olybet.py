"""Adaptateur Olybet (olybet.fr) : l'historique des paris, chaque pari ouvert d'un clic (son détail).

La liste ne donne le détail d'un pari qu'une fois cliqué. Le détail, copié (ou lu par l'extension), donne :

    Date25-10-2026 20:50:39                         date du pari
    ID:33874999389297Pari Simple                    référence (la clé anti-doublon), type
    Mise, €0.10
    Cote totale1.340
    Gains potentiels, €0.13
    StatutEn attente des résultats
    Date de l'événement26-10-2026 20:30:00          puis, pour chaque sélection :
    SélectionFootball. France. Ligue 1. Paris Saint-Germain - Olympique Lyonnais
    PariRésultat du match : Equipe 1                marché : choix (« Equipe 1 » : la première équipe nommée)
    Cote1.340

Selon la copie, un libellé et sa valeur sont collés (comme ci-dessus) ou sur deux lignes : la lecture accepte les
deux. Les montants ont un point décimal. Un pari dont le détail n'est pas ouvert n'a pas de référence : il n'est
pas lu (ouvre-le, puis recopie la page ; l'extension relit la page à chaque pari ouvert).
"""
from __future__ import annotations

import re
from datetime import datetime

from ..modeles import (
    ANNULE,
    CASHOUT,
    COMBINE,
    EN_COURS,
    GAGNE,
    INCONNU,
    PERDU,
    SIMPLE,
    SYSTEME,
    Pari,
    Selection,
    categorie_marche,
    sans_accents,
)
from ..sports import normaliser_sport

NOM = "olybet"
LIBELLE = "Olybet"
CONSIGNE = (
    "Sur olybet.fr : Historique des paris, choisis la période (90 jours au plus), puis clique sur chaque pari pour "
    "ouvrir son détail. Copie ensuite la page (Ctrl+A, Ctrl+C, ou le bouton « Copier le texte de la page » de "
    "l'extension) et colle-la ici. Avec l'extension, chaque pari ouvert est enregistré tout seul."
)

_HORODATAGE = r"(\d{2}-\d{2}-\d{4}\s+\d{2}:\d{2}:\d{2})"
_ID = re.compile(r"\bID\s*:\s*(\d{8,})")
# « Date25-10-2026 20:50:39 » (pas « Date de l'événement… ») : le début d'un pari.
_DATE_PARI = re.compile(r"\bDate\s*" + _HORODATAGE)
_DATE_EVENEMENT = re.compile(r"Date de l['’]événement\s*" + _HORODATAGE)
_NOMBRE = r"(\d[\d  ,]*(?:\.\d+)?)"
_MISE = re.compile(r"\bMise\s*,?\s*€?\s*" + _NOMBRE)
_COTE_TOTALE = re.compile(r"\bCote totale\s*(\d+(?:[.,]\d+)?)")
_GAINS = re.compile(r"\bGains?(\s+potentiels?)?\s*,?\s*€?\s*" + _NOMBRE, re.IGNORECASE)
_STATUT = re.compile(r"\bStatut\s*:?\s*([^\n]+)")
_TYPE = re.compile(r"^\s*(?:Pari\s+)?(Simple|Combiné|Multiple|Express|Système)", re.IGNORECASE)
_SELECTION = re.compile(r"\bSélection(?!s)\s*:?\s*([^\n]+)")
_PARI = re.compile(r"\bPari\s*:?\s*([^\n]+)")
_COTE = re.compile(r"\bCote\s*(\d+(?:[.,]\d+)?)")


def reconnait(texte: str) -> bool:
    return "olybet" in texte.lower() or bool(_ID.search(texte) and re.search(r"Cote totale", texte))


def identifiant(texte: str) -> str | None:
    """La page d'historique n'affiche pas d'identifiant de compte (seulement le prénom, dans l'en-tête)."""
    return None


def _montant(brut: str) -> float | None:
    propre = re.sub(r"[\s  ]", "", brut)
    if "," in propre and "." in propre:
        propre = propre.replace(",", "")
    elif "," in propre:
        propre = propre.replace(",", ".") if re.search(r",\d{1,2}$", propre) else propre.replace(",", "")
    try:
        return float(propre)
    except ValueError:
        return None


def _horodatage(brut: str) -> datetime:
    return datetime.strptime(re.sub(r"\s+", " ", brut), "%d-%m-%Y %H:%M:%S")


def _etat(statut: str) -> str:
    s = sans_accents(statut).lower().strip()
    if "cash" in s:
        return CASHOUT
    if s.startswith("gagn"):
        return GAGNE
    if s.startswith("perd"):
        return PERDU
    if "attente" in s or "cours" in s:
        return EN_COURS
    if s.startswith(("rembours", "annul", "nul")):
        return ANNULE
    return INCONNU


def _selections(bloc: str) -> tuple[list[Selection], list[datetime]]:
    """Les sélections du détail : « Sélection … », puis « Pari … » et « Cote … » qui la suivent."""
    selections, dates = [], []
    trouvees = list(_SELECTION.finditer(bloc))
    for n, m in enumerate(trouvees):
        fin = trouvees[n + 1].start() if n + 1 < len(trouvees) else len(bloc)
        suite = bloc[m.end():fin]
        avant = bloc[trouvees[n - 1].end() if n else 0:m.start()]
        dates += [_horodatage(d.group(1)) for d in _DATE_EVENEMENT.finditer(avant)]
        # « Football. France. Ligue 1. Paris Saint-Germain - Olympique Lyonnais » : sport, pays, compétition, match.
        morceaux = [x.strip() for x in re.split(r"\.\s+", m.group(1).strip()) if x.strip()]
        sport_brut = morceaux[0] if len(morceaux) > 1 else ""
        evenement = morceaux[-1] if morceaux else ""
        competition = " - ".join(morceaux[1:-1])
        equipes = [e.strip() for e in evenement.split(" - ")]
        pari = _PARI.search(suite)
        marche, choix = "", ""
        if pari:
            valeur = pari.group(1).strip()
            marche, _, choix = valeur.partition(" : ")
            marche, choix = marche.strip(), choix.strip()
        if len(equipes) == 2 and all(equipes):
            choix = re.sub(r"\b[EÉ]quipe 1\b", equipes[0], choix)
            choix = re.sub(r"\b[EÉ]quipe 2\b", equipes[1], choix)
            evenement = " / ".join(equipes)
        cote = _COTE.search(suite)
        contexte = f"{competition} {evenement}"
        selections.append(Selection(
            sport=normaliser_sport(sport_brut, contexte) if sport_brut else "Autre",
            evenement=evenement, marche=marche, choix=choix, competition=competition,
            cote=_montant(cote.group(1)) if cote else None,
        ))
    if not trouvees:
        dates += [_horodatage(d.group(1)) for d in _DATE_EVENEMENT.finditer(bloc)]
    return selections, dates


def parser(texte: str) -> tuple[list[Pari], list[str]]:
    paris: list[Pari] = []
    avertissements: list[str] = []
    ids = list(_ID.finditer(texte))
    for n, m in enumerate(ids):
        reference = m.group(1)
        # La date du pari : le dernier « Date… » avant sa référence (et après le pari précédent).
        debut_zone = ids[n - 1].end() if n else 0
        dates = [d for d in _DATE_PARI.finditer(texte, debut_zone, m.start())]
        if not dates:
            avertissements.append(f"Olybet {reference} : date du pari introuvable, pari ignoré.")
            continue
        # Le détail s'arrête au pari suivant (sa date, ou sa référence).
        suivant = _DATE_PARI.search(texte, m.end())
        fin = min(suivant.start() if suivant else len(texte), ids[n + 1].start() if n + 1 < len(ids) else len(texte))
        bloc = texte[m.end():fin]
        mise_m = _MISE.search(bloc)
        mise = _montant(mise_m.group(1)) if mise_m else None
        if mise is None:
            avertissements.append(f"Olybet {reference} : mise introuvable, pari ignoré.")
            continue
        cote_m = _COTE_TOTALE.search(bloc)
        cote = _montant(cote_m.group(1)) if cote_m else None
        statut_m = _STATUT.search(bloc)
        statut = statut_m.group(1).strip() if statut_m else ""
        etat = _etat(statut)
        gains_lus = {bool(g.group(1)): _montant(g.group(2)) for g in _GAINS.finditer(bloc)}
        gains_reels, gains_potentiels = gains_lus.get(False), gains_lus.get(True)
        if etat == GAGNE:
            gains = gains_reels if gains_reels is not None else gains_potentiels
        elif etat == PERDU:
            gains = 0.0
        elif etat == ANNULE:
            gains = gains_reels if gains_reels is not None else mise
        elif etat == CASHOUT:
            gains = gains_reels
        else:
            gains = None
        if etat == INCONNU:
            avertissements.append(f"Olybet {reference} : statut « {statut or '?'} » non reconnu.")
        elif etat in (GAGNE, CASHOUT) and gains is None:
            avertissements.append(f"Olybet {reference} : gain introuvable.")

        selections, jours = _selections(bloc)
        if not selections:
            avertissements.append(f"Olybet {reference} : sélection illisible.")
        type_m = _TYPE.match(bloc)
        type_brut = sans_accents(type_m.group(1)).lower() if type_m else ""
        if type_brut.startswith("syst"):
            type_pari = SYSTEME
        elif len(selections) > 1 or type_brut in ("combine", "multiple", "express"):
            type_pari = COMBINE
        else:
            type_pari = SIMPLE
        paris.append(Pari(
            bookmaker=NOM,
            reference=reference,
            date_pari=_horodatage(dates[-1].group(1)),
            type=type_pari,
            etat=etat,
            etat_brut=statut,
            mise=mise,
            gains=round(gains, 2) if gains is not None else None,
            cote_boostee=any(categorie_marche(s.marche) == "Cote boostée" for s in selections),
            nb_selections=max(1, len(selections)),
            selections=selections,
            cote=cote,
            date_evenement=max(jours) if jours else None,
        ))
    return paris, avertissements
