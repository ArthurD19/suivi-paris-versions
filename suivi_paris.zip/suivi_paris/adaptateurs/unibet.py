"""Adaptateur Unibet : page « Mes paris » → onglet « Terminés », copiée en entier (même lecture pour l'ancienne
page « Mes paris précédents », d'avant la fusion avec PSEL).

Un pari s'y lit ainsi, une information par ligne :

    Simple | Combiné (n)                   type (un combiné est suivi d'un résumé « 1 / gagné / 1 / perdu »)
    Compétition de cycling                 sport, en anglais (parfois vide : « Compétition de »)
    Tour de Catalogne - Etape 1            événement (un match : « A.De Minaur », « - », « R.Sakamoto »)
    perdu | gagné | annulé                 état de la sélection (absent quand le pari a été annulé d'office)
    Podium de l'étape :  Brady Gilmore     marché et choix ; « MyBet » regroupe plusieurs choix du même événement
    3,50 | Annulé                          cote de la sélection
    … (autres sélections d'un combiné)
    Cote totale / 3,50
    Mise / 50,00€
    Gains | Remboursement | Pari annulé / 0,00€
    Pari n°2784/2348 | Pari n°Z870182820   référence : la clé anti-doublon (« Z… » depuis la fusion avec PSEL)
    Le 23-03-26 à 12h07                    date du pari

Contrairement à Betclic et Winamax, Unibet affiche les cotes, y compris des paris perdus : elles sont gardées.
"""
from __future__ import annotations

import re
from datetime import datetime

from ..modeles import (
    ANNULE,
    COMBINE,
    EN_COURS,
    GAGNE,
    INCONNU,
    MYCOMBI,
    PERDU,
    SIMPLE,
    SYSTEME,
    Pari,
    Selection,
    categorie_marche,
    montant,
    normaliser_etat,
)
from ..sports import deviner_sport, normaliser_sport

NOM = "unibet"
LIBELLE = "Unibet"
CONSIGNE = (
    "Sur unibet.fr : Mes paris → onglet « Terminés » (paris d'avant la fusion avec PSEL : Mes paris (ancienne "
    "version Unibet) → Mes paris précédents → Terminés). Fais défiler jusqu'aux paris voulus, "
    "sélectionne toute la page (Ctrl+A), copie (Ctrl+C), puis colle ici (Ctrl+V)."
)

_REF = re.compile(r"^Pari n°\s*([A-Z]?\d+(?:/\d+)?)$")
_DATE = re.compile(r"^Le (\d{2})-(\d{2})-(\d{2}) à (\d{2})h(\d{2})$")
_TYPE = re.compile(r"^(Simple|Combiné(?:\s*\((\d+)\))?|Système.*)$")
_COMPETITION = re.compile(r"^Compétition de ?(.*)$")
_ETATS_SELECTION = {"perdu", "gagné", "annulé", "remboursé", "en cours", "cash out", "cashout"}
_COTE = re.compile(r"^\d+(?:[.,]\d+)?$")
_RESUME_COMBINE = re.compile(r"^(\d+|perdu|gagné|annulé|remboursé|en cours)$")


# Le favori lit la page telle qu'affichée : le site y met certains libellés en capitales (« SIMPLE »).
_LIBELLES = {l.lower(): l for l in ("Cote totale", "Mise", "Gains", "Gains potentiels", "Remboursement",
                                    "Pari annulé", "MyBet")}
_TYPE_LIBRE = re.compile(r"^(simple|combin[ée].*|syst[èe]me.*)$", re.IGNORECASE)


def _canonique(ligne: str) -> str:
    """« SIMPLE » -> « Simple », « COTE TOTALE » -> « Cote totale » ; les autres lignes restent telles quelles."""
    if ligne.lower() in _LIBELLES:
        return _LIBELLES[ligne.lower()]
    if _TYPE_LIBRE.match(ligne) and not _TYPE.match(ligne):
        return ligne.capitalize()
    return ligne


def reconnait(texte: str) -> bool:
    return bool(re.search(r"^Pari n°\s*[A-Z]?\d+(?:/\d+)?$", texte, re.MULTILINE)) or "unibet" in texte.lower()


def identifiant(texte: str) -> str | None:
    """La page Unibet copiée n'affiche pas le pseudo du compte."""
    return None


def _cote(ligne: str) -> float | None:
    return float(ligne.replace(",", ".")) if _COTE.match(ligne) else None


def _sport(brut: str, marche: str, choix: str, evenement: str) -> str:
    nom = brut.split(" -")[0].strip()  # « football -europe » -> « football »
    if not nom:
        return deviner_sport(marche, choix, evenement)
    connu = normaliser_sport(nom, f"{evenement} {marche}")
    return connu if connu != nom else nom.capitalize()


def _evenement(ligne: str) -> str:
    return re.sub(r"\s*-\s*LIVE$", "", ligne).strip()


def _lire_choix(ligne: str) -> tuple[str, str]:
    # Le choix suit le dernier « : » : « CB : Danemark et Pologne marquent… - 90 Mins :  Oui » -> « Oui ».
    marche, _, choix = ligne.rpartition(" : ")
    return re.sub(r"\s+", " ", marche).strip(), re.sub(r"\s+", " ", choix).strip()


def _lire_selections(lignes: list[str], ref: str, avertissements: list[str]) -> tuple[list[Selection], list[str], bool]:
    """Renvoie (sélections, états lus, True si c'est un « MyBet » : plusieurs choix d'un même événement)."""
    selections: list[Selection] = []
    etats: list[str] = []
    mybet = False
    i = 0
    while i < len(lignes):
        m = _COMPETITION.match(lignes[i])
        if not m:
            i += 1
            continue
        sport_brut = m.group(1)
        evenement = _evenement(lignes[i + 1]) if i + 1 < len(lignes) else ""
        j = i + 2
        # Un match s'affiche sur trois lignes : « A.De Minaur », « - », « R.Sakamoto ».
        if j + 1 < len(lignes) and lignes[j] == "-":
            evenement = f"{evenement} / {_evenement(lignes[j + 1])}"
            j += 2
        if j < len(lignes) and lignes[j].lower() in _ETATS_SELECTION:
            etats.append(lignes[j].lower())
            j += 1
        if j < len(lignes) and lignes[j] == "MyBet":
            mybet = True
            j += 1
            if j < len(lignes) and lignes[j].startswith("Cote totale"):
                j += 1
        trouve = False
        while j < len(lignes) and not _COMPETITION.match(lignes[j]):
            ligne = lignes[j]
            if " : " in ligne:
                marche, choix = _lire_choix(ligne)
                cote = None
                if j + 1 < len(lignes) and (_cote(lignes[j + 1]) is not None or lignes[j + 1] == "Annulé"):
                    cote = _cote(lignes[j + 1])
                    j += 1
                elif j + 1 < len(lignes) and lignes[j + 1].lower() in _ETATS_SELECTION:
                    etats.append(lignes[j + 1].lower())  # MyBet : un état après chaque choix
                    j += 1
                sport = _sport(sport_brut, marche, choix, evenement)
                etape = re.search(r"[ÉE]tape (\d+)", evenement)
                selections.append(Selection(sport, evenement, marche, choix, evenement,
                                            int(etape.group(1)) if etape else None, cote))
                trouve = True
            j += 1
        if not trouve:
            avertissements.append(f"Unibet {ref} : sélection sans choix lisible ({evenement or 'événement inconnu'}).")
        i = j
    return selections, etats, mybet


def parser(texte: str) -> tuple[list[Pari], list[str]]:
    """Renvoie (paris, avertissements)."""
    lignes = [_canonique(l.strip()) for l in texte.splitlines()]
    paris: list[Pari] = []
    avertissements: list[str] = []
    debut = 0
    for r, ligne in enumerate(lignes):
        ref_m = _REF.match(ligne)
        if not ref_m:
            continue
        reference = ref_m.group(1)
        bloc, debut = lignes[debut:r], r + 2
        date_m = _DATE.match(lignes[r + 1]) if r + 1 < len(lignes) else None
        if not date_m:
            avertissements.append(f"Unibet {reference} : date du pari introuvable, pari ignoré.")
            continue
        j, mo, a, h, mi = (int(x) for x in date_m.groups())
        date_pari = datetime(2000 + a, mo, j, h, mi)

        utiles = [l for l in bloc if l]
        # Le début du pari est sa ligne de type (« Simple », « Combiné (2) ») : la dernière avant « Cote totale ».
        # Ce qui précède (menus du site, compétitions favorites…) est ignoré.
        fin = utiles.index("Cote totale") if "Cote totale" in utiles else len(utiles)
        t = next((i for i in range(fin - 1, -1, -1) if _TYPE.match(utiles[i])), None)
        if t is None:
            avertissements.append(f"Unibet {reference} : type du pari introuvable, pari ignoré.")
            continue
        type_m = _TYPE.match(utiles[t])
        corps = utiles[t + 1 :]

        try:
            i_total = corps.index("Cote totale")
            i_mise = corps.index("Mise", i_total)
        except ValueError:
            avertissements.append(f"Unibet {reference} : cote ou mise introuvable, pari ignoré.")
            continue
        cote_totale = _cote(corps[i_total + 1]) if i_total + 1 < len(corps) else None
        mise = montant(corps[i_mise + 1]) if i_mise + 1 < len(corps) else None
        libelle = corps[i_mise + 2] if i_mise + 2 < len(corps) else ""
        valeur = montant(corps[i_mise + 3]) if i_mise + 3 < len(corps) else None
        if mise is None:
            avertissements.append(f"Unibet {reference} : montant de la mise illisible, pari ignoré.")
            continue

        selections, etats, mybet = _lire_selections(corps[:i_total], reference, avertissements)

        libelle_min = libelle.lower()
        if libelle_min.startswith(("remboursement", "pari annulé")):
            etat, gains = ANNULE, valeur
        elif "potentiel" in libelle_min or "en cours" in etats:
            etat, gains = EN_COURS, None
        elif libelle_min.startswith("gains") and valeur is not None and valeur > 0:
            etat, gains = GAGNE, valeur
        elif libelle_min.startswith("gains") and valeur == 0:
            etat, gains = PERDU, 0.0
        else:
            etat, gains = normaliser_etat(etats[0]) if etats else INCONNU, valeur
            if etat == INCONNU:
                avertissements.append(f"Unibet {reference} : état du pari non reconnu.")
        etat_brut = libelle if etat == ANNULE else (etats[0] if etats else libelle)

        if type_m.group(1).startswith("Combiné"):
            type_pari = MYCOMBI if mybet and len({s.evenement for s in selections}) == 1 else COMBINE
        elif type_m.group(1).startswith("Système"):
            type_pari = SYSTEME
        else:
            type_pari = MYCOMBI if mybet else SIMPLE

        boost = any(categorie_marche(s.marche) == "Cote boostée" for s in selections)
        paris.append(
            Pari(
                bookmaker=NOM,
                reference=reference,
                date_pari=date_pari,
                type=type_pari,
                etat=etat,
                etat_brut=etat_brut,
                mise=mise,
                gains=gains,
                cote_boostee=boost,
                nb_selections=max(1, len(selections)),
                selections=selections,
                # Un pari annulé d'office affiche « Cote totale 1,00 » : ce n'est pas sa vraie cote.
                cote=None if etat == ANNULE and cote_totale == 1.0 else cote_totale,
            )
        )
    return paris, avertissements

