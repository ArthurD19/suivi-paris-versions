"""Adaptateur PIWI247 : même logiciel que ps3838 (page « Mes paris », statut « Réglé »), même lecture.

Seule différence vue : la colonne « Gain » (ps3838 : « Gain/Perte » et « Commission »). Le lecteur ps3838 reconnaît
un gain net comme un gain brut (voir ps3838.parser). La partie « exchange » du site n'est pas encore lue.
"""
from __future__ import annotations

import re

from . import ps3838
from .ps3838 import _ENTETE_PIWI

NOM = "piwi247"
LIBELLE = "PIWI247"
MEME_PAGE = "ps3838"  # un collage sur un compte PIWI247 que l'on prendrait pour du ps3838 est du PIWI247
CONSIGNE = (
    "Sur PIWI247 : Mes paris, statut « Réglé », puis Recherche (comme ps3838). Sélectionne toute la page (Ctrl+A), "
    "copie (Ctrl+C), puis colle ici (Ctrl+V). Pour tout l'historique, utilise l'extension."
)


def reconnait(texte: str) -> bool:
    return bool(_ENTETE_PIWI.search(texte)) and "ps3838" not in texte.lower()


def identifiant(texte: str) -> str | None:
    """Le numéro de compte (« PIW_73078 ») s'il est dans la page."""
    m = re.search(r"\b(PIW_\d{3,})\b", texte)
    return m.group(1) if m else None


def parser(texte: str):
    return ps3838.parser(texte, nom=NOM, libelle=LIBELLE)
