"""Adaptateur Betclic : page « Mes paris » (onglet des paris terminés ou en cours), copiée en entier.

Un pari s'y lit ainsi, une information par ligne :

    Simple | Combiné (n)          type
    Gagné | Perdu | Annulé | …    état
    <choix>                       ex. « Pello Bilbao », « + de 9,5 », ou « MYCOMBI » puis des paires choix/marché
    <marché>                      ex. « Top 10 », « Nombre total d'aces dans le match »
    Sam. 10/10 11:00              date de l'événement
    <événement>                   nom de la course, ou les deux équipes avec leurs scores
    Mise / 50,00 € / Gains / 275,00 €
    Réf 6ac9fa2d9d1efd1046af73ce  référence : la clé anti-doublon
    10/10/2026 10:41              date du pari

Betclic n'affiche pas le sport : il est deviné (voir sports.py). La cote d'un pari en cours est affichée à côté du
choix (« 200 »), sinon elle se déduit des « Gains possibles » (gains possibles / mise) : elle est gardée quand le
pari se règle, car l'onglet « Terminés » ne la montre plus (sauf, pour un pari gagné, gains / mise). Les combinés
n'affichent pas leurs sélections.

Freebet : la mise est offerte (une icône « F » devant elle, qui ne se copie pas) et les gains ne la rendent pas :
18,75 € à 13 donnent « Gains possibles 225,00 € » (18,75 × 12). Le pari se reconnaît ainsi : les gains valent
mise × (cote affichée − 1), et non mise × cote.
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

from ..modeles import (
    COMBINE,
    EN_COURS,
    GAGNE,
    INCONNU,
    MYCOMBI,
    SIMPLE,
    SYSTEME,
    Pari,
    Selection,
    categorie_marche,
    montant,
    normaliser_etat,
)
from ..sports import deviner_sport

NOM = "betclic"
LIBELLE = "Betclic"
CONSIGNE = (
    "Sur betclic.fr : Mes paris → onglet « Terminés », et « En cours » (la cote s'y lit). Fais défiler jusqu'aux paris "
    "voulus, sélectionne toute la page (Ctrl+A), copie (Ctrl+C), puis colle ici (Ctrl+V). Pour tout "
    "l'historique sans faire défiler à la main, utilise le favori."
)

_TYPE = re.compile(r"^(Simple|Combiné(?:\s*\((\d+)\))?|Système.*)$")
_REF = re.compile(r"^Réf\.?\s*:?\s*([0-9A-Za-z][0-9A-Za-z-]{7,})$")
_DATE_PARI = re.compile(r"^(\d{2}/\d{2}/\d{4})\s+(\d{2}:\d{2})$")
_DATE_EVT = re.compile(
    r"^(?:(?P<rel>Aujourd['’]hui|Hier|Demain)|(?:Lun|Mar|Mer|Jeu|Ven|Sam|Dim)\.?\s+(?P<j>\d{2})/(?P<m>\d{2}))"
    r"\s+(?P<h>\d{2}):(?P<min>\d{2})$"
)
_NOMBRE = re.compile(r"^\d+$")
_GAINS_POSSIBLES = re.compile(r"^Gains (potentiels|possibles)", re.IGNORECASE)
_COTE_SEULE = re.compile(r"^\d+(?:,\d{1,2})?$")
_FREEBET = re.compile(r"^(free ?bets?|mise offerte|pari offert)$", re.IGNORECASE)
_SCORE_TIRET = re.compile(r"^\d+\s*-\s*\d+$")
_BUT = re.compile(r"\d+'(\+\d+)?$")  # « K. Mbappé 54' » : un buteur sous un match de foot


def reconnait(texte: str) -> bool:
    return bool(re.search(r"^Réf\s+[0-9a-f]{16,}", texte, re.MULTILINE)) or "betclic" in texte.lower()


def identifiant(texte: str) -> str | None:
    """La page Betclic copiée n'affiche pas le nom du compte."""
    return None


def _date_evenement(m: re.Match, date_pari: datetime, aujourd_hui: date, regle: bool = False) -> datetime | None:
    """Betclic écrit « 24/05 » sans l'année : c'est celle qui place l'événement juste après le pari (ou quelques
    heures avant, pour un pari en direct). Un pari réglé a eu lieu : son événement n'est jamais dans le futur ; s'il
    n'en a pas après le pari (Betclic affiche parfois le début d'une compétition), la date la plus proche du pari."""
    heure, minute = int(m["h"]), int(m["min"])
    if m["rel"]:
        rel = m["rel"].lower()
        decalage = 0 if rel.startswith("aujourd") else (-1 if rel == "hier" else 1)
        jour = aujourd_hui + timedelta(days=decalage)
        return datetime(jour.year, jour.month, jour.day, heure, minute)
    jour, mois = int(m["j"]), int(m["m"])
    candidats = []
    for annee in (date_pari.year, date_pari.year + 1, date_pari.year - 1):
        try:
            candidats.append(datetime(annee, mois, jour, heure, minute))
        except ValueError:
            continue
    if regle:
        limite = datetime(aujourd_hui.year, aujourd_hui.month, aujourd_hui.day) + timedelta(days=2)
        candidats = [c for c in candidats if c <= limite]
    apres = [c for c in candidats if c >= date_pari - timedelta(days=2) and c - date_pari < timedelta(days=330)]
    if apres:
        return min(apres, key=lambda c: c - date_pari)
    if regle and candidats:
        return min(candidats, key=lambda c: abs(c - date_pari))
    return None


def _lire_evenement(lignes: list[str]) -> tuple[str, list[int], bool]:
    """Renvoie (événement, scores numériques, score au format « 1 - 4 »)."""
    if not lignes:
        return "", [], False
    nombres = [int(l) for l in lignes if _NOMBRE.match(l)]
    tiret = any(_SCORE_TIRET.match(l) for l in lignes)
    if nombres or tiret:
        noms = [l for l in lignes if not _NOMBRE.match(l) and not _SCORE_TIRET.match(l) and not _BUT.search(l)]
        return " / ".join(noms[:2]), nombres, tiret
    return lignes[0], [], False


def parser(texte: str, aujourd_hui: date | None = None) -> tuple[list[Pari], list[str]]:
    """Renvoie (paris, avertissements). `aujourd_hui` sert à dater « Aujourd'hui » et « Hier »."""
    aujourd_hui = aujourd_hui or date.today()
    lignes = [l.strip() for l in texte.splitlines()]
    # L'extension et le favori lisent l'icône « F » d'un freebet comme le mot « Freebet », seul ou devant la mise
    # (« Freebet 18,75 € ») : il devient une ligne à lui.
    lignes = [x for l in lignes for x in _sans_marque(l)]
    paris: list[Pari] = []
    avertissements: list[str] = []

    debut = 0
    for r, ligne in enumerate(lignes):
        ref = _REF.match(ligne)
        if not ref:
            continue
        bloc, debut = lignes[debut:r], r + 2
        reference = ref.group(1)

        date_m = _DATE_PARI.match(lignes[r + 1]) if r + 1 < len(lignes) else None
        if not date_m:
            avertissements.append(f"Betclic {reference} : date du pari introuvable, pari ignoré.")
            continue
        date_pari = datetime.strptime(f"{date_m.group(1)} {date_m.group(2)}", "%d/%m/%Y %H:%M")

        # Début du pari : une ligne de type suivie d'un état reconnu (ce qui précède est l'en-tête du site).
        # Onglet « En cours » : pas d'état écrit sous le type, mais des « Gains possibles » plus bas.
        t = next(
            (
                i
                for i in range(len(bloc) - 1)
                if _TYPE.match(bloc[i]) and normaliser_etat(bloc[i + 1]) != INCONNU
            ),
            None,
        )
        sans_etat = False
        if t is None and any(_GAINS_POSSIBLES.match(l) for l in bloc):
            t = max((i for i in range(len(bloc)) if _TYPE.match(bloc[i])), default=None)
            sans_etat = t is not None
        if t is None:
            avertissements.append(f"Betclic {reference} : type ou état du pari introuvable, pari ignoré.")
            continue
        type_m = _TYPE.match(bloc[t])
        if sans_etat:
            etat_brut, etat, corps = "En cours", EN_COURS, bloc[t + 1 :]
        else:
            etat_brut = bloc[t + 1]
            etat = normaliser_etat(etat_brut)
            corps = bloc[t + 2 :]

        if "Mise" not in corps:
            avertissements.append(f"Betclic {reference} : mise introuvable, pari ignoré.")
            continue
        im = corps.index("Mise")
        if im + 1 < len(corps) and _FREEBET.match(corps[im + 1]):
            corps = corps[:im + 1] + corps[im + 2:] + ["Freebet"]  # « Mise / Freebet / 18,75 € »
        mise = montant(corps[im + 1]) if im + 1 < len(corps) else None
        gains = potentiel = None
        for j in range(im + 2, len(corps) - 1):
            if corps[j].startswith("Gains"):
                if _GAINS_POSSIBLES.match(corps[j]):
                    potentiel = _montant_lisible(corps[j + 1])
                elif etat != EN_COURS:
                    gains = montant(corps[j + 1])
                break
        if mise is None:
            avertissements.append(f"Betclic {reference} : montant de la mise illisible, pari ignoré.")
            continue
        contenu = [l for l in corps[:im] if l and not l.startswith("Pourquoi mon pari") and not _FREEBET.match(l)]
        cote_affichee = _cote_affichee(contenu, type_m.group(1))
        freebet = any(_FREEBET.match(l) for l in corps) or _rend_pas_la_mise(
            mise, potentiel if etat == EN_COURS else (gains if etat == GAGNE else None), cote_affichee)
        # Cote : celle affichée, sinon gains potentiels / mise (c'est ce que Betclic multiplie ; un freebet ne rend
        # pas sa mise, d'où le + 1).
        cote = cote_affichee or (round(potentiel / mise + (1 if freebet else 0), 2) if potentiel and mise else None)

        # Combiné : Betclic n'affiche que « Cote totale », pas les sélections.
        if type_m.group(1).startswith("Combiné"):
            nb = int(type_m.group(2)) if type_m.group(2) else 2
            paris.append(
                Pari(NOM, reference, date_pari, COMBINE, etat, etat_brut, mise, gains, nb_selections=nb, cote=cote,
                     freebet=freebet)
            )
            continue
        type_pari = SYSTEME if type_m.group(1).startswith("Système") else SIMPLE

        id_ = next((i for i, l in enumerate(contenu) if _DATE_EVT.match(l)), None)
        avant = contenu if id_ is None else contenu[:id_]
        if len(avant) > 2 and avant[0].upper() != "MYCOMBI":
            # La cote affichée à côté du choix (« 200 »), quand la copie la reprend : elle se recalcule par la mise.
            avant = [l for l in avant if not _COTE_SEULE.match(l)]
        apres = [] if id_ is None else contenu[id_ + 1 :]
        date_evt = (_date_evenement(_DATE_EVT.match(contenu[id_]), date_pari, aujourd_hui, regle=etat != EN_COURS)
                    if id_ is not None else None)
        evenement, scores, tiret = _lire_evenement(apres)

        if avant and avant[0].upper() == "MYCOMBI":
            type_pari = MYCOMBI
            paires = [(avant[i], avant[i + 1] if i + 1 < len(avant) else "") for i in range(1, len(avant), 2)]
        else:
            paires = [(avant[0] if avant else "", avant[1] if len(avant) > 1 else "")]
            if len(avant) > 2:
                avertissements.append(f"Betclic {reference} : lignes inattendues dans la sélection, vérifie ce pari.")

        texte_marches = " ".join(m for _, m in paires)
        texte_choix = " ".join(c for c, _ in paires)
        sport = deviner_sport(texte_marches, texte_choix, evenement, scores, tiret)
        etape = re.search(r"[ÉE]tape (\d+)", evenement)
        competition = "" if (scores or tiret) else evenement
        selections = [
            Selection(sport, evenement, marche, choix, competition, int(etape.group(1)) if etape else None)
            for choix, marche in paires
        ]
        boost = any(categorie_marche(s.marche) == "Cote boostée" for s in selections)
        paris.append(
            Pari(
                bookmaker=NOM,
                reference=reference,
                date_pari=date_pari,
                type=type_pari,
                etat=etat,
                etat_brut=etat_brut,
                mise=mise,
                gains=gains,
                cote_boostee=boost,
                nb_selections=len(selections),
                date_evenement=date_evt,
                selections=selections,
                cote=cote,
                sport_devine=True,
                freebet=freebet,
            )
        )
    return paris, avertissements


def _sans_marque(ligne: str) -> list[str]:
    """« Freebet 18,75 € » -> [« Freebet », « 18,75 € »]."""
    m = re.match(r"^Freebet\s+(\S.*)$", ligne)
    return ["Freebet", m.group(1)] if m else [ligne]


def _cote_affichee(contenu: list[str], type_brut: str) -> float | None:
    """La cote que Betclic affiche (quand la copie la reprend) : la ligne « 13 » sous le choix et le marché, ou la
    valeur de « Cote totale » d'un combiné."""
    if type_brut.startswith("Combiné"):
        k = contenu.index("Cote totale") if "Cote totale" in contenu else None
        brut = contenu[k + 1] if k is not None and k + 1 < len(contenu) else ""
    else:
        k_evt = next((i for i, l in enumerate(contenu) if _DATE_EVT.match(l)), len(contenu))
        avant = contenu[:k_evt]
        if len(avant) <= 2 or avant[0].upper() == "MYCOMBI":
            return None
        brut = next((l for l in avant[2:] if _COTE_SEULE.match(l)), "")
    if not _COTE_SEULE.match(brut):
        return None
    cote = float(brut.replace(",", "."))
    return cote if cote >= 1 else None


def _rend_pas_la_mise(mise: float | None, gains: float | None, cote: float | None) -> bool:
    """Les gains valent mise × (cote − 1) au centime près, et non mise × cote : la mise était offerte."""
    if not (mise and gains and cote) or cote <= 1:
        return False
    return abs(gains - mise * (cote - 1)) <= 0.011 and abs(gains - mise * cote) > 0.011


def _montant_lisible(texte: str) -> float | None:
    try:
        return montant(texte)
    except ValueError:
        return None
