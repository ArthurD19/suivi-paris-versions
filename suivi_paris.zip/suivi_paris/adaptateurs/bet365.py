"""Adaptateur bet365 : Mon compte → Mon activité → Historique → « Paris terminés » (ou « Paris en cours »).

bet365 empêche de sélectionner le texte de ses pages : Ctrl+A ne prend rien. L'extension Suivi Paris lit la page
quand même (elle relève le texte affiché, sans sélection), et son bouton « Copier le texte de la page » le met
dans le presse-papiers pour un collage à la main.

« Mes paris » (en haut du site) n'affiche les détails d'un pari qu'après un clic : c'est l'historique du compte
qui est lu, où chaque pari est déplié. Un pari s'y lit ainsi :

    15/10/2026 10:04:52                          date et heure du pari, à la seconde
    Pari personnalisé                            type : Simple, Pari personnalisé (même match), Double, Système…
    2,55                                         cote totale
    Brisbane Bullets vs SE Melbourne Phoenix     événement
    Tyrell Harrison - 20 points ou plus          sélection…
    Points                                       … et son marché, pour chaque sélection
    50,00 € Pari personnalisé @ 2,55             résumé : mise, type, cote
    …
    Kevin Vermaerke                              un simple : la sélection seule, sans marché ni événement
    201,00
    10,00 € Simple                               son résumé n'a pas de « @ cote »
    Mise 50,00 €
    Gains 0,00 €                                 « Gains potentiels » tant que le pari est en cours
    Informations du pari

La page n'affiche pas de référence de pari : la clé anti-doublon est la date à la seconde et la mise
(« 20261015100452-50.00 »), qui ne changent pas quand le pari passe d'« en cours » à « terminé ».
L'état se déduit des gains : 0 € perdu, la mise rendue remboursé, mise × cote gagné, tout autre montant cash-out
(encaissé avant la fin : 39,42 € pour 10 € à 201). Le sport n'est pas affiché : il est deviné (« Autre » s'il ne se reconnaît pas).
"""
from __future__ import annotations

import re
from datetime import datetime

from ..modeles import (
    ANNULE,
    CASHOUT,
    COMBINE,
    EN_COURS,
    GAGNE,
    MYCOMBI,
    PERDU,
    SIMPLE,
    SYSTEME,
    Pari,
    Selection,
    montant,
    normaliser_etat,
)
from ..sports import deviner_sport

NOM = "bet365"
LIBELLE = "bet365"
CONSIGNE = (
    "Sur bet365.fr : Mon compte → Mon activité → Historique → « Paris terminés » (et « Paris en cours »). "
    "Le site empêche de sélectionner le texte : l'extension Suivi Paris lit la page toute seule, ou copie son texte "
    "avec son bouton « Copier le texte de la page », à coller ici."
)

_DATE = re.compile(r"^(\d{2})/(\d{2})/(\d{4})\s+(\d{2}):(\d{2})(?::(\d{2}))?$")
_SOMME = r"\d{1,3}(?:[ .]?\d{3})*,\d{2}"
_RESUME = re.compile(rf"^({_SOMME})\s*€\s*(.+?)(?:\s*@\s*(\d+(?:[.,]\d+)?))?$")  # « @ cote » absent d'un simple
_MISE = re.compile(rf"^Mise\s*:?\s*({_SOMME})\s*€?$", re.IGNORECASE)
_GAINS = re.compile(rf"^(Gains(?: potentiels)?|Retour(?: potentiel)?)\s*:?\s*({_SOMME})\s*€?$", re.IGNORECASE)
_COTE = re.compile(r"^\d+(?:,\d+)?$")
_LIBELLES = ("Mise", "Gains", "Gains potentiels", "Retour", "Retour potentiel")
_ETATS = {"gagné", "perdu", "remboursé", "annulé", "cash out", "cash-out", "encaissé", "en cours"}
_TYPE_LIBELLE = re.compile(r"^(Simple|Pari personnalisé|Double|Triple|Quadruple|Combiné.*|Multiple.*|\d+ ?fois.*|Système.*|Trixie|Patent|Yankee|Super Yankee|Lucky \d+|Canadian|Heinz|Super Heinz|Goliath)$", re.IGNORECASE)
_FIN = {"Informations du pari", "Informations sur le pari"}


def reconnait(texte: str) -> bool:
    if "bet365" in texte.lower():
        return True
    return bool(re.search(r"^Paris (terminés|en cours) - Sports$", texte, re.MULTILINE)) and bool(
        re.search(r"^\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2}$", texte, re.MULTILINE)
    )


def identifiant(texte: str) -> str | None:
    """L'historique bet365 n'affiche pas le nom du compte."""
    return None


def _lignes(texte: str) -> list[str]:
    """Une ligne par information, quelle que soit la façon dont la page a été relevée : « 50,00 » et « € » sur deux
    lignes, ou « Mise » seule au-dessus de son montant, sont recollés."""
    brutes = [re.sub(r"\s+", " ", l).strip() for l in texte.splitlines()]
    lignes: list[str] = []
    for l in brutes:
        if not l:
            continue
        if lignes and (l.startswith("€") or (lignes[-1] in _LIBELLES and re.match(_SOMME, l))):
            lignes[-1] = f"{lignes[-1]} {l}"
        else:
            lignes.append(l)
    return lignes


def _type(libelle: str, nb: int) -> str:
    l = libelle.lower()
    if l.startswith("simple"):
        return SIMPLE
    if "personnalis" in l or "même match" in l:
        return MYCOMBI
    if re.search(r"syst|trixie|patent|yankee|lucky|canadian|heinz|goliath|super ?yankee", l):
        return SYSTEME
    if re.search(r"double|triple|quadruple|combin|multiple|\d+ ?fois|accumul", l):
        return COMBINE
    return COMBINE if nb > 1 else SIMPLE


_VS = re.compile(r"\s+(?:vs?\.?|contre)\s+", re.IGNORECASE)


def _evenement(texte: str) -> str:
    return _VS.sub(" / ", texte)


def _etat(bloc: list[str], mise: float, gains: float | None, libelle_gains: str, cote: float | None) -> tuple[str, str]:
    for l in bloc:
        if l.lower() in _ETATS:
            return normaliser_etat(l.replace("Encaissé", "cash")), l
    if gains is None or "potentiel" in libelle_gains.lower():
        return EN_COURS, "En cours"
    if gains == 0:
        return PERDU, "Gains 0,00 €"
    if abs(gains - mise) < 0.005:
        return ANNULE, "Mise rendue"
    # Gagné : mise × cote. D'autres gains (39,42 € pour 10 € à 201) : le pari a été encaissé avant la fin.
    if cote is None or abs(gains - mise * cote) <= max(0.02, 0.01 * gains):
        return (GAGNE, f"Gains {gains:.2f} €") if gains > mise else (CASHOUT, f"Gains {gains:.2f} € (moins que la mise)")
    return CASHOUT, f"Gains {gains:.2f} € (cash-out : mise × cote = {mise * cote:.2f} €)"


def _lire_bloc(date_pari: datetime, bloc: list[str], page_en_cours: bool) -> Pari | None:
    resume = next((i for i, l in enumerate(bloc) if _RESUME.match(l)), None)
    mise_ligne = next((_MISE.match(l) for l in bloc if _MISE.match(l)), None)
    gains_ligne = next((_GAINS.match(l) for l in bloc if _GAINS.match(l)), None)
    fin_entete = resume if resume is not None else next(
        (i for i, l in enumerate(bloc) if _MISE.match(l) or _GAINS.match(l) or l in _FIN), len(bloc))

    libelle = cote = mise = None
    if resume is not None:
        m = _RESUME.match(bloc[resume])
        mise, libelle = montant(m.group(1)), m.group(2).strip()
        cote = float(m.group(3).replace(",", ".")) if m.group(3) else None
    if mise_ligne:
        mise = montant(mise_ligne.group(1))
    if mise is None:
        return None

    # En-tête d'un pari à plusieurs sélections : type, cote totale, événement, puis chaque sélection et son marché.
    # Celui d'un simple : la sélection (« Kevin Vermaerke ») et la cote, sans marché ni événement affichés.
    entete = [l for l in bloc[:fin_entete] if l.lower() not in _ETATS]
    cotes = [l for l in entete if _COTE.match(l)]
    if cote is None and cotes:
        cote = float(cotes[0].replace(",", "."))
    entete = [l for l in entete if not _COTE.match(l)]
    if entete and (entete[0] == libelle or _TYPE_LIBELLE.match(entete[0])):
        libelle = libelle or entete[0]
        entete = entete[1:]
    selections = []
    if _type(libelle or "", 1) == SIMPLE and entete:
        choix = entete[0]
        evenement = next((_evenement(l) for l in entete[1:] if _VS.search(l)), "")
        marche = next((l for l in entete[1:] if not _VS.search(l)), "")
        selections.append(Selection(deviner_sport(marche, choix, evenement) or "Autre", evenement, marche, choix,
                                    evenement))
        entete = []
    evenement = _evenement(entete[0]) if entete else ""
    reste = entete[1:]
    for k in range(0, len(reste), 2):
        choix = reste[k]
        marche = reste[k + 1] if k + 1 < len(reste) else ""
        sport = deviner_sport(marche, choix, evenement)
        selections.append(Selection(sport or "Autre", evenement, marche, choix, evenement))
    if not selections and evenement:
        selections.append(Selection(deviner_sport("", "", evenement) or "Autre", evenement, "", "", evenement))

    gains = montant(gains_ligne.group(2)) if gains_ligne else None
    libelle_gains = gains_ligne.group(1) if gains_ligne else ""
    if gains_ligne is None and page_en_cours:
        libelle_gains = "potentiel"
    etat, etat_brut = _etat(bloc, mise, gains, libelle_gains, cote)
    if etat == EN_COURS:
        gains = None
    type_pari = _type(libelle or "", len(selections))
    return Pari(
        bookmaker=NOM,
        reference=f"{date_pari:%Y%m%d%H%M%S}-{mise:.2f}",
        date_pari=date_pari,
        type=type_pari,
        etat=etat,
        etat_brut=etat_brut,
        mise=mise,
        gains=gains,
        nb_selections=max(len(selections), 1),
        selections=selections,
        cote=cote,
        sport_devine=True,
    )


def parser(texte: str) -> tuple[list[Pari], list[str]]:
    lignes = _lignes(texte)
    page_en_cours = any(re.match(r"^Paris en cours - Sports$", l) for l in lignes)
    paris: list[Pari] = []
    avertissements: list[str] = []
    debuts = [i for i, l in enumerate(lignes) if _DATE.match(l)]
    for n, i in enumerate(debuts):
        j, mo, a, h, mi, s = _DATE.match(lignes[i]).groups()
        date_pari = datetime(int(a), int(mo), int(j), int(h), int(mi), int(s or 0))
        bloc = lignes[i + 1:debuts[n + 1] if n + 1 < len(debuts) else len(lignes)]
        pari = _lire_bloc(date_pari, bloc, page_en_cours)
        if pari is None:
            if any(_RESUME.match(l) or l.startswith("Mise") for l in bloc):
                avertissements.append(f"Pari du {lignes[i]} : mise illisible, ignoré.")
            continue
        paris.append(pari)
    if not paris:
        avertissements.append("Aucun pari bet365 lu : ouvre Historique → « Paris terminés » dans ton compte bet365.")
    return paris, avertissements
