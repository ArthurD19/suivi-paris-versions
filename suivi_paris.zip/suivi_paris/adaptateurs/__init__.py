"""Un adaptateur par bookmaker. Chacun expose :

- NOM, LIBELLE, CONSIGNE (où copier l'historique sur le site) ;
- reconnait(texte) -> bool ;
- identifiant(texte) -> str | None : le pseudo du compte s'il figure dans la page copiée ;
- parser(texte) -> (list[Pari], list[str] avertissements).

Ajouter un bookmaker = écrire un module sur ce modèle et l'ajouter à ADAPTATEURS.
"""
from __future__ import annotations

import inspect
from datetime import date
from types import ModuleType

from . import bet365, betclic, bwin, netbet, olybet, orbitx, piwi247, pmu, ps3838, sportaza, unibet, winamax

ADAPTATEURS: dict[str, ModuleType] = {m.NOM: m for m in (betclic, pmu, piwi247, ps3838, unibet, winamax, bet365, olybet, bwin, sportaza, netbet, orbitx)}


def detecter(texte: str) -> str | None:
    """Renvoie le nom du bookmaker reconnu, ou None."""
    for nom, module in ADAPTATEURS.items():
        if module.reconnait(texte):
            return nom
    return None


# Espaces insécables (et fines) : un copier-coller les change en espaces ordinaires, mais pas un favori, qui relève
# la page telle qu'affichée (« Epreuve :\u00a0 Thibaud Gruel »). On les ramène tous à une espace ordinaire.
_ESPACES = str.maketrans({"\u00a0": " ", "\u202f": " ", "\u2007": " ", "\u2009": " "})


def parser(texte: str, bookmaker: str | None = None, aujourd_hui: date | None = None):
    """Analyse un texte collé. Renvoie (bookmaker, paris, avertissements).

    `aujourd_hui` : le jour où la page a été lue, pour les dates relatives (« Aujourd'hui », « Hier » chez Betclic)
    d'une page lue un autre jour que celui de l'import (l'extension garde les pages tant que l'appli est fermée)."""
    texte = texte.translate(_ESPACES)
    nom = bookmaker or detecter(texte)
    if nom is None:
        return None, [], ["Bookmaker non reconnu : choisis-le dans la liste."]
    lire = ADAPTATEURS[nom].parser
    if aujourd_hui is not None and "aujourd_hui" in inspect.signature(lire).parameters:
        paris, avertissements = lire(texte, aujourd_hui=aujourd_hui)
    else:
        paris, avertissements = lire(texte)
    return nom, dedoublonner(paris), avertissements


def dedoublonner(paris):
    """Un même pari peut apparaître deux fois (pages qui se chevauchent) : on garde la lecture la plus complète."""
    gardes = {}
    for p in paris:
        deja = gardes.get(p.reference)
        if deja is None or len(p.selections) > len(deja.selections):
            gardes[p.reference] = p
    return list(gardes.values())
