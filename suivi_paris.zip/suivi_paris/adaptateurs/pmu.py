"""Adaptateur PMU : page Sport → « Mes paris » (ou « Mon historique de paris », onglet « Sport »), copiée en entier
après avoir cliqué sur « Voir plus » autant que voulu.

Un pari s'y lit ainsi, une information par ligne, l'en-tête avant la référence et le détail après :

    Simple | Combiné (n)                    type (l'état y est parfois collé : « Combiné (2)Gagné »)
    @ / 2,75                                cote totale
    Perdu | Gagné | 0 sur 2 terminé(s)      état (« n sur m terminé(s) » : pari en cours)
    10 oct. 2026 • 10:43                    date du pari
    Référence du pari: 13206293862          référence : la clé anti-doublon
    Top 10: Oscar Onley (1-10)              marché et choix, puis l'événement, pour chaque sélection
    Tour de Lombardie 2026
    … (autres sélections d'un combiné)
    Cote : / 10,13                          cote totale, quand elle n'est pas dans l'en-tête
    Mise : / 50,00 €
    Gain : / 183,00 €                       absent d'un pari perdu ; « Gain potentiel : » pour un pari en cours

PMU affiche la cote totale, y compris des paris perdus, et les sélections des combinés (sans leur cote propre).
Il n'affiche ni le sport (deviné, voir sports.py) ni la date de l'événement.

Le favori relève le texte tel qu'affiché, où le site change la casse (« Référence Du Pari ») et regroupe certaines
informations sur une ligne (« Combiné (2) @ 2,04 • Gagné », « Mise : 96,15 € • Gain : 196,15 € ») : les deux
lectures sont acceptées.
"""
from __future__ import annotations

import re
from datetime import datetime

from ..modeles import (
    ANNULE,
    COMBINE,
    EN_COURS,
    GAGNE,
    INCONNU,
    MYCOMBI,
    PERDU,
    SIMPLE,
    SYSTEME,
    Pari,
    Selection,
    categorie_marche,
    montant,
    normaliser_etat,
    sans_accents,
)
from ..sports import SPORTS, course_cycliste, deviner_sport, normaliser_sport

NOM = "pmu"
LIBELLE = "PMU"
CONSIGNE = (
    "Sur pmu.fr : Sport → Mes paris (onglet « Tous »). Clique sur « Voir plus » jusqu'aux paris "
    "voulus, sélectionne toute la page (Ctrl+A), copie (Ctrl+C), puis colle ici (Ctrl+V). Pour tout "
    "l'historique sans cliquer à la main, utilise le favori."
)

_REF = re.compile(r"^Référence du pari\s*:\s*(\d+)$", re.IGNORECASE)
_TYPE = re.compile(
    r"^(?P<type>Simple|Combiné|Système(?:\s*\d+/\d+)?)(?:\s*\((?P<n>\d+)\))?"
    r"\s*(?P<etat>[^\W\d_].*|\d+\s+sur\s+\d+.*)?$",
    re.IGNORECASE,
)
_DATE = re.compile(r"^(\d{1,2})\s+([^\W\d_]+)\.?\s+(\d{4})\s*•\s*(\d{1,2}):(\d{2})$")
_TERMINES = re.compile(r"^(\d+)\s+sur\s+(\d+)\s+terminé", re.IGNORECASE)  # « 2 sur 2 terminé(s) »
_COTE_ORIGINE = re.compile(r"^\(\d+(?:[.,]\d+)?\)$")  # « (1,40) » : la cote d'origine, sous la cote réglée
# Bandeau d'offre glissé dans une sélection (« GARANTIE COACHING ») : ni marché ni événement.
_BANDEAU = re.compile(r"^[A-ZÀÂÇÉÈÊËÎÏÔÛÙÜ]{3,}(?: [A-ZÀÂÇÉÈÊËÎÏÔÛÙÜ]{3,})+$")
# Marchés dont la précision entre parenthèses est une place : « Classement: X (1-3) », « Top 10: X (1-10) ».
_BASES_CLASSEMENT = re.compile(r"^(classement( final)?|competition|vainqueur|top \d+|termine dans le top \d+)$")
_COTE = re.compile(r"^\d+(?:[.,]\d+)?$")
# Le deux-points est exigé : un événement peut commencer par « Cote » (« Cote d'Ivoire - Ghana »).
_LIBELLE = re.compile(r"^(?:(?P<arobase>@)|(?P<nom>Cote|Mise|Gain potentiel|Gain)\s*:)\s*(?P<valeur>.*)$",
                      re.IGNORECASE)
# « Combiné (2) @ 2,04 » : le type et la cote sur une même ligne.
_TYPE_ET_COTE = re.compile(r"^(?P<type>.+?)\s*@\s*(?P<cote>\d+(?:[.,]\d+)?)$")
_QUALIFICATIF = re.compile(r"^(?P<choix>.+?)\s*\((?P<q>[^()]+)\)$")
_MOIS = {"janv": 1, "fevr": 2, "mars": 3, "avr": 4, "mai": 5, "juin": 6, "juil": 7, "aout": 8,
         "sept": 9, "oct": 10, "nov": 11, "dec": 12}


def reconnait(texte: str) -> bool:
    return bool(re.search(r"^\s*Référence du pari\s*:\s*\d+\s*$", texte, re.MULTILINE | re.IGNORECASE)) or "PMU Play" in texte


def identifiant(texte: str) -> str | None:
    """La page PMU copiée n'affiche pas le pseudo du compte."""
    return None


def _nettoyer(ligne: str) -> str:
    # La page glisse des marques de sens d'écriture (invisibles) dans certains libellés : « Cote\u200e: ».
    return re.sub("[\u200e\u200f]", "", ligne).strip()


def _decouper(ligne: str) -> list[str]:
    """Ramène une ligne du texte affiché à celles du copier-coller : « Combiné (2) @ 2,04 • Gagné » ->
    « Combiné (2) », « @ 2,04 », « Gagné » ; « Mise : 96,15 € • Gain : 196,15 € » -> deux lignes. Une date
    (« 14 oct. 2026 • 07:52 ») reste entière."""
    if "•" not in ligne and "@" not in ligne or _DATE.match(ligne):
        return [ligne]
    morceaux = []
    for morceau in (m.strip() for m in ligne.split("•")):
        tc = _TYPE_ET_COTE.match(morceau)
        if tc and _TYPE.match(tc.group("type")):
            morceaux += [tc.group("type"), "@ " + tc.group("cote")]
        elif morceau:
            morceaux.append(morceau)
    # Seuls l'en-tête et la ligne cote / mise / gain sont découpés ; une autre ligne (un événement…) reste entière.
    if _TYPE.match(morceaux[0]) or _cle(_LIBELLE.match(morceaux[0])) not in (None, "@"):
        return morceaux
    return [ligne]


def _cote(texte: str) -> float | None:
    texte = texte.strip()
    return float(texte.replace(",", ".")) if _COTE.match(texte) else None


def _date(ligne: str) -> datetime | None:
    m = _DATE.match(ligne)
    if not m:
        return None
    jour, mois_brut, annee, heure, minute = m.groups()
    mois = next((n for cle, n in _MOIS.items() if sans_accents(mois_brut).lower().startswith(cle)), None)
    if mois is None:
        return None
    return datetime(int(annee), mois, int(jour), int(heure), int(minute))


def _marche_choix(ligne: str) -> tuple[str, str, str]:
    """Renvoie (marché, choix, marché tel qu'affiché) :
    « Top 10: Oscar Onley (1-10) » -> « Top 10 », « Oscar Onley » ;
    « Classement: Christian Scaroni (Vainqueur) » ou « (Compétition) » -> « Vainqueur », « Christian Scaroni » ;
    « Duel: Daan Hoole (Tobias Foss - Daan Hoole) » -> « Duel (Tobias Foss - Daan Hoole) », « Daan Hoole » ;
    « Un coureur de cette équipe gagne 1+ étape: Movistar: Oui (Movistar - Vuelta a España) »
    -> « Un coureur de cette équipe gagne 1+ étape », « Movistar: Oui »."""
    marche, sep, choix = ligne.partition(":")
    if not sep:
        return "", ligne.strip(), ""
    marche, choix = marche.strip(), choix.strip()
    m = _QUALIFICATIF.match(choix)
    if not m:
        return marche, choix, marche
    choix, q = m.group("choix"), m.group("q").strip()
    if not _BASES_CLASSEMENT.match(sans_accents(marche).lower()):
        # Ailleurs, la précision rappelle le contexte (le duel, l'équipe, la compétition) : gardée pour un duel.
        return (f"{marche} ({q})" if marche.lower().startswith("duel") else marche), choix, marche
    # La précision dit la place visée : « 1-10 », « 1-3 », « Top 3 », « Vainqueur », « Compétition » (la course).
    plage = re.match(r"^1\s*-\s*(\d+)$", q)
    if plage:
        return (f"Top {plage.group(1)}" if int(plage.group(1)) > 1 else "Vainqueur"), choix, marche
    if re.match(r"^Top \d+$", q, re.IGNORECASE):
        return q.capitalize(), choix, marche
    if sans_accents(q).lower() in ("vainqueur", "competition"):
        return "Vainqueur", choix, marche
    return f"{marche} ({q})", choix, marche  # précision non reconnue : gardée telle quelle


# Détail d'un pari ouvert d'un clic : pour chaque sélection, la date de l'événement (« 17 oct. 2026, 10:30 ») et
# le chemin « Basketball / Australie / NBL », dont le premier mot est le sport.
_DATE_EVENEMENT = re.compile(r"^(\d{1,2})\s+([^\W\d_]+)\.?\s+(\d{4}),\s*(\d{1,2}):(\d{2})$")
_CHEMIN = re.compile(r"^[^/@:]+(?: / [^/]+)+$")
_FIN_DETAIL = "Afficher l'historique des transactions"


def _details(lignes: list[str]) -> tuple[list[datetime], list[str]]:
    """Les dates d'événement et les sports lus dans le détail d'un pari ouvert (vides s'il ne l'est pas)."""
    dates, sports = [], []
    for ligne in lignes:
        if ligne == _FIN_DETAIL or _TYPE.match(ligne):
            break
        m = _DATE_EVENEMENT.match(ligne)
        if m:
            d = _date(f"{m.group(1)} {m.group(2)} {m.group(3)} • {m.group(4)}:{m.group(5)}")
            if d:
                dates.append(d)
        elif _CHEMIN.match(ligne):
            morceaux = [x.strip() for x in ligne.split(" / ")]
            sport = normaliser_sport(morceaux[0], ligne)
            if sport in ("Sports d'hiver", "Sports mécaniques", "Ski") and len(morceaux) > 1:
                precis = normaliser_sport(morceaux[1], ligne)
                sport = precis if precis in SPORTS else sport
            sports.append(sport)
    return dates, sports


def _sport(marche_affiche: str, marche: str, choix: str, evenement: str) -> str:
    sport = deviner_sport(marche, choix, evenement)
    # « Vainqueur du match » (tennis…) et « Classement final » (un tournoi) ne sont pas du vélo : sans course
    # cycliste reconnue dans l'événement, le sport reste à préciser plutôt que deviné.
    if sport == "Cyclisme" and marche_affiche.lower() in ("vainqueur du match", "classement final") \
            and not course_cycliste(evenement):
        return "Autre"
    return sport


def _cle(m: re.Match | None) -> str | None:
    """« @ », « Cote », « Mise », « Gain » ou « Gain potentiel » ; None si la ligne n'est pas un libellé."""
    if not m:
        return None
    return "@" if m.group("arobase") else m.group("nom")


def _valeur(lignes: list[str], i: int, valeur: str) -> str:
    """La valeur suit son libellé sur la même ligne (« Mise : 50,00 € ») ou sur la suivante."""
    if valeur:
        return valeur
    return lignes[i + 1] if i + 1 < len(lignes) else ""


_SOMME = re.compile(r"\d[\d ]*(?:[.,]\d+)?")


def _somme(texte: str) -> tuple[float | None, str]:
    """« 5,00 €Ticket Sport » -> (5.0, « Ticket Sport ») : le montant, et ce qui l'accompagne (sans le « € »)."""
    m = _SOMME.search(texte)
    if not m:
        return None, texte.strip()
    reste = (texte[: m.start()] + " " + texte[m.end() :]).replace("€", " ")
    return montant(m.group()), re.sub(r"\s+", " ", reste).strip()


def parser(texte: str) -> tuple[list[Pari], list[str]]:
    """Renvoie (paris, avertissements)."""
    lignes = [m for x in texte.splitlines() if (l := _nettoyer(x)) for m in _decouper(l)]
    paris: list[Pari] = []
    avertissements: list[str] = []
    refs = [i for i, l in enumerate(lignes) if _REF.match(l)]

    for k, r in enumerate(refs):
        reference = _REF.match(lignes[r]).group(1)
        precedente = refs[k - 1] if k else -1

        # En-tête : de la ligne de type (la dernière avant la référence) jusqu'à la référence.
        t = next((i for i in range(r - 1, precedente, -1) if _TYPE.match(lignes[i])), None)
        if t is None:
            avertissements.append(f"PMU {reference} : type du pari introuvable, pari ignoré.")
            continue
        type_m = _TYPE.match(lignes[t])
        entete = lignes[t + 1 : r]

        date_pari = next((d for d in map(_date, entete) if d), None)
        if date_pari is None:
            avertissements.append(f"PMU {reference} : date du pari introuvable, pari ignoré.")
            continue

        cote, etats = None, [type_m.group("etat")] if type_m.group("etat") else []
        i = 0
        while i < len(entete):
            ligne = entete[i]
            lib = _LIBELLE.match(ligne)
            if _cle(lib) == "@":
                cote = _cote(_valeur(entete, i, lib.group("valeur")))
                i += 1 if lib.group("valeur") else 2
                continue
            if not _date(ligne) and not _COTE_ORIGINE.match(ligne):
                etats.append(ligne)
            i += 1

        # Détail : les sélections (marché : choix, puis événement), puis cote, mise et gain.
        fin = refs[k + 1] if k + 1 < len(refs) else len(lignes)
        corps = lignes[r + 1 : fin]
        i_fin = next((i for i, l in enumerate(corps) if _cle(_LIBELLE.match(l)) not in (None, "@")), None)
        if i_fin is None:
            avertissements.append(f"PMU {reference} : mise introuvable, pari ignoré.")
            continue
        mise, gain, potentiel, nature_mise, boost = None, None, False, "", False
        i = i_fin
        while i < len(corps):
            lib = _LIBELLE.match(corps[i])
            cle = _cle(lib)
            if cle in (None, "@"):
                break
            valeur = _valeur(corps, i, lib.group("valeur"))
            if cle == "Cote":
                # « Cote : / 1,50 / 2,00 » : la cote d'origine puis la cote boostée, qui est celle du pari.
                cotes = [_cote(valeur)]
                j = i + (1 if lib.group("valeur") else 2)
                while j < len(corps) and _cote(corps[j]) is not None:
                    cotes.append(_cote(corps[j]))
                    j += 1
                cote, boost = (cotes[-1] if cote is None else cote), boost or len(cotes) > 1
                i = j
                continue
            if cle == "Mise":
                mise, nature_mise = _somme(valeur)
            else:
                gain, potentiel = _somme(valeur)[0], cle == "Gain potentiel"
            i += 1 if lib.group("valeur") else 2
            if cle.startswith("Gain"):
                break
        if mise is None:
            avertissements.append(f"PMU {reference} : montant de la mise illisible, pari ignoré.")
            continue
        if "ticket" in nature_mise.lower():
            # Mise payée par un Ticket Sport (pari offert) : pas de l'argent du solde, compté à part plus tard.
            avertissements.append(f"PMU {reference} : pari joué avec un {nature_mise} ({mise:.2f} €), "
                                  "pas encore pris en charge, ignoré.")
            continue

        lignes_sel = [l for l in corps[:i_fin] if not _BANDEAU.match(l)]
        if len(lignes_sel) % 2:
            avertissements.append(f"PMU {reference} : sélection incomplète, vérifie ce pari.")
        selections = []
        for j in range(0, len(lignes_sel), 2):
            marche, choix, affiche = _marche_choix(lignes_sel[j])
            evenement = lignes_sel[j + 1] if j + 1 < len(lignes_sel) else ""
            etape = re.search(r"(?:[ÉE]tape|Stage) (\d+)", evenement)
            selections.append(Selection(_sport(affiche, marche, choix, evenement), evenement, marche, choix,
                                        evenement, int(etape.group(1)) if etape else None))

        etat_brut = etats[0] if etats else ""
        termines = _TERMINES.match(etat_brut)
        if termines and int(termines.group(1)) < int(termines.group(2)):
            etat = EN_COURS
        elif termines:
            # Plusieurs simples sur un même ticket, tous réglés : PMU ne donne que le gain total.
            total = gain or 0.0
            etat = GAGNE if total > mise else ANNULE if total == mise else PERDU
            gain = total
        elif "rembours" in etat_brut.lower():  # « Non enregistré (remboursé) », « Remboursé »
            etat = ANNULE
            gain = mise if potentiel or gain is None else gain
        else:
            etat = normaliser_etat(etat_brut)
            if etat == INCONNU and potentiel:
                etat = EN_COURS
        if etat == GAGNE and cote == 1.0 and gain == mise:
            etat = ANNULE  # « Gagné » à 1,00 (pari réglé à la cote 1) : la mise est seulement rendue
        if etat == GAGNE:
            if gain is None:
                avertissements.append(f"PMU {reference} : pari gagné sans montant de gain, pari ignoré.")
                continue
            gains = gain
        elif etat == PERDU:
            gains = gain if termines else 0.0
        elif etat == EN_COURS:
            gains = None
        else:  # annulé, cash-out ou état inconnu : le gain affiché, s'il y en a un
            gains = gain
            if etat == INCONNU:
                avertissements.append(f"PMU {reference} : état du pari non reconnu ({etat_brut or 'absent'}).")

        # Pari ouvert d'un clic sur le site : la date de l'événement et le sport de chaque sélection.
        dates_evt, sports_site = _details(corps[i:])
        sport_sur = bool(selections) and len(sports_site) == len(selections)
        if sport_sur:
            for sel, sport in zip(selections, sports_site, strict=True):
                sel.sport = sport

        type_brut = type_m.group("type")
        if type_brut.lower().startswith("combin"):
            # Toutes les sélections sur le même match : un combiné même match.
            meme_match = len(selections) > 1 and len({s.evenement for s in selections}) == 1
            type_pari = MYCOMBI if meme_match else COMBINE
            nb = int(type_m.group("n")) if type_m.group("n") else len(selections)
            if selections and nb != len(selections):
                avertissements.append(f"PMU {reference} : {nb} sélections annoncées, {len(selections)} lues.")
        elif type_brut.lower().startswith("syst"):
            type_pari, nb = SYSTEME, len(selections)
        else:
            # « Simple (2) » : deux paris simples pris ensemble, avec une mise et un gain communs.
            type_pari, nb = SIMPLE, int(type_m.group("n")) if type_m.group("n") else 1
            if nb != max(1, len(selections)):
                avertissements.append(f"PMU {reference} : {nb} sélections annoncées, {len(selections)} lues.")

        paris.append(
            Pari(
                bookmaker=NOM,
                reference=reference,
                date_pari=date_pari,
                type=type_pari,
                etat=etat,
                etat_brut=etat_brut,
                mise=mise,
                gains=gains,
                cote_boostee=boost or any(categorie_marche(s.marche) == "Cote boostée" for s in selections),
                nb_selections=max(1, nb),
                selections=selections,
                cote=None if etat == ANNULE and cote == 1.0 else cote,
                sport_devine=not sport_sur,
                date_evenement=max(dates_evt) if dates_evt else None,
            )
        )
    return paris, avertissements
