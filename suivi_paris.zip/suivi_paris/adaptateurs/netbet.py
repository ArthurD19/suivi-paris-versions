"""Adaptateur NetBet (netbet.fr) : Mon tableau de bord → Mes paris → Paris terminés (et en cours).

Un pari s'y lit ainsi :

    Simple | Combiné (6)                                   type (et nombre de sélections)
    Réf : Q7N6P3043RR6NP50 - ID:                           la référence (clé anti-doublon)
    Annulé                                                  (parfois : l'état ; sinon il est une icône)
    Voir les détails | Masquer les détails                  (combiné : son détail s'ouvre d'un clic)
    Tennis - WTA - US Open (F) - sam. 12 sept. 22:00       sport - compétition - date de l'événement
    WTA - US Open 2026 - Vainqueur                          événement
    Vainqueur                                               marché
    Mon choix : Elena Rybakina
    Résultat : Elena Rybakina
    Mise | Crédit de jeu / 20.00 €                          mise (« Crédit de jeu » : mise en crédit offert)
    Cote / 13.00
    Gain / 260.00 € | -                                     « - » : perdu

Dans un combiné ouvert, chaque sélection a sa ligne d'en-tête, l'événement, le marché, « Mon choix », « Cote : »
et sa cote, « Résultat ». L'état n'est pas écrit (une icône) : il se lit aux gains (« - » perdu, la mise rendue
remboursé, plus que la mise gagné). La page ne donne pas la date du pari : c'est celle de l'événement (la plus
ancienne d'un combiné), dont l'année se déduit du jour de la semaine (« sam. 12 sept. » : 2026).
"""
from __future__ import annotations

import re
from datetime import date, datetime

from ..modeles import ANNULE, CASHOUT, COMBINE, EN_COURS, GAGNE, PERDU, SIMPLE, SYSTEME, Pari, Selection, montant
from ..sports import ALIAS, deviner_sport, normaliser_sport

NOM = "netbet"
LIBELLE = "NetBet"
CONSIGNE = (
    "Sur netbet.fr : Mon tableau de bord → Mes paris → Paris terminés. Le site empêche Ctrl+A : l'extension lit la "
    "page toute seule, page après page (ou son bouton « Copier le texte de la page »)."
)

_TYPE = re.compile(r"^(Simple|Combiné(?: \((\d+)\))?|Système.*)$")
_REF = re.compile(r"^Réf\s*:\s*([0-9A-Z]{8,})\s*-\s*ID\s*:?\s*(\d*)$")
_JOURS = {"lun": 0, "mar": 1, "mer": 2, "jeu": 3, "ven": 4, "sam": 5, "dim": 6}
_MOIS = {"janv": 1, "févr": 2, "fevr": 2, "mars": 3, "avr": 4, "mai": 5, "juin": 6, "juil": 7, "août": 8, "aout": 8,
         "sept": 9, "oct": 10, "nov": 11, "déc": 12, "dec": 12}
_ENTETE = re.compile(r"^(.*) - (lun|mar|mer|jeu|ven|sam|dim)\.? (\d{1,2}) ([a-zéû]+)\.? (\d{1,2}):(\d{2})$")
_EUROS = re.compile(r"^-?\d[\d\s.,]*\s*€$")
_COTE = re.compile(r"^\d+(?:[.,]\d+)?$")


def reconnait(texte: str) -> bool:
    return "netbet.fr" in texte or ("NetBet" in texte and bool(re.search(r"^Réf\s*:\s*[0-9A-Z]{8,}\s*-\s*ID", texte,
                                                                        re.MULTILINE)))


def identifiant(texte: str) -> str | None:
    """La page n'affiche pas d'identifiant de compte."""
    return None


def _quand(m: re.Match, borne: date, indice: str = "") -> datetime | None:
    """« sam. 12 sept. 22:00 » : l'année où le 12 septembre est un samedi, la plus récente qui ne dépasse pas
    `borne` (la liste va du plus récent au plus ancien : un pari est au plus tard un peu après le précédent). Le
    même jour de semaine revient tous les 5, 6 ou 11 ans : sans cette borne, 2020 et 2025 se confondraient. Une
    date écrite dans l'événement (« Super Cote 02/01/2022 ») tranche."""
    _, jour_sem, j, mois, h, mi = m.groups()
    mois_n = _MOIS.get(mois.rstrip("."))
    if not mois_n:
        return None
    ecrite = re.search(rf"\b0?{int(j)}/0?{mois_n}/(20\d\d)\b", indice)
    annees = [int(ecrite.group(1))] if ecrite else range(borne.year, borne.year - 15, -1)
    for annee in annees:
        try:
            d = datetime(annee, mois_n, int(j), int(h), int(mi))
        except ValueError:
            continue
        if d.weekday() == _JOURS[jour_sem] and (ecrite or d.date() <= borne):
            return d
    return None


def _sport(entete: str, evenement: str, marche: str, choix: str) -> str:
    """« Tennis - WTA - … » : le premier mot ; « Super Cotes - Super Cote Basket - … » : le sport de la super cote."""
    morceaux = [m.strip() for m in entete.split(" - ")]
    brut = morceaux[0]
    if brut.lower().startswith(("super cote", "cote boost")) and len(morceaux) > 1:
        brut = re.sub(r"^(super cote|cote boostée?)\s*", "", morceaux[1], flags=re.IGNORECASE)
    cle = brut.lower()
    if cle in ALIAS or cle.capitalize() in ("Tennis", "Football", "Cyclisme", "Rugby", "Handball", "Golf", "Boxe",
                                             "Biathlon", "Baseball", "Snooker", "Mma", "Badminton"):
        return normaliser_sport(brut, evenement)
    return deviner_sport(marche, choix, f"{entete} {evenement}") or "Autre"


def parser(texte: str, aujourd_hui: date | None = None) -> tuple[list[Pari], list[str]]:
    aujourd_hui = aujourd_hui or date.today()
    lignes = [l.strip() for l in texte.splitlines() if l.strip()]
    debuts = [i for i in range(len(lignes) - 1) if _TYPE.match(lignes[i]) and _REF.match(lignes[i + 1])]
    paris: list[Pari] = []
    avertissements: list[str] = []
    borne = date.fromordinal(aujourd_hui.toordinal() + 60)  # un pari en cours peut porter sur un événement à venir
    for n, i in enumerate(debuts):
        bloc = lignes[i:debuts[n + 1] if n + 1 < len(debuts) else len(lignes)]
        type_m = _TYPE.match(bloc[0])
        reference = _REF.match(bloc[1]).group(1)
        # Les montants : « Mise » ou « Crédit de jeu », « Cote », « Gain », chacun suivi de sa valeur.
        def valeur(libelle: str, bloc: list[str] = bloc) -> str | None:
            return next((bloc[k + 1] for k in range(len(bloc) - 1) if bloc[k] == libelle), None)
        credit = valeur("Crédit de jeu") is not None
        mise_brute = valeur("Crédit de jeu") if credit else valeur("Mise")
        cote_brute, gain_brut = valeur("Cote"), valeur("Gain")
        if not mise_brute or not _EUROS.match(mise_brute):
            avertissements.append(f"NetBet {reference} : mise illisible, pari ignoré.")
            continue
        mise = montant(mise_brute)
        cote = float(cote_brute.replace(",", ".")) if cote_brute and _COTE.match(cote_brute) else None
        gains_lus = montant(gain_brut) if gain_brut and _EUROS.match(gain_brut) else None
        annule = "Annulé" in bloc[2:4] or any(l == "Résultat : Annulé" for l in bloc)

        # Les sélections : chaque en-tête « Sport - … - sam. 12 sept. 22:00 », puis événement, marché, choix…
        selections, jours = [], []
        entetes = [k for k, l in enumerate(bloc) if _ENTETE.match(l)]
        for e_n, k in enumerate(entetes):
            fin = entetes[e_n + 1] if e_n + 1 < len(entetes) else len(bloc)
            sous = bloc[k + 1:fin]
            m = _ENTETE.match(bloc[k])
            quand = _quand(m, borne, " ".join(sous[:2]))
            if quand:
                jours.append(quand)
            k_choix = next((j for j, l in enumerate(sous) if l.startswith("Mon choix")), None)
            avant = sous[:k_choix] if k_choix is not None else sous[:2]
            choix = sous[k_choix].split(":", 1)[1].strip() if k_choix is not None else ""
            evenement = avant[0] if avant else ""
            marche = avant[1] if len(avant) > 1 else ""
            cote_sel = None
            if "Cote :" in sous:
                brut = sous[sous.index("Cote :") + 1] if sous.index("Cote :") + 1 < len(sous) else ""
                cote_sel = float(brut.replace(",", ".")) if _COTE.match(brut) else None
            competition = " - ".join(x.strip() for x in m.group(1).split(" - ")[1:])
            selections.append(Selection(_sport(m.group(1), evenement, marche, choix), evenement.replace(" / ", " / "),
                                        marche, choix, competition, cote=cote_sel))
        nb_annonce = int(type_m.group(2)) if type_m.group(2) else None
        if bloc[0].startswith("Système"):
            type_pari = SYSTEME
        elif bloc[0].startswith("Combiné"):
            type_pari = COMBINE
        else:
            type_pari = SIMPLE
        if not jours:
            avertissements.append(f"NetBet {reference} : date introuvable (ouvre le détail du pari), pari ignoré.")
            continue
        # Le suivant (plus ancien) a lieu au plus tard un mois après celui-ci (paris pris longtemps à l'avance).
        borne = date.fromordinal(min(jours).date().toordinal() + 31)

        if annule:
            etat, gains = ANNULE, gains_lus if gains_lus is not None else mise
        elif gain_brut == "-":
            etat, gains = PERDU, 0.0
        elif gains_lus is None:
            etat, gains = EN_COURS, None
        elif abs(gains_lus - mise) < 0.005:
            etat, gains = ANNULE, gains_lus
        else:
            etat, gains = (GAGNE, gains_lus) if gains_lus > mise or credit else (CASHOUT, gains_lus)
        etat_brut = {GAGNE: "Gagné", PERDU: "Perdu", ANNULE: "Annulé", CASHOUT: "Cash-out", EN_COURS: "En cours"}[etat]
        if credit:
            etat_brut += " (crédit de jeu)"
        paris.append(Pari(
            bookmaker=NOM, reference=reference, date_pari=min(jours), type=type_pari, etat=etat, etat_brut=etat_brut,
            mise=mise, gains=round(gains, 2) if gains is not None else None,
            cote_boostee=any("super cote" in bloc[k].lower() for k in entetes),
            nb_selections=nb_annonce or max(1, len(selections)), selections=selections, cote=cote,
            date_evenement=max(jours), sport_devine=True, freebet=credit,
            # Un combiné fermé (sans « Masquer les détails ») ne donne pas ses sélections : il ne remplace pas
            # celles lues ouvert.
            detail_partiel=type_pari != SIMPLE and len(selections) < (nb_annonce or 2),
        ))
    return paris, avertissements
