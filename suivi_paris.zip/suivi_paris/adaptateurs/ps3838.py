"""Adaptateur ps3838 : page « Mes paris » (statut « Réglé » ou « En cours »), copiée en entier.

Le tableau y est copié une cellule par groupe de lignes :

    1	Bookmaker de paris sportifs           numéro de ligne, produit
    3522336713                            référence : la clé anti-doublon
    Biathlon                              sport
    2025-12-13 23:11:57                   date d'acceptation (heure de Paris)
    2025-12-14 13:40:25                   date de règlement (paris réglés seulement)
    Italie                                choix
    Italie -vs- États-Unis                événement
    Duels Money Line                      marché
    4x7.5km Relay Hochfilzen @ 2025-12-14 compétition @ date
    1.781                                 cote décimale
    D	Risque: 96.00                       format de cote, mise
    (96.00)	-96.00	0.00	Réglé            mise, gain/perte (ou gain potentiel), commission, statut
    PERDRE                                résultat
    Duels: [0-1]                          score

ps3838 donne la cote de chaque pari et le gain ou la perte nets : les gains se déduisent (mise + gain/perte).
L'export Excel du site donne les mêmes colonnes, mais avec des heures en GMT-4 : la page reste la référence.
"""
from __future__ import annotations

import re
from datetime import date, datetime

from ..modeles import ANNULE, COMBINE, EN_COURS, GAGNE, PERDU, SIMPLE, Pari, Selection, categorie_marche
from ..sports import SPORTS, deviner_sport, normaliser_sport

NOM = "ps3838"
LIBELLE = "ps3838"
CONSIGNE = (
    "Sur ps3838.com : Mon compte → Mes paris, statut « Réglé », puis Recherche. Sélectionne toute la page "
    "(Ctrl+A), copie (Ctrl+C), puis colle ici (Ctrl+V). Le site limite la recherche à un mois : pour tout "
    "l'historique, utilise le favori."
)

_REFERENCE = re.compile(r"^\d{7,}$")
_DATE = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})$")
_COTE = re.compile(r"^\d+\.\d+$")
_MISE = re.compile(r"^Risque\s*:\s*([\d.,]+)$")
_COMPETITION = re.compile(r"^(.*?)\s*@\s*(\d{4}-\d{2}-\d{2})$")


# PIWI247 (même logiciel, autre site) : la même page ; seul son nom la distingue (l'extension, elle, connaît le site,
# et un collage passe par le compte choisi).
_ENTETE_PIWI = re.compile(r"piwi", re.IGNORECASE)


def reconnait(texte: str) -> bool:
    if _ENTETE_PIWI.search(texte) and "ps3838" not in texte.lower():
        return False  # page PIWI247 (adaptateur piwi247)
    if "ps3838" in texte.lower() or "Bookmaker de paris sportifs" in texte:
        return True
    # Site mobile, copié sans en-tête : « ID: 3822706739 • 2026-10-25 14:04:51 » et « Gain / Perte: ».
    return bool(re.search(r"^ID\s*:\s*\d{7,}\s*•", texte, re.MULTILINE)) and "Gain / Perte" in texte


def identifiant(texte: str) -> str | None:
    """La page copiée n'affiche pas l'identifiant du compte."""
    return None


def _nombre(texte: str) -> float | None:
    try:
        return float(texte.replace(",", "").replace("−", "-").strip())
    except ValueError:
        return None


def _selections(lignes: list[str], sport: str) -> list[Selection]:
    """Les lignes de la cellule « Sélection », regroupées par compétition (« … @ date »)."""
    groupes, courant = [], []
    for ligne in lignes:
        courant.append(ligne)
        if _COMPETITION.match(ligne):
            groupes.append(courant)
            courant = []
    if courant:
        groupes.append(courant)
    selections = []
    for g in groupes:
        comp_m = _COMPETITION.match(g[-1])
        competition = comp_m.group(1) if comp_m else ""
        evenement = next((l for l in g if "-vs-" in l), competition)
        evenement = re.sub(r"\s*-vs-\s*", " / ", evenement)
        corps = g[:-1] if comp_m else g
        autres = [l for l in corps if "-vs-" not in l]
        choix = autres[0] if autres else ""
        marche = autres[-1] if len(autres) > 1 else ""
        sport_sel = normaliser_sport(sport, f"{competition} {evenement}") if sport else deviner_sport(marche, choix, evenement)
        etape = re.search(r"[ÉE]tape (\d+)", competition)
        selections.append(Selection(sport_sel, evenement, marche, choix, competition,
                                    int(etape.group(1)) if etape else None))
    return selections


def _jetons(texte: str) -> list[str]:
    """Toutes les cellules et lignes de cellule, dans l'ordre : le découpage en lignes ou en tabulations dépend
    de la façon dont la page a été copiée, l'ordre des informations, lui, ne change pas."""
    return [j.strip() for ligne in texte.splitlines() for j in ligne.split("\t") if j.strip()]


# Le site mobile (« /m/fr/asian/my-bets », sur le téléphone) : un pari par bloc, chaque information sur sa ligne.
#
#     ID: 3822706739 • 2026-10-25 14:04:51   référence et date du pari
#     Perdre                                 résultat (« En cours »… pour un pari ouvert)
#     Ski alpin Duels Money Line             sport, puis marché
#     Zan Kranjec  @1.775(D)                 choix @ cote (format)
#     Mise:100.00 / Risque:100.00            mise
#     Gain / Perte:-100.00                   gain ou perte nets (paris réglés)
#     Slalom géant de Sölden - 0001          compétition
#     Zan Kranjec -contre- River Radamus     événement
#     2026-10-25 [TF : 0-1]                  date de l'événement et score
_ID_MOBILE = re.compile(r"^ID\s*:\s*(\d{7,})\s*•\s*(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})$")
_CHOIX_MOBILE = re.compile(r"^(.*?)\s*@\s*(\d+(?:\.\d+)?)\s*(?:\([A-Z]+\))?$")
_MONTANT_MOBILE = re.compile(r"^(Mise|Risque|Gain\s*/\s*Perte)\s*:\s*(-?[\d.,]+)$", re.IGNORECASE)
_EVENEMENT_MOBILE = re.compile(r"\s+-(?:contre|vs)-\s+", re.IGNORECASE)
_DATE_SCORE_MOBILE = re.compile(r"^\d{4}-\d{2}-\d{2}(?:\s+\[.*\])?$")


def _sport_et_marche(ligne: str) -> tuple[str, str]:
    """« Ski alpin Duels Money Line » -> (« Ski alpin », « Duels Money Line ») : le plus long début de ligne qui est
    un sport connu. Aucun : pas de sport (il sera deviné), toute la ligne est le marché."""
    mots = ligne.split()
    for k in range(min(4, len(mots) - 1), 0, -1):
        debut = " ".join(mots[:k])
        sport = normaliser_sport(debut)
        if sport in SPORTS:
            return debut, " ".join(mots[k:])
    return "", ligne


def _parser_mobile(lignes: list[str], nom: str, libelle: str) -> tuple[list[Pari], list[str]]:
    debuts = [i for i, l in enumerate(lignes) if _ID_MOBILE.match(l)]
    paris: list[Pari] = []
    avertissements: list[str] = []
    for n, i in enumerate(debuts):
        bloc = lignes[i:debuts[n + 1] if n + 1 < len(debuts) else len(lignes)]
        m = _ID_MOBILE.match(bloc[0])
        reference, date_pari = m.group(1), datetime.strptime(m.group(2), "%Y-%m-%d %H:%M:%S")
        montants = {}
        for l in bloc:
            mm = _MONTANT_MOBILE.match(l)
            if mm:
                montants[re.sub(r"\s+", "", mm.group(1).lower())] = _nombre(mm.group(2))
        mise = montants.get("risque") if montants.get("risque") is not None else montants.get("mise")
        choix = [(j, _CHOIX_MOBILE.match(l)) for j, l in enumerate(bloc) if _CHOIX_MOBILE.match(l)]
        if mise is None or not choix:
            avertissements.append(f"{libelle} {reference} : mise ou choix introuvable, pari ignoré.")
            continue
        statut = bloc[1] if len(bloc) > 1 else ""
        valeur = montants.get("gain/perte")
        if valeur is None or re.search(r"cours|attente|accept", statut, re.IGNORECASE):
            etat, gains = EN_COURS, None
        else:
            gains = round(mise + valeur, 2)
            etat = GAGNE if valeur > 0 else PERDU if valeur < 0 else ANNULE
        selections = []
        for k, (j, c) in enumerate(choix):
            fin = choix[k + 1][0] if k + 1 < len(choix) else len(bloc)
            suite = [l for l in bloc[j + 1:fin] if not _MONTANT_MOBILE.match(l) and not _DATE_SCORE_MOBILE.match(l)]
            sport_brut, marche = _sport_et_marche(bloc[j - 1]) if j >= 2 else ("", "")
            evenement = next((l for l in suite if _EVENEMENT_MOBILE.search(l)), "")
            competition = next((l for l in suite if l != evenement), "")
            evenement = _EVENEMENT_MOBILE.sub(" / ", evenement) if evenement else competition
            sport = normaliser_sport(sport_brut, evenement + " " + competition) if sport_brut \
                else deviner_sport(marche, c.group(1), evenement)
            etape = re.search(r"[ÉE]tape (\d+)", competition)
            selections.append(Selection(sport, evenement, marche, c.group(1).strip(), competition,
                                        int(etape.group(1)) if etape else None, float(c.group(2))))
        paris.append(Pari(
            bookmaker=nom, reference=reference, date_pari=date_pari,
            type=COMBINE if len(selections) > 1 else SIMPLE, etat=etat,
            etat_brut=statut.capitalize() if statut else "", mise=mise, gains=gains,
            cote_boostee=any(categorie_marche(s.marche) == "Cote boostée" for s in selections),
            nb_selections=len(selections), selections=selections,
            cote=selections[0].cote if len(selections) == 1 else None,
        ))
    return paris, avertissements


def parser(texte: str, nom: str = NOM, libelle: str = LIBELLE) -> tuple[list[Pari], list[str]]:
    """Renvoie (paris, avertissements). `nom`, `libelle` : le site (ps3838, ou PIWI247, qui a la même page)."""
    lignes = [l.strip() for l in texte.splitlines() if l.strip()]
    if any(_ID_MOBILE.match(l) for l in lignes):
        return _parser_mobile(lignes, nom, libelle)
    jetons = _jetons(texte)
    debuts = [i for i, j in enumerate(jetons) if _REFERENCE.match(j)]
    paris: list[Pari] = []
    avertissements: list[str] = []
    for n, i in enumerate(debuts):
        fin = debuts[n + 1] if n + 1 < len(debuts) else len(jetons)
        bloc = jetons[i:fin]
        if "Total" in bloc:
            bloc = bloc[: bloc.index("Total")]
        reference = bloc[0]
        k_mise = next((k for k, j in enumerate(bloc) if _MISE.match(j)), None)
        k_cote = next((k for k in range((k_mise or 0) - 1, 0, -1) if _COTE.match(bloc[k])), None) if k_mise else None
        if k_mise is None or k_cote is None:
            avertissements.append(f"{libelle} {reference} : cote ou mise introuvable, pari ignoré.")
            continue
        sport = bloc[1] if len(bloc) > 1 and not _DATE.match(bloc[1]) else ""
        dates = [j for j in bloc[1:k_cote] if _DATE.match(j)]
        if not dates:
            avertissements.append(f"{libelle} {reference} : date du pari introuvable, pari ignoré.")
            continue
        date_pari = datetime.strptime(dates[0], "%Y-%m-%d %H:%M:%S")
        contenu = [j for j in bloc[2 if sport else 1 : k_cote] if not _DATE.match(j)]
        cote = float(bloc[k_cote])
        mise = _nombre(_MISE.match(bloc[k_mise]).group(1))

        # Après la mise : « (96.00) », puis les montants (gain/perte, commission), le statut, le résultat.
        suite = bloc[k_mise + 1 :]
        if suite and re.fullmatch(r"\([\d.,]+\)", suite[0]):
            suite = suite[1:]
        nombres = []
        while suite and _nombre(suite[0]) is not None:
            nombres.append(_nombre(suite.pop(0)))
        statut = suite[0] if suite else ""
        resultat = suite[1] if len(suite) > 1 else ""
        valeur = nombres[0] if nombres else None
        if mise is None:
            avertissements.append(f"{libelle} {reference} : mise illisible, pari ignoré.")
            continue

        if "cours" in statut.lower():
            etat, gains, etat_brut = EN_COURS, None, statut
        elif valeur is None:
            avertissements.append(f"{libelle} {reference} : gain ou perte illisible, pari ignoré.")
            continue
        else:
            # Gain/Perte net (ps3838) : positif gagné (même à moitié), négatif perdu, nul remboursé. Si la colonne
            # donnait le gain brut (« Gain » de PIWI247, pas encore vu sur un pari réglé : 0 pour un pari perdu,
            # mise × cote pour un pari gagné), le résultat écrit (« PERDRE ») et le montant le disent : un gain net
            # est inférieur de toute la mise à mise × cote.
            if valeur == 0 and "PERD" in resultat.upper():
                etat, gains = PERDU, 0.0
            elif valeur > 0 and abs(valeur - mise * cote) <= 0.011 + 0.001 * mise:
                etat, gains = GAGNE, round(valeur, 2)
            else:
                gains = round(mise + valeur, 2)
                etat = GAGNE if valeur > 0 else PERDU if valeur < 0 else ANNULE
            etat_brut = resultat.capitalize() if resultat and not re.match(r"^\w+\s*:", resultat) else statut

        selections = _selections(contenu, sport)
        if not selections:
            avertissements.append(f"{libelle} {reference} : sélection illisible.")
        type_pari = COMBINE if len(selections) > 1 else SIMPLE
        jours = [date.fromisoformat(m.group(2)) for j in contenu if (m := _COMPETITION.match(j))]
        paris.append(
            Pari(
                bookmaker=nom,
                reference=reference,
                date_pari=date_pari,
                type=type_pari,
                etat=etat,
                etat_brut=etat_brut,
                mise=mise,
                gains=gains,
                cote_boostee=any(categorie_marche(s.marche) == "Cote boostée" for s in selections),
                nb_selections=max(1, len(selections)),
                selections=selections,
                cote=cote,
                date_evenement=max(jours) if jours else None,
            )
        )
    return paris, avertissements
