"""Adaptateur ps3838 : page « Mes paris » (statut « Réglé » ou « En cours »), copiée en entier.

Le tableau y est copié une cellule par groupe de lignes :

    1	Bookmaker de paris sportifs           numéro de ligne, produit
    3522336713                            référence : la clé anti-doublon
    Biathlon                              sport
    2025-12-13 23:11:57                   date d'acceptation (heure de Paris)
    2025-12-14 13:40:25                   date de règlement (paris réglés seulement)
    Italie                                choix
    Italie -vs- États-Unis                événement
    Duels Money Line                      marché
    4x7.5km Relay Hochfilzen @ 2025-12-14 compétition @ date
    1.781                                 cote décimale
    D	Risque: 96.00                       format de cote, mise
    (96.00)	-96.00	0.00	Réglé            mise, gain/perte (ou gain potentiel), commission, statut
    PERDRE                                résultat
    Duels: [0-1]                          score

ps3838 donne la cote de chaque pari et le gain ou la perte nets : les gains se déduisent (mise + gain/perte).
L'export Excel du site donne les mêmes colonnes, mais avec des heures en GMT-4 : la page reste la référence.
"""
from __future__ import annotations

import re
from datetime import date, datetime

from ..modeles import ANNULE, COMBINE, EN_COURS, GAGNE, PERDU, SIMPLE, Pari, Selection, categorie_marche
from ..sports import deviner_sport, normaliser_sport

NOM = "ps3838"
LIBELLE = "ps3838"
CONSIGNE = (
    "Sur ps3838.com : Mon compte → Mes paris, statut « Réglé », puis Recherche. Sélectionne toute la page "
    "(Ctrl+A), copie (Ctrl+C), puis colle ici (Ctrl+V). Le site limite la recherche à un mois : pour tout "
    "l'historique, utilise le favori."
)

_REFERENCE = re.compile(r"^\d{7,}$")
_DATE = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})$")
_COTE = re.compile(r"^\d+\.\d+$")
_MISE = re.compile(r"^Risque\s*:\s*([\d.,]+)$")
_COMPETITION = re.compile(r"^(.*?)\s*@\s*(\d{4}-\d{2}-\d{2})$")


# PIWI247 (même logiciel, autre site) : la même page ; seul son nom la distingue (l'extension, elle, connaît le site,
# et un collage passe par le compte choisi).
_ENTETE_PIWI = re.compile(r"piwi", re.IGNORECASE)


def reconnait(texte: str) -> bool:
    if _ENTETE_PIWI.search(texte) and "ps3838" not in texte.lower():
        return False  # page PIWI247 (adaptateur piwi247)
    return "ps3838" in texte.lower() or "Bookmaker de paris sportifs" in texte


def identifiant(texte: str) -> str | None:
    """La page copiée n'affiche pas l'identifiant du compte."""
    return None


def _nombre(texte: str) -> float | None:
    try:
        return float(texte.replace(",", "").replace("−", "-").strip())
    except ValueError:
        return None


def _selections(lignes: list[str], sport: str) -> list[Selection]:
    """Les lignes de la cellule « Sélection », regroupées par compétition (« … @ date »)."""
    groupes, courant = [], []
    for ligne in lignes:
        courant.append(ligne)
        if _COMPETITION.match(ligne):
            groupes.append(courant)
            courant = []
    if courant:
        groupes.append(courant)
    selections = []
    for g in groupes:
        comp_m = _COMPETITION.match(g[-1])
        competition = comp_m.group(1) if comp_m else ""
        evenement = next((l for l in g if "-vs-" in l), competition)
        evenement = re.sub(r"\s*-vs-\s*", " / ", evenement)
        corps = g[:-1] if comp_m else g
        autres = [l for l in corps if "-vs-" not in l]
        choix = autres[0] if autres else ""
        marche = autres[-1] if len(autres) > 1 else ""
        sport_sel = normaliser_sport(sport, f"{competition} {evenement}") if sport else deviner_sport(marche, choix, evenement)
        etape = re.search(r"[ÉE]tape (\d+)", competition)
        selections.append(Selection(sport_sel, evenement, marche, choix, competition,
                                    int(etape.group(1)) if etape else None))
    return selections


def _jetons(texte: str) -> list[str]:
    """Toutes les cellules et lignes de cellule, dans l'ordre : le découpage en lignes ou en tabulations dépend
    de la façon dont la page a été copiée, l'ordre des informations, lui, ne change pas."""
    return [j.strip() for ligne in texte.splitlines() for j in ligne.split("\t") if j.strip()]


def parser(texte: str, nom: str = NOM, libelle: str = LIBELLE) -> tuple[list[Pari], list[str]]:
    """Renvoie (paris, avertissements). `nom`, `libelle` : le site (ps3838, ou PIWI247, qui a la même page)."""
    jetons = _jetons(texte)
    debuts = [i for i, j in enumerate(jetons) if _REFERENCE.match(j)]
    paris: list[Pari] = []
    avertissements: list[str] = []
    for n, i in enumerate(debuts):
        fin = debuts[n + 1] if n + 1 < len(debuts) else len(jetons)
        bloc = jetons[i:fin]
        if "Total" in bloc:
            bloc = bloc[: bloc.index("Total")]
        reference = bloc[0]
        k_mise = next((k for k, j in enumerate(bloc) if _MISE.match(j)), None)
        k_cote = next((k for k in range((k_mise or 0) - 1, 0, -1) if _COTE.match(bloc[k])), None) if k_mise else None
        if k_mise is None or k_cote is None:
            avertissements.append(f"{libelle} {reference} : cote ou mise introuvable, pari ignoré.")
            continue
        sport = bloc[1] if len(bloc) > 1 and not _DATE.match(bloc[1]) else ""
        dates = [j for j in bloc[1:k_cote] if _DATE.match(j)]
        if not dates:
            avertissements.append(f"{libelle} {reference} : date du pari introuvable, pari ignoré.")
            continue
        date_pari = datetime.strptime(dates[0], "%Y-%m-%d %H:%M:%S")
        contenu = [j for j in bloc[2 if sport else 1 : k_cote] if not _DATE.match(j)]
        cote = float(bloc[k_cote])
        mise = _nombre(_MISE.match(bloc[k_mise]).group(1))

        # Après la mise : « (96.00) », puis les montants (gain/perte, commission), le statut, le résultat.
        suite = bloc[k_mise + 1 :]
        if suite and re.fullmatch(r"\([\d.,]+\)", suite[0]):
            suite = suite[1:]
        nombres = []
        while suite and _nombre(suite[0]) is not None:
            nombres.append(_nombre(suite.pop(0)))
        statut = suite[0] if suite else ""
        resultat = suite[1] if len(suite) > 1 else ""
        valeur = nombres[0] if nombres else None
        if mise is None:
            avertissements.append(f"{libelle} {reference} : mise illisible, pari ignoré.")
            continue

        if "cours" in statut.lower():
            etat, gains, etat_brut = EN_COURS, None, statut
        elif valeur is None:
            avertissements.append(f"{libelle} {reference} : gain ou perte illisible, pari ignoré.")
            continue
        else:
            # Gain/Perte net (ps3838) : positif gagné (même à moitié), négatif perdu, nul remboursé. Si la colonne
            # donnait le gain brut (« Gain » de PIWI247, pas encore vu sur un pari réglé : 0 pour un pari perdu,
            # mise × cote pour un pari gagné), le résultat écrit (« PERDRE ») et le montant le disent : un gain net
            # est inférieur de toute la mise à mise × cote.
            if valeur == 0 and "PERD" in resultat.upper():
                etat, gains = PERDU, 0.0
            elif valeur > 0 and abs(valeur - mise * cote) <= 0.011 + 0.001 * mise:
                etat, gains = GAGNE, round(valeur, 2)
            else:
                gains = round(mise + valeur, 2)
                etat = GAGNE if valeur > 0 else PERDU if valeur < 0 else ANNULE
            etat_brut = resultat.capitalize() if resultat and not re.match(r"^\w+\s*:", resultat) else statut

        selections = _selections(contenu, sport)
        if not selections:
            avertissements.append(f"{libelle} {reference} : sélection illisible.")
        type_pari = COMBINE if len(selections) > 1 else SIMPLE
        jours = [date.fromisoformat(m.group(2)) for j in contenu if (m := _COMPETITION.match(j))]
        paris.append(
            Pari(
                bookmaker=nom,
                reference=reference,
                date_pari=date_pari,
                type=type_pari,
                etat=etat,
                etat_brut=etat_brut,
                mise=mise,
                gains=gains,
                cote_boostee=any(categorie_marche(s.marche) == "Cote boostée" for s in selections),
                nb_selections=max(1, len(selections)),
                selections=selections,
                cote=cote,
                date_evenement=max(jours) if jours else None,
            )
        )
    return paris, avertissements
