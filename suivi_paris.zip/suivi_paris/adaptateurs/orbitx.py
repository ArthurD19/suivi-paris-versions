"""Adaptateur OrbitX (orbitxch.com), un exchange : My Bets → Settled.

Un tableau, une cellule par ligne :

    232074992                         Ref ID (la clé anti-doublon)
    25 Oct 2026 07:44                 réglé le
    24 Oct 2026 15:43                 placé le (la date du pari)
    Ashlyn Krueger                    sélection
    As Krueger v K Siniakova – Match Odds   événement – marché
    WTA Osaka 2026                    compétition
    Back | Lay                        sens du pari
    2.16                              cote
    100.00                            mise (« stake »)
    100.00                            risque (« liability »)
    -100.00 | 184.50                  gains totaux
    -100.00 | +109.50                 profit ou perte
    Lost | Won | Cancelled | Void     état

Un pari « Back » se compte comme ailleurs : mise, et gains = mise + profit. Un pari « Lay » (contre la sélection) :
l'argent en jeu est le risque, la mise est le risque et les gains = risque + profit ; le choix est « Contre … » et
la cote affichée (celle du lay) ne se compare pas à une cote de bookmaker : elle reste dans le marché, la cote du
pari reste vide. Une mise « Cancelled » (non appariée, rendue) n'est pas un pari : elle est ignorée.
"""
from __future__ import annotations

import re
from datetime import datetime

from ..modeles import ANNULE, GAGNE, INCONNU, PERDU, SIMPLE, Pari, Selection
from ..sports import deviner_sport

NOM = "orbitx"
LIBELLE = "OrbitX"
CONSIGNE = (
    "Sur orbitxch.com : Account → My Bets → Settled, choisis la période et le nombre de résultats par page, puis "
    "copie la page (l'extension la lit toute seule, page après page)."
)

_REF = re.compile(r"^\d{6,}$")
_DATE = re.compile(r"^(\d{1,2}) ([A-Z][a-z]{2}) (\d{4}) (\d{2}):(\d{2})$")
_MOIS = {m: i for i, m in enumerate(("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov",
                                     "Dec"), start=1)}
_NOMBRE = re.compile(r"^[+-]?\d[\d,]*(?:\.\d+)?$")
_ETATS = {"won": GAGNE, "lost": PERDU, "void": ANNULE, "voided": ANNULE, "cancelled": None, "lapsed": None}


def reconnait(texte: str) -> bool:
    return "orbitxch.com" in texte or ("Orbit Exchange" in texte and "Ref ID" in texte)


def identifiant(texte: str) -> str | None:
    """Le pseudo, juste avant « Balance: » en haut de la page."""
    lignes = [l.strip() for l in texte.splitlines() if l.strip()]
    for i, l in enumerate(lignes[:40]):
        if l.startswith("Balance") and i and re.fullmatch(r"[\w.\-]{3,30}", lignes[i - 1]):
            return lignes[i - 1]
    return None


def _date(m: re.Match) -> datetime:
    j, mois, a, h, mi = m.groups()
    return datetime(int(a), _MOIS[mois], int(j), int(h), int(mi))


def _nombre(brut: str) -> float | None:
    return float(brut.replace(",", "").replace("+", "")) if _NOMBRE.match(brut) else None


def parser(texte: str) -> tuple[list[Pari], list[str]]:
    lignes = [l.strip() for l in texte.splitlines() if l.strip()]
    paris: list[Pari] = []
    avertissements: list[str] = []
    vues: dict[str, int] = {}
    for i in range(len(lignes) - 12):
        if not (_REF.match(lignes[i]) and _DATE.match(lignes[i + 1]) and _DATE.match(lignes[i + 2])):
            continue
        ref = lignes[i]
        choix, titre, competition, sens = lignes[i + 3:i + 7]
        cote = _nombre(lignes[i + 7])
        mise, risque = _nombre(lignes[i + 8]), _nombre(lignes[i + 9])
        profit = _nombre(lignes[i + 11])
        etat_brut = lignes[i + 12]
        if etat_brut.lower() not in _ETATS:
            avertissements.append(f"OrbitX {ref} : état « {etat_brut} » non reconnu, pari ignoré.")
            continue
        etat = _ETATS[etat_brut.lower()]
        if etat is None:
            continue  # mise non appariée, rendue : pas un pari
        if sens not in ("Back", "Lay") or mise is None or risque is None or (profit is None and etat != ANNULE):
            avertissements.append(f"OrbitX {ref} : pari illisible, ignoré.")
            continue
        evenement, _, marche = titre.partition(" – ")
        evenement = re.sub(r"\s+(?:v|vs\.?|@)\s+", " / ", evenement.strip())
        lay = sens == "Lay"
        en_jeu = risque if lay else mise
        gains = en_jeu if etat == ANNULE else round(en_jeu + (profit or 0.0), 2)
        if etat == PERDU:
            gains = 0.0
        sport = deviner_sport(marche, choix, f"{competition} {evenement}") or "Autre"
        selection = Selection(sport, evenement, f"{marche} (lay à {lignes[i + 7]})" if lay else marche,
                              f"Contre {choix}" if lay else choix, competition)
        vues[ref] = vues.get(ref, 0) + 1
        reference = ref if vues[ref] == 1 else f"{ref}-{vues[ref]}"
        paris.append(Pari(
            bookmaker=NOM, reference=reference, date_pari=_date(_DATE.match(lignes[i + 2])), type=SIMPLE,
            etat=etat if etat is not None else INCONNU, etat_brut=f"{etat_brut} ({sens})", mise=round(en_jeu, 2),
            gains=gains, nb_selections=1, selections=[selection], cote=None if lay else cote, sport_devine=True,
        ))
    return paris, avertissements
