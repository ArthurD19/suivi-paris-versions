"""AsianConnect (ac0188.com) : le courtier par lequel passent les dépôts et retraits de ps3838 et PIWI247.

Ce n'est pas un bookmaker (pas de paris, pas de compte à lui dans l'appli) : son historique des transactions donne
les dépôts, retraits et transferts des comptes ps3838 et PIWI247, rangés chacun sur son compte. Une transaction
n'affiche son produit (le compte concerné) qu'une fois dépliée d'un clic :

    EffectuéTransfert                 statut et type (« Dépôt|SKRILL » : type et moyen de paiement)
    6/30/2026                         date (mois/jour/année)
    20260630-050235-472683-3          numéro : date et heure de la transaction, puis le type (1 dépôt, 2 retrait,
    Numéro de transaction                      3 transfert, 4 bonus)
    150 EUR                           montant
    Effectué
    Produit                           dépliée seulement :
    De PS3838 (AC88023806)              un transfert : du compte…
    À PIWI247 (PIW_73078)               … vers le compte (un dépôt, un retrait : « PS3838 (AC88023806) »)

Un dépôt va sur le compte du produit, un retrait en sort ; un transfert est un retrait du premier compte et un
dépôt sur le second. Les bonus et le portefeuille AsianConnect (« AC Wallet ») ne comptent pas. Une transaction
pas dépliée n'est pas lue (son compte n'est pas affiché).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime

from ..modeles import DEPOT, RETRAIT, Mouvement

NOM = "asianconnect"
LIBELLE = "AsianConnect"

_NUMERO = re.compile(r"^(\d{8})-(\d{6})-\d+-(\d)$")
_TETE = re.compile(r"^(Effectué|Refusé|En attente|En cours|Annulé|Rejeté)\s*(Dépôt|Retrait|Transfert|Bonus)"
                   r"(?:\s*\|\s*(.+))?$", re.IGNORECASE)
_MONTANT = re.compile(r"^(\d[\d,]*(?:\.\d+)?)\s*EUR$")
_PRODUIT = re.compile(r"^(?:(De|À|A)\s+)?(.+?)\s*\(([^()]+)\)$")
_TYPES_NUMERO = {"1": "dépôt", "2": "retrait", "3": "transfert", "4": "bonus"}
# Le nom d'un produit AsianConnect -> le bookmaker de l'appli.
PRODUITS = {"ps3838": "ps3838", "pinnacle": "ps3838", "piwi247": "piwi247", "piwi": "piwi247", "orbitx": "orbitx",
            "orbitexchange": "orbitx", "orbit": "orbitx"}


@dataclass
class MouvementCompte:
    """Un dépôt ou un retrait, et le compte qu'il concerne (bookmaker et numéro de compte chez lui)."""

    bookmaker: str
    identifiant: str
    mouvement: Mouvement


def reconnait(texte: str) -> bool:
    return "Numéro de transaction" in texte and bool(re.search(r"^\d{8}-\d{6}-\d+-\d$", texte, re.MULTILINE))


def _bookmaker(nom: str) -> str | None:
    return PRODUITS.get(re.sub(r"\s+", "", nom).lower())


def lire(texte: str) -> tuple[list[MouvementCompte], list[str], int]:
    """Renvoie (mouvements par compte, avertissements, nombre de transactions pas dépliées)."""
    lignes = [l.strip() for l in texte.splitlines() if l.strip()]
    numeros = [i for i, l in enumerate(lignes) if _NUMERO.match(l)]
    resultat: list[MouvementCompte] = []
    avertissements: list[str] = []
    fermees = 0
    for n, i in enumerate(numeros):
        fin = numeros[n + 1] - 2 if n + 1 < len(numeros) else len(lignes)
        bloc = lignes[i:fin]
        num = _NUMERO.match(lignes[i])
        quand = datetime.strptime(num.group(1) + num.group(2), "%Y%m%d%H%M%S")
        tete = _TETE.match(lignes[i - 2]) if i >= 2 else None
        statut = tete.group(1).capitalize() if tete else ""
        type_ = (tete.group(2) if tete else _TYPES_NUMERO.get(num.group(3), "")).lower()
        moyen = (tete.group(3) or "").strip().capitalize() if tete else ""
        montant = next((float(m.group(1).replace(",", "")) for l in bloc if (m := _MONTANT.match(l))), None)
        if montant is None:
            avertissements.append(f"AsianConnect {lignes[i]} : montant illisible, ignoré.")
            continue
        if type_ == "bonus" or not statut:
            continue
        if "Produit" not in bloc:
            fermees += 1
            continue
        k = bloc.index("Produit") + 1
        produits = []
        while k < len(bloc) and (p := _PRODUIT.match(bloc[k])):
            produits.append((p.group(1) or "", p.group(2), p.group(3).strip()))
            k += 1
        cibles = [(sens_, _bookmaker(nom), ident) for sens_, nom, ident in produits]

        a_ranger = []  # (bookmaker, identifiant, sens, libellé)
        if type_ == "transfert":
            depuis = next((c for c in cibles if c[0] == "De"), None)
            vers = next((c for c in cibles if c[0] in ("À", "A")), None)
            if not depuis or not vers:
                avertissements.append(f"AsianConnect {lignes[i]} : transfert sans ses deux comptes, ignoré.")
                continue
            nom_vers = next(p[1] for p in produits if p[0] in ("À", "A"))
            nom_depuis = next(p[1] for p in produits if p[0] == "De")
            a_ranger += [(depuis[1], depuis[2], RETRAIT, f"Transfert AsianConnect vers {nom_vers}"),
                         (vers[1], vers[2], DEPOT, f"Transfert AsianConnect depuis {nom_depuis}")]
        elif type_ in ("dépôt", "retrait") and cibles:
            sens = DEPOT if type_ == "dépôt" else RETRAIT
            a_ranger.append((cibles[0][1], cibles[0][2], sens, f"{moyen} (AsianConnect)" if moyen else "AsianConnect"))
        else:
            avertissements.append(f"AsianConnect {lignes[i]} : produit illisible, ignoré.")
        # Sans bookmaker (« AC Wallet » : le portefeuille d'AsianConnect), pas un compte de l'appli.
        resultat += [MouvementCompte(bk, ident, Mouvement(quand, montant, statut, libelle, sens))
                     for bk, ident, sens, libelle in a_ranger if bk]
    return resultat, avertissements, fermees
