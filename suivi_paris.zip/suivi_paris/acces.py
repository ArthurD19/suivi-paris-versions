"""Accès depuis l'iPhone : l'appli de l'ordinateur devient joignable sur le réseau, protégée par un code.

- Le serveur local (127.0.0.1) ne change pas. Quand l'accès est activé, un second serveur écoute sur le
  réseau (port 8787 par défaut) : Wi-Fi de la maison, et partout ailleurs via Tailscale si installé.
- Tout y est refusé sans session valide. On s'y connecte en scannant le QR code affiché sur l'ordinateur,
  ou en tapant le code d'accès (utile dans l'appli ajoutée à l'écran d'accueil, qui a ses propres cookies).
- La session est un cookie HttpOnly, SameSite=Strict, qui contient l'empreinte du code : changer le code
  déconnecte tous les appareils.
- Depuis le téléphone, on ne peut ni arrêter l'appli, ni tout effacer, ni changer ces réglages.
"""
from __future__ import annotations

import hashlib
import hmac
import io
import ipaddress
import secrets
import shutil
import socket
import subprocess
import threading
import time

import segno

from . import reglages

PORT_PAR_DEFAUT = 8787
NOM_COOKIE = "suivi_paris_session"
ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"  # sans O/0, I/1, L : facile à taper sur un téléphone


def nouveau_code() -> str:
    brut = "".join(secrets.choice(ALPHABET) for _ in range(10))
    return f"{brut[:5]}-{brut[5:]}"


def normaliser_code(code: str) -> str:
    propre = "".join(c for c in (code or "").upper() if c in ALPHABET)
    return f"{propre[:5]}-{propre[5:]}" if len(propre) == 10 else ""


def empreinte(code: str) -> str:
    return hashlib.sha256(("suivi-paris:" + code).encode()).hexdigest()


def config() -> dict:
    """Réglages d'accès, avec un code créé au premier besoin."""
    r = reglages.lire()
    if not r.get("acces_code"):
        r = reglages.ecrire(acces_code=nouveau_code())
    return {
        "actif": bool(r.get("acces_actif")),
        "port": int(r.get("acces_port") or PORT_PAR_DEFAUT),
        "code": r["acces_code"],
    }


def changer_code() -> str:
    code = nouveau_code()
    reglages.ecrire(acces_code=code)
    return code


def session_valide(valeur_cookie: str | None) -> bool:
    if not valeur_cookie:
        return False
    return hmac.compare_digest(valeur_cookie, empreinte(config()["code"]))


def cookie_session(code: str) -> str:
    return (f"{NOM_COOKIE}={empreinte(code)}; Max-Age=31536000; Path=/; HttpOnly; SameSite=Strict")


class Limiteur:
    """Au plus 8 essais de code par adresse et par tranche de 10 minutes."""

    def __init__(self, essais: int = 8, fenetre: float = 600):
        self.essais, self.fenetre = essais, fenetre
        self.historique: dict[str, list[float]] = {}
        self.verrou = threading.Lock()

    def autorise(self, adresse: str) -> bool:
        maintenant = time.time()
        with self.verrou:
            recents = [t for t in self.historique.get(adresse, []) if maintenant - t < self.fenetre]
            self.historique[adresse] = recents
            return len(recents) < self.essais

    def echec(self, adresse: str) -> None:
        with self.verrou:
            self.historique.setdefault(adresse, []).append(time.time())


# --------------------------------------------------------------------------- #
# Adresses où joindre l'ordinateur
# --------------------------------------------------------------------------- #
def ip_reseau_local() -> str | None:
    """L'adresse de l'ordinateur sur le Wi-Fi (aucun paquet n'est envoyé)."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("192.0.2.1", 9))
            ip = s.getsockname()[0]
    except OSError:
        return None
    adresse = ipaddress.ip_address(ip)
    if adresse.is_loopback or ip_tailscale_valide(ip):
        return None
    return ip


def ip_tailscale_valide(ip: str) -> bool:
    try:
        return ipaddress.ip_address(ip) in ipaddress.ip_network("100.64.0.0/10")
    except ValueError:
        return False


def ip_tailscale() -> str | None:
    """L'adresse Tailscale de l'ordinateur, si Tailscale est installé et connecté."""
    commandes = [shutil.which("tailscale"), "/Applications/Tailscale.app/Contents/MacOS/Tailscale",
                 r"C:\Program Files\Tailscale\tailscale.exe"]
    for commande in filter(None, commandes):
        try:
            sortie = subprocess.run([commande, "ip", "-4"], capture_output=True, text=True, timeout=3, check=False)
        except (OSError, subprocess.SubprocessError):
            continue
        for ligne in sortie.stdout.split():
            if ip_tailscale_valide(ligne.strip()):
                return ligne.strip()
    return None


def qr_svg(texte: str) -> str:
    tampon = io.BytesIO()
    segno.make(texte, error="m").save(tampon, kind="svg", scale=5, border=2, xmldecl=False, dark="#1B1340")
    return tampon.getvalue().decode()


def adresses(port: int, code: str) -> list[dict]:
    resultat = []
    for type_, ip in (("wifi", ip_reseau_local()), ("tailscale", ip_tailscale())):
        if ip:
            base = f"http://{ip}:{port}"
            lien = f"{base}/connexion?code={code.replace('-', '')}"
            resultat.append({"type": type_, "adresse": base, "lien": lien, "qr": qr_svg(lien)})
    return resultat
