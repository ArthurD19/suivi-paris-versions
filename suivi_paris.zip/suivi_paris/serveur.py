"""Serveur local de Suivi Paris : sert l'interface (dossier web/) et les données (routes /api/…).

Le serveur principal n'écoute que sur 127.0.0.1. Pour qu'une page web ouverte ailleurs dans le navigateur ne
puisse ni lire ni modifier les données, il refuse toute requête dont l'en-tête Host n'est pas le sien, et toute
écriture qui n'a pas l'en-tête « X-Suivi-Paris » (qu'un autre site ne peut pas envoyer sans y être autorisé).

Quand l'accès depuis l'iPhone est activé (voir acces.py), un second serveur écoute sur le réseau : il exige
en plus une session ouverte avec le code d'accès, et certaines actions y sont interdites.
"""
from __future__ import annotations

import csv
import http.cookies
import io
import json
import mimetypes
import os
import re
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
from datetime import date, datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pandas as pd

from . import acces, adaptateurs, analyse, chemins, demo, discord, miseajour, public, resume, soldes, stockage, synchro
from .adaptateurs import asianconnect
from .adaptateurs import mouvements as lecteur_mouvements
from .modeles import LIBELLES_ETATS, LIBELLES_TYPES
from .sports import SPORTS
from .version import VERSION

WEB = Path(__file__).resolve().parent / "web"
TYPES = {".js": "text/javascript", ".css": "text/css", ".html": "text/html", ".woff2": "font/woff2",
         ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".txt": "text/plain", ".webmanifest": "application/manifest+json"}


# Logo personnel d'un bookmaker : une image déposée dans le dossier « logos » des données (pas de SVG, qui peut
# contenir du script).
FORMATS_LOGO = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}


class ErreurClient(Exception):
    pass


class Interdit(Exception):
    """Action réservée à l'ordinateur."""


# Pages et fichiers accessibles sans session sur le serveur réseau (la page de connexion et son habillage).
PUBLIC_DISTANT = ("/connexion.html", "/icone.png", "/manifest.webmanifest", "/polices/")
# Dossier de l'extension Chrome, à charger dans chrome://extensions (affiché sur la page Importer).
DOSSIER_EXTENSION = Path(__file__).resolve().parent.parent / "extension"

# Port de l'appli, fixe pour que l'extension Chrome la trouve (si il est pris, un port au hasard est utilisé).
PORT_LOCAL = 47830

ROUTES_LOCALES = {"/api/quitter", "/api/effacer", "/api/resume/auto", "/api/acces", "/api/acces/code",
                  "/api/mouvements/effacer", "/api/montrer", "/api/mise-a-jour", "/api/redemarrer",
                  "/api/ouvrir-extensions", "/api/paris/supprimer", "/api/mouvements/supprimer", "/api/fermeture",
                  "/api/sites/supprimer", "/api/fusionner", "/api/synchro", "/api/synchro/desactiver",
                  "/api/synchro/maintenant"}


def version_extension_fournie() -> str | None:
    """La version de l'extension livrée avec l'appli (son manifeste), relue à chaque fois : une mise à jour de l'appli
    la change sans redémarrer le serveur."""
    try:
        return json.loads((DOSSIER_EXTENSION / "manifest.json").read_text(encoding="utf-8")).get("version")
    except (OSError, ValueError):
        return None


def ouvrir_page_extensions() -> bool:
    """Ouvre chrome://extensions dans le navigateur habituel (le profil de tous les jours, pas celui de la fenêtre de
    l'appli, où l'extension ne servirait à rien). Renvoie False si aucun navigateur compatible n'est trouvé."""
    from .lanceur import trouver_navigateur  # le lanceur importe ce module : import tardif

    navigateur = trouver_navigateur()
    if navigateur is None:
        return False
    page = "edge://extensions" if "edge" in Path(navigateur).name.lower() else "chrome://extensions"
    subprocess.Popen([navigateur, page], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return True


def montrer_dans_dossier(chemin: Path) -> None:
    """Ouvre le Finder (l'Explorateur sous Windows) sur `chemin`, sélectionné : l'interface n'affiche jamais le
    chemin complet, qui contient le nom de la session de l'utilisateur."""
    if sys.platform == "darwin":
        subprocess.Popen(["open", "-R", str(chemin)])
    elif os.name == "nt":
        subprocess.Popen(["explorer", f"/select,{chemin}"])
    else:
        subprocess.Popen(["xdg-open", str(chemin.parent)])


class Application:
    def __init__(self, chemin_base: Path, mode_demo: bool = False, mobile: bool = False):
        self.chemin_base = Path(chemin_base)
        self.mode_demo = mode_demo
        self.mobile = mobile  # l'appli iPhone : ce code tourne dans le navigateur du téléphone (mobile.py)
        self.verrou = threading.Lock()
        self.cx = stockage.ouvrir(self.chemin_base)
        if mode_demo and not self.cx.execute("SELECT COUNT(*) FROM paris").fetchone()[0]:
            demo.remplir(self.cx)
        self.dernier_signe: float | None = None
        self.fermeture_le: float | None = None  # la fenêtre de l'appli s'est fermée (ou rechargée) à ce moment
        self.arret = threading.Event()
        self.relancer = False  # après une mise à jour : le lanceur rouvre l'appli en s'arrêtant
        self._donnees: tuple | None = None  # (état de la base, paris analysés) : voir donnees()
        self._tableaux: dict = {}
        self.version_extension_vue: str | None = None  # celle qui a écrit en dernier (pas gardée en base)
        self.serveur_distant: ThreadingHTTPServer | None = None
        self.erreur_distant: str | None = None
        self.limiteur = acces.Limiteur()
        self.synchro = synchro.Synchro(self)  # avec l'iPhone, par GitHub (chiffré) ; démarrée par demarrer()

    # ------------------------------------------------------------------ accès depuis l'iPhone
    def demarrer_distant(self) -> None:
        if self.serveur_distant is not None:
            return
        if self.mode_demo:
            raise ErreurClient("L'accès depuis l'iPhone n'est pas disponible en démonstration.")
        port = acces.config()["port"]
        try:
            serveur = ThreadingHTTPServer(("0.0.0.0", port), fabriquer_gestionnaire(self, None, distant=True))
        except OSError as exc:
            self.erreur_distant = (f"Impossible d'ouvrir l'accès sur le port {port} ({exc.strerror or exc}). "
                                   "Une autre fenêtre de Suivi Paris tourne peut-être déjà : quitte-la, puis réessaie.")
            raise ErreurClient(self.erreur_distant) from exc
        self.erreur_distant = None
        serveur.daemon_threads = True
        threading.Thread(target=serveur.serve_forever, daemon=True).start()
        self.serveur_distant = serveur

    def arreter_distant(self) -> None:
        if self.serveur_distant is not None:
            self.serveur_distant.shutdown()
            self.serveur_distant.server_close()
            self.serveur_distant = None

    def etat_acces(self) -> dict:
        cfg = acces.config()
        actif = self.serveur_distant is not None
        return {
            "actif": actif, "port": cfg["port"], "code": cfg["code"], "demo": self.mode_demo,
            "voulu": cfg["actif"], "erreur": self.erreur_distant,
            "adresses": acces.adresses(cfg["port"], cfg["code"]) if actif else [],
        }

    # ------------------------------------------------------------------ lecture
    def dossier_logos(self) -> Path:
        return Path(self.chemin_base).parent / "logos"

    def logo(self, bookmaker: str) -> Path | None:
        if bookmaker not in adaptateurs.ADAPTATEURS:
            return None
        for extension in FORMATS_LOGO:
            chemin = self.dossier_logos() / f"{bookmaker}{extension}"
            if chemin.is_file():
                return chemin
        return None

    def familles(self) -> list[dict]:
        sports = [r[0] for r in self.cx.execute("SELECT sport FROM paris GROUP BY sport ORDER BY COUNT(*) DESC")]
        return analyse.familles_presentes(sports)

    def etat(self, distant: bool = False) -> dict:
        return {
            "demo": self.mode_demo,
            "distant": distant,
            "mobile": self.mobile,
            # L'appli téléphone, publiée sur GitHub Pages avec chaque version (outils/publier.py --iphone).
            "adresse_iphone": "https://{}.github.io/{}/".format(*miseajour.DEPOT_VERSIONS.lower().split("/")),
            "acces_actif": self.serveur_distant is not None,
            # Les bookmakers lus par l'appli, puis les sites ajoutés à la main (`manuel` : ni import ni extension).
            "bookmakers": [{"nom": m.NOM, "libelle": m.LIBELLE, "consigne": m.CONSIGNE, "manuel": False,
                            "logo": self.logo(m.NOM) is not None}
                           for m in adaptateurs.ADAPTATEURS.values()]
                          + [{"nom": x["nom"], "libelle": x["libelle"], "consigne": "", "manuel": True, "logo": False}
                             for x in stockage.lister_sites(self.cx)],
            "familles": self.familles(),
            "comptes": stockage.lister_comptes(self.cx),
            "n_paris": self.cx.execute("SELECT COUNT(*) FROM paris").fetchone()[0],
            "bankroll": stockage.bankroll(self.cx),
            "extension_vue_le": stockage.extension_vue_le(self.cx),
            "extension_fournie": not distant and not self.mobile and DOSSIER_EXTENSION.is_dir(),
            "version": VERSION,
            "version_extension": version_extension_fournie(),
            "version_extension_vue": self.version_extension_vue,
            "developpement": miseajour.copie_de_developpement(),
            "sports": SPORTS,
            "etats": LIBELLES_ETATS,
            "types": LIBELLES_TYPES,
        }

    @staticmethod
    def _liste(q: dict, cle: str, conv=str) -> list | None:
        valeur = q.get(cle, [""])[0]
        return [conv(v) for v in valeur.split(",") if v] or None

    @staticmethod
    def _nombre(valeur) -> float | None:
        """« 12,50 », « 1 200 », 12.5 -> nombre ; vide -> None."""
        if valeur in (None, ""):
            return None
        return float(str(valeur).replace(",", ".").replace(" ", "").replace("\u202f", ""))

    def _saisie(self, corps: dict) -> dict:
        """Le formulaire d'un pari (ajout ou correction), en valeurs prêtes pour stockage."""
        def quand(cle: str) -> datetime | date | None:
            valeur = str(corps.get(cle) or "").strip()
            if not valeur:
                return None
            try:
                if cle == "date_evenement" and len(valeur) == 10:
                    return date.fromisoformat(valeur)  # connue au jour près
                return datetime.fromisoformat(valeur)
            except ValueError:
                raise ErreurClient("Date illisible.") from None

        try:
            nombres = {k: self._nombre(corps.get(k)) for k in ("mise", "cote", "gains")}
            selections = [{**{k: str(s.get(k) or "") for k in ("evenement", "marche", "choix", "competition")},
                           "cote": self._nombre(s.get("cote"))} for s in corps.get("selections") or []]
            nb = int(corps.get("nb_selections") or 0)
        except (ValueError, AttributeError):
            raise ErreurClient("Nombre illisible : écris par exemple 12,50.") from None
        return {"compte_id": int(corps.get("compte_id") or 0), "date_pari": quand("date_pari"),
                "date_evenement": quand("date_evenement"), "type": corps.get("type") or "simple",
                "sport": str(corps.get("sport") or ""), "selections": selections, "nb_selections": nb,
                "cote_boostee": bool(corps.get("cote_boostee")), "freebet": bool(corps.get("freebet")), "etat": corps.get("etat") or "", **nombres}

    @staticmethod
    def _date(q: dict, cle: str) -> date | None:
        valeur = q.get(cle, [""])[0]
        return date.fromisoformat(valeur) if valeur else None

    def donnees(self) -> pd.DataFrame:
        """Tous les paris, analysés : rechargés seulement si la base a changé depuis (ou si le jour a changé).
        Une copie, pour qu'aucune page ne modifie celle gardée."""
        cle = (self.cx.total_changes, date.today())
        if self._donnees is None or self._donnees[0] != cle:
            self._donnees = (cle, analyse.charger(self.cx))
            self._tableaux.clear()
        return self._donnees[1].copy()

    def tableau(self, q: dict) -> dict:
        """Le tableau de bord, gardé pour chaque combinaison de filtres tant que la base ne change pas : revenir
        au tableau de bord ou à une période déjà vue est immédiat."""
        cle = (self.cx.total_changes, date.today(), tuple(sorted((k, tuple(v)) for k, v in q.items())))
        if cle not in self._tableaux:
            if len(self._tableaux) >= 12:
                self._tableaux.pop(next(iter(self._tableaux)))
            self._tableaux[cle] = self._calculer_tableau(q)
        return self._tableaux[cle]

    def _calculer_tableau(self, q: dict) -> dict:
        df = self.donnees()
        comptes = stockage.lister_comptes(self.cx)
        options = analyse.options_filtres(df)
        if df.empty:
            return {"vide": True, "options": options}
        filtres = {
            "debut": self._date(q, "debut"), "fin": self._date(q, "fin"),
            "comptes": self._liste(q, "comptes", int), "sports": self._liste(q, "sports"),
            "types": self._liste(q, "types"), "bookmakers": self._liste(q, "bookmakers"),
            "partages": q.get("partages", [""])[0] == "1",
        }
        return {"vide": False, "options": options, **analyse.tableau(df, comptes, **filtres)}

    def paris(self, q: dict) -> dict:
        df = self.donnees()
        if df.empty:
            return {"total": 0, "lignes": []}
        d = analyse.filtrer(df, debut=self._date(q, "debut"), fin=self._date(q, "fin"),
                            comptes=self._liste(q, "comptes", int), sports=self._liste(q, "sports"),
                            bookmakers=self._liste(q, "bookmakers"), partages=q.get("partages", [""])[0] == "1")
        jour = self._date(q, "jour")
        if jour is not None:  # un jour du calendrier : tous les paris de ce jour, réglés ou non
            d = d[d["date_ref"].dt.date == jour]
        etats = self._liste(q, "etats")
        if etats:
            d = d[d["etat"].isin(etats)]
        reference = q.get("reference", [""])[0]
        if reference:  # un seul pari (avec bookmakers=…) : son ticket
            d = d[d["reference"] == reference]
        recherche = q.get("recherche", [""])[0].strip().lower()
        if recherche:
            champs = d[["resume", "evenement", "choix", "marche", "compte_nom"]].fillna("")
            d = d[champs.apply(lambda col: col.str.lower().str.contains(recherche, regex=False)).any(axis=1)]
        d = d.sort_values(["date_ref", "date_pari"], ascending=False)  # par date de l'événement, comme le calendrier
        page, par_page = int(q.get("page", ["1"])[0]), int(q.get("par_page", ["50"])[0])
        tranche = d.iloc[(page - 1) * par_page : page * par_page]
        colonnes = ["bookmaker", "reference", "compte_id", "compte_nom", "compte_couleur", "date_pari",
                    "date_evenement", "sport", "sport_corrige", "resume", "type", "etat", "etat_brut", "mise", "gains",
                    "profit", "cote", "cote_boostee", "nb_selections", "categorie_marche", "selections", "modifie_main",
                    "valeurs_import", "partage", "partage_le", "etat_au_partage", "partage_source", "partage_pct",
                    "manuel", "champs_corriges", "date_ref", "evenement_heure", "devise", "mise_devise", "gains_devise",
                    "mise_jouee", "freebet"]
        lignes = [{k: analyse._propre(v) for k, v in r.items()} for r in tranche[colonnes].to_dict("records")]
        for l in lignes:  # le détail des sélections, pour afficher le pari comme un ticket
            l["selections"] = json.loads(l["selections"] or "[]")
            l["valeurs_import"] = json.loads(l["valeurs_import"]) if l["valeurs_import"] else None
        return {"total": len(d), "page": page, "par_page": par_page, "lignes": lignes,
                "mise": analyse._propre(d["mise"].sum()), "profit": analyse._propre(d["profit"].sum())}

    def export_csv(self) -> bytes:
        df = self.donnees()
        tampon = io.StringIO()
        if df.empty:
            return "﻿".encode()
        colonnes = ["date_pari", "date_evenement", "bookmaker", "compte_nom", "reference", "sport", "type_libelle",
                    "etat_libelle", "evenement", "marche", "choix", "mise", "gains", "profit", "mise_jouee", "freebet"]
        df[colonnes].to_csv(tampon, sep=";", index=False, quoting=csv.QUOTE_MINIMAL)
        return ("﻿" + tampon.getvalue()).encode("utf-8")

    def copie_base(self) -> bytes:
        with tempfile.TemporaryDirectory() as dossier:
            cible = Path(dossier) / "copie.db"
            with sqlite3.connect(cible) as copie:
                self.cx.backup(copie)
            return cible.read_bytes()

    # ------------------------------------------------------------------ import
    def _analyser_texte(self, corps: dict):
        texte = corps.get("texte") or ""
        if not texte.strip():
            raise ErreurClient("Colle d'abord le texte de ta page d'historique.")
        bookmaker = corps.get("bookmaker") or None
        if bookmaker is None and corps.get("compte_id"):
            # PIWI247 a la même page que ps3838 et son nom n'y figure pas toujours : un collage sur un compte PIWI247
            # que l'on prendrait pour du ps3838 est lu comme PIWI247.
            choisi = stockage.compte(self.cx, corps["compte_id"])
            module = adaptateurs.ADAPTATEURS.get(choisi["bookmaker"]) if choisi else None
            if module is not None and getattr(module, "MEME_PAGE", None) == adaptateurs.detecter(texte):
                bookmaker = module.NOM
        bookmaker, paris, avertissements = adaptateurs.parser(texte, bookmaker)
        if bookmaker is None:
            raise ErreurClient("Bookmaker non reconnu : choisis-le dans la liste.")
        identifiant = adaptateurs.ADAPTATEURS[bookmaker].identifiant(texte)
        return bookmaker, paris, avertissements, identifiant

    def _est_discord(self, corps: dict) -> bool:
        """Des lignes « … @cote (x%) » et aucun pari de bookmaker lisible : un message de pronos. (Le nom d'un
        bookmaker y figure souvent, « :Betclic: » : il ne suffit pas à en faire une page de ce bookmaker.)"""
        texte = corps.get("texte") or ""
        if not discord.reconnait(texte):
            return False
        try:
            _, paris, _ = adaptateurs.parser(texte)
        except (ValueError, IndexError):
            paris = []
        return not paris

    def analyser(self, corps: dict) -> dict:
        if self._est_discord(corps):
            return {"type": "discord", **stockage.relier_discord(self.cx, corps["texte"])}
        bookmaker, paris, avertissements, identifiant = self._analyser_texte(corps)
        compte_id = corps.get("compte_id")
        suggere = stockage.compte_par_identifiant(self.cx, bookmaker, identifiant)
        choisi = stockage.compte(self.cx, compte_id) if compte_id else None
        if choisi and choisi["bookmaker"] != bookmaker:
            choisi, compte_id = None, None
        if compte_id is None and suggere:
            compte_id = suggere["id"]
        if choisi and identifiant and choisi["identifiant"] and choisi["identifiant"] != identifiant:
            avertissements.append(
                f"Cette page est celle du compte Winamax « {identifiant} », mais tu as choisi « {choisi['nom']} »"
                f" (rattaché à « {choisi['identifiant']} »). Vérifie le compte avant d'enregistrer.")
        statuts = stockage.comparer(self.cx, paris, compte_id)
        lignes = []
        for p in paris:
            s = statuts[p.reference]
            lignes.append({
                "reference": p.reference, "date": p.date_pari.isoformat(),
                "sport": p.sport if p.selections else "Combiné", "resume": p.resume, "etat": p.etat,
                "etat_brut": p.etat_brut, "mise": p.mise, "gains": p.gains, "freebet": p.freebet,
                "statut": s["statut"], "autre_compte": s["autre_compte"],
            })
        compte = {"nouveau": 0, "mis à jour": 0, "déjà connu": 0}
        for ligne in lignes:
            compte[ligne["statut"]] += 1
        return {
            "bookmaker": bookmaker, "libelle": adaptateurs.ADAPTATEURS[bookmaker].LIBELLE,
            "identifiant": identifiant, "compte_suggere": suggere["id"] if suggere else None,
            "compte_id": compte_id, "paris": lignes, "bilan": compte,
            "autre_compte": sum(1 for x in lignes if x["autre_compte"]), "avertissements": avertissements,
        }

    def enregistrer(self, corps: dict) -> dict:
        bookmaker, paris, _, identifiant = self._analyser_texte(corps)
        compte_id = corps.get("compte_id")
        if not compte_id:
            raise ErreurClient("Choisis le compte sur lequel enregistrer ces paris.")
        if not paris:
            raise ErreurClient("Aucun pari trouvé dans ce texte.")
        return stockage.enregistrer(self.cx, paris, bookmaker, int(compte_id), identifiant)

    # ------------------------------------------------------------------ extension Chrome
    def _compte_extension(self, bookmaker: str, corps: dict, identifiant: str | None) -> tuple[dict | None, dict]:
        """Le compte d'une page lue par l'extension : celui que la page désigne elle-même (pseudo Winamax, déjà
        rattaché à un compte), sinon celui confirmé sur le site pour cet onglet, sinon le seul compte du
        bookmaker. Sinon : (None, réponse à renvoyer) ; l'extension demande alors sur quel compte on est connecté.
        La page passe avant le choix : un choix resté d'un autre compte ne peut pas l'emporter sur le pseudo affiché."""
        libelle = adaptateurs.ADAPTATEURS[bookmaker].LIBELLE
        comptes = [c for c in stockage.lister_comptes(self.cx) if c["bookmaker"] == bookmaker]
        # Une page de la boîte (extension sans appli, iPhone) désigne son compte par son nom : les numéros des comptes
        # ne sont pas les mêmes sur l'ordinateur et sur l'iPhone.
        nom = str(corps.get("compte_nom") or "").lower()
        choisi = next((c for c in comptes if nom and c["nom"].lower() == nom), None) \
            or next((c for c in comptes if c["id"] == corps.get("compte_id")), None)
        compte = stockage.compte_par_identifiant(self.cx, bookmaker, identifiant) or choisi \
            or (comptes[0] if len(comptes) == 1 else None)
        if compte is None:
            return None, {"statut": "choisir_compte" if comptes else "aucun_compte", "bookmaker": bookmaker,
                          "libelle": libelle, "comptes": [{"id": c["id"], "nom": c["nom"]} for c in comptes]}
        return compte, {"bookmaker": bookmaker, "libelle": libelle, "compte": compte["nom"]}

    def chercher_mise_a_jour(self) -> dict:
        try:
            return miseajour.derniere_version()
        except miseajour.ErreurMiseAJour as exc:
            raise ErreurClient(str(exc)) from None

    def mettre_a_jour(self) -> dict:
        """Télécharge et installe la dernière version ; l'appli est ensuite redémarrée (/api/redemarrer)."""
        try:
            info = miseajour.derniere_version()
            if not info["disponible"]:
                raise ErreurClient(f"Suivi Paris est déjà à jour (version {VERSION}).")
            if not info["zip"]:
                raise ErreurClient("Cette version n'a pas de fichier à installer : préviens celui qui l'a publiée.")
            return miseajour.installer(miseajour.telecharger(info["zip"]))
        except miseajour.ErreurMiseAJour as exc:
            raise ErreurClient(str(exc)) from None

    def solde_extension(self, corps: dict) -> dict:
        """Le haut d'une page du bookmaker : son solde, s'il est affiché."""
        bookmaker = corps.get("bookmaker") or ""
        if bookmaker not in adaptateurs.ADAPTATEURS:
            return {"statut": "non_reconnu"}
        solde, identifiant = soldes.lire(bookmaker, corps.get("texte") or "")
        if solde is None:
            return {"statut": "aucun_solde", "bookmaker": bookmaker}
        compte, reponse = self._compte_extension(bookmaker, corps, identifiant)
        if compte is not None and (erreur := self._autre_devise(compte, corps.get("texte") or "", reponse)):
            return erreur
        if compte is None:
            if reponse["statut"] == "choisir_compte":  # à attribuer dans la page Soldes
                stockage.garder_solde_en_attente(self.cx, bookmaker, solde, corps.get("capture_le"), identifiant)
            return {**reponse, "solde": solde}
        change = stockage.releve_solde(self.cx, compte["id"], solde, corps.get("capture_le"), identifiant)
        stockage.oublier_solde_en_attente(self.cx, bookmaker)
        return {"statut": "ok", "solde": solde, "change": change, **reponse}

    def _autre_devise(self, compte: dict, texte: str, reponse: dict) -> dict | None:
        """Le site affiche une autre monnaie que celle du compte (des francs suisses sur un compte en euros) : rien
        n'est enregistré, tant que la monnaie du compte n'est pas réglée (page Comptes)."""
        lue = soldes.devise(texte)
        if lue is None or lue == (compte.get("devise") or "EUR"):
            return None
        return {"statut": "autre_devise", **reponse, "devise": lue, "nouveaux": 0, "message": (
            f"Suivi Paris : ce compte {reponse['libelle']} est en {lue}. Règle sa monnaie et son taux dans la page "
            "Comptes de l'appli : rien n'est enregistré d'ici là.")}

    def mouvements_extension(self, corps: dict) -> dict:
        """Une page de dépôts ou de retraits lue par l'extension. Le sens : celui de chaque ligne (PMU), sinon
        l'adresse de la page (« depot », « withdraw »…), sinon le moyen de paiement (Betclic : dépôts seulement)."""
        bookmaker = corps.get("bookmaker") or ""
        if bookmaker == asianconnect.NOM:
            return self.mouvements_asianconnect(corps)
        if bookmaker not in adaptateurs.ADAPTATEURS:
            return {"statut": "non_reconnu"}
        texte = (corps.get("texte") or "").translate(adaptateurs._ESPACES)
        mouvements, _ = lecteur_mouvements.lire(texte)
        if not mouvements:
            return {"statut": "aucun_mouvement", "bookmaker": bookmaker}
        identifiant = adaptateurs.ADAPTATEURS[bookmaker].identifiant(texte)
        compte, reponse = self._compte_extension(bookmaker, corps, identifiant)
        if compte is None:
            return reponse
        if erreur := self._autre_devise(compte, texte, reponse):
            return erreur
        sens = lecteur_mouvements.deviner_sens(mouvements)
        adresse = (corps.get("url") or "").lower()
        if sens != "page":
            if re.search(r"withdraw|retrait|payout|cashout", adresse):
                sens = "retrait"
            elif re.search(r"deposit|depot|dépôt|approvision", adresse):
                sens = "depot"
        bilan = stockage.enregistrer_mouvements(self.cx, compte["id"], sens, mouvements)
        return {"statut": "ok", "sens": sens, **reponse, **bilan}

    def mouvements_asianconnect(self, corps: dict) -> dict:
        """L'historique d'AsianConnect, le courtier de ps3838 et PIWI247 : chaque transaction dépliée va sur le compte
        qu'elle nomme (« PS3838 (AC12345678) »), reconnu à son numéro (relevé avec le solde sur le site), sinon le
        seul compte de ce bookmaker, qui prend alors ce numéro. Plusieurs comptes sans ce numéro : rien n'est deviné."""
        texte = (corps.get("texte") or "").translate(adaptateurs._ESPACES)
        lus, _, fermees = asianconnect.lire(texte)
        reponse = {"bookmaker": asianconnect.NOM, "libelle": asianconnect.LIBELLE, "fermees": fermees}
        if not lus:
            return {"statut": "aucun_mouvement", **reponse}
        groupes: dict[tuple[str, str], list] = {}
        for m in lus:
            groupes.setdefault((m.bookmaker, m.identifiant), []).append(m.mouvement)
        nouveaux, noms, sans_compte = 0, [], []
        for (bookmaker, identifiant), mouvements in groupes.items():
            compte = stockage.compte_par_identifiant(self.cx, bookmaker, identifiant)
            if compte is None:
                comptes = [c for c in stockage.lister_comptes(self.cx) if c["bookmaker"] == bookmaker]
                if len(comptes) == 1 and not comptes[0]["identifiant"]:
                    compte = comptes[0]
                    stockage.rattacher_identifiant(self.cx, compte["id"], identifiant)
            libelle = adaptateurs.ADAPTATEURS[bookmaker].LIBELLE
            if compte is None:
                sans_compte.append(f"{libelle} {identifiant}")
                continue
            nouveaux += stockage.enregistrer_mouvements(self.cx, compte["id"], "page", mouvements)["nouveaux"]
            noms.append(f"{libelle} {compte['nom']}")
        message = None
        if sans_compte:
            message = (f"Suivi Paris : aucun compte pour {', '.join(sans_compte)}. Crée-le, ou ouvre une fois ce compte "
                       "sur son site (son numéro est relevé avec le solde), puis rouvre cette page.")
        return {"statut": "ok", **reponse, "compte": ", ".join(noms), "nouveaux": nouveaux, "sans_compte": sans_compte,
                "message": message}

    def importer_extension(self, corps: dict) -> dict:
        """Une page de paris lue par l'extension. Le compte : celui choisi dans l'extension, sinon celui du pseudo
        (Winamax), sinon le seul compte du bookmaker. Plusieurs comptes et aucun choix : on demande."""
        texte = corps.get("texte") or ""
        capture = corps.get("capture_le") or ""
        aujourd_hui = date.fromisoformat(capture[:10]) if capture else None
        bookmaker, paris, avertissements = adaptateurs.parser(texte, corps.get("bookmaker") or None, aujourd_hui)
        if bookmaker is None:
            return {"statut": "non_reconnu"}
        if not paris:
            return {"statut": "aucun_pari", "bookmaker": bookmaker,
                    "libelle": adaptateurs.ADAPTATEURS[bookmaker].LIBELLE}
        identifiant = adaptateurs.ADAPTATEURS[bookmaker].identifiant(texte)
        compte, reponse = self._compte_extension(bookmaker, corps, identifiant)
        if compte is None:
            return reponse
        bilan = stockage.enregistrer(self.cx, paris, bookmaker, compte["id"], identifiant)
        return {"statut": "ok", **reponse, "avertissements": avertissements, **bilan}

    # ------------------------------------------------------------------ dépôts et retraits
    def argent(self) -> dict:
        return {**stockage.bilan_argent(self.cx), "mouvements": stockage.lister_mouvements(self.cx),
                "soldes_en_attente": stockage.soldes_en_attente(self.cx)}

    def _lire_mouvements(self, corps: dict):
        texte = corps.get("texte") or ""
        if not texte.strip():
            raise ErreurClient("Colle d'abord la page de tes dépôts ou de tes retraits.")
        compte_id = corps.get("compte_id")
        if not compte_id or stockage.compte(self.cx, int(compte_id)) is None:
            raise ErreurClient("Choisis le compte de ces dépôts ou retraits.")
        mouvements, avertissements = lecteur_mouvements.lire(texte)
        if not mouvements:
            raise ErreurClient("Aucun dépôt ni retrait reconnu dans ce texte. Colle la page entière (Ctrl+A, Ctrl+C).")
        devine = lecteur_mouvements.deviner_sens(mouvements)
        # « page » : la page dit le sens de chaque mouvement (PMU), rien à choisir.
        sens = "page" if devine == "page" else corps.get("sens") or devine
        if sens not in (*stockage.SENS, "page"):
            raise ErreurClient("Indique s'il s'agit de dépôts ou de retraits.")
        return int(compte_id), sens, devine, mouvements, avertissements

    def analyser_mouvements(self, corps: dict) -> dict:
        compte_id, sens, devine, mouvements, avertissements = self._lire_mouvements(corps)
        return {"sens": sens, "sens_devine": devine, "avertissements": avertissements,
                **stockage.comparer_mouvements(self.cx, compte_id, sens, mouvements)}

    def enregistrer_mouvements(self, corps: dict) -> dict:
        compte_id, sens, _, mouvements, _ = self._lire_mouvements(corps)
        return {"sens": sens, **stockage.enregistrer_mouvements(self.cx, compte_id, sens, mouvements)}

    # ------------------------------------------------------------------ résumé iPhone
    def etat_resume(self) -> dict:
        chemin, icloud = resume.destination(not self.mode_demo)
        existe = chemin.exists()
        return {
            "auto": bool(resume.reglages().get("resume_auto")) and not self.mode_demo,
            "icloud": icloud, "chemin": str(chemin), "existe": existe,
            "date": datetime.fromtimestamp(chemin.stat().st_mtime).isoformat(timespec="seconds") if existe else None,
            "demo": self.mode_demo,
        }

    # ------------------------------------------------------------------ routage
    def repondre(self, methode: str, chemin: str, requete: str, brut: bytes, distant: bool = False
                 ) -> tuple[int, bytes, str, dict | None]:
        """Une requête /api/… : (statut, contenu, type, en-têtes). Le serveur HTTP et l'appli iPhone (mobile.py,
        dans le navigateur) passent tous deux par ici."""
        def joint(contenu: bytes, type_: str, nom: str) -> tuple:
            return 200, contenu, type_, {"Content-Disposition": f'attachment; filename="{nom}"'}

        def json_(statut: int, donnees) -> tuple:
            return statut, json.dumps(donnees, ensure_ascii=False, default=str).encode("utf-8"), \
                "application/json; charset=utf-8", None

        if chemin == "/api/export.csv":
            with self.verrou:
                return joint(self.export_csv(), "text/csv; charset=utf-8", f"paris_{datetime.now():%Y-%m-%d}.csv")
        if chemin == "/api/resume.html":
            with self.verrou:
                return joint(resume.generer(self.cx).encode("utf-8"), "text/html; charset=utf-8", "Suivi Paris - resume.html")
        if chemin == "/api/partages.html":
            with self.verrou:
                return joint(public.generer(self.cx).encode("utf-8"), "text/html; charset=utf-8", "Suivi public.html")
        if chemin.startswith("/api/logo/"):
            fichier = self.logo(chemin.rsplit("/", 1)[-1])
            if fichier is None:
                return 404, b"Introuvable", "text/plain", None
            return 200, fichier.read_bytes(), FORMATS_LOGO[fichier.suffix.lower()], None
        if chemin == "/api/sauvegarde.db":
            with self.verrou:
                return joint(self.copie_base(), "application/octet-stream",
                             f"suivi-paris-sauvegarde_{datetime.now():%Y-%m-%d}.db")
        try:
            corps = json.loads(brut or b"{}")
        except json.JSONDecodeError:
            return json_(400, {"erreur": "Requête illisible."})
        try:
            with self.verrou:
                resultat = self.traiter(methode, chemin, parse_qs(requete), corps, distant)
            if methode != "GET" and not chemin.startswith("/api/synchro"):
                self.synchro.signaler()  # la base a pu changer : l'iPhone la recevra
            return json_(200, resultat)
        except Interdit:
            return json_(403, {"erreur": "Cette action se fait sur l'ordinateur."})
        except (ErreurClient, ValueError, KeyError) as exc:
            return json_(400, {"erreur": str(exc) if not isinstance(exc, KeyError) else f"Champ manquant : {exc}"})
        except LookupError:
            return json_(404, {"erreur": "Route inconnue."})
        except Exception as exc:  # noqa: BLE001
            return json_(HTTPStatus.INTERNAL_SERVER_ERROR, {"erreur": f"Erreur interne : {exc}"})

    def traiter(self, methode: str, chemin: str, q: dict, corps: dict, distant: bool = False):
        if distant and chemin in ROUTES_LOCALES:
            raise Interdit(chemin)
        routes_lecture = {
            "/api/etat": lambda: self.etat(distant),
            "/api/mise-a-jour": lambda: self.chercher_mise_a_jour(),
            "/api/acces": lambda: self.etat_acces(),
            "/api/synchro": lambda: self.synchro.etat(),
            "/api/tableau": lambda: self.tableau(q),
            "/api/paris": lambda: self.paris(q),
            "/api/imports": lambda: stockage.imports(self.cx),
            "/api/resume": lambda: self.etat_resume(),
            "/api/argent": lambda: self.argent(),
        }
        if methode == "GET" and chemin in routes_lecture:
            return routes_lecture[chemin]()
        if methode == "POST":
            if chemin == "/api/analyser":
                return self.analyser(corps)
            if chemin == "/api/enregistrer":
                return self.enregistrer(corps)
            if chemin == "/api/comptes":
                bookmaker = corps.get("bookmaker", "")
                if corps.get("site"):  # un site que l'appli ne lit pas : paris et soldes à la main
                    bookmaker = stockage.creer_site(self.cx, corps["site"],
                                                    {n: m.LIBELLE for n, m in adaptateurs.ADAPTATEURS.items()})
                elif bookmaker not in adaptateurs.ADAPTATEURS and bookmaker not in {
                        x["nom"] for x in stockage.lister_sites(self.cx)}:
                    raise ErreurClient("Choisis le site du compte.")
                cid = stockage.creer_compte(self.cx, bookmaker, corps.get("nom", ""), corps.get("couleur"))
                return stockage.compte(self.cx, cid)
            if chemin.startswith("/api/extension/"):
                if self.mode_demo:
                    raise ErreurClient("L'extension n'importe rien dans la démonstration.")
                stockage.noter_extension(self.cx)
                self.version_extension_vue = corps.get("version_extension") or self.version_extension_vue
                traitement = {
                    "/api/extension/importer": self.importer_extension,
                    "/api/extension/solde": self.solde_extension,
                    "/api/extension/mouvements": self.mouvements_extension,
                    "/api/extension/bonjour": lambda _corps: {"statut": "ok"},  # l'extension démarre : installée
                }.get(chemin)
                if traitement is not None:
                    # L'extension chargée depuis le dossier de l'appli se recharge d'elle-même si l'appli en livre
                    # une plus récente (après une mise à jour de l'appli).
                    return {**traitement(corps), "version_extension": version_extension_fournie()}
            if chemin == "/api/ouvrir-extensions":
                if not ouvrir_page_extensions():
                    raise ErreurClient("Chrome ou Edge introuvable : ouvre-le et tape chrome://extensions dans la barre "
                                       "d'adresse.")
                montrer_dans_dossier(DOSSIER_EXTENSION)
                return {"ok": True}
            if chemin == "/api/montrer":
                cible = {"extension": DOSSIER_EXTENSION, "base": self.chemin_base}.get(corps.get("quoi"))
                if cible is None or not cible.exists():
                    raise ErreurClient("Dossier introuvable.")
                montrer_dans_dossier(cible)
                return {"ok": True}
            if chemin == "/api/soldes/attribuer":
                solde = stockage.attribuer_solde_en_attente(self.cx, corps.get("bookmaker") or "",
                                                            int(corps.get("compte_id") or 0))
                return {"solde": solde}
            if chemin == "/api/soldes/oublier":
                stockage.oublier_solde_en_attente(self.cx, corps.get("bookmaker") or "")
                return {"ok": True}
            if chemin == "/api/discord/relier":
                if not self._est_discord(corps):
                    raise ErreurClient("Ce texte n'est pas un message de pronos Discord.")
                return stockage.relier_discord(self.cx, corps["texte"], appliquer=True)
            if chemin == "/api/bankroll":
                montant = self._nombre(corps.get("bankroll"))
                stockage.definir_bankroll(self.cx, montant)
                return {"bankroll": stockage.bankroll(self.cx)}
            if chemin == "/api/mouvements/analyser":
                return self.analyser_mouvements(corps)
            if chemin == "/api/mouvements":
                return self.enregistrer_mouvements(corps)
            if chemin == "/api/mouvements/effacer":
                stockage.sauvegarder(self.cx, self.chemin_base, "avant-effacement-mouvements")
                n = stockage.effacer_mouvements(self.cx, int(corps["compte_id"]), corps.get("sens") or None)
                return {"effaces": n}
            if chemin == "/api/paris/sport":
                stockage.corriger_sport(self.cx, corps["bookmaker"], corps["reference"], corps["sport"])
                return {"ok": True}
            if chemin == "/api/paris/modifier":
                try:
                    valeurs = {k: self._nombre(corps.get(k)) for k in ("gains", "mise", "cote")}
                except ValueError:
                    raise ErreurClient("Montant illisible : écris par exemple 12,50.") from None
                stockage.modifier_pari(self.cx, corps["bookmaker"], corps["reference"], corps.get("etat", ""), **valeurs)
                return {"ok": True}
            if chemin == "/api/paris/ajouter":
                p = stockage.ajouter_pari(self.cx, self._saisie(corps))
                return {"bookmaker": p["bookmaker"], "reference": p["reference"]}
            if chemin == "/api/paris/editer":
                p = stockage.editer_pari(self.cx, corps["bookmaker"], corps["reference"], self._saisie(corps))
                return {"bookmaker": p["bookmaker"], "reference": p["reference"]}
            if chemin == "/api/paris/supprimer":
                stockage.supprimer_pari(self.cx, corps["bookmaker"], corps["reference"])
                return {"ok": True}
            if chemin == "/api/fusionner":  # la base de l'iPhone (ou de l'ordinateur), ajoutée à celle-ci
                import base64

                try:
                    octets = base64.b64decode(corps.get("base") or "", validate=True)
                except ValueError:
                    raise ErreurClient("Fichier illisible.") from None
                bilan = stockage.fusionner(self.cx, octets)
                self._donnees, self._tableaux = None, {}
                return bilan
            if chemin in ("/api/synchro", "/api/synchro/desactiver", "/api/synchro/maintenant"):
                if self.mode_demo:
                    raise ErreurClient("Pas de synchronisation en démonstration.")
                try:
                    if chemin == "/api/synchro/desactiver":
                        return self.synchro.desactiver()
                    if chemin == "/api/synchro/maintenant":
                        self.synchro.signaler()
                        return self.synchro.etat()
                    return self.synchro.activer(corps.get("jeton") or "")
                except synchro.ErreurSynchro as exc:
                    raise ErreurClient(str(exc)) from None
            if chemin == "/api/sites/supprimer":
                try:
                    stockage.supprimer_site(self.cx, str(corps.get("nom") or ""))
                except ValueError as exc:
                    raise ErreurClient(str(exc)) from None
                return {"ok": True}
            if chemin == "/api/mouvements/ajouter":
                try:
                    montant = self._nombre(corps.get("montant"))
                    quand = datetime.fromisoformat(str(corps.get("date") or ""))
                except ValueError:
                    raise ErreurClient("Montant ou date illisible.") from None
                return stockage.ajouter_mouvement(self.cx, int(corps.get("compte_id") or 0), corps.get("sens", ""),
                                                  quand, montant or 0)
            if chemin == "/api/mouvements/supprimer":
                n = stockage.supprimer_mouvement(self.cx, int(corps["compte_id"]), corps["sens"], corps["date"],
                                                 float(corps["montant"]), int(corps["rang"]))
                return {"supprimes": n}
            if chemin == "/api/paris/partage":
                stockage.partager_pari(self.cx, corps["bookmaker"], corps["reference"], bool(corps.get("partage")))
                return {"ok": True}
            if chemin == "/api/paris/compte":
                n = stockage.deplacer_paris(self.cx, corps["bookmaker"], corps["references"], int(corps["compte_id"]))
                return {"deplaces": n}
            if chemin == "/api/effacer":
                if corps.get("confirmation") != "EFFACER":
                    raise ErreurClient("Confirmation manquante.")
                stockage.sauvegarder(self.cx, self.chemin_base, "avant-effacement")
                stockage.supprimer_tout(self.cx)
                return {"ok": True}
            if chemin == "/api/resume":
                resume.ecrire(self.cx, icloud_autorise=not self.mode_demo)
                return self.etat_resume()
            if chemin == "/api/resume/auto":
                if self.mode_demo:
                    raise ErreurClient("Indisponible en démonstration.")
                resume.enregistrer_reglages(resume_auto=bool(corps.get("actif")))
                return self.etat_resume()
            if chemin == "/api/acces":
                if corps.get("actif"):
                    self.demarrer_distant()
                else:
                    self.arreter_distant()
                acces.reglages.ecrire(acces_actif=self.serveur_distant is not None)
                return self.etat_acces()
            if chemin == "/api/acces/code":
                acces.changer_code()
                return self.etat_acces()
            if chemin == "/api/ping":
                self.dernier_signe = time.time()
                return {"ok": True}
            if chemin == "/api/fermeture":  # la page se ferme ; si aucune ne se rouvre (rechargement), l'appli s'arrête
                self.fermeture_le = time.time()
                return {"ok": True}
            if chemin == "/api/quitter":
                threading.Timer(0.3, self.arret.set).start()
                return {"ok": True}
            if chemin == "/api/redemarrer":  # après une mise à jour : le lanceur rouvre l'appli
                self.relancer = True
                threading.Timer(0.3, self.arret.set).start()
                return {"ok": True}
            if chemin == "/api/mise-a-jour":
                return self.mettre_a_jour()
        if chemin.startswith("/api/comptes/"):
            cid = int(chemin.rsplit("/", 1)[1])
            if methode == "PATCH":
                solde, effacer = None, False
                if "solde" in corps:
                    brut = str(corps["solde"] if corps["solde"] is not None else "").replace(",", ".").replace(" ", "")
                    try:
                        solde, effacer = (float(brut), False) if brut else (None, True)
                    except ValueError:
                        raise ErreurClient("Solde illisible : écris un montant, par exemple 12,50.") from None
                taux = None
                if corps.get("taux") not in (None, ""):
                    try:
                        taux = float(str(corps["taux"]).replace(",", ".").replace(" ", ""))
                    except ValueError:
                        raise ErreurClient("Taux illisible : écris un nombre, par exemple 1,07.") from None
                try:
                    stockage.modifier_compte(self.cx, cid, corps.get("nom"), corps.get("couleur"), solde, effacer,
                                             corps.get("devise"), taux)
                except ValueError as exc:
                    raise ErreurClient(str(exc)) from None
                return stockage.compte(self.cx, cid)
            if methode == "DELETE":
                stockage.supprimer_compte(self.cx, cid)
                return {"ok": True}
        raise LookupError(chemin)


def fabriquer_gestionnaire(app: Application, hote_attendu: str | None, distant: bool = False):
    class Gestionnaire(BaseHTTPRequestHandler):
        server_version = "SuiviParis"

        def log_message(self, *args):  # silencieux
            pass

        def _envoyer(self, statut: int, contenu: bytes, type_: str, entetes: dict | None = None):
            self.send_response(statut)
            self.send_header("Content-Type", type_)
            self.send_header("Content-Length", str(len(contenu)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            for k, v in (entetes or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(contenu)

        def _json(self, statut: int, donnees) -> None:
            self._envoyer(statut, json.dumps(donnees, ensure_ascii=False, default=str).encode(),
                          "application/json; charset=utf-8")

        def _hote_valide(self) -> bool:
            return distant or self.headers.get("Host", "") == hote_attendu

        def _session(self) -> bool:
            if not distant:
                return True
            biscuits = http.cookies.SimpleCookie()
            try:
                biscuits.load(self.headers.get("Cookie", ""))
            except http.cookies.CookieError:
                return False
            valeur = biscuits.get(acces.NOM_COOKIE)
            return acces.session_valide(valeur.value if valeur else None)

        def _rediriger(self, cible: str, entetes: dict | None = None) -> None:
            self.send_response(302)
            self.send_header("Location", cible)
            self.send_header("Content-Length", "0")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Referrer-Policy", "no-referrer")
            for k, v in (entetes or {}).items():
                self.send_header(k, v)
            self.end_headers()

        def _connexion(self, methode: str, url) -> bool:
            """Gère /connexion (lien du QR code) et /api/connexion (code tapé). Renvoie True si traité."""
            adresse = self.client_address[0]
            if methode == "GET" and url.path == "/connexion":
                code = acces.normaliser_code(parse_qs(url.query).get("code", [""])[0])
                if code and app.limiteur.autorise(adresse) and hmac_egal(code, acces.config()["code"]):
                    self._rediriger("/", {"Set-Cookie": acces.cookie_session(code)})
                else:
                    if code:
                        app.limiteur.echec(adresse)
                    self._rediriger("/connexion.html?erreur=1")
                return True
            if methode == "POST" and url.path == "/api/connexion":
                if not app.limiteur.autorise(adresse):
                    self._json(429, {"erreur": "Trop d'essais : réessaie dans quelques minutes."})
                    return True
                longueur = int(self.headers.get("Content-Length") or 0)
                try:
                    corps = json.loads(self.rfile.read(longueur) or b"{}") if longueur else {}
                except json.JSONDecodeError:
                    corps = {}
                code = acces.normaliser_code(str(corps.get("code", "")))
                if code and hmac_egal(code, acces.config()["code"]):
                    self._envoyer(200, b'{"ok": true}', "application/json",
                                  {"Set-Cookie": acces.cookie_session(code)})
                else:
                    app.limiteur.echec(adresse)
                    self._json(401, {"erreur": "Code incorrect. Il s'affiche sur l'ordinateur, page iPhone."})
                return True
            return False

        def _statique(self, chemin: str) -> None:
            relatif = "index.html" if chemin in ("/", "") else chemin.lstrip("/")
            cible = (WEB / relatif).resolve()
            if not str(cible).startswith(str(WEB)) or not cible.is_file():
                self._envoyer(404, b"Introuvable", "text/plain")
                return
            type_ = TYPES.get(cible.suffix, mimetypes.guess_type(cible.name)[0] or "application/octet-stream")
            if type_.startswith("text/"):
                type_ += "; charset=utf-8"
            self._envoyer(200, cible.read_bytes(), type_)

        def _traiter(self, methode: str) -> None:
            if not self._hote_valide():
                self._envoyer(403, b"Refuse", "text/plain")
                return
            url = urlparse(self.path)
            if distant:
                if self._connexion(methode, url):
                    return
                if not self._session():
                    if methode == "GET" and url.path.startswith(PUBLIC_DISTANT):
                        self._statique(url.path)
                    elif url.path.startswith("/api/"):
                        self._json(401, {"erreur": "Session expirée : reconnecte-toi avec le code d'accès."})
                    else:
                        self._rediriger("/connexion.html")
                    return
            if not url.path.startswith("/api/"):
                if methode == "GET":
                    self._statique(url.path)
                else:
                    self._envoyer(405, b"", "text/plain")
                return
            if methode != "GET" and self.headers.get("X-Suivi-Paris") != "1":
                self._envoyer(403, b"Refuse", "text/plain")
                return
            longueur = int(self.headers.get("Content-Length") or 0)
            brut = self.rfile.read(longueur) if longueur else b""
            statut, contenu, type_, entetes = app.repondre(methode, url.path, url.query, brut, distant)
            self._envoyer(statut, contenu, type_, entetes)

        def do_GET(self):
            self._traiter("GET")

        def do_POST(self):
            self._traiter("POST")

        def do_PATCH(self):
            self._traiter("PATCH")

        def do_DELETE(self):
            self._traiter("DELETE")

    return Gestionnaire


def hmac_egal(a: str, b: str) -> bool:
    return acces.hmac.compare_digest(a.encode(), b.encode())


def demarrer(port: int = 0, mode_demo: bool | None = None, chemin_base: Path | None = None,
             acces_reseau: bool | None = None):
    """Démarre le serveur dans un fil d'exécution. Renvoie (serveur, application, url).

    L'accès réseau (iPhone) est rouvert s'il était activé, sauf si `acces_reseau=False`."""
    mode_demo = chemins.mode_demo() if mode_demo is None else mode_demo
    app = Application(chemin_base or chemins.base(mode_demo), mode_demo)
    serveur = ThreadingHTTPServer(("127.0.0.1", port), None)
    port = serveur.server_address[1]
    serveur.RequestHandlerClass = fabriquer_gestionnaire(app, f"127.0.0.1:{port}")
    serveur.daemon_threads = True
    threading.Thread(target=serveur.serve_forever, daemon=True).start()
    if not mode_demo:
        app.synchro.demarrer()
    if acces_reseau is None:
        acces_reseau = not mode_demo and acces.config()["actif"]
    if acces_reseau:
        try:
            app.demarrer_distant()
        except ErreurClient:
            pass  # la page iPhone affichera l'accès comme coupé, avec le moyen de le relancer
    return serveur, app, f"http://127.0.0.1:{port}"
