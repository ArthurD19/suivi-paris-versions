"""Calculs du tableau de bord, à partir de la base. Aucune dépendance à l'interface : tout sort en
structures simples (listes, dictionnaires), prêtes à être envoyées en JSON."""
from __future__ import annotations

import math
import sqlite3

import numpy as np
import pandas as pd

from .adaptateurs import ADAPTATEURS
from .modeles import ANNULE, EN_COURS, ETATS_REGLES, GAGNE, LIBELLES_ETATS, LIBELLES_TYPES, PERDU, categorie_marche
from .sports import AUTRES_SPORTS, FAMILLES, famille

TRANCHES_MISE = ([0, 10, 25, 50, 100, np.inf], ["< 10 €", "10–25 €", "25–50 €", "50–100 €", "≥ 100 €"])
TRANCHES_ANTICIPATION = (
    [-np.inf, 1, 6, 24, 24 * 7, np.inf],
    ["< 1 h ou en direct", "1 à 6 h avant", "6 à 24 h avant", "1 à 7 jours avant", "Plus de 7 jours avant"],
)
TRANCHES_COTE = ([1, 1.5, 2, 3, 5, 10, np.inf], ["1 – 1,5", "1,5 – 2", "2 – 3", "3 – 5", "5 – 10", "10 et +"])
TRANCHES_HEURE = ([0, 6, 12, 14, 18, 21, 24], ["Nuit (0 h – 6 h)", "Matin (6 h – 12 h)", "Midi (12 h – 14 h)",
                                             "Après-midi (14 h – 18 h)", "Soirée (18 h – 21 h)", "Tard (21 h – 0 h)"])
JOURS = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]


def _propre(x):
    """NaN / infinis / types numpy -> valeurs JSON."""
    if x is None or x is pd.NaT:
        return None
    if isinstance(x, np.bool_):
        return bool(x)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating, float)):
        return None if math.isnan(x) or math.isinf(x) else round(float(x), 4)
    if isinstance(x, pd.Timestamp):
        return None if pd.isna(x) else x.isoformat()
    return x


def charger(cx: sqlite3.Connection) -> pd.DataFrame:
    df = pd.read_sql_query(
        """SELECT p.*, c.nom AS compte_nom, c.couleur AS compte_couleur, COALESCE(c.devise, 'EUR') AS devise,
                  CASE WHEN COALESCE(c.devise, 'EUR') = 'EUR' THEN 1.0 ELSE COALESCE(c.taux, 1.0) END AS taux
           FROM paris p LEFT JOIN comptes c ON c.id = p.compte_id""",
        cx,
    )
    if df.empty:
        return df
    # Un compte dans une autre monnaie (francs suisses) : tous les chiffres en euros, au taux fixé pour le compte ;
    # les montants du bookmaker restent à côté (`mise_devise`), pour les corriger dans sa monnaie.
    df["mise_devise"], df["gains_devise"] = df["mise"], df["gains"]
    df["mise"], df["gains"] = (df["mise"] * df["taux"]).round(2), (df["gains"] * df["taux"]).round(2)
    # Un freebet ne coûte rien : `mise` est l'argent réellement engagé (profit, ROI, montants misés), `mise_jouee` la
    # mise affichée sur le ticket.
    df["freebet"] = df["freebet"].fillna(0).astype(int) if "freebet" in df else 0
    df["mise_jouee"] = df["mise"]
    df["mise"] = np.where(df["freebet"] == 1, 0.0, df["mise_jouee"])
    # format="ISO8601" : des dates avec ou sans fractions de seconde peuvent se côtoyer dans la base.
    df["date_pari"] = pd.to_datetime(df["date_pari"], format="ISO8601")
    # « 2026-10-14 » : l'événement n'est connu qu'au jour près (Winamax, ps3838) ; « …T20:45:00 » : à l'heure près.
    heure_connue = df["date_evenement"].fillna("").astype(str).str.len() > 10
    df["date_evenement"] = pd.to_datetime(df["date_evenement"], format="ISO8601")
    # Date de référence d'un pari : celle de l'événement si on la connaît (Betclic), sinon celle du pari.
    df["date_ref"] = df["date_evenement"].fillna(df["date_pari"])
    # Un pari réglé a eu lieu : un événement daté dans le futur est une année mal devinée, la date du pari fait foi.
    futur = (df["etat"] != EN_COURS) & (df["date_evenement"] > pd.Timestamp.now() + pd.Timedelta(days=2))
    df.loc[futur, "date_ref"] = df.loc[futur, "date_pari"]
    df["regle"] = df["etat"].isin(ETATS_REGLES)
    df["profit"] = np.where(df["regle"], df["gains"].fillna(0) - df["mise"], np.nan)
    df.loc[df["etat"] == ANNULE, "profit"] = 0.0
    # Les gains d'un freebet ne rendent pas la mise : sa cote est gains / mise + 1.
    df["cote_gagnee"] = np.where(df["etat"] == GAGNE, df["gains"] / df["mise_jouee"] + df["freebet"], np.nan)
    df["anticipation_h"] = ((df["date_evenement"] - df["date_pari"]).dt.total_seconds() / 3600).where(heure_connue)
    df["evenement_heure"] = heure_connue
    df["etat_libelle"] = df["etat"].map(LIBELLES_ETATS).fillna(df["etat"])
    df["type_libelle"] = df["type"].map(LIBELLES_TYPES).fillna(df["type"])
    libelles = {nom: m.LIBELLE for nom, m in ADAPTATEURS.items()}
    libelles |= {r[0]: r[1] for r in cx.execute("SELECT nom, libelle FROM sites")}  # sites ajoutés à la main
    df["bookmaker_libelle"] = df["bookmaker"].map(libelles).fillna(df["bookmaker"].str.capitalize())
    df["famille"] = df["sport"].map(famille)
    # Moment où le pari a été pris (et non celui de l'événement).
    df["jour_semaine"] = pd.Categorical(df["date_pari"].dt.dayofweek.map(dict(enumerate(JOURS))),
                                        categories=JOURS, ordered=True)
    df["heure"] = df["date_pari"].dt.hour + df["date_pari"].dt.minute / 60
    df["boost_libelle"] = np.where(df["cote_boostee"] == 1, "Cotes boostées", "Cotes normales")
    df["compte_nom"] = df["compte_nom"].fillna("Sans compte")
    df["compte_libelle"] = df["compte_nom"] + " (" + df["bookmaker_libelle"] + ")"
    df["mois"] = df["date_ref"].dt.to_period("M").astype(str)
    # Recalculée à chaque chargement : une amélioration du regroupement profite aussi aux paris déjà importés.
    simples = (df["type"] == "simple") & (df["cote_boostee"] == 0) & df["marche"].fillna("").ne("")
    df.loc[simples, "categorie_marche"] = [categorie_marche(m, c or "") for m, c in
                                           zip(df.loc[simples, "marche"], df.loc[simples, "choix"].fillna(""), strict=True)]
    return df.sort_values("date_ref").reset_index(drop=True)


def filtrer(df: pd.DataFrame, debut=None, fin=None, bookmakers=None, comptes=None, sports=None,
            types=None, partages=False) -> pd.DataFrame:
    """`partages` : seulement les paris marqués « partagés »."""
    if df.empty:
        return df
    masque = pd.Series(True, index=df.index)
    if debut is not None:
        masque &= df["date_ref"].dt.date >= debut
    if fin is not None:
        masque &= df["date_ref"].dt.date <= fin
    if bookmakers:
        masque &= df["bookmaker"].isin(bookmakers)
    if comptes:
        masque &= df["compte_id"].isin(comptes)
    if sports:
        masque &= df["sport"].isin(sports)
    if types:
        masque &= df["type"].isin(types)
    if partages:
        masque &= df["partage"].fillna(0).astype(int) == 1
    return df[masque]


# --------------------------------------------------------------------------- #
# Indicateurs
# --------------------------------------------------------------------------- #
def intervalle_roi(profits: np.ndarray, mises: np.ndarray, n: int = 2000, graine: int = 0) -> tuple[float, float]:
    """Intervalle de confiance à 95 % du ROI, par rééchantillonnage des paris (bootstrap)."""
    rng = np.random.default_rng(graine)
    idx = rng.integers(0, len(profits), size=(n, len(profits)))
    with np.errstate(divide="ignore", invalid="ignore"):  # un tirage fait que de freebets : rien de misé
        rois = profits[idx].sum(axis=1) / mises[idx].sum(axis=1)
    rois = rois[np.isfinite(rois)]
    if not len(rois):
        return float("nan"), float("nan")
    return float(np.percentile(rois, 2.5)), float(np.percentile(rois, 97.5))


def indicateurs(df: pd.DataFrame) -> dict:
    regles = df[df["regle"]] if not df.empty else df
    en_cours = df[df["etat"] == EN_COURS] if not df.empty else df
    res = {
        "n": len(regles),
        "mise": float(regles["mise"].sum()) if len(regles) else 0.0,
        "gains": float(regles["gains"].fillna(0).sum()) if len(regles) else 0.0,
        "n_en_cours": len(en_cours),
        "engage": float(en_cours["mise"].sum()) if len(en_cours) else 0.0,
        "n_annules": int((df["etat"] == ANNULE).sum()) if not df.empty else 0,
        "n_freebets": int(regles["freebet"].sum()) if len(regles) and "freebet" in regles else 0,
        "profit_freebets": float(regles.loc[regles["freebet"] == 1, "profit"].sum())
        if len(regles) and "freebet" in regles else 0.0,
    }
    res["profit"] = res["gains"] - res["mise"]
    res["roi"] = res["profit"] / res["mise"] if res["mise"] else None
    res["reussite"] = float((regles["etat"] == GAGNE).mean()) if len(regles) else None
    res["mise_moyenne"] = res["mise"] / res["n"] if res["n"] else None
    res["ic"] = (
        intervalle_roi(regles["profit"].to_numpy(), regles["mise"].to_numpy()) if res["n"] >= 20 else None
    )
    if len(regles):
        ordonnes = regles.sort_values("date_ref")
        cumul = ordonnes["profit"].cumsum()
        sommet = cumul.cummax().clip(lower=0)
        baisse = sommet - cumul
        res["drawdown"] = float(baisse.max())
        # Séries de paris gagnés et perdus d'affilée ; un pari remboursé ne coupe pas la série.
        gagnes_suite = perdus_suite = meilleure = pire = 0
        for etat in ordonnes["etat"]:
            if etat == GAGNE:
                gagnes_suite, perdus_suite = gagnes_suite + 1, 0
            elif etat == PERDU:
                gagnes_suite, perdus_suite = 0, perdus_suite + 1
            meilleure, pire = max(meilleure, gagnes_suite), max(pire, perdus_suite)
        res["pire_serie"], res["meilleure_serie"] = pire, meilleure
        gagnes, perdus = regles[regles["etat"] == GAGNE], regles[regles["etat"] == PERDU]
        res["gain_moyen"] = float(gagnes["profit"].mean()) if len(gagnes) else None
        res["perte_moyenne"] = float(-perdus["profit"].mean()) if len(perdus) else None
        jours = regles.groupby(regles["date_ref"].dt.normalize())["profit"].sum()
        res["jours_joues"] = len(jours)
        res["jours_gagnants"] = float((jours > 0).mean())
        res["meilleur_jour"] = {"date": jours.idxmax().date().isoformat(), "profit": float(jours.max())}
        res["pire_jour"] = {"date": jours.idxmin().date().isoformat(), "profit": float(jours.min())}
        res["meilleur_gain"] = float(regles["profit"].max())
        res["cote_moyenne_gagnee"] = float(regles["cote_gagnee"].mean()) if (regles["etat"] == GAGNE).any() else None
    else:
        for cle in ("drawdown", "pire_serie", "meilleur_gain", "cote_moyenne_gagnee", "meilleure_serie", "gain_moyen",
                    "perte_moyenne", "jours_joues", "jours_gagnants", "meilleur_jour", "pire_jour"):
            res[cle] = None
    return res


def lecture_ic(ic: tuple[float, float] | None) -> str:
    if ic is None:
        return "Moins de 20 paris réglés : trop peu pour juger si le résultat vient de la chance."
    bas, haut = ic
    if bas > 0:
        return "Même en tenant compte de la variance, ton ROI reste positif : ce n'est pas que de la chance."
    if haut < 0:
        return "Même en tenant compte de la variance, ton ROI reste négatif sur cette sélection."
    return "L'intervalle contient 0 : pas encore assez de paris pour distinguer un vrai avantage de la chance."


# --------------------------------------------------------------------------- #
# Tableaux par dimension
# --------------------------------------------------------------------------- #
def par(df: pd.DataFrame, colonne: str, min_paris: int = 1) -> pd.DataFrame:
    """Paris / Réussite / Misé / Profit / ROI / Cote moyenne des gagnants, par valeur de `colonne`."""
    regles = df[df["regle"]]
    colonnes = [colonne, "Paris", "Réussite", "Misé", "Profit", "ROI", "Cote moy. gagnée"]
    if regles.empty:
        return pd.DataFrame(columns=colonnes)
    g = regles.groupby(colonne, observed=True)
    t = pd.DataFrame(
        {
            "Paris": g.size(),
            "Réussite": g["etat"].apply(lambda s: (s == GAGNE).mean() * 100),
            "Misé": g["mise"].sum(),
            "Profit": g["profit"].sum(),
            "Cote moy. gagnée": g["cote_gagnee"].mean(),
        }
    )
    t["ROI"] = t["Profit"] / t["Misé"] * 100
    t = t[t["Paris"] >= min_paris]
    return t.reset_index()[colonnes]


def par_tranche(df: pd.DataFrame, colonne: str, tranches: tuple[list, list], nom: str) -> pd.DataFrame:
    d = df[df[colonne].notna()].copy()
    if d.empty:
        return pd.DataFrame(columns=[nom, "Paris", "Réussite", "Misé", "Profit", "ROI", "Cote moy. gagnée"])
    d[nom] = pd.cut(d[colonne], bins=tranches[0], labels=tranches[1], right=False)
    return par(d, nom)


def par_regroupe(df: pd.DataFrame, colonne: str, n: int = 12, libelle: str = "Autres") -> pd.DataFrame:
    """Comme `par`, mais seules les `n` valeurs les plus misées gardent leur ligne ; le reste est regroupé."""
    regles = df[df["regle"]]
    if regles.empty:
        return par(df, colonne)
    garder = regles.groupby(colonne)["mise"].sum().nlargest(n).index
    if len(garder) == regles[colonne].nunique():
        return par(df, colonne)
    d = df.assign(**{colonne: np.where(df[colonne].isin(garder), df[colonne], libelle)})
    return par(d, colonne)


def _lignes(t: pd.DataFrame, cle: str) -> list[dict]:
    return [
        {
            "cle": str(r[cle]),
            "paris": int(r["Paris"]),
            "reussite": _propre(r["Réussite"]),
            "mise": _propre(r["Misé"]),
            "profit": _propre(r["Profit"]),
            "roi": _propre(r["ROI"]),
            "cote": _propre(r["Cote moy. gagnée"]),
        }
        for _, r in t.iterrows()
    ]


# --------------------------------------------------------------------------- #
# Séries temporelles
# --------------------------------------------------------------------------- #
def courbe(df: pd.DataFrame) -> pd.DataFrame:
    """Profit cumulé dans le temps : une série « Total » + une par compte s'il y en a plusieurs."""
    d = df[df["regle"]].sort_values("date_ref")
    if d.empty:
        return pd.DataFrame(columns=["date", "Série", "Profit cumulé"])
    series = [pd.DataFrame({"date": d["date_ref"], "Série": "Total", "Profit cumulé": d["profit"].cumsum()})]
    if d["compte_libelle"].nunique() > 1:
        for nom, g in d.groupby("compte_libelle"):
            series.append(pd.DataFrame({"date": g["date_ref"], "Série": nom, "Profit cumulé": g["profit"].cumsum()}))
    return pd.concat(series, ignore_index=True)


def _points_courbe(d: pd.DataFrame) -> list[list]:
    """Un point par jour (dernier cumul du jour), précédé du point de départ à 0."""
    if d.empty:
        return []
    jour = d.assign(jour=d["date_ref"].dt.normalize()).groupby("jour")["profit"].sum().cumsum()
    depart = jour.index[0] - pd.Timedelta(days=1)
    return [[depart.date().isoformat(), 0.0]] + [[j.date().isoformat(), round(float(v), 2)] for j, v in jour.items()]


def _reperes(points: list[list]) -> dict:
    """Sommet de la courbe et pire baisse (du sommet précédent au creux)."""
    if len(points) < 2:
        return {}
    valeurs = np.array([p[1] for p in points])
    i_sommet = int(valeurs.argmax())
    pics = np.maximum.accumulate(valeurs)
    i_creux = int((pics - valeurs).argmax())
    i_pic = int(valeurs[: i_creux + 1].argmax())
    return {
        "sommet": {"date": points[i_sommet][0], "valeur": float(valeurs[i_sommet])},
        "baisse": {
            "debut": points[i_pic][0], "fin": points[i_creux][0],
            "de": float(valeurs[i_pic]), "a": float(valeurs[i_creux]),
            "montant": float(valeurs[i_pic] - valeurs[i_creux]),
        },
    }


def _resume_compte(g: pd.DataFrame) -> dict:
    """Ce qu'affiche la carte d'un compte : les mêmes calculs que `indicateurs`, sans le reste (intervalle de
    confiance, séries…), inutile ici et coûteux quand il y a beaucoup de comptes."""
    regles = g[g["regle"]]
    en_cours = g[g["etat"] == EN_COURS]
    mise = float(regles["mise"].sum())
    profit = float(regles["gains"].fillna(0).sum()) - mise
    return {"n": len(regles), "profit": profit, "roi": profit / mise if mise else None,
            "n_en_cours": len(en_cours), "engage": float(en_cours["mise"].sum())}


def _sparkline(g: pd.DataFrame, n: int = 30) -> list[float]:
    cumul = g[g["regle"]].sort_values("date_ref")["profit"].cumsum().to_numpy()
    if len(cumul) == 0:
        return []
    cumul = np.concatenate([[0.0], cumul])
    idx = np.linspace(0, len(cumul) - 1, min(n, len(cumul))).round().astype(int)
    return [round(float(cumul[i]), 2) for i in idx]


def records(df: pd.DataFrame, n: int = 5) -> tuple[pd.DataFrame, pd.DataFrame]:
    d = df[df["regle"]]
    colonnes = ["date_ref", "bookmaker", "reference", "bookmaker_libelle", "compte_nom", "sport", "resume", "mise", "gains",
                "profit", "mise_jouee", "freebet"]
    return d.nlargest(n, "profit")[colonnes], d.nsmallest(n, "profit")[colonnes]


def forme(df: pd.DataFrame, jours: int = 30) -> dict | None:
    """Les `jours` derniers jours de la sélection (jusqu'au dernier pari réglé), comparés à l'ensemble."""
    regles = df[df["regle"]]
    if regles.empty:
        return None
    fin = regles["date_ref"].max().normalize()
    recents = regles[regles["date_ref"] >= fin - pd.Timedelta(days=jours - 1)]
    mise = float(recents["mise"].sum())
    profit = float(recents["profit"].sum())
    return {"jours": jours, "n": len(recents), "mise": mise, "profit": profit, "roi": profit / mise if mise else None}


def calendrier(df: pd.DataFrame) -> list[list]:
    """Profit et nombre de paris réglés, jour par jour : [[date, profit, n], …]."""
    regles = df[df["regle"]]
    if regles.empty:
        return []
    g = regles.groupby(regles["date_ref"].dt.normalize())["profit"].agg(["sum", "size"])
    return [[j.date().isoformat(), round(float(r["sum"]), 2), int(r["size"])] for j, r in g.iterrows()]


# --------------------------------------------------------------------------- #
# Charge utile complète du tableau de bord
# --------------------------------------------------------------------------- #
def tableau(df_complet: pd.DataFrame, liste_comptes: list[dict], **filtres) -> dict:
    d = filtrer(df_complet, **filtres)
    k = indicateurs(d)
    regles = d[d["regle"]]

    total = _points_courbe(regles)
    # Un seul découpage par compte (et non un filtre par compte) : la page reste rapide avec beaucoup de comptes.
    regles_par_compte = {cid: g for cid, g in regles.groupby("compte_id")}
    paris_par_compte = {cid: g for cid, g in d.groupby("compte_id")}
    series_comptes = []
    for c in liste_comptes:
        g = regles_par_compte.get(c["id"])
        if g is not None and not g.empty:
            series_comptes.append({"id": c["id"], "nom": c["nom"], "bookmaker": c["bookmaker"],
                                   "couleur": c["couleur"], "points": _points_courbe(g)})

    cartes = []
    for c in liste_comptes:
        g = paris_par_compte.get(c["id"])
        kc = _resume_compte(g) if g is not None and not g.empty else None
        cartes.append({
            "id": c["id"], "nom": c["nom"], "bookmaker": c["bookmaker"], "couleur": c["couleur"],
            "n": kc["n"] if kc else 0, "profit": kc["profit"] if kc else 0.0,
            "roi": _propre(kc["roi"]) if kc else None, "en_cours": kc["n_en_cours"] if kc else 0,
            "engage": kc["engage"] if kc else 0.0, "sparkline": _sparkline(g) if kc else [],
        })

    meilleurs, pires = records(d) if not d.empty else (pd.DataFrame(), pd.DataFrame())

    def recs(t: pd.DataFrame) -> list[dict]:
        return [{k2: _propre(v) for k2, v in r.items()} for r in t.to_dict("records")]

    gagnes = d[d["etat"] == GAGNE].copy()
    if not gagnes.empty:
        gagnes["tranche"] = pd.cut(gagnes["cote_gagnee"], bins=TRANCHES_COTE[0], labels=TRANCHES_COTE[1], right=False)
        cotes = [{"cle": str(k3), "paris": len(g), "profit": _propre(g["profit"].sum())}
                 for k3, g in gagnes.groupby("tranche", observed=False)]
    else:
        cotes = []

    avec_cote = d[d["cote"].notna()] if "cote" in d else d.iloc[0:0]
    par_cote = _lignes(par_tranche(avec_cote, "cote", TRANCHES_COTE, "Cote"), "Cote") if not avec_cote.empty else []

    evenements = par(d[d["evenement"].fillna("") != ""], "evenement", min_paris=2)
    evenements = evenements.sort_values("Misé", ascending=False).head(30)

    f30 = forme(d)
    familles = _lignes(par(d, "famille"), "famille")
    sports_famille = {}
    for l in _lignes(par(d, "sport"), "sport"):
        sports_famille.setdefault(famille(l["cle"]), []).append(l["cle"])
    for l in familles:
        l["sports"] = sports_famille.get(l["cle"], [])

    return {
        "forme": {c: _propre(v) for c, v in f30.items()} if f30 else None,
        "calendrier": calendrier(d),
        "par_famille": familles,
        "par_bookmaker": _lignes(par(d, "bookmaker_libelle"), "bookmaker_libelle"),
        "par_type_pari": _lignes(par(d, "type_libelle"), "type_libelle"),
        "par_boost": _lignes(par(d, "boost_libelle"), "boost_libelle"),
        "par_jour": _lignes(par(d, "jour_semaine"), "jour_semaine"),
        "par_heure": _lignes(par_tranche(d, "heure", TRANCHES_HEURE, "Heure"), "Heure"),
        "indicateurs": {**{c: _propre(v) for c, v in k.items() if c not in ("ic", "meilleur_jour", "pire_jour")},
                        "meilleur_jour": _jour(k["meilleur_jour"]), "pire_jour": _jour(k["pire_jour"]),
                        "ic": [_propre(x) for x in k["ic"]] if k["ic"] else None,
                        "lecture_ic": lecture_ic(k["ic"])},
        "courbe": {"total": total, "comptes": series_comptes, "reperes": _reperes(total)},
        "comptes": cartes,
        "par_sport": _lignes(par(d, "sport"), "sport"),
        "par_type": _lignes(par_regroupe(d, "categorie_marche", 14, "Autres marchés"), "categorie_marche"),
        "par_evenement": _lignes(evenements, "evenement"),
        "par_mois": _lignes(par(d, "mois"), "mois"),
        # Par mise jouée : un freebet de 20 € est rangé avec les mises de 20 €, même s'il n'a rien coûté.
        "par_mise": _lignes(par_tranche(d, "mise_jouee" if "mise_jouee" in d else "mise", TRANCHES_MISE, "Mise"), "Mise"),
        "par_anticipation": _lignes(
            par_tranche(d, "anticipation_h", TRANCHES_ANTICIPATION, "Anticipation"), "Anticipation"),
        "par_cote_gagnes": cotes,
        "par_cote": par_cote,
        "records": {"meilleurs": recs(meilleurs), "pires": recs(pires)},
        "n_filtres": len(d),
    }


def _jour(j: dict | None) -> dict | None:
    return {"date": j["date"], "profit": _propre(j["profit"])} if j else None


def familles_presentes(sports: list[str]) -> list[dict]:
    """Les familles qui ont au moins un sport parmi `sports` (rangés du plus joué au moins joué), dans l'ordre de
    FAMILLES ; « Autres sports » en dernier."""
    ordre = [nom for nom, _ in FAMILLES] + [AUTRES_SPORTS]
    groupes: dict[str, list[str]] = {}
    for s in sports:
        groupes.setdefault(famille(s), []).append(s)
    return [{"nom": nom, "sports": groupes[nom]} for nom in ordre if nom in groupes]


def options_filtres(df: pd.DataFrame) -> dict:
    if df.empty:
        return {"debut": None, "fin": None, "sports": [], "familles": [], "types": []}
    sports = df["sport"].value_counts().index.tolist()
    return {
        "debut": df["date_ref"].min().date().isoformat(),
        # Jusqu'au dernier pari pris (un pari en cours peut porter sur un événement de l'an prochain).
        "fin": max(df["date_pari"].max(), df.loc[df["regle"], "date_ref"].max() if df["regle"].any() else df["date_pari"].max())
        .date().isoformat(),
        "sports": sports,
        "familles": familles_presentes(sports),
        "types": [{"cle": t, "libelle": LIBELLES_TYPES.get(t, t)} for t in df["type"].value_counts().index],
        # Paris par semaine, sur tout l'historique : le relief du curseur de dates.
        "activite": [[d.date().isoformat(), int(n)] for d, n in
                     df.groupby(df["date_ref"].dt.to_period("W").dt.start_time).size().items()],
    }
