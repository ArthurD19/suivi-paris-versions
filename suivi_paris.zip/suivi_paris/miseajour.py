"""Mise à jour de l'appli depuis les versions publiées sur GitHub (bouton « Mettre à jour » de Mes données).

- `derniere_version()` interroge GitHub (seulement quand on le demande : l'appli ne se connecte nulle part d'elle-même) ;
- `installer(zip)` remplace le code de l'appli par celui de la nouvelle version. Les données (la base de paris,
  les sauvegardes) sont rangées ailleurs (`chemins.dossier_donnees()`) et ne sont jamais touchées. En cas d'échec
  en cours de route, l'ancien code est remis en place.

Une copie de développement (dossier `.git`) ne se met pas à jour ainsi : `git pull`.
"""
from __future__ import annotations

import io
import json
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

from .chemins import RACINE_PROJET
from .version import DEPOT_VERSIONS, VERSION

# Ce qu'une version remplace : ces dossiers en entier (les fichiers disparus de la nouvelle version sont retirés),
# et ces fichiers. Rien d'autre n'est touché (.venv, données, fichiers ajoutés par l'utilisateur).
DOSSIERS = ("suivi_paris", "extension", "assets")
FICHIERS = ("pyproject.toml", "uv.lock", ".python-version", "README.md", "LICENSE", "CONFIDENTIALITE.md",
            "Installer Suivi Paris.cmd", "Installer Suivi Paris (Mac).command", "installer-suivi-paris.sh")
EXECUTABLES = (".command", ".sh")
DELAI = 15


class ErreurMiseAJour(Exception):
    pass


def numero(version: str) -> tuple[int, ...]:
    """« v1.10.2 » -> (1, 10, 2) : pour comparer des versions (1.10 vient après 1.9)."""
    parties = []
    for morceau in version.strip().lstrip("vV").split("."):
        chiffres = "".join(c for c in morceau if c.isdigit())
        parties.append(int(chiffres) if chiffres else 0)
    return tuple(parties)


def est_plus_recente(version: str, actuelle: str = VERSION) -> bool:
    return numero(version) > numero(actuelle)


def copie_de_developpement(racine: Path = RACINE_PROJET) -> bool:
    return (racine / ".git").exists()


def _lire_json(url: str) -> dict:
    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json", "User-Agent": "SuiviParis"})
    with urllib.request.urlopen(req, timeout=DELAI) as r:
        return json.loads(r.read())


def lire_publication(publication: dict) -> dict:
    """D'une « release » GitHub : version, notes, page, et l'adresse du ZIP de l'appli (pas celui de l'extension)."""
    zips = [a for a in publication.get("assets", []) if a.get("name", "").endswith(".zip")
            and "extension" not in a["name"]]
    return {
        "version": publication.get("tag_name", "").lstrip("vV"),
        "notes": publication.get("body") or "",
        "page": publication.get("html_url", ""),
        "zip": zips[0]["browser_download_url"] if zips else None,
    }


def derniere_version(depot: str = DEPOT_VERSIONS) -> dict:
    """La dernière version publiée, et si elle est plus récente que celle-ci."""
    try:
        publication = lire_publication(_lire_json(f"https://api.github.com/repos/{depot}/releases/latest"))
    except (OSError, ValueError) as exc:  # hors connexion (URLError est un OSError), dépôt introuvable, réponse illisible
        raise ErreurMiseAJour(f"Impossible de joindre GitHub ({exc}). Vérifie ta connexion à Internet.") from None
    return {**publication, "actuelle": VERSION, "disponible": est_plus_recente(publication["version"]),
            "developpement": copie_de_developpement()}


def telecharger(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "SuiviParis"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.read()


def _racine_archive(archive: zipfile.ZipFile) -> str:
    """Le dossier de l'appli dans le ZIP (« Suivi Paris/ »), repéré à son paquet suivi_paris/."""
    for nom in archive.namelist():
        if nom.endswith("suivi_paris/version.py"):
            return nom[: -len("suivi_paris/version.py")]
    raise ErreurMiseAJour("Ce fichier n'est pas une version de Suivi Paris.")


def installer(contenu_zip: bytes, racine: Path = RACINE_PROJET, synchroniser=None) -> dict:
    """Remplace le code de l'appli par celui du ZIP. Renvoie {version, dependances} ; `dependances` dit si les
    bibliothèques ont dû être mises à jour (uv sync)."""
    if copie_de_developpement(racine):
        raise ErreurMiseAJour("Copie de développement (dossier .git) : mets-la à jour avec git pull.")
    try:
        archive = zipfile.ZipFile(io.BytesIO(contenu_zip))
    except zipfile.BadZipFile:
        raise ErreurMiseAJour("Le téléchargement est abîmé : réessaie.") from None
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        prefixe = _racine_archive(archive)
        for info in archive.infolist():
            if not info.filename.startswith(prefixe) or info.is_dir():
                continue
            relatif = Path(info.filename[len(prefixe):])
            if relatif.is_absolute() or ".." in relatif.parts:
                raise ErreurMiseAJour("Archive invalide.")
            cible = tmp / "nouvelle" / relatif
            cible.parent.mkdir(parents=True, exist_ok=True)
            cible.write_bytes(archive.read(info))
        nouvelle = tmp / "nouvelle"
        version = _version_de(nouvelle)
        ancien_lock = (racine / "uv.lock").read_bytes() if (racine / "uv.lock").exists() else b""

        # Mise de côté de l'ancien code, pour le remettre si quelque chose échoue.
        cote = tmp / "ancienne"
        cote.mkdir()
        deplaces = []
        try:
            for nom in DOSSIERS + FICHIERS:
                if (racine / nom).exists() and (nouvelle / nom).exists():
                    shutil.move(str(racine / nom), str(cote / nom))
                    deplaces.append(nom)
            for nom in DOSSIERS + FICHIERS:
                if (nouvelle / nom).is_dir():
                    shutil.copytree(nouvelle / nom, racine / nom)
                elif (nouvelle / nom).exists():
                    shutil.copy2(nouvelle / nom, racine / nom)
            for f in racine.iterdir():
                if f.suffix in EXECUTABLES:
                    f.chmod(0o755)
        except OSError as exc:
            for nom in deplaces:
                if (racine / nom).is_dir():
                    shutil.rmtree(racine / nom)
                elif (racine / nom).exists():
                    (racine / nom).unlink()
                shutil.move(str(cote / nom), str(racine / nom))
            raise ErreurMiseAJour(f"Mise à jour interrompue, l'ancienne version est remise en place ({exc}).") from None

    dependances = (racine / "uv.lock").read_bytes() != ancien_lock
    if dependances:
        (synchroniser or synchroniser_dependances)(racine)
    return {"version": version, "dependances": dependances}


def _version_de(dossier: Path) -> str:
    texte = (dossier / "suivi_paris" / "version.py").read_text(encoding="utf-8")
    for ligne in texte.splitlines():
        if ligne.startswith("VERSION"):
            return ligne.split("=", 1)[1].strip().strip("\"'")
    return "?"


def _uv() -> str | None:
    trouve = shutil.which("uv")
    if trouve:
        return trouve
    for candidat in (Path.home() / ".local" / "bin" / ("uv.exe" if sys.platform == "win32" else "uv"),
                     Path.home() / ".cargo" / "bin" / "uv"):
        if candidat.exists():
            return str(candidat)
    return None


def synchroniser_dependances(racine: Path = RACINE_PROJET) -> None:
    """Les bibliothèques de la nouvelle version (uniquement si elles ont changé)."""
    uv = _uv()
    if uv is None:
        raise ErreurMiseAJour("Nouvelles bibliothèques à installer : ferme Suivi Paris et relance l'installateur.")
    r = subprocess.run([uv, "sync", "--no-dev"], cwd=racine, capture_output=True, text=True, check=False)
    if r.returncode != 0:
        raise ErreurMiseAJour("Le code est à jour, mais les bibliothèques n'ont pas pu l'être pendant que l'appli "
                              "tourne : ferme Suivi Paris et relance l'installateur pour finir.")
