"""Format pivot : ce que chaque adaptateur de bookmaker doit produire.

Le reste de l'application (stockage, analyse, interface) ne connaît que ces classes,
jamais le format d'un bookmaker en particulier.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from datetime import date, datetime

# États normalisés
GAGNE, PERDU, EN_COURS, ANNULE, CASHOUT, INCONNU = "gagne", "perdu", "en_cours", "annule", "cashout", "inconnu"

# États qui comptent dans le ROI. Un pari annulé ou remboursé (mise rendue) n'en fait pas partie :
# l'inclure gonflerait le volume misé sans rien dire de la qualité des paris.
ETATS_REGLES = {GAGNE, PERDU, CASHOUT}

LIBELLES_ETATS = {
    GAGNE: "Gagné",
    PERDU: "Perdu",
    EN_COURS: "En cours",
    ANNULE: "Annulé / remboursé",
    CASHOUT: "Cash-out",
    INCONNU: "Inconnu",
}

# Types de paris normalisés
SIMPLE, COMBINE, MYCOMBI, SYSTEME = "simple", "combine", "mycombi", "systeme"

LIBELLES_TYPES = {SIMPLE: "Simple", COMBINE: "Combiné", MYCOMBI: "Combiné même match", SYSTEME: "Système"}


@dataclass
class Selection:
    """Une sélection d'un pari (un pari simple en a une, un combiné plusieurs)."""

    sport: str
    evenement: str  # ex. « Tour de Lombardie 2026 », « Perth Wildcats / NZ Breakers »
    marche: str  # ex. « Top 10 », « Face-à-face - A. Renard v. A. Romele »
    choix: str  # ex. « Pello Bilbao », « + de 9,5 »
    competition: str = ""
    etape: int | None = None
    cote: float | None = None  # cote de la sélection, quand le bookmaker l'affiche (Unibet)

    @property
    def categorie_marche(self) -> str:
        return categorie_marche(self.marche, self.choix)


@dataclass
class Pari:
    bookmaker: str
    reference: str  # identifiant du pari chez le bookmaker : la clé anti-doublon
    date_pari: datetime
    type: str  # simple / combine / mycombi / systeme
    etat: str
    etat_brut: str  # l'état tel qu'affiché par le bookmaker
    mise: float
    gains: float | None  # None tant que le pari n'est pas réglé
    cote_boostee: bool = False
    nb_selections: int = 1
    # Date de l'événement : avec l'heure (Betclic), ou seulement le jour (`date` : Winamax, ps3838).
    date_evenement: datetime | date | None = None
    selections: list[Selection] = field(default_factory=list)
    cote: float | None = None  # cote totale affichée par le bookmaker (Unibet) ; sinon inconnue
    # Lu sur une page moins détaillée qu'une autre du même bookmaker (Winamax « Mes paris » face à l'historique de
    # compte, qui donne le sport et les sélections des combinés) : cette lecture met à jour le résultat d'un pari
    # déjà connu, jamais son détail.
    detail_partiel: bool = False
    # Le bookmaker n'affiche pas le sport : il a été deviné (sports.py). Un nom (coureur, joueur, équipe) déjà vu
    # avec un sport sûr dans la base le corrige à l'enregistrement.
    sport_devine: bool = False
    # Joué avec une mise offerte (freebet Betclic, crédit de jeu NetBet) : il ne coûte rien s'il perd, et ses gains
    # ne rendent pas la mise (18,75 € offerts à 13 rapportent 225 €, pas 243,75 €).
    freebet: bool = False

    @property
    def sport(self) -> str:
        sports = {s.sport for s in self.selections if s.sport}
        if len(sports) == 1:
            return sports.pop()
        return "Multi-sports" if sports else "Inconnu"

    @property
    def regle(self) -> bool:
        return self.etat in ETATS_REGLES

    @property
    def profit(self) -> float | None:
        if self.etat == ANNULE:
            return 0.0
        if not self.regle:
            return None
        return round((self.gains or 0.0) - (0.0 if self.freebet else self.mise), 2)

    @property
    def cote_effective(self) -> float | None:
        """Cote déduite des gains. Les historiques ne donnent pas les cotes : seulement calculable si gagné."""
        if self.etat == GAGNE and self.gains and self.mise:
            return round(self.gains / self.mise + (1 if self.freebet else 0), 2)
        return None

    @property
    def resume(self) -> str:
        if self.type == COMBINE:
            # Nombre de sélections inconnu (combiné Sportaza lu fermé) : « Combiné », sans chiffre inventé.
            return f"Combiné de {self.nb_selections} sélections" if self.nb_selections > 1 else "Combiné"
        if not self.selections:
            return "?"
        s = self.selections[0]
        if self.type == MYCOMBI:
            return f"{s.evenement} — combiné même match ({len(self.selections)} sélections)"
        texte = f"{s.marche} : {s.choix}"
        return f"{texte} — {s.evenement}" if s.evenement else texte


# Dépôts et retraits d'argent sur un compte
DEPOT, RETRAIT = "depot", "retrait"
LIBELLES_SENS = {DEPOT: "Dépôt", RETRAIT: "Retrait"}


@dataclass
class Mouvement:
    """Un dépôt ou un retrait, tel que listé par le bookmaker. Quand la page ne dit pas s'il s'agit d'un dépôt ou
    d'un retrait (Betclic), le sens est donné à l'enregistrement."""

    date: datetime
    montant: float
    statut: str  # tel qu'affiché : « Validé », « Refusé »…
    moyen: str = ""  # « Carte bancaire », « Paypal »… quand la page l'affiche
    sens: str = ""  # « depot » ou « retrait » quand la page le dit (PMU) ; sinon choisi à l'enregistrement

    @property
    def valide(self) -> bool:
        return sans_accents(self.statut).lower().startswith(("valid", "effectu", "accept", "termin", "complet", "approv",
                                                                  "success"))


# --------------------------------------------------------------------------- #
# Outils partagés par les adaptateurs
# --------------------------------------------------------------------------- #
def sans_accents(texte: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", texte) if unicodedata.category(c) != "Mn")


def montant(texte: str | None) -> float | None:
    """« 1 234,50 € » -> 1234.5"""
    if texte is None:
        return None
    propre = re.sub(r"[\s  €]", "", texte).replace(",", ".")
    if not propre:
        return None
    return float(propre)


def normaliser_etat(brut: str) -> str:
    e = sans_accents(brut).lower().strip()
    if "cash" in e:
        return CASHOUT
    if e.startswith("gagn"):
        return GAGNE
    if e.startswith("perdu"):
        return PERDU
    if "cours" in e or "attente" in e:
        return EN_COURS
    if e.startswith(("rembours", "annul")):
        return ANNULE
    return INCONNU


# « + de 9,5 », « Moins de 2,5 », « Over 2.5 », « U 45.5 » : un total au-dessus ou en dessous d'une ligne.
_PLUS_MOINS_CHOIX = re.compile(r"^(\+|-|−|plus|moins|over|under|o|u)\s*(de\s*)?\d+(?:[.,]\d+)?\b", re.IGNORECASE)
_PLUS_MOINS_MARCHE = re.compile(r"\b(plus\s*/\s*moins|over\s*/\s*under|\+/-|nombre total|total)\b|^(over|under)\b")
# « Rybakina -6 j », « PSG (-1,5) », « Lakers +4.5 » : un nom, puis un écart signé (jeux, sets, points, buts).
_HANDICAP_CHOIX = re.compile(r"^(?![+\-−]).*[^\W\d_.)](?:\s+|\s*\(\s*)[+\-−]\s*\d+(?:[.,]\d+)?\s*"
                             r"(j|jeux?|sets?|pts?|points?|buts?|g)?\s*\)?$", re.IGNORECASE)


def categorie_marche(marche: str, choix: str = "") -> str:
    """Regroupe les libellés de marché des différents bookmakers en catégories comparables.

    « Vainqueur de l'étape », « Vainqueur de la Course », « Vainqueur » -> « Vainqueur » ;
    « Face-à-face - A v. B », « Face à face - A - B » -> « Face-à-face » ; etc.
    Les marchés non reconnus gardent leur libellé (sans les noms de joueurs).
    """
    m = sans_accents(marche).lower().strip()
    if not m:
        return "Inconnu"
    # « CB », « CB FLASH » : cotes boostées d'Unibet.
    if "boost" in m or m.startswith("flash bet") or re.match(r"cb\b", m):
        return "Cote boostée"
    c = sans_accents(choix or "").strip()
    if "handicap" in m or "ecart" in m or "spread" in m or (c and _HANDICAP_CHOIX.match(c)):
        return "Handicap"
    if _PLUS_MOINS_MARCHE.search(m) or (c and _PLUS_MOINS_CHOIX.match(c)):
        return "Plus / Moins"
    if m.startswith("double chance"):
        return "Double chance"
    if m.startswith(("face a face", "face-a-face", "duel")):  # « Duel », « Duel de pilotes » (PMU)
        return "Face-à-face"
    top = re.match(r"top (\d+)", m)
    if top:
        return f"Top {top.group(1)}"
    if m.startswith("podium"):
        return "Podium"
    if m.startswith("vainqueur"):
        return "Vainqueur"
    if m.startswith(("classement", "maillot")):
        return "Classements annexes"
    if "buteur" in m:
        return "Buteur"
    morceaux = [x.strip() for x in marche.split(" - ") if x.strip()]
    if len(morceaux) >= 2 and _ressemble_a_un_nom(morceaux[0]) and not _ressemble_a_un_nom(morceaux[1]):
        # « Elise Mertens - Stade de l'élimination » : le joueur d'abord, le marché ensuite.
        return categorie_marche(" - ".join(morceaux[1:]), choix)
    return morceaux[0] if morceaux else marche.strip()


def _ressemble_a_un_nom(texte: str) -> bool:
    """« Elise Mertens », « J. Pegula » : 2 à 4 mots qui commencent tous par une majuscule, sans chiffre."""
    mots = texte.split()
    particules = {"de", "da", "di", "van", "von", "der", "le", "la", "del", "du"}
    return (
        2 <= len(mots) <= 4
        and not any(c.isdigit() for c in texte)
        and all(m[0].isupper() or m in particules for m in mots)
        and mots[0][0].isupper()
    )
